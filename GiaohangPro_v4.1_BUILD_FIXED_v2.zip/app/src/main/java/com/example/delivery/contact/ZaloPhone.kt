package com.example.delivery.contact

/** Chuẩn hóa số Việt Nam để Zalo nhận diện liên hệ theo đầu số quốc tế 84. */
fun zaloPhoneNumber(rawPhone: String): String? {
    val digits = rawPhone.filter(Char::isDigit)
    val international = when {
        digits.startsWith("0084") -> digits.removePrefix("00")
        digits.startsWith("84") -> digits
        digits.startsWith("0") -> "84${digits.drop(1)}"
        else -> digits
    }
    return international.takeIf { it.startsWith("84") && it.length in 11..12 }
}

/** Số dạng E.164 mà Android Danh bạ truyền cho các ứng dụng nhắn tin. */
fun zaloContactPhone(rawPhone: String): String? = zaloPhoneNumber(rawPhone)?.let { "+$it" }
