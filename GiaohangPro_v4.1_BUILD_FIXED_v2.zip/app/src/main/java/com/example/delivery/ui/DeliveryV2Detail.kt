package com.example.delivery.ui

import androidx.compose.runtime.Composable
import com.example.delivery.model.DeliveryOrder

/** GROUP: DETAIL - Màn hình chi tiết đơn và các callback nghiệp vụ liên quan. */
@Composable
internal fun DeliveryV2Detail(
    state: DeliveryV2State,
    orders: List<DeliveryOrder>,
    onCall: (DeliveryOrder) -> Unit,
    onZalo: (DeliveryOrder, String) -> Unit,
    onSms: (DeliveryOrder, String) -> Unit,
    transferMessage: (DeliveryOrder) -> String,
    onDelivered: (DeliveryOrder) -> Unit,
) {
    OrderDetailScreen(
        orders = orders,
        searchQuery = state.detailSearchQuery,
        onSearchChange = { state.detailSearchQuery = it },
        selectedWaybill = state.selectedWaybill,
        scrollToTopRequest = state.detailScrollTopRequest,
        onSelectOrder = { order -> state.selectedWaybill = order.waybill; state.selectedNavigationOrder = order },
        onOpenScanner = { state.scannerOpen = true },
        onDelivered = onDelivered,
        onCall = onCall,
        onZalo = { onZalo(it, transferMessage(it)) },
        onSms = { onSms(it, transferMessage(it)) },
        onOpenCustomer = { order -> state.selectedWaybill = order.waybill; state.focusPhone = order.phone; state.tab = DeliveryTab.CUSTOMERS },
        onNavigateOrder = { order -> state.selectedWaybill = order.waybill; state.selectedNavigationOrder = order; state.tab = DeliveryTab.MAP },
    )
}
