package com.example.delivery.ui

import androidx.compose.runtime.Composable
import com.example.delivery.model.DeliveryOrder
import com.example.delivery.ui.logic.nextOrderAfterCompletion

/** GROUP: DIALOG - Chỉ chứa dialog xác nhận hoàn tất đơn. */
@Composable
internal fun DeliveryV2Dialog(
    state: DeliveryV2State,
    orders: List<DeliveryOrder>,
    onDirectDelivered: (DeliveryOrder) -> Unit,
) {
    state.completingOrder?.let { order ->
        DeliveryCompletionDialog(
            order = order,
            onDismiss = { state.completingOrder = null },
            onConfirm = {
                val nextOrder = nextOrderAfterCompletion(orders, order)
                onDirectDelivered(order)
                state.completingOrder = null
                state.detailSearchQuery = ""
                state.selectedWaybill = nextOrder?.waybill
                state.selectedNavigationOrder = nextOrder
            },
        )
    }
}
