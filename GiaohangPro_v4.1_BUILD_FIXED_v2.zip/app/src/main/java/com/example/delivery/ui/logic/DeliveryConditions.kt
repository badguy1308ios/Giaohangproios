package com.example.delivery.ui.logic

import com.example.delivery.model.DeliveryOrder
import com.example.delivery.model.hasStoredCoordinates
import com.example.delivery.model.isRouteActive
import com.example.delivery.model.sequenceSortValue
import com.example.delivery.model.sequenceText
import com.example.delivery.navigation.GeoPoint
import com.example.delivery.navigation.preferredRouteOrigin
import com.example.delivery.navigation.routeOrdersFrom

/** GROUP: DELIVERY CONDITIONS / ROUTE LOGIC.
 * Sửa các luật điều kiện/tính tuyến tại đây thay vì nhúng vào UI. */

internal fun findRouteOrigin(orders: List<DeliveryOrder>, currentGps: GeoPoint?): GeoPoint? {
    val fallback = orders
        .filter { it.isRouteActive() && it.hasStoredCoordinates() }
        .minByOrNull { if (it.sequence > 0) it.sequence else Int.MAX_VALUE }
        ?.let { GeoPoint(it.latitude, it.longitude) }
    return preferredRouteOrigin(null, currentGps, fallback)
}

internal fun buildRouteSequence(orders: List<DeliveryOrder>, origin: GeoPoint): Map<String, String> =
    routeOrdersFrom(origin, orders.filter(DeliveryOrder::hasStoredCoordinates))
        .associate { it.waybill to it.sequenceText() }

internal fun nextOrderAfterCompletion(orders: List<DeliveryOrder>, completed: DeliveryOrder): DeliveryOrder? {
    val completedSequence = completed.sequenceSortValue()
    val candidates = orders
        .asSequence()
        .filter { it.waybill != completed.waybill && it.isRouteActive() }
        .sortedWith(compareBy<DeliveryOrder> { it.sequenceSortValue() }.thenBy { it.waybill })
        .toList()
    return candidates.firstOrNull { it.sequenceSortValue() > completedSequence } ?: candidates.firstOrNull()
}

internal fun isValidRouteSequenceText(value: String): Boolean {
    val normalized = value.trim()
    if (normalized.isBlank()) return false
    val parts = normalized.split('.', limit = 2)
    val baseValid = parts[0].toIntOrNull()?.let { it > 0 } == true
    val suffixValid = parts.size == 1 || parts[1].equals("n", true) || parts[1].toIntOrNull()?.let { it > 0 } == true
    return baseValid && suffixValid
}
