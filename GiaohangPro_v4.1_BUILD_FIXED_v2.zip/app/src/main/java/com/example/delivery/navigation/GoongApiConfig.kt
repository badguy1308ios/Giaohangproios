package com.example.delivery.navigation

import com.example.delivery.BuildConfig

/**
 * GOONG API CONFIGURATION — đặt ở đầu package navigation để dễ tìm và kiểm tra.
 *
 * API #1: Map Tiles/Style: tiles.goong.io (MapLibre dùng style JSON + các tile/font/sprite resource).
 * API #2: Directions REST: rsapi.goong.io/Direction (tính tuyến đường giữa hai điểm).
 *
 * API key thật không đặt trong source. Gradle lấy từ local.properties:
 * GOONG_MAP_TILES_KEY và GOONG_REST_API_KEY.
 */
internal object GoongApiConfig {
    /** GOONG Map Tiles key được Gradle đưa vào BuildConfig từ local.properties. */
    val mapTilesKey: String
        get() = BuildConfig.GOONG_MAP_TILES_KEY

    /** GOONG REST Directions key được Gradle đưa vào BuildConfig từ local.properties. */
    val restApiKey: String
        get() = BuildConfig.GOONG_REST_API_KEY

    /** Endpoint REST dùng để gọi API Directions. */
    const val directionsEndpoint = "https://rsapi.goong.io/Direction"

    /** Base domain của hệ thống Map Tiles GOONG, dùng để kiểm tra/cấu hình style. */
    const val mapTilesEndpoint = "https://tiles.goong.io/"
}
