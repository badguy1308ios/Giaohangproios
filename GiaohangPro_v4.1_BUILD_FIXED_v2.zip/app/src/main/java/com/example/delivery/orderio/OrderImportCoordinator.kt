package com.example.delivery.orderio

import com.example.delivery.customer.CustomerProfile
import com.example.delivery.customer.customerPhoneKey
import com.example.delivery.model.DeliveryStatus
import com.example.delivery.model.DeliveryOrder
import com.example.delivery.model.isPickupAtWarehouse
import com.example.delivery.model.isTemporaryFailure
import com.example.delivery.model.normalizedCoordinates
import java.util.Locale

data class OrderMergeResult(
    val orders: List<DeliveryOrder>,
    val addedOrders: List<DeliveryOrder>,
    val ignoredDuplicateCount: Int,
    val restoredProductCount: Int = 0,
    val reactivatedCount: Int = 0,
    val removedNotInLatestImportCount: Int = 0,
)

/** Ghép đơn từ file vào danh sách hiện có mà không bao giờ thay thế dữ liệu của MVĐ đã lưu. */
object OrderImportCoordinator {
    /**
     * Nạp một danh sách MVĐ mới cho ca hiện tại. Chỉ các MVĐ có trong file được giữ trên
     * Chi tiết/Bản đồ; khách hàng và lịch sử không thuộc danh sách orders nên không bị xóa.
     */
    fun replaceWithImportedBatch(
        existingOrders: List<DeliveryOrder>,
        importedOrders: List<DeliveryOrder>,
        customerProfiles: List<CustomerProfile> = emptyList(),
    ): OrderMergeResult {
        val existingByWaybill = existingOrders.associateBy { it.waybillKey() }
        val accepted = mutableListOf<DeliveryOrder>()
        val added = mutableListOf<DeliveryOrder>()
        val temporaryIndexes = mutableListOf<Int>()
        val importedKeys = mutableSetOf<String>()
        var duplicates = 0
        var restoredProducts = 0

        importedOrders.forEach { imported ->
            val waybillKey = imported.waybillKey()
            if (!importedKeys.add(waybillKey)) return@forEach
            val saved = existingByWaybill[waybillKey]
            if (saved == null) {
                val newOrder = imported.withCustomerAddress(customerProfiles).normalizedCoordinates()
                accepted += newOrder
                added += newOrder
            } else {
                duplicates++
                val preserved = if (saved.product.isBlank() && imported.product.isNotBlank()) {
                    restoredProducts++
                    saved.copy(product = imported.product.trim())
                } else {
                    saved
                }
                accepted += preserved
                if (preserved.isTemporaryFailure() || preserved.isPickupAtWarehouse()) temporaryIndexes += accepted.lastIndex
            }
        }

        // Nhập đơn không tự đánh STT. Kể cả đơn có tọa độ hoặc được kích hoạt lại,
        // người dùng phải chủ động tạo/cập nhật tuyến mới để app sinh STT.
        temporaryIndexes.forEach { index ->
            val order = accepted[index]
            accepted[index] = order.copy(
                status = DeliveryStatus.TT500,
                sequence = 0,
                sequenceLabel = null,
                requiresRedelivery = false,
                wasRedelivered = false,
                failureReason = null,
            )
        }
        accepted.indices.forEach { index ->
            accepted[index] = accepted[index].copy(sequence = 0, sequenceLabel = null)
        }
        val removed = existingOrders.count { it.waybillKey() !in importedKeys }
        return OrderMergeResult(
            orders = accepted,
            addedOrders = added,
            ignoredDuplicateCount = duplicates,
            restoredProductCount = restoredProducts,
            reactivatedCount = temporaryIndexes.size,
            removedNotInLatestImportCount = removed,
        )
    }

    fun appendNew(
        existingOrders: List<DeliveryOrder>,
        importedOrders: List<DeliveryOrder>,
        customerProfiles: List<CustomerProfile> = emptyList(),
    ): OrderMergeResult {
        val mergedOrders = existingOrders.toMutableList()
        val indexByWaybill = existingOrders.mapIndexed { index, order -> order.waybillKey() to index }.toMap().toMutableMap()
        val added = mutableListOf<DeliveryOrder>()
        var duplicates = 0
        var restoredProducts = 0
        importedOrders.forEach { imported ->
            val waybillKey = imported.waybillKey()
            val existingIndex = indexByWaybill[waybillKey]
            if (existingIndex == null) {
                val accepted = imported.withCustomerAddress(customerProfiles).normalizedCoordinates()
                indexByWaybill[waybillKey] = mergedOrders.size
                mergedOrders += accepted
                added += accepted
            } else {
                duplicates++
                val existing = mergedOrders[existingIndex]
                if (existing.product.isBlank() && imported.product.isNotBlank()) {
                    mergedOrders[existingIndex] = existing.copy(product = imported.product.trim())
                    restoredProducts++
                }
            }
        }
        return OrderMergeResult(mergedOrders, added, duplicates, restoredProducts)
    }

    private fun DeliveryOrder.waybillKey(): String = waybill.trim().lowercase(Locale.ROOT)

    /**
     * Nạp dữ liệu đã lưu của khách vào ĐƠN mới mà không sửa hồ sơ khách hàng.
     *
     * Quy tắc bắt buộc:
     * 1. So SĐT sau khi chuẩn hóa nên +84/84/0084/0xxx đều khớp nhau.
     * 2. Hồ sơ khách hàng là dữ liệu gốc cho tọa độ/địa chỉ đã lưu.
     * 3. Không tạo CustomerProfile mới nếu SĐT đã tồn tại.
     * 4. Không ghi đè CustomerProfile, đặc biệt không làm mất housePhotoPath.
     * 5. Chỉ copy địa chỉ/tọa độ từ hồ sơ sang DeliveryOrder đang nạp.
     */
    private fun DeliveryOrder.withCustomerAddress(profiles: List<CustomerProfile>): DeliveryOrder {
        val targetPhone = phone.customerPhoneKey()
        if (targetPhone.isBlank()) return this

        // Tìm trong TOÀN BỘ hồ sơ đã lưu, không chỉ trong các khách đang có MVĐ.
        val matchedProfile = profiles.firstOrNull { profile ->
            profile.phones.any { savedPhone ->
                savedPhone.number.customerPhoneKey() == targetPhone
            }
        } ?: return this

        val savedAddress = matchedProfile.primaryAddress
        if (savedAddress.address.isBlank()) return this

        // Đây chỉ là copy sang bản ghi đơn hàng. CustomerProfile không bị thay đổi.
        // Nếu hồ sơ có tọa độ thì luôn ưu tiên tọa độ đã lưu; nếu chưa có thì giữ dữ liệu
        // tọa độ của file nhập. Ảnh cổng nằm trong CustomerProfile nên hoàn toàn không bị đụng tới.
        return copy(
            address = savedAddress.address,
            latitude = savedAddress.latitude ?: latitude,
            longitude = savedAddress.longitude ?: longitude,
        )
    }

}
