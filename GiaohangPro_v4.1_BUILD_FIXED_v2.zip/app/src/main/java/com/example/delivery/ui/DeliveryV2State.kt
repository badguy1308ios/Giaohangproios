package com.example.delivery.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import com.example.delivery.model.DeliveryOrder
import com.example.delivery.navigation.persistedRouteLabels
import com.example.delivery.navigation.DeliveryZone
import com.example.delivery.navigation.GeoPoint

/**
 * GROUP: STATE
 * Chứa toàn bộ trạng thái màn hình DeliveryV2.
 * UI chỉ đọc/ghi state này; không đặt thuật toán nghiệp vụ ở đây.
 */
internal enum class DeliveryTab { MAP, DETAIL, CUSTOMERS }

data class TransferPhotoState(val billPath: String? = null, val dropOffPath: String? = null)

internal class DeliveryV2State {
    var tab by mutableStateOf(DeliveryTab.MAP)
    var selectedNavigationOrder by mutableStateOf<DeliveryOrder?>(null)
    var selectedWaybill by mutableStateOf<String?>(null)
    var detailScrollTopRequest by mutableStateOf(0)
    var detailSearchQuery by mutableStateOf("")
    var scannerOpen by mutableStateOf(false)
    var settingsOpen by mutableStateOf(false)
    var backupOpen by mutableStateOf(false)
    var cashAuditOpen by mutableStateOf(false)
    var transferCheckOpen by mutableStateOf(false)
    var orderManagementOpen by mutableStateOf(false)
    var coordinateUpdateOpen by mutableStateOf(false)
    var routeScreenOpen by mutableStateOf(false)
    var completingOrder by mutableStateOf<DeliveryOrder?>(null)
    var focusPhone by mutableStateOf<String?>(null)
    var currentGps by mutableStateOf<GeoPoint?>(null)
    var currentGpsUpdatedAt by mutableStateOf(0L)
    var stableRouteSequence by mutableStateOf<Map<String, String>>(emptyMap())
    var previewRouteSequence by mutableStateOf<Map<String, String>?>(null)
    var zones by mutableStateOf<List<DeliveryZone>>(emptyList())
    var zonesLoaded by mutableStateOf(false)
    var locationGranted by mutableStateOf(false)
    var lastBackPressedAt by mutableStateOf(0L)
    var routeStateInitialized by mutableStateOf(false)
}

@Composable
internal fun rememberDeliveryV2State(orders: List<DeliveryOrder>): DeliveryV2State {
    val state = remember { DeliveryV2State() }

    // Khôi phục STT đã commit từ dữ liệu đơn hàng; GPS mới không tự đánh lại STT.
    LaunchedEffect(orders) {
        if (orders.isEmpty()) {
            state.stableRouteSequence = emptyMap()
            state.previewRouteSequence = null
            state.routeStateInitialized = false
        } else if (!state.routeStateInitialized) {
            state.stableRouteSequence = orders.persistedRouteLabels()
            state.routeStateInitialized = true
        }
    }
    return state
}
