package com.example.delivery.orderio

import com.example.delivery.customer.CustomerProfile
import com.example.delivery.model.DeliveryOrder

/** Áp dụng quy tắc thêm tay: chỉ đơn khớp SĐT có tọa độ đã lưu mới được gán số cuối tuyến. */
object ManualOrderCoordinator {
    fun place(draft: DeliveryOrder, profiles: List<CustomerProfile>, existingOrders: List<DeliveryOrder>, routeActive: Boolean = true): DeliveryOrder {
        require(draft.waybill.trim().isNotBlank()) { "Vui lòng nhập mã vận đơn." }
        require(existingOrders.none { it.waybill.equals(draft.waybill.trim(), ignoreCase = true) }) { "Mã vận đơn đã tồn tại." }
        val phoneKey = draft.phone.phoneKey()
        val profile = profiles.firstOrNull { candidate ->
            phoneKey.isNotBlank() && candidate.phones.any { it.number.phoneKey() == phoneKey }
        }
        val locatedAddress = profile?.addresses?.firstOrNull { address ->
            address.latitude?.isFinite() == true && address.longitude?.isFinite() == true
        }
        val hasCoordinates = locatedAddress != null
        return draft.copy(
            waybill = draft.waybill.trim(),
            customer = draft.customer.trim().ifBlank { profile?.displayName.orEmpty() },
            phone = draft.phone.trim(),
            address = draft.address.trim().ifBlank { locatedAddress?.address.orEmpty() },
            latitude = locatedAddress?.latitude ?: 0.0,
            longitude = locatedAddress?.longitude ?: 0.0,
            // Đơn mới không tự nối vào tuyến; người dùng chủ động chèn STT bằng Sửa/Lưu.
            sequence = 0,
        )
    }

    private fun String.phoneKey(): String = filter(Char::isDigit)
}
