package com.example.delivery.orderio

import com.example.delivery.customer.CustomerProfile
import com.example.delivery.model.DeliveryOrder
import com.example.delivery.model.canReceiveRouteSequence
import com.example.delivery.model.hasStoredCoordinates

data class CustomerCoordinateSyncResult(
    val orders: List<DeliveryOrder>,
    val phoneMatchedWaybills: Set<String>,
    val coordinateUpdatedWaybills: Set<String>,
    val resequencedWaybills: Set<String>,
)

/** Rà từng SĐT đơn với hồ sơ khách, sao chép tọa độ địa chỉ chính và đánh lại số tuyến đang giao. */
object CustomerCoordinateSyncCoordinator {
    fun sync(profiles: List<CustomerProfile>, orders: List<DeliveryOrder>): CustomerCoordinateSyncResult {
        val coordinatesByPhone = linkedMapOf<String, ParsedCoordinates>()
        profiles.forEach { profile ->
            val address = profile.primaryAddress
            val latitude = address.latitude
            val longitude = address.longitude
            if (latitude != null && longitude != null && latitude.isFinite() && longitude.isFinite() && (latitude != 0.0 || longitude != 0.0)) {
                profile.phones.map { it.number.phoneKey() }.filter(String::isNotBlank).forEach { phone ->
                    coordinatesByPhone.putIfAbsent(phone, ParsedCoordinates(latitude, longitude))
                }
            }
        }

        val matchedWaybills = linkedSetOf<String>()
        val changedCoordinates = linkedSetOf<String>()
        val withProfileCoordinates = orders.map { order ->
            val coordinates = coordinatesByPhone[order.phone.phoneKey()] ?: return@map order
            matchedWaybills += order.waybill
            if (order.latitude != coordinates.latitude || order.longitude != coordinates.longitude) changedCoordinates += order.waybill
            order.copy(latitude = coordinates.latitude, longitude = coordinates.longitude)
        }

        var sequence = 1
        val resequenced = linkedSetOf<String>()
        val resequencedOrders = withProfileCoordinates.map { order ->
            val shouldRoute = order.canReceiveRouteSequence() && order.hasStoredCoordinates()
            val newSequence = if (shouldRoute) sequence++ else 0
            if (order.sequence != newSequence) resequenced += order.waybill
            order.copy(sequence = newSequence)
        }
        return CustomerCoordinateSyncResult(resequencedOrders, matchedWaybills, changedCoordinates, resequenced)
    }

    private fun String.phoneKey(): String = filter(Char::isDigit)
}
