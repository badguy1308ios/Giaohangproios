package com.example.delivery.location

object RealtimeLocationPolicy {
    const val MAX_LAST_KNOWN_AGE_MS = 2 * 60 * 1000L
    const val MAX_CUSTOMER_LOCATION_ACCURACY_METERS = 75f

    fun isFreshLastKnown(locationTimeMillis: Long, nowMillis: Long): Boolean =
        locationTimeMillis > 0 && nowMillis >= locationTimeMillis && nowMillis - locationTimeMillis <= MAX_LAST_KNOWN_AGE_MS

    fun shouldAccept(currentTimeMillis: Long?, candidateTimeMillis: Long): Boolean =
        currentTimeMillis == null || candidateTimeMillis >= currentTimeMillis

    /** Không lưu điểm GPS cũ hoặc có bán kính sai số lớn cho địa chỉ khách. */
    fun isUsableForCustomer(locationTimeMillis: Long, accuracyMeters: Float, nowMillis: Long): Boolean =
        isFreshLastKnown(locationTimeMillis, nowMillis) && accuracyMeters.isFinite() && accuracyMeters in 0f..MAX_CUSTOMER_LOCATION_ACCURACY_METERS
}
