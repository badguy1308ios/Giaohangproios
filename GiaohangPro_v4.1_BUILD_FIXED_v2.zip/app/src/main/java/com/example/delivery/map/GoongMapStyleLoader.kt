package com.example.delivery.map

import android.content.Context
import com.example.delivery.R
import com.example.delivery.navigation.GoongApiConfig

/**
 * Nạp style GOONG cho MapLibre và thay API key trong style bằng BuildConfig.
 *
 * Lý do tách riêng:
 * - Tập trung toàn bộ logic Map Tiles API vào một chỗ.
 * - Không để API key hard-code trong goong_map_style.json.
 * - Các màn hình bản đồ chỉ cần gọi load(context).
 */
internal object GoongMapStyleLoader {
    fun load(context: Context): String {
        val key = GoongApiConfig.mapTilesKey
        check(key.isNotBlank()) { "Thiếu GOONG_MAP_TILES_KEY" }

        return context.resources
            .openRawResource(R.raw.goong_map_style)
            .bufferedReader()
            .use { it.readText() }
            .replace("__GOONG_MAP_TILES_KEY__", key)
    }
}
