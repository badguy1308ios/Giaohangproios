package com.example.delivery.ui

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.delivery.history.*
import com.example.delivery.customer.CustomerProfile
import com.example.delivery.model.*
import com.example.delivery.orderio.CoordinateUpdateRequest
import com.example.delivery.ui.logic.*

@Composable
fun DeliveryV2Screen(
    orders: List<DeliveryOrder>,
    transferPhotos: Map<String, TransferPhotoState>,
    transferEvidence: List<TransferEvidence>,
    customerProfiles: List<CustomerProfile>,
    onDirectDelivered: (DeliveryOrder) -> Unit,
    onSaveTransfer: (DeliveryOrder, PaymentChannel, String, String?, String?) -> Unit,
    onCaptureTransferPhoto: (DeliveryOrder, ProofPhotoType) -> Unit,
    onCall: (DeliveryOrder) -> Unit,
    onZalo: (DeliveryOrder, String) -> Unit,
    onSms: (DeliveryOrder, String) -> Unit,
    onConfirmTransferPayment: (String) -> Unit,
    transferMessage: (DeliveryOrder) -> String,
    onRouteSequenceLocked: (Map<String, String>) -> Unit,
    onCreateRoute: (RouteCreationMode) -> Unit,
    onDeleteRoute: () -> Unit,
    onSaveCustomer: (CustomerProfile) -> Unit,
    onDeleteCustomer: (CustomerProfile) -> Unit,
    onGetCustomerCoordinates: () -> Pair<Double, Double>?,
    onExportBackup: () -> Unit,
    onImportBackup: () -> Unit,
    onImportOrders: () -> Unit,
    onExportOrders: () -> Unit,
    onExportStt: () -> Unit,
    onImportStt: () -> Unit,
    onAddManualOrder: (DeliveryOrder) -> Unit,
    onDeleteOrder: (String) -> Unit,
    onDeleteAllOrders: () -> Unit,
    onUpdateCoordinates: (CoordinateUpdateRequest) -> Unit,
    onSyncOrdersFromCustomerCoordinates: () -> Unit,
    onOpenVtmanExport: () -> Unit,
    backupStatus: String?,
) {
    // GROUP: STATE — tạo và giữ toàn bộ trạng thái của màn hình.
    val state = rememberDeliveryV2State(orders)
    val context = LocalContext.current

    // GROUP: NAVIGATION — nếu đang ở màn hình con thì không vẽ màn hình chính.
    val childScreenShown = DeliveryV2Navigation(
        state = state,
        orders = orders,
        transferEvidence = transferEvidence,
        backupStatus = backupStatus,
        onConfirmTransferPayment = onConfirmTransferPayment,
        onOpenVtmanExport = onOpenVtmanExport,
        onCreateRoute = onCreateRoute,
        onDeleteRoute = onDeleteRoute,
        onAddManualOrder = onAddManualOrder,
        onDeleteOrder = onDeleteOrder,
        onDeleteAllOrders = onDeleteAllOrders,
        onUpdateCoordinates = onUpdateCoordinates,
        onSyncOrdersFromCustomerCoordinates = onSyncOrdersFromCustomerCoordinates,
        onExportBackup = onExportBackup,
        onImportBackup = onImportBackup,
        onImportOrders = onImportOrders,
        onExportOrders = onExportOrders,
        onExportStt = onExportStt,
        onImportStt = onImportStt,
        onRouteSequenceLocked = { updated ->
            state.stableRouteSequence = updated
            onRouteSequenceLocked(updated)
        },
    )
    if (childScreenShown) return

    // GROUP: LOGIC — chuẩn hóa thứ tự hiển thị; thuật toán nằm trong DeliveryConditions.kt.
    LaunchedEffect(state.currentGps, orders, state.stableRouteSequence) {
        if (state.stableRouteSequence.isEmpty()) {
            val origin = findRouteOrigin(orders, state.currentGps)
            if (origin != null) {
                val initial = buildRouteSequence(orders, origin)
                state.stableRouteSequence = initial
                onRouteSequenceLocked(initial)
            }
        }
    }
    val displayOrders = orders.withStableRouteLabels(state.previewRouteSequence ?: state.stableRouteSequence)

    // GROUP: MAIN UI — Header + Map + Detail + Customer + Bottom tabs.
    Column(Modifier.fillMaxSize().background(AppBackground).statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { state.settingsOpen = true }) {
                Icon(Icons.Filled.Settings, "Cài đặt", tint = androidx.compose.ui.graphics.Color(0xFF12385F))
            }
            Text("GIAO HÀNG THEO CÁCH CỦA BẠN", modifier = Modifier.weight(1f), color = androidx.compose.ui.graphics.Color(0xFFE57B22), fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
        }
        Box(Modifier.weight(1f)) {
            DeliveryV2Map(state, displayOrders, onRouteSequenceLocked)
            when (state.tab) {
                DeliveryTab.MAP -> Unit
                DeliveryTab.DETAIL -> DeliveryV2Detail(
                    state = state,
                    orders = displayOrders,
                    onCall = onCall,
                    onZalo = onZalo,
                    onSms = onSms,
                    transferMessage = transferMessage,
                    onDelivered = { state.completingOrder = it },
                )
                DeliveryTab.CUSTOMERS -> DeliveryV2Customer(
                    state = state,
                    context = context,
                    customerProfiles = customerProfiles,
                    onSaveCustomer = onSaveCustomer,
                    onDeleteCustomer = onDeleteCustomer,
                    onGetCustomerCoordinates = onGetCustomerCoordinates,
                )
            }
            if (state.tab == DeliveryTab.DETAIL) {
                IconButton(
                    onClick = { state.detailScrollTopRequest += 1 },
                    modifier = Modifier.align(Alignment.BottomStart).padding(start = 22.dp, bottom = 18.dp).size(62.dp)
                        .background(androidx.compose.ui.graphics.Color(0xFF12385F), androidx.compose.foundation.shape.CircleShape),
                ) {
                    Icon(Icons.Filled.ArrowUpward, contentDescription = "Về đầu danh sách", tint = androidx.compose.ui.graphics.Color.White, modifier = Modifier.size(31.dp))
                }
            }
        }
        Row(
            Modifier.fillMaxWidth().background(AppSurface).padding(horizontal = 10.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(7.dp),
        ) {
            TabButton("Bản đồ", Icons.Filled.Map, state.tab == DeliveryTab.MAP, Modifier.weight(1f)) { state.tab = DeliveryTab.MAP }
            TabButton("Chi tiết", Icons.Filled.ReceiptLong, state.tab == DeliveryTab.DETAIL, Modifier.weight(1f)) { state.tab = DeliveryTab.DETAIL }
            TabButton("Khách hàng", Icons.Filled.People, state.tab == DeliveryTab.CUSTOMERS, Modifier.weight(1f)) { state.tab = DeliveryTab.CUSTOMERS }
        }
    }

    // GROUP: DIALOG — dialog được tách riêng để không lẫn vào UI chính.
    DeliveryV2Dialog(state, orders, onDirectDelivered)
}
