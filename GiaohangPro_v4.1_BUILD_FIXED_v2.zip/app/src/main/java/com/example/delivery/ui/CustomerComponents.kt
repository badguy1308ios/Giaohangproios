package com.example.delivery.ui

import android.Manifest
import android.app.Activity
import android.content.Context
import android.widget.Toast
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.relocation.BringIntoViewRequester
import androidx.compose.foundation.relocation.bringIntoViewRequester
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import com.example.delivery.history.DeliveryPhotoHistory
import com.example.delivery.history.PaymentChannel
import com.example.delivery.history.ProofPhotoType
import com.example.delivery.history.TransferEvidence
import com.example.delivery.orderio.CoordinateUpdateRequest
import com.example.delivery.orderio.CoordinateTextParser
import com.example.delivery.location.RealtimeLocationPolicy
import com.example.delivery.customer.CustomerAddress
import com.example.delivery.customer.CustomerContactMethod
import com.example.delivery.customer.CustomerPhone
import com.example.delivery.customer.CustomerProfile
import com.example.delivery.customer.CustomerProfileStore
import com.example.delivery.customer.matchesSearch
import com.example.delivery.model.DeliveryOrder
import com.example.delivery.model.DeliveryOutcome
import com.example.delivery.model.DeliveryStatus
import com.example.delivery.model.hasStoredCoordinates
import com.example.delivery.model.canReceiveRouteSequence
import com.example.delivery.model.dispatchDisplayOrder
import com.example.delivery.model.formatVnd
import com.example.delivery.model.isMapVisible
import com.example.delivery.model.isPickupAtWarehouse
import com.example.delivery.model.isRouteActive
import com.example.delivery.model.statusLabel
import com.example.delivery.model.withStableRouteLabels
import com.example.delivery.model.resequenceDraftLabels
import com.example.delivery.model.sequenceText
import com.example.delivery.model.sequenceSortValue
import com.example.delivery.model.csvStatus
import com.example.delivery.navigation.DeliveryRouteStore
import com.example.delivery.navigation.DeliveryZone
import com.example.delivery.navigation.GeoPoint
import com.example.delivery.navigation.persistedRouteLabels
import com.example.delivery.navigation.preferredRouteOrigin
import com.example.delivery.navigation.routeOrdersFrom
import kotlinx.coroutines.delay
import java.util.Locale

// UI GROUP: CUSTOMER
// Chứa riêng UI danh sách, chi tiết và chỉnh sửa khách hàng.
@Composable
internal fun CustomerList(
    profiles: List<CustomerProfile>,
    focusPhone: String?,
    onSaveCustomer: (CustomerProfile) -> Unit,
    onDeleteCustomer: (CustomerProfile) -> Unit,
    onGetCustomerCoordinates: () -> Pair<Double, Double>?,
) {
    var searchQuery by rememberSaveable { mutableStateOf("") }
    var editor by remember { mutableStateOf<CustomerProfile?>(null) }
    var deleteConfirmation by remember { mutableStateOf<CustomerProfile?>(null) }
    var detailProfile by remember { mutableStateOf<CustomerProfile?>(null) }
    val context = LocalContext.current
    val listState = rememberLazyListState()
    val filteredProfiles = profiles.filter { it.matchesSearch(searchQuery) }
    LaunchedEffect(focusPhone, profiles) {
        if (!focusPhone.isNullOrBlank()) {
            searchQuery = ""
            val index = profiles.indexOfFirst { profile -> profile.phones.any { it.number == focusPhone } }
            if (index >= 0) listState.scrollToItem(index)
        }
    }
    Box(Modifier.fillMaxSize().background(AppBackground)) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("KHÁCH HÀNG", color = Color(0xFF12385F), fontWeight = FontWeight.ExtraBold, fontSize = 19.sp)
                    Text("${filteredProfiles.size}/${profiles.size} khách trong danh sách", color = Color(0xFF6F7A84), fontSize = 12.sp)
                }
            }
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                label = { Text("Tìm tên, SĐT, địa chỉ", fontSize = 12.sp) },
                singleLine = true,
                trailingIcon = {
                    if (searchQuery.isNotBlank()) IconButton(onClick = { searchQuery = "" }) { Icon(Icons.Filled.Close, "Xóa tìm kiếm") }
                },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 3.dp).heightIn(min = 54.dp),
            )
            LazyColumn(Modifier.weight(1f), state = listState, verticalArrangement = Arrangement.spacedBy(7.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 8.dp)) {
                if (filteredProfiles.isEmpty()) {
                    item { Text("Không tìm thấy khách hàng phù hợp.", color = Color(0xFF68727C), fontSize = 13.sp, modifier = Modifier.fillMaxWidth().padding(top = 24.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center) }
                } else {
                    itemsIndexed(filteredProfiles, key = { index, profile -> customerListItemKey(profile, index) }) { _, profile ->
                        CustomerPrimaryNameRow(
                            name = profile.displayName,
                            highlighted = profile.phones.any { it.number == focusPhone },
                            onOpen = { detailProfile = profile },
                        )
                    }
                }
            }
        }
        IconButton(onClick = { editor = CustomerProfile.empty() }, modifier = Modifier.align(Alignment.BottomStart).padding(start = 22.dp, bottom = 18.dp).size(62.dp).background(Color(0xFF1E73BE), RoundedCornerShape(50))) {
            Icon(Icons.Filled.Add, "Thêm khách hàng", tint = Color.White, modifier = Modifier.size(31.dp))
        }
    }
    detailProfile?.let { profile ->
        CustomerDetailDialog(
            profile = profile,
            onDismiss = { detailProfile = null },
            onEdit = { editor = profile },
            onDelete = { deleteConfirmation = profile },
            onOpenMap = { address -> openCustomerAddressInMap(context, address) },
            onNavigate = { address -> navigateToCustomerAddress(context, address) },
            onCall = { openCustomerChannel(context, profile, CustomerContactMethod.CALL) },
            onOpenZalo = { openCustomerChannel(context, profile, CustomerContactMethod.ZALO) },
            onOpenSms = { openCustomerChannel(context, profile, CustomerContactMethod.SMS) },
        )
    }
    editor?.let { profile -> CustomerEditorDialog(profile, onDismiss = { editor = null }, onSave = { saved -> onSaveCustomer(saved); detailProfile = saved; editor = null }, onGetCustomerCoordinates = onGetCustomerCoordinates) }
    deleteConfirmation?.let { profile ->
        AlertDialog(
            onDismissRequest = { deleteConfirmation = null },
            title = { Text("Xóa khách hàng?") },
            text = { Text("Bạn có chắc chắn muốn xóa hồ sơ ${profile.displayName}? Thông tin khách hàng sẽ không còn xuất hiện trong danh sách.") },
            confirmButton = {
                Button(onClick = { onDeleteCustomer(profile); detailProfile = null; deleteConfirmation = null }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC23D35))) { Text("Xóa") }
            },
            dismissButton = { OutlinedButton(onClick = { deleteConfirmation = null }) { Text("Hủy") } },
        )
    }
}

/**
 * Hồ sơ cũ có thể mang id trùng do từng được sinh từ SĐT. Ghép index vào key
 * chỉ để bảo vệ LazyColumn; dữ liệu chính đã được gộp theo SĐT ở model.
 */
internal fun customerListItemKey(profile: CustomerProfile, index: Int): String = "customer|${profile.id}|$index"

@Composable
private fun CustomerPrimaryNameRow(name: String, highlighted: Boolean, onOpen: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(if (highlighted) Color(0xFFFBEDE3) else AppSurface, RoundedCornerShape(14.dp))
            .border(1.dp, if (highlighted) Color(0xFFE5B37A) else Color(0xFFE0E6EA), RoundedCornerShape(14.dp))
            .clickable(onClick = onOpen)
            .padding(horizontal = 14.dp, vertical = 15.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Filled.People, null, tint = Color(0xFF12385F), modifier = Modifier.size(24.dp))
        Text(name, color = Color(0xFF182B3D), fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, modifier = Modifier.weight(1f).padding(start = 10.dp))
        Icon(Icons.Filled.Navigation, "Mở chi tiết khách hàng", tint = Color(0xFF698092), modifier = Modifier.size(20.dp))
    }
}

@Composable
private fun CustomerDetailDialog(
    profile: CustomerProfile,
    onDismiss: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onOpenMap: (CustomerAddress) -> Unit,
    onNavigate: (CustomerAddress) -> Unit,
    onCall: () -> Unit,
    onOpenZalo: () -> Unit,
    onOpenSms: () -> Unit,
) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            modifier = Modifier.fillMaxSize().navigationBarsPadding().padding(6.dp),
            shape = RoundedCornerShape(18.dp),
            color = AppBackground,
        ) {
            Column(Modifier.fillMaxSize()) {
                Row(
                    modifier = Modifier.fillMaxWidth().background(AppSurface).padding(horizontal = 10.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("CHI TIẾT KHÁCH HÀNG", color = Color(0xFF12385F), fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, modifier = Modifier.weight(1f))
                    IconButton(onClick = onEdit) { Icon(Icons.Filled.Edit, "Sửa khách hàng", tint = Color(0xFF1E73BE)) }
                    IconButton(onClick = onDelete) { Icon(Icons.Filled.Delete, "Xóa khách hàng", tint = Color(0xFFC23D35)) }
                    IconButton(onClick = onDismiss) { Icon(Icons.Filled.Close, "Đóng chi tiết", tint = Color(0xFF40515E)) }
                }
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp),
                ) {
                    item {
                        CustomerHousePhotosAtTop(profile)
                    }
                    item {
                        CustomerProfileBlock(
                            profile = profile,
                            onOpenMap = onOpenMap,
                            onNavigate = onNavigate,
                            onCall = onCall,
                            onOpenZalo = onOpenZalo,
                            onOpenSms = onOpenSms,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CustomerProfileBlock(
    profile: CustomerProfile,
    onOpenMap: (CustomerAddress) -> Unit,
    onNavigate: (CustomerAddress) -> Unit,
    onCall: () -> Unit,
    onOpenZalo: () -> Unit,
    onOpenSms: () -> Unit,
) {
    val names = profile.names.ifEmpty { listOf(profile.displayName) }.filter(String::isNotBlank)
    val phones = profile.phones.filter { it.number.isNotBlank() }
    val addresses = profile.addresses.filter { it.address.isNotBlank() }
    Column(
        Modifier
            .fillMaxWidth()
            .background(AppSurface, RoundedCornerShape(20.dp))
            .border(1.dp, Color(0xFFE0E6EA), RoundedCornerShape(20.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        names.forEachIndexed { index, name ->
            Text(
                text = name,
                color = Color(0xFF182B3D),
                fontWeight = FontWeight.ExtraBold,
                fontSize = 15.sp,
                modifier = Modifier.padding(start = 33.dp),
            )
        }
        phones.forEachIndexed { index, phone ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (index == 0) Icon(Icons.Filled.Phone, "Số điện thoại", tint = Color(0xFF12385F), modifier = Modifier.size(24.dp)) else Spacer(Modifier.width(24.dp))
                Text(
                    text = phone.number,
                    color = Color(0xFF182B3D),
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(start = 8.dp),
                )
            }
        }
        addresses.forEachIndexed { index, address ->
            CustomerAddressDisplayRow(
                address = address,
                index = index,
                total = addresses.size,
                onOpenMap = { onOpenMap(address) },
                onNavigate = { onNavigate(address) },
            )
        }
        Row(Modifier.fillMaxWidth().padding(top = 2.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            OutlinedButton(
                onClick = onCall,
                modifier = Modifier.weight(1f).height(42.dp),
                enabled = phones.any { CustomerContactMethod.CALL in it.methods },
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF12385F)),
            ) { Icon(Icons.Filled.Phone, null, modifier = Modifier.size(18.dp)); Text(" Gọi", fontSize = 14.sp, fontWeight = FontWeight.ExtraBold) }
            OutlinedButton(
                onClick = onOpenZalo,
                modifier = Modifier.weight(1f).height(42.dp),
                enabled = phones.any { CustomerContactMethod.ZALO in it.methods },
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF1474B5)),
            ) { Text("Zalo", fontSize = 14.sp, fontWeight = FontWeight.ExtraBold) }
            OutlinedButton(
                onClick = onOpenSms,
                modifier = Modifier.weight(1f).height(42.dp),
                enabled = phones.any { CustomerContactMethod.SMS in it.methods },
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF12385F)),
            ) { Icon(Icons.Filled.Sms, null, modifier = Modifier.size(18.dp)); Text(" SMS", fontSize = 14.sp, fontWeight = FontWeight.ExtraBold) }
        }
    }
}

@Composable
private fun CustomerAddressDisplayRow(
    address: CustomerAddress,
    index: Int,
    total: Int,
    onOpenMap: () -> Unit,
    onNavigate: () -> Unit,
) {
    Column(Modifier.fillMaxWidth().padding(top = 3.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
            Icon(Icons.Filled.LocationOn, "Địa chỉ", tint = Color(0xFF12385F), modifier = Modifier.size(24.dp))
            Column(Modifier.weight(1f).padding(start = 8.dp)) {
                Text(
                    text = if (total == 1) address.address else "${address.address} (địa chỉ ${index + 1})",
                    color = Color(0xFF182B3D),
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 14.sp,
                )
                val coordinate = if (address.latitude != null && address.longitude != null) {
                    String.format(java.util.Locale.US, "Tọa độ: %.4f, %.4f", address.latitude, address.longitude)
                } else {
                    "Chưa có tọa độ"
                }
                Text(coordinate, color = Color(0xFF66737E), fontSize = 10.sp, modifier = Modifier.padding(top = 1.dp))
            }
        }
        Row(
            Modifier.fillMaxWidth().padding(start = 32.dp, top = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            OutlinedButton(onClick = onOpenMap, enabled = address.latitude != null && address.longitude != null, modifier = Modifier.height(36.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 9.dp)) { Icon(Icons.Filled.LocationOn, "Xem vị trí", modifier = Modifier.size(18.dp)); Text(" Vị trí", fontSize = 11.sp) }
            OutlinedButton(onClick = onNavigate, enabled = address.latitude != null && address.longitude != null, modifier = Modifier.height(36.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 9.dp)) { Icon(Icons.Filled.Navigation, "Chỉ đường", modifier = Modifier.size(18.dp)); Text(" Chỉ đường", fontSize = 11.sp) }
        }
    }
}

@Composable
private fun CustomerHousePhotosAtTop(profile: CustomerProfile) {
    val photos = profile.addresses.mapNotNull { address -> address.housePhotoPath?.takeIf(String::isNotBlank)?.let { path -> address to path } }
    if (photos.isNotEmpty()) {
        Column(Modifier.fillMaxWidth().padding(bottom = 10.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            photos.forEachIndexed { index, (address, path) ->
                val bitmap = remember(path) { BitmapFactory.decodeFile(path) }
                if (bitmap != null) {
                    if (photos.size > 1) Text("Ảnh nhà • Địa chỉ ${index + 1}", color = Color(0xFF40515E), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Image(
                        bitmap = bitmap.asImageBitmap(),
                        contentDescription = "Ảnh nhà khách ${address.address}",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)),
                    )
                }
            }
        }
    }
}

private fun openCustomerAddressInMap(context: Context, address: CustomerAddress) {
    val latitude = address.latitude ?: return
    val longitude = address.longitude ?: return
    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("geo:$latitude,$longitude?q=$latitude,$longitude(${Uri.encode(address.address)})"))
    if (intent.resolveActivity(context.packageManager) != null) context.startActivity(intent)
}

private fun navigateToCustomerAddress(context: Context, address: CustomerAddress) {
    val latitude = address.latitude ?: return
    val longitude = address.longitude ?: return
    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/dir/?api=1&destination=$latitude,$longitude"))
    if (intent.resolveActivity(context.packageManager) != null) context.startActivity(intent)
}

private fun openCustomerChannel(context: Context, profile: CustomerProfile, method: CustomerContactMethod) {
    val phone = profile.phones.firstOrNull { method in it.methods }?.number
    if (phone.isNullOrBlank()) {
        Toast.makeText(context, "Số điện thoại không chọn dùng ${method.label}", Toast.LENGTH_SHORT).show()
        return
    }
    when (method) {
        CustomerContactMethod.CALL -> openCustomerCall(context, phone)
        CustomerContactMethod.ZALO -> openCustomerZalo(context, phone)
        CustomerContactMethod.SMS -> openCustomerSms(context, phone)
    }
}

private fun openCustomerCall(context: Context, phone: String) {
    val cleanPhone = phone.filter(Char::isDigit)
    if (cleanPhone.isBlank()) return
    val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$cleanPhone"))
    if (intent.resolveActivity(context.packageManager) != null) context.startActivity(intent)
}

private fun openCustomerZalo(context: Context, phone: String) {
    val cleanPhone = phone.filter(Char::isDigit)
    if (cleanPhone.isBlank()) return
    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://zalo.me/$cleanPhone"))
    if (intent.resolveActivity(context.packageManager) != null) context.startActivity(intent)
}

private fun openCustomerSms(context: Context, phone: String) {
    val cleanPhone = phone.filter(Char::isDigit)
    if (cleanPhone.isBlank()) return
    val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$cleanPhone"))
    if (intent.resolveActivity(context.packageManager) != null) context.startActivity(intent)
}

@Composable
private fun CustomerEditorDialog(profile: CustomerProfile, onDismiss: () -> Unit, onSave: (CustomerProfile) -> Unit, onGetCustomerCoordinates: () -> Pair<Double, Double>?) {
    val context = LocalContext.current
    var names by remember(profile.id) { mutableStateOf(profile.names.ifEmpty { listOf(profile.name) }.ifEmpty { listOf("") }) }
    var note by remember(profile.id) { mutableStateOf(profile.note) }
    var phones by remember(profile.id) { mutableStateOf(profile.phones.ifEmpty { listOf(CustomerPhone("", isPrimary = true)) }) }
    var addresses by remember(profile.id) { mutableStateOf(profile.addresses.ifEmpty { listOf(CustomerAddress("", isPrimary = true)) }) }
    var gateCaptureTarget by remember(profile.id) { mutableStateOf<Pair<Int, java.io.File>?>(null) }
    var coordinatePickerTarget by remember(profile.id) { mutableStateOf<Int?>(null) }
    val gateCamera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { saved ->
        val target = gateCaptureTarget ?: return@rememberLauncherForActivityResult
        gateCaptureTarget = null
        if (!saved) {
            target.second.delete()
        } else {
            addresses = addresses.mapIndexed { index, value -> if (index == target.first) value.copy(housePhotoPath = target.second.path) else value }
        }
    }
    val dialogShape = RoundedCornerShape(18.dp)
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(
            Modifier
                .fillMaxSize()
                .navigationBarsPadding()
                .imePadding()
                .padding(start = 6.dp, top = 8.dp, end = 6.dp, bottom = 12.dp),
        ) {
            Surface(modifier = Modifier.fillMaxSize().clip(dialogShape), shape = dialogShape, color = AppBackground) {
                Column(modifier = Modifier.fillMaxSize()) {
                Row(
                    modifier = Modifier.fillMaxWidth().background(Color(0xFFEAF5F2)).padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(7.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(if (profile.displayName.isBlank()) "THÊM KHÁCH HÀNG" else "SỬA KHÁCH HÀNG", color = Color(0xFF12385F), fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, modifier = Modifier.weight(1f))
                    Button(
                        onClick = { onSave(profile.copy(name = names.firstOrNull().orEmpty(), names = names, phones = phones, addresses = addresses, note = note).normalized()) },
                        enabled = CustomerProfile(id = profile.id, name = names.firstOrNull().orEmpty(), names = names, phones = phones, addresses = addresses, note = note).normalized().isValid(),
                        modifier = Modifier.height(34.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E73BE)),
                    ) { Text("Lưu", fontSize = 11.sp) }
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.height(34.dp)) { Text("Đóng", fontSize = 11.sp) }
                }
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .padding(start = 14.dp, top = 9.dp, end = 14.dp, bottom = 40.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Text("1. Thông tin cơ bản", fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
                    names.forEachIndexed { index, value ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(value = value, onValueChange = { updated -> names = names.mapIndexed { i, item -> if (i == index) updated else item } }, label = { Text(if (index == 0) "Tên khách hàng" else "Tên gọi khác", fontSize = 12.sp) }, modifier = Modifier.weight(1f).heightIn(min = 56.dp).keyboardSafeTextField(), singleLine = true)
                            if (names.size > 1) IconButton(onClick = { names = names.filterIndexed { i, _ -> i != index } }, modifier = Modifier.padding(start = 6.dp).size(40.dp).background(Color(0xFFFCE8E6), RoundedCornerShape(10.dp))) { Icon(Icons.Filled.Remove, "Xóa tên", tint = Color(0xFFC23D35)) }
                        }
                    }
                    Button(onClick = { names = names + "" }, modifier = Modifier.fillMaxWidth().height(40.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0E7490))) { Icon(Icons.Filled.Add, null, modifier = Modifier.size(17.dp)); Text(" Thêm tên khách hàng", fontSize = 12.sp) }
                    phones.forEachIndexed { index, phone ->
                        PhoneEditorRow(
                            phone = phone,
                            canDelete = phones.size > 1,
                            onChange = { updated -> phones = phones.mapIndexed { i, value -> if (i == index) updated else value } },
                            onPrimary = { phones = phones.mapIndexed { i, value -> value.copy(isPrimary = i == index) } },
                            onDelete = {
                                val remaining = phones.filterIndexed { i, _ -> i != index }
                                phones = if (remaining.any { it.isPrimary }) remaining else remaining.mapIndexed { i, value -> value.copy(isPrimary = i == 0) }
                            },
                        )
                    }
                    Button(onClick = { phones = phones + CustomerPhone("") }, modifier = Modifier.fillMaxWidth().height(40.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E73BE))) { Icon(Icons.Filled.Add, null, modifier = Modifier.size(17.dp)); Text(" Thêm số điện thoại", fontSize = 12.sp) }
                    Text("2. Địa chỉ & Định vị", fontWeight = FontWeight.ExtraBold, fontSize = 13.sp, modifier = Modifier.padding(top = 3.dp))
                    addresses.forEachIndexed { index, address ->
                        AddressEditorBlock(
                            address = address,
                            canDelete = addresses.size > 1,
                            onChange = { updated -> addresses = addresses.mapIndexed { i, value -> if (i == index) updated else value } },
                            onPrimary = { addresses = addresses.mapIndexed { i, value -> value.copy(isPrimary = i == index) } },
                            onDelete = {
                                val remaining = addresses.filterIndexed { i, _ -> i != index }
                                addresses = if (remaining.any { it.isPrimary }) remaining else remaining.mapIndexed { i, value -> value.copy(isPrimary = i == 0) }
                            },
                            onCaptureGate = {
                                val file = DeliveryPhotoHistory.createCustomerGateFile(context, profile.id)
                                gateCaptureTarget = index to file
                                gateCamera.launch(DeliveryPhotoHistory.providerUri(context, file))
                            },
                            onPickCoordinates = { coordinatePickerTarget = index },
                        )
                    }
                    Button(onClick = { addresses = addresses + CustomerAddress("") }, modifier = Modifier.fillMaxWidth().height(40.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF229846))) { Icon(Icons.Filled.Add, null, modifier = Modifier.size(17.dp)); Text(" Thêm địa chỉ mới", fontSize = 12.sp) }
                    Text("3. Thông tin bổ sung", fontWeight = FontWeight.ExtraBold, fontSize = 13.sp, modifier = Modifier.padding(top = 3.dp))
                    OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text("Ghi chú", fontSize = 12.sp) }, modifier = Modifier.fillMaxWidth().heightIn(min = 88.dp).keyboardSafeTextField())
                    Spacer(Modifier.height(180.dp))
                }
            }
        }
    }
}
    coordinatePickerTarget?.let { index ->
        addresses.getOrNull(index)?.let { address ->
            CustomerCoordinatePickerDialog(
                initialLatitude = address.latitude,
                initialLongitude = address.longitude,
                onDismiss = { coordinatePickerTarget = null },
                onConfirm = { latitude, longitude ->
                    addresses = addresses.mapIndexed { addressIndex, value ->
                        if (addressIndex == index) value.copy(latitude = latitude, longitude = longitude) else value
                    }
                    coordinatePickerTarget = null
                },
            )
        }
    }
}

@Composable
@OptIn(ExperimentalFoundationApi::class)
private fun Modifier.keyboardSafeTextField(): Modifier {
    val requester = remember { BringIntoViewRequester() }
    var focused by remember { mutableStateOf(false) }
    LaunchedEffect(focused) {
        if (focused) {
            delay(220)
            requester.bringIntoView()
            delay(260)
            requester.bringIntoView()
        }
    }
    return bringIntoViewRequester(requester).onFocusChanged { focused = it.isFocused }
}

@Composable
private fun PhoneEditorRow(phone: CustomerPhone, canDelete: Boolean, onChange: (CustomerPhone) -> Unit, onPrimary: () -> Unit, onDelete: () -> Unit) {
    var menuExpanded by remember { mutableStateOf(false) }
    Row(verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(value = phone.number, onValueChange = { onChange(phone.copy(number = it)) }, label = { Text("Số điện thoại", fontSize = 12.sp) }, modifier = Modifier.weight(1f).heightIn(min = 56.dp).keyboardSafeTextField(), singleLine = true, trailingIcon = {
            Box {
                IconButton(onClick = { menuExpanded = true }) { Icon(Icons.Filled.ArrowDropDown, "Chọn Gọi, SMS, Zalo") }
                DropdownMenu(expanded = menuExpanded, onDismissRequest = { menuExpanded = false }) {
                    CustomerContactMethod.entries.forEach { method ->
                        DropdownMenuItem(text = { Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(checked = method in phone.methods, onCheckedChange = null); Text(method.label) } }, onClick = {
                            val methods = if (method in phone.methods) phone.methods - method else phone.methods + method
                            onChange(phone.copy(methods = methods.ifEmpty { setOf(CustomerContactMethod.CALL) }))
                        })
                    }
                }
            }
        })
        Checkbox(checked = phone.isPrimary, onCheckedChange = { if (it) onPrimary() })
        Text("Chính", fontSize = 10.sp)
        if (canDelete) IconButton(onClick = onDelete, modifier = Modifier.padding(start = 4.dp).size(38.dp).background(Color(0xFFFCE8E6), RoundedCornerShape(9.dp))) { Icon(Icons.Filled.Remove, "Xóa số điện thoại", tint = Color(0xFFC23D35)) }
    }
}

@Composable
private fun AddressEditorBlock(address: CustomerAddress, canDelete: Boolean, onChange: (CustomerAddress) -> Unit, onPrimary: () -> Unit, onDelete: () -> Unit, onCaptureGate: () -> Unit, onPickCoordinates: () -> Unit) {
    var longitudeText by remember { mutableStateOf(address.longitude?.toString().orEmpty()) }
    var latitudeText by remember { mutableStateOf(address.latitude?.toString().orEmpty()) }
    var committedLongitude by remember { mutableStateOf(address.longitude) }
    var committedLatitude by remember { mutableStateOf(address.latitude) }
    LaunchedEffect(address.longitude, address.latitude) {
        if (address.longitude != committedLongitude) {
            longitudeText = address.longitude?.toString().orEmpty()
            committedLongitude = address.longitude
        }
        if (address.latitude != committedLatitude) {
            latitudeText = address.latitude?.toString().orEmpty()
            committedLatitude = address.latitude
        }
    }
    fun applyPastedCoordinates(value: String): Boolean {
        val coordinates = CoordinateTextParser.parse(value) ?: return false
        latitudeText = coordinates.latitude.toString()
        longitudeText = coordinates.longitude.toString()
        committedLatitude = coordinates.latitude
        committedLongitude = coordinates.longitude
        onChange(address.copy(latitude = coordinates.latitude, longitude = coordinates.longitude))
        return true
    }
    Column(Modifier.fillMaxWidth().background(Color(0xFFEAF5F2), RoundedCornerShape(10.dp)).padding(7.dp)) {
        OutlinedTextField(value = address.address, onValueChange = { onChange(address.copy(address = it)) }, label = { Text("Địa chỉ", fontSize = 12.sp) }, modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp).keyboardSafeTextField(), singleLine = true)
        Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = address.isPrimary, onCheckedChange = { if (it) onPrimary() }, modifier = Modifier.size(34.dp))
            Text("Địa chỉ chính", fontSize = 10.sp, modifier = Modifier.weight(1f))
            if (canDelete) IconButton(onClick = onDelete, modifier = Modifier.size(38.dp).background(Color(0xFFFCE8E6), RoundedCornerShape(9.dp))) { Icon(Icons.Filled.Remove, "Xóa địa chỉ", tint = Color(0xFFC23D35)) }
        }
        Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = latitudeText,
                onValueChange = { value ->
                    latitudeText = value
                    if (!applyPastedCoordinates(value)) {
                        val latitude = value.trim().replace(',', '.').toDoubleOrNull()
                        committedLatitude = latitude
                        onChange(address.copy(latitude = latitude))
                    }
                },
                label = { Text("Vĩ độ (dán cụm)", fontSize = 11.sp) },
                placeholder = { Text("Dán 10.802462, 107.000142", fontSize = 10.sp) },
                modifier = Modifier.weight(1f).heightIn(min = 56.dp).keyboardSafeTextField(),
                singleLine = true,
            )
            OutlinedTextField(
                value = longitudeText,
                onValueChange = { value ->
                    longitudeText = value
                    val longitude = value.trim().replace(',', '.').toDoubleOrNull()
                    committedLongitude = longitude
                    onChange(address.copy(longitude = longitude))
                },
                label = { Text("Kinh độ", fontSize = 11.sp) },
                modifier = Modifier.weight(1f).heightIn(min = 56.dp).keyboardSafeTextField(),
                singleLine = true,
            )
        }
        Text("Nhập tay từng ô hoặc dán cụm Google Maps theo thứ tự Vĩ độ, Kinh độ vào ô Vĩ độ bên trái.", color = Color(0xFF66737E), fontSize = 9.sp, modifier = Modifier.padding(top = 2.dp))
        Row(Modifier.fillMaxWidth().padding(top = 7.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = onCaptureGate, modifier = Modifier.weight(1f).height(42.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E73BE))) { Icon(Icons.Filled.CameraAlt, "Chụp cổng nhà", modifier = Modifier.size(18.dp)); Text(" Ảnh cổng", fontSize = 11.sp) }
            Button(onClick = onPickCoordinates, modifier = Modifier.weight(1f).height(42.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF229846))) { Icon(Icons.Filled.LocationOn, "Chọn tọa độ trên bản đồ", modifier = Modifier.size(18.dp)); Text(" Lấy tọa độ", fontSize = 11.sp) }
        }
    }
}

