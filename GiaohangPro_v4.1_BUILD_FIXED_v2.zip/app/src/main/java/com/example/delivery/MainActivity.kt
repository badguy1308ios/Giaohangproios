package com.example.delivery

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.location.Location
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope
import com.example.delivery.backup.CustomerBackupArchive
import com.example.delivery.backup.CustomerBackupResult
import com.example.delivery.history.DeliveryPhotoHistory
import com.example.delivery.history.PaymentChannel
import com.example.delivery.history.ProofPhotoType
import com.example.delivery.history.TransferEvidence
import com.example.delivery.integration.VtmanExportContract
import com.example.delivery.location.RealtimeLocationPolicy
import com.example.delivery.navigation.DeliveryRouteStore
import com.example.delivery.navigation.DeliveryZone
import com.example.delivery.navigation.GeoPoint
import com.example.delivery.navigation.routeOrdersFrom
import com.example.delivery.navigation.distanceMeters
import com.example.delivery.navigation.routeOrdersFromZones
import com.example.delivery.navigation.orderRouteGroupsByZoneAndGeo
import com.example.delivery.customer.CustomerProfile
import com.example.delivery.customer.CustomerProfileStore
import com.example.delivery.customer.mergeOrderCustomers
import com.example.delivery.debug.CrashDiagnostic
import com.example.delivery.model.DeliveryOrder
import com.example.delivery.model.DeliveryStatus
import com.example.delivery.model.formatVnd
import com.example.delivery.model.isRouteActive
import com.example.delivery.model.canReceiveRouteSequence
import com.example.delivery.model.hasStoredCoordinates
import com.example.delivery.model.withSequenceLabel
import com.example.delivery.model.withSharedPhoneSequence
import com.example.delivery.model.phoneGroupKey
import com.example.delivery.model.deliveryOutcome
import com.example.delivery.model.csvStatus
import com.example.delivery.model.normalizedCoordinates
import com.example.delivery.model.nextActiveSequence
import com.example.delivery.model.sampleOrders
import com.example.delivery.orderio.DeliveryOrderStore
import com.example.delivery.orderio.CoordinateUpdateCoordinator
import com.example.delivery.orderio.CoordinateUpdateRequest
import com.example.delivery.orderio.CustomerCoordinateSyncCoordinator
import com.example.delivery.orderio.ManualOrderCoordinator
import com.example.delivery.orderio.OrderDeletionCoordinator
import com.example.delivery.orderio.OrderFileCodec
import com.example.delivery.orderio.OrderImportCoordinator
import com.example.delivery.orderio.OrderImportResult
import com.example.delivery.orderio.SttSequenceFileCodec
import com.example.delivery.ui.DeliveryV2Screen
import com.example.delivery.ui.RouteCreationMode
import com.example.delivery.ui.TransferPhotoState
import kotlinx.coroutines.delay
import java.io.File
import java.nio.charset.StandardCharsets
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private data class CaptureTarget(val order: DeliveryOrder, val type: ProofPhotoType, val file: File)

class MainActivity : ComponentActivity() {
    private val orders = mutableStateListOf<DeliveryOrder>()
    private val transferPhotos = mutableStateMapOf<String, TransferPhotoState>()
    private var evidence by mutableStateOf<List<TransferEvidence>>(emptyList())
    private var customerProfiles by mutableStateOf<List<CustomerProfile>>(emptyList())
    private var backupStatus by mutableStateOf<String?>(null)
    private var captureTarget: CaptureTarget? = null
    private val backupExport = registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        uri?.let(::exportBackupTo)
    }
    private val backupImport = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let(::importBackupFrom)
    }
    private val orderImport = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let(::importOrdersFrom)
    }
    private val orderExport = registerForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        uri?.let(::exportOrdersTo)
    }
    private val sttExport = registerForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        uri?.let(::exportSttTo)
    }
    private val sttImport = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let(::importSttFrom)
    }
    private val camera = registerForActivityResult(ActivityResultContracts.TakePicture()) { saved ->
        val target = captureTarget ?: return@registerForActivityResult
        captureTarget = null
        if (!saved) { target.file.delete(); return@registerForActivityResult }
        val path = if (target.type == ProofPhotoType.DROP_OFF_WATERMARK) {
            val location = lastLocation()
            DeliveryPhotoHistory.addDropOffWatermark(target.file, target.order, location?.latitude, location?.longitude)
        } else target.file.path
        when (target.type) {
            ProofPhotoType.BILL_CLOSEUP -> transferPhotos[target.order.waybill] = (transferPhotos[target.order.waybill] ?: TransferPhotoState()).copy(billPath = path)
            ProofPhotoType.DROP_OFF_WATERMARK -> transferPhotos[target.order.waybill] = (transferPhotos[target.order.waybill] ?: TransferPhotoState()).copy(dropOffPath = path)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val storedOrders = DeliveryOrderStore.load(this)
        // Chỉ nạp dữ liệu mẫu ở lần chạy đầu; danh sách rỗng sau khi người dùng xóa tất cả phải được giữ nguyên.
        val initialOrders = if (storedOrders.isEmpty() && !DeliveryOrderStore.hasBeenInitialized(this)) {
            sampleOrders().also { DeliveryOrderStore.replace(this, it) }
        } else {
            storedOrders
        }
        val normalizedOrders = initialOrders.map(DeliveryOrder::normalizedCoordinates).withSharedPhoneSequence()
        orders.addAll(normalizedOrders)
        if (normalizedOrders != initialOrders) persistOrders()
        evidence = DeliveryPhotoHistory.getEvidence(this)
        customerProfiles = CustomerProfileStore.load(this)
        val systemBars = WindowCompat.getInsetsController(window, window.decorView)
        systemBars.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        systemBars.hide(WindowInsetsCompat.Type.systemBars())
        setContent {
            var showSplash by remember { mutableStateOf(true) }
            var crashDebug by remember { mutableStateOf(CrashDiagnostic.consume(this@MainActivity)) }
            LaunchedEffect(Unit) {
                delay(1_500)
                showSplash = false
                systemBars.show(WindowInsetsCompat.Type.systemBars())
            }
            if (showSplash) {
                DeliveryLaunchScreen()
            } else DeliveryV2Screen(
                orders = orders,
                transferPhotos = transferPhotos,
                transferEvidence = evidence,
                customerProfiles = customerProfiles.mergeOrderCustomers(orders),
                onDirectDelivered = ::markDelivered,
                onSaveTransfer = ::saveTransfer,
                onCaptureTransferPhoto = ::captureProof,
                onCall = ::openDial,
                onZalo = ::openZalo,
                onSms = ::openSms,
                onConfirmTransferPayment = ::confirmTransferPayment,
                transferMessage = ::transferMessage,
                onRouteSequenceLocked = ::lockRouteSequence,
                onCreateRoute = ::createRoute,
                onDeleteRoute = ::deleteRoute,
                onSaveCustomer = { profile -> customerProfiles = CustomerProfileStore.upsert(this, profile) },
                onDeleteCustomer = { profile -> customerProfiles = CustomerProfileStore.delete(this, profile.id) },
                onGetCustomerCoordinates = { lastLocation()?.let { it.latitude to it.longitude } },
                onExportBackup = ::startBackupExport,
                onImportBackup = ::startBackupImport,
                onImportOrders = ::startOrderImport,
                onExportOrders = ::startOrderExport,
                onExportStt = ::startSttExport,
                onImportStt = ::startSttImport,
                onAddManualOrder = ::addManualOrder,
                onDeleteOrder = ::deleteOrder,
                onDeleteAllOrders = ::deleteAllOrders,
                onUpdateCoordinates = ::updateCoordinates,
                onSyncOrdersFromCustomerCoordinates = ::syncOrdersFromCustomerCoordinates,
                onOpenVtmanExport = ::openVtmanExport,
                backupStatus = backupStatus,
            )
            crashDebug?.let { detail ->
                AlertDialog(
                    onDismissRequest = { crashDebug = null },
                    title = { Text("DEBUG LỖI CRASH") },
                    text = { SelectionContainer { Text(detail) } },
                    confirmButton = {
                        Button(onClick = {
                            val clipboard = getSystemService(ClipboardManager::class.java)
                            clipboard.setPrimaryClip(ClipData.newPlainText("Giao Hàng Goong Alpha crash debug", detail))
                        }) { Text("Sao chép lỗi") }
                    },
                    dismissButton = {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { crashDebug = null }) { Text("Đóng") }
                            OutlinedButton(onClick = { crashDebug = null; recreate() }) { Text("Khởi động lại") }
                        }
                    },
                )
            }
        }
    }

    private fun markDelivered(order: DeliveryOrder) {
        val index = orders.indexOfFirst { it.waybill == order.waybill }
        if (index < 0) return
        val updated = orders[index].copy(
            status = DeliveryStatus.TT500,
            requiresRedelivery = false,
            failureReason = null,
            delivered = true,
            sequence = 0,
            sequenceLabel = null,
        )
        orders.removeAt(index)
        orders.add(updated)
        persistOrders()
    }
    private fun resetRetryableOrdersForRouting() {
        var changed = false
        orders.indices.forEach { index ->
            val order = orders[index]
            if (order.csvStatus() == DeliveryStatus.TT506 || order.csvStatus() == DeliveryStatus.TT507 || order.csvStatus() == DeliveryStatus.TT508) {
                orders[index] = order.copy(
                    status = DeliveryStatus.TT500,
                    requiresRedelivery = false,
                    wasRedelivered = false,
                    failureReason = null,
                    delivered = false,
                )
                changed = true
            }
        }
        if (changed) persistOrders()
    }

    private fun createRoute(mode: RouteCreationMode) {
        resetRetryableOrdersForRouting()
        val zones = DeliveryRouteStore.loadZones(this)
        val groupKey: (DeliveryOrder) -> String = { order -> order.phone.filter(Char::isDigit).ifBlank { order.waybill } }
        val eligibleForNew = orders.filter { order ->
            order.hasStoredCoordinates() && order.canReceiveRouteSequence()
        }
        val eligibleForUpdate = run {
            val newlyLocatedKeys = orders.filter { it.hasStoredCoordinates() && it.sequence == 0 && it.canReceiveRouteSequence() }
                .map(groupKey).toSet()
            orders.filter { order ->
                groupKey(order) in newlyLocatedKeys && order.hasStoredCoordinates() && order.canReceiveRouteSequence()
            }
        }
        val candidates = if (mode == RouteCreationMode.NEW_ROUTE) eligibleForNew else eligibleForUpdate
        val groups = candidates.groupBy(groupKey).values
        // Ưu tiên thứ tự Zone trong cùng khu vực gần nhau; tổng thể đi trái-phải,
        // dưới-lên để các MVĐ gần nhau, kể cả khác Zone, nhận STT gần nhau.
        val ordered = orderRouteGroupsByZoneAndGeo(groups, zones)
        var next = if (mode == RouteCreationMode.NEW_ROUTE) 1 else orders.filter { it.isRouteActive() }.maxOfOrNull { it.sequence }?.plus(1) ?: 1
        val sequenceByWaybill = mutableMapOf<String, Int>()
        ordered.forEach { group -> group.forEach { order -> sequenceByWaybill[order.waybill] = next }; next++ }
        orders.indices.forEach { index -> sequenceByWaybill[orders[index].waybill]?.let { sequence -> orders[index] = orders[index].copy(sequence = sequence, sequenceLabel = null) } }
        persistOrders()
        DeliveryRouteStore.setRouteActive(this, true)
        val label = if (mode == RouteCreationMode.NEW_ROUTE) "Tuyến mới" else "Cập nhật tuyến"
        backupStatus = "Đã $label: ${ordered.size} nhóm SĐT, ${candidates.size} MVĐ được đánh STT."
    }

    private fun deleteRoute() {
        orders.indices.forEach { index -> orders[index] = orders[index].copy(sequence = 0, sequenceLabel = null) }
        persistOrders()
        DeliveryRouteStore.clearRoute(this)
        backupStatus = "Đã xóa tuyến và toàn bộ STT."
    }

    private fun lockRouteSequence(sequenceByWaybill: Map<String, String>) {
        var changed = false
        val labelsByPhone = orders.mapNotNull { order ->
            sequenceByWaybill[order.waybill]?.trim()?.takeIf { it.isValidSequenceLabel() }?.let { order.phoneGroupKey() to it }
        }.toMap()
        orders.indices.forEach { index ->
            val current = orders[index]
            val label = labelsByPhone[current.phoneGroupKey()] ?: sequenceByWaybill[current.waybill]?.trim()
            if (label != null && current.hasStoredCoordinates() && !current.delivered && label.isValidSequenceLabel()) {
                val updated = current.withSequenceLabel(label)
                if (updated.sequence != current.sequence || updated.sequenceLabel != current.sequenceLabel) {
                    orders[index] = updated
                    changed = true
                }
            }
        }
        if (changed) persistOrders()
    }

    private fun String.isValidSequenceLabel(): Boolean {
        val parts = trim().split('.', limit = 2)
        return parts[0].toIntOrNull()?.let { it > 0 } == true &&
            (parts.size == 1 || parts[1].equals("n", true) || parts[1].toIntOrNull()?.let { it > 0 } == true)
    }
    private fun replace(order: DeliveryOrder, update: (DeliveryOrder) -> DeliveryOrder) {
        orders.indexOfFirst { it.waybill == order.waybill }.takeIf { it >= 0 }?.let { index ->
            orders[index] = update(orders[index])
            persistOrders()
        }
    }
    private fun captureProof(order: DeliveryOrder, type: ProofPhotoType) {
        val file = DeliveryPhotoHistory.createOutputFile(this, order.waybill, type)
        captureTarget = CaptureTarget(order, type, file)
        camera.launch(DeliveryPhotoHistory.providerUri(this, file))
    }
    private fun saveTransfer(order: DeliveryOrder, channel: PaymentChannel, message: String, bill: String?, drop: String?) {
        DeliveryPhotoHistory.upsertEvidence(this, TransferEvidence(order.waybill, order.customer, order.phone, order.cod, channel, message, bill, drop, sentConfirmed = true))
        evidence = DeliveryPhotoHistory.getEvidence(this)
    }
    private fun confirmTransferPayment(waybill: String) {
        val item = DeliveryPhotoHistory.confirmPaid(this, waybill) ?: return
        orders.indexOfFirst { it.waybill == waybill }.takeIf { it >= 0 }?.let { index ->
            orders[index] = orders[index].copy(status = DeliveryStatus.TT500, requiresRedelivery = false, failureReason = null, delivered = true)
            persistOrders()
        }
        evidence = DeliveryPhotoHistory.getEvidence(this)
    }
    private fun transferMessage(order: DeliveryOrder) = "Chào anh/chị ${order.customer}, em giao đơn hàng ${order.waybill}. Tiền COD: ${order.cod.formatVnd()}. Anh/Chị chuyển tiền vào STK: 0123456789 - Ngân hàng mặc định - Giao Hàng. Nội dung chuyển khoản: ${order.waybill}. Em cảm ơn ạ!"
    private fun startBackupExport() {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
        backupExport.launch("giaohang_backup_$stamp.zip")
    }

    private fun startBackupImport() = backupImport.launch(arrayOf("application/zip", "application/x-zip-compressed"))

    /** Một số trình quản lý tệp gán MIME không chuẩn cho CSV, nên mở tất cả rồi kiểm tra đuôi tệp trong OrderFileCodec. */
    private fun startOrderImport() = orderImport.launch(arrayOf("*/*"))

    private fun startOrderExport() {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
        orderExport.launch("don_hang_$stamp.csv")
    }

    private fun startSttExport() {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
        sttExport.launch("stt_tuyen_giao_$stamp.csv")
    }

    private fun startSttImport() = sttImport.launch(arrayOf("text/csv", "text/plain", "*/*"))

    private fun importOrdersFrom(uri: Uri) {
        lifecycleScope.launch {
            backupStatus = "Đang nhập đơn hàng…"
            runCatching {
                withContext(Dispatchers.IO) {
                    contentResolver.openInputStream(uri)?.use { input ->
                        OrderFileCodec.import(orderDocumentName(uri), input)
                    } ?: error("Không thể mở tệp đơn hàng.")
                }
            }.onSuccess { result: OrderImportResult ->
                // QUAN TRỌNG: dùng toàn bộ hồ sơ khách hàng đã lưu làm nguồn đối chiếu SĐT.
                // Không dùng mergeOrderCustomers(orders) ở đây vì hàm đó chỉ phục vụ danh sách
                // khách đang xuất hiện trong danh sách MVĐ hiện tại; một khách đã lưu tọa độ/ảnh
                // nhưng chưa có trong ca hiện tại có thể bị bỏ khỏi tập đối chiếu.
                // Khi nạp MVĐ mới, nếu SĐT (0xxx / 84xxx / +84xxx / 0084xxx) trùng hồ sơ đã lưu,
                // OrderImportCoordinator sẽ lấy dữ liệu địa chỉ/tọa độ đã lưu cho ĐƠN, còn hồ sơ
                // khách hàng vẫn được giữ nguyên, tuyệt đối không tạo hồ sơ mới hay ghi đè hồ sơ cũ.
                val knownCustomers = customerProfiles
                val merge = OrderImportCoordinator.replaceWithImportedBatch(orders.toList(), result.orders, knownCustomers)
                orders.clear()
                // replaceWithImportedBatch đã khôi phục đúng các đơn không liên lạc được,
                // hẹn giao lại và tới kho nhận. Không reset trạng thái của các đơn khác tại đây.
                orders.addAll(merge.orders.withSharedPhoneSequence())
                persistOrders()
                customerProfiles = CustomerProfileStore.upsertMissingFromOrders(this@MainActivity, merge.addedOrders)
                val messages = mutableListOf("Đã nạp ${merge.orders.size} MVĐ cho danh sách hiện tại")
                if (merge.addedOrders.isNotEmpty()) messages += "thêm ${merge.addedOrders.size} MVĐ mới"
                if (merge.restoredProductCount > 0) messages += "bổ sung Hàng hóa cho ${merge.restoredProductCount} MVĐ đã có"
                if (merge.ignoredDuplicateCount > 0) messages += "giữ nguyên ${merge.ignoredDuplicateCount} MVĐ đã tồn tại"
                if (merge.reactivatedCount > 0) messages += "đưa lại ${merge.reactivatedCount} MVĐ không liên lạc được/hẹn giao lại/tới kho nhận về Đang giao"
                if (merge.removedNotInLatestImportCount > 0) messages += "ẩn ${merge.removedNotInLatestImportCount} MVĐ không có trong file khỏi Chi tiết và Bản đồ"
                if (result.skippedRows > 0) messages += "bỏ qua ${result.skippedRows} dòng không hợp lệ"
                backupStatus = messages.joinToString("; ") + "."
            }.onFailure { error ->
                backupStatus = "Nhập đơn hàng thất bại: ${error.message ?: "file không hợp lệ"}"
            }
        }
    }

    private fun exportSttTo(uri: Uri) {
        val snapshot = orders.toList()
        lifecycleScope.launch {
            backupStatus = "Đang lưu STT…"
            runCatching {
                withContext(Dispatchers.IO) {
                    contentResolver.openOutputStream(uri)?.use { output ->
                        output.write(SttSequenceFileCodec.exportCsv(snapshot).toByteArray(StandardCharsets.UTF_8))
                    } ?: error("Không thể tạo tệp CSV STT.")
                }
            }.onSuccess {
                backupStatus = "Đã lưu STT của ${snapshot.count { it.sequence > 0 }} mã vận đơn."
            }.onFailure { error ->
                backupStatus = "Lưu STT thất bại: ${error.message ?: "lỗi không xác định"}"
            }
        }
    }

    private fun importSttFrom(uri: Uri) {
        lifecycleScope.launch {
            backupStatus = "Đang khôi phục STT…"
            runCatching {
                withContext(Dispatchers.IO) {
                    contentResolver.openInputStream(uri)?.use { SttSequenceFileCodec.import(it) }
                        ?: error("Không thể mở tệp STT.")
                }
            }.map { entries -> SttSequenceFileCodec.restore(orders.toList(), entries) }
                .onSuccess { result ->
                    orders.clear()
                    orders.addAll(result.orders.withSharedPhoneSequence())
                    persistOrders()
                    if (result.restoredCount > 0) DeliveryRouteStore.setRouteActive(this@MainActivity, true)
                    backupStatus = "Đã khôi phục ${result.restoredCount} STT; bỏ qua ${result.skippedMissingCount} MVĐ không còn trong danh sách và ${result.skippedStatusCount} MVĐ không đủ điều kiện."
                }.onFailure { error ->
                    backupStatus = "Khôi phục STT thất bại: ${error.message ?: "tệp không hợp lệ"}"
                }
        }
    }

    private fun exportOrdersTo(uri: Uri) {
        val snapshot = orders.toList()
        lifecycleScope.launch {
            backupStatus = "Đang xuất đơn hàng…"
            runCatching {
                withContext(Dispatchers.IO) {
                    contentResolver.openOutputStream(uri)?.use { output ->
                        output.write(OrderFileCodec.exportCsv(snapshot).toByteArray(StandardCharsets.UTF_8))
                    } ?: error("Không thể tạo tệp CSV.")
                }
            }.onSuccess {
                backupStatus = "Đã xuất ${snapshot.size} đơn hàng ra CSV."
            }.onFailure { error ->
                backupStatus = "Xuất đơn hàng thất bại: ${error.message ?: "lỗi không xác định"}"
            }
        }
    }

    private fun addManualOrder(draft: DeliveryOrder) {
        runCatching {
            val placed = ManualOrderCoordinator.place(draft, customerProfiles.mergeOrderCustomers(orders), orders, DeliveryRouteStore.isRouteActive(this))
            orders.add(placed)
            persistOrders()
            customerProfiles = CustomerProfileStore.upsertMissingFromOrders(this, listOf(placed))
            backupStatus = if (placed.sequence > 0) {
                "Đã thêm ${placed.waybill} với số thứ tự ${placed.sequence}."
            } else {
                "Đã thêm ${placed.waybill} ở đầu danh sách; hãy bổ sung tọa độ khách hàng để xếp tuyến."
            }
        }.onFailure { error ->
            backupStatus = "Không thể thêm mã vận đơn: ${error.message ?: "dữ liệu không hợp lệ"}"
        }
    }

    private fun deleteAllOrders() {
        runCatching {
            val count = orders.size
            // Không ghi outcome vào lịch sử: yêu cầu là xóa sạch, không để lại dấu vết MVD.
            orders.clear()
            transferPhotos.clear()
            DeliveryOrderStore.replace(this, emptyList())
            DeliveryPhotoHistory.clearAll(this)
            DeliveryRouteStore.clearRoute(this)
            evidence = emptyList()
            backupStatus = "Đã xóa vĩnh viễn toàn bộ $count đơn hàng, trạng thái và lịch sử hình ảnh."
        }.onFailure { error ->
            backupStatus = "Xóa toàn bộ đơn hàng thất bại: ${error.message ?: "không xác định"}"
        }
    }

    private fun deleteOrder(waybill: String) {
        runCatching {
            val deleted = orders.firstOrNull { it.waybill.equals(waybill.trim(), ignoreCase = true) }
                ?: error("Không tìm thấy mã vận đơn cần xóa.")
            // Lưu hẳn khách trước khi bỏ đơn, để khách không bị mất khi đây là đơn duy nhất của họ.
            customerProfiles = CustomerProfileStore.upsertMissingFromOrders(this, listOf(deleted))
            val remaining = OrderDeletionCoordinator.delete(waybill, orders)
            orders.clear()
            orders.addAll(remaining)
            persistOrders()
            backupStatus = "Đã xóa đơn ${deleted.waybill}. Thông tin khách hàng vẫn được giữ lại."
        }.onFailure { error ->
            backupStatus = "Không thể xóa đơn: ${error.message ?: "dữ liệu không hợp lệ"}"
        }
    }

    private fun updateCoordinates(request: CoordinateUpdateRequest) {
        runCatching {
            val result = CoordinateUpdateCoordinator.update(request, customerProfiles.mergeOrderCustomers(orders), orders)
            orders.clear()
            orders.addAll(result.orders)
            persistOrders()
            customerProfiles = CustomerProfileStore.replace(this, result.profiles)
            val ordersText = result.updatedWaybills.size.takeIf { it > 0 }?.let { "$it đơn" }
            val customersText = result.updatedProfileIds.size.takeIf { it > 0 }?.let { "$it khách hàng" }
            backupStatus = "Đã cập nhật tọa độ cho ${listOfNotNull(ordersText, customersText).joinToString(" và ")}."
        }.onFailure { error ->
            backupStatus = "Cập nhật tọa độ thất bại: ${error.message ?: "dữ liệu không hợp lệ"}"
        }
    }

    private fun syncOrdersFromCustomerCoordinates() {
        runCatching {
            val profiles = customerProfiles.mergeOrderCustomers(orders)
            val result = CustomerCoordinateSyncCoordinator.sync(profiles, orders)
            orders.clear()
            orders.addAll(result.orders)
            persistOrders()
            customerProfiles = CustomerProfileStore.replace(this, profiles)
            backupStatus = when {
                result.phoneMatchedWaybills.isEmpty() -> "Không có đơn nào khớp SĐT khách hàng đã lưu tọa độ."
                else -> "Đã rà ${result.phoneMatchedWaybills.size} đơn theo SĐT; cập nhật ${result.coordinateUpdatedWaybills.size} tọa độ và xếp lại ${result.resequencedWaybills.size} đơn."
            }
        }.onFailure { error ->
            backupStatus = "Rà soát SĐT thất bại: ${error.message ?: "dữ liệu không hợp lệ"}"
        }
    }

    private fun orderDocumentName(uri: Uri): String = contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
        if (cursor.moveToFirst()) cursor.getString(0) else null
    } ?: uri.lastPathSegment.orEmpty()

    private fun persistOrders() = DeliveryOrderStore.replace(this, orders.toList())

    private fun openVtmanExport() {
        val launchIntent = packageManager.getLaunchIntentForPackage(VtmanExportContract.packageName)
        if (launchIntent == null) {
            Toast.makeText(this, VtmanExportContract.unavailableMessage, Toast.LENGTH_LONG).show()
        } else {
            startActivity(launchIntent)
        }
    }

    private fun exportBackupTo(uri: Uri) {
        lifecycleScope.launch {
            backupStatus = "Đang xuất file ZIP…"
            runCatching {
                withContext(Dispatchers.IO) {
                    contentResolver.openOutputStream(uri)?.use { CustomerBackupArchive.export(this@MainActivity, it) }
                        ?: error("Không thể tạo file ZIP.")
                }
            }.onSuccess { result -> backupStatus = result.exportMessage() }
                .onFailure { backupStatus = "Xuất ZIP thất bại: ${it.message ?: "lỗi không xác định"}" }
        }
    }

    private fun importBackupFrom(uri: Uri) {
        lifecycleScope.launch {
            backupStatus = "Đang kiểm tra và nhập file ZIP…"
            runCatching {
                withContext(Dispatchers.IO) {
                    contentResolver.openInputStream(uri)?.use { CustomerBackupArchive.import(this@MainActivity, it) }
                        ?: error("Không thể mở file ZIP.")
                }
            }.onSuccess { result ->
                refreshBackupData()
                backupStatus = result.importMessage()
            }.onFailure { backupStatus = "Nhập ZIP thất bại: ${it.message ?: "file không hợp lệ"}" }
        }
    }

    private fun refreshBackupData() {
        evidence = DeliveryPhotoHistory.getEvidence(this)
        customerProfiles = CustomerProfileStore.load(this)
    }

    private fun CustomerBackupResult.exportMessage() = "Đã xuất ZIP: $customerCount khách, $imageCount ảnh WebP" + if (missingImageCount > 0) "; thiếu $missingImageCount ảnh không còn trên máy." else "."
    private fun CustomerBackupResult.importMessage() = "Đã nhập ZIP: $customerCount khách, $imageCount ảnh."
    private fun openDial(order: DeliveryOrder) = startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${order.phone}")))
    private fun openSms(order: DeliveryOrder, message: String) = startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${order.phone}")).putExtra("sms_body", message))
    private fun openZalo(order: DeliveryOrder, ignoredMessage: String) {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("zalo://conversation?phone=${order.phone}"))
        runCatching { startActivity(intent) }.getOrElse {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://zalo.me/${order.phone}")))
        }
    }
    private fun lastLocation() = runCatching {
        val manager = getSystemService(LocationManager::class.java)
        val now = System.currentTimeMillis()
        val candidates: List<Location> = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)
            .mapNotNull { provider -> runCatching { manager.getLastKnownLocation(provider) }.getOrNull() }
            .filter { location -> RealtimeLocationPolicy.isUsableForCustomer(location.time, location.accuracy, now) }
        candidates.minWithOrNull(compareBy<Location> { it.accuracy }.thenByDescending { it.time })
    }.getOrNull()

}

@Composable
private fun DeliveryLaunchScreen() {
    Image(
        painter = painterResource(com.example.delivery.R.drawable.delivery_splash),
        contentDescription = "Đang tải ứng dụng giao hàng",
        modifier = Modifier.fillMaxSize().background(Color.White),
        contentScale = ContentScale.Fit,
    )
}
