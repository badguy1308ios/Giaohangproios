package com.example.delivery.orderio

import com.example.delivery.model.DeliveryOrder

/** Chỉ loại bỏ đơn theo MVĐ. Hồ sơ khách được lưu riêng bởi lớp gọi trước khi thực hiện xóa. */
object OrderDeletionCoordinator {
    fun delete(waybill: String, orders: List<DeliveryOrder>): List<DeliveryOrder> {
        val key = waybill.trim()
        require(key.isNotBlank()) { "Vui lòng nhập mã vận đơn cần xóa." }
        require(orders.any { it.waybill.equals(key, ignoreCase = true) }) { "Không tìm thấy mã vận đơn cần xóa." }
        return orders.filterNot { it.waybill.equals(key, ignoreCase = true) }
    }
}
