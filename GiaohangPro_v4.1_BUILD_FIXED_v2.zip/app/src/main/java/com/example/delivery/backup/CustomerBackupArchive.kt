package com.example.delivery.backup

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import com.example.delivery.customer.CustomerProfileStore
import com.example.delivery.history.DeliveryPhotoHistory
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.security.MessageDigest
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

internal object BackupArchiveRules {
    const val FORMAT = "giaohang-customer-backup"
    const val SCHEMA_VERSION = 1
    const val MANIFEST = "manifest.json"
    const val CUSTOMERS = "customers.json"
    const val EVIDENCE = "transfer_evidence.json"
    const val MAX_ENTRY_COUNT = 5_000
    const val MAX_UNCOMPRESSED_BYTES = 350L * 1024L * 1024L
    const val MAX_JSON_BYTES = 5L * 1024L * 1024L

    fun isSafeArchivePath(path: String): Boolean {
        if (path.isBlank() || path.startsWith('/') || path.startsWith('\\')) return false
        if (':' in path) return false
        return path.split('/').none { it.isBlank() || it == "." || it == ".." }
    }

    fun photoFolderForEntry(path: String): String? = when {
        path.startsWith("photos/customer_gate/") -> "customer_gate"
        path.startsWith("photos/bill/") -> "delivery_confirmation"
        path.startsWith("photos/drop_off/") -> "delivery_confirmation"
        else -> null
    }
}

data class CustomerBackupResult(
    val customerCount: Int,
    val evidenceCount: Int,
    val imageCount: Int,
    val missingImageCount: Int = 0,
)

/**
 * Xuất và nhập snapshot dữ liệu Khách hàng và evidence chuyển khoản. Ảnh luôn được chuyển sang WebP
 * trong gói ZIP; dữ liệu đang chạy của ứng dụng tiếp tục dùng file ảnh riêng.
 */
object CustomerBackupArchive {
    private const val WEBP_QUALITY = 84
    private const val MAX_EXPORT_DIMENSION = 1920
    private const val BUFFER_SIZE = 32 * 1024

    fun export(context: Context, output: OutputStream): CustomerBackupResult {
        val catalog = ExportPhotoCatalog()
        val customersJson = rewriteCustomersForExport(CustomerProfileStore.snapshotJson(context), catalog)
        val evidenceJson = rewriteEvidenceForExport(DeliveryPhotoHistory.snapshotEvidenceJson(context), catalog)
        val entries = mutableListOf<ArchiveEntryInfo>()

        ZipOutputStream(BufferedOutputStream(output, BUFFER_SIZE)).use { zip ->
            entries += zip.writeJson(BackupArchiveRules.CUSTOMERS, customersJson)
            entries += zip.writeJson(BackupArchiveRules.EVIDENCE, evidenceJson)
            catalog.plans.values.forEach { plan -> entries += zip.writeWebp(plan) }

            val manifest = JSONObject()
                .put("format", BackupArchiveRules.FORMAT)
                .put("schemaVersion", BackupArchiveRules.SCHEMA_VERSION)
                .put("createdAt", System.currentTimeMillis())
                .put("customers", JSONArray(customersJson).length())
                .put("transferEvidence", JSONArray(evidenceJson).length())
                .put("images", catalog.plans.size)
                .put("missingImages", catalog.missingImageCount)
                .put("entries", JSONArray(entries.map { it.toJson() }))
            zip.writeJson(BackupArchiveRules.MANIFEST, manifest.toString())
        }

        return CustomerBackupResult(
            customerCount = JSONArray(customersJson).length(),
            evidenceCount = JSONArray(evidenceJson).length(),
            imageCount = catalog.plans.size,
            missingImageCount = catalog.missingImageCount,
        )
    }

    fun import(context: Context, input: InputStream): CustomerBackupResult {
        val temporaryRoot = File(context.cacheDir, "customer_backup_import_${System.nanoTime()}")
        try {
            temporaryRoot.mkdirs()
            extractZip(input, temporaryRoot)

            val manifestFile = File(temporaryRoot, BackupArchiveRules.MANIFEST)
            val customerFile = File(temporaryRoot, BackupArchiveRules.CUSTOMERS)
            val evidenceFile = File(temporaryRoot, BackupArchiveRules.EVIDENCE)
            require(manifestFile.isFile && customerFile.isFile && evidenceFile.isFile) {
                "ZIP thiếu file dữ liệu bắt buộc."
            }
            require(manifestFile.length() <= BackupArchiveRules.MAX_JSON_BYTES && customerFile.length() <= BackupArchiveRules.MAX_JSON_BYTES && evidenceFile.length() <= BackupArchiveRules.MAX_JSON_BYTES) {
                "Dữ liệu JSON trong ZIP vượt giới hạn cho phép."
            }

            val manifest = JSONObject(manifestFile.readText(Charsets.UTF_8))
            validateManifest(manifest, temporaryRoot)

            val customerRaw = customerFile.readText(Charsets.UTF_8)
            val evidenceRaw = evidenceFile.readText(Charsets.UTF_8)
            CustomerProfileStore.validateBackupJson(customerRaw)
            DeliveryPhotoHistory.validateBackupJson(evidenceRaw)

            val photoPaths = copyPhotosToApplicationStorage(context, manifest, temporaryRoot)
            val customerJson = rewriteCustomersForImport(customerRaw, photoPaths)
            val evidenceJson = rewriteEvidenceForImport(evidenceRaw, photoPaths)

            CustomerProfileStore.validateBackupJson(customerJson)
            DeliveryPhotoHistory.validateBackupJson(evidenceJson)
            CustomerProfileStore.replaceFromBackupJson(context, customerJson)
            DeliveryPhotoHistory.replaceFromBackupJson(context, evidenceJson)

            return CustomerBackupResult(
                customerCount = JSONArray(customerJson).length(),
                evidenceCount = JSONArray(evidenceJson).length(),
                    imageCount = photoPaths.size,
            )
        } finally {
            temporaryRoot.deleteRecursively()
        }
    }

    private fun rewriteCustomersForExport(raw: String, catalog: ExportPhotoCatalog): String {
        val customers = JSONArray(raw)
        repeat(customers.length()) { customerIndex ->
            val addresses = customers.getJSONObject(customerIndex).optJSONArray("addresses") ?: JSONArray()
            repeat(addresses.length()) { addressIndex ->
                val address = addresses.getJSONObject(addressIndex)
                address.put("housePhoto", catalog.reference(address.optString("housePhoto"), "customer_gate"))
            }
        }
        return customers.toString()
    }

    private fun rewriteEvidenceForExport(raw: String, catalog: ExportPhotoCatalog): String {
        val evidence = JSONArray(raw)
        repeat(evidence.length()) { index ->
            evidence.getJSONObject(index).apply {
                put("bill", catalog.reference(optString("bill"), "bill"))
                put("drop", catalog.reference(optString("drop"), "drop_off"))
            }
        }
        return evidence.toString()
    }

    private fun rewriteCustomersForImport(raw: String, photoPaths: Map<String, String>): String {
        val customers = JSONArray(raw)
        repeat(customers.length()) { customerIndex ->
            val addresses = customers.getJSONObject(customerIndex).optJSONArray("addresses") ?: JSONArray()
            repeat(addresses.length()) { addressIndex ->
                val address = addresses.getJSONObject(addressIndex)
                address.put("housePhoto", resolvePhotoPath(address.optString("housePhoto"), photoPaths))
            }
        }
        return customers.toString()
    }

    private fun rewriteEvidenceForImport(raw: String, photoPaths: Map<String, String>): String {
        val evidence = JSONArray(raw)
        repeat(evidence.length()) { index ->
            evidence.getJSONObject(index).apply {
                put("bill", resolvePhotoPath(optString("bill"), photoPaths))
                put("drop", resolvePhotoPath(optString("drop"), photoPaths))
            }
        }
        return evidence.toString()
    }

    private fun resolvePhotoPath(reference: String, photoPaths: Map<String, String>): String? {
        if (reference.isBlank() || reference == "null") return null
        return photoPaths[reference] ?: throw IllegalArgumentException("ZIP tham chiếu ảnh không tồn tại: $reference")
    }

    private fun extractZip(input: InputStream, root: File) {
        val rootPath = root.canonicalPath + File.separator
        var entryCount = 0
        var totalBytes = 0L
        val names = mutableSetOf<String>()

        ZipInputStream(BufferedInputStream(input, BUFFER_SIZE)).use { zip ->
            var entry = zip.nextEntry
            while (entry != null) {
                entryCount += 1
                require(entryCount <= BackupArchiveRules.MAX_ENTRY_COUNT) { "ZIP có quá nhiều file." }
                require(BackupArchiveRules.isSafeArchivePath(entry.name) && names.add(entry.name)) { "ZIP có đường dẫn không an toàn." }
                val destination = File(root, entry.name)
                require(destination.canonicalPath.startsWith(rootPath)) { "ZIP có đường dẫn không an toàn." }

                if (entry.isDirectory) {
                    destination.mkdirs()
                } else {
                    destination.parentFile?.mkdirs()
                    FileOutputStream(destination).use { target ->
                        val buffer = ByteArray(BUFFER_SIZE)
                        while (true) {
                            val read = zip.read(buffer)
                            if (read <= 0) break
                            totalBytes += read
                            require(totalBytes <= BackupArchiveRules.MAX_UNCOMPRESSED_BYTES) { "ZIP vượt giới hạn dung lượng giải nén." }
                            target.write(buffer, 0, read)
                        }
                    }
                }
                zip.closeEntry()
                entry = zip.nextEntry
            }
        }
    }

    private fun validateManifest(manifest: JSONObject, root: File) {
        require(manifest.optString("format") == BackupArchiveRules.FORMAT) { "Không phải file sao lưu Giao Hàng hợp lệ." }
        require(manifest.optInt("schemaVersion") == BackupArchiveRules.SCHEMA_VERSION) { "Phiên bản file sao lưu chưa được hỗ trợ." }
        val entries = manifest.optJSONArray("entries") ?: throw IllegalArgumentException("ZIP thiếu danh sách kiểm tra.")
        val declared = mutableSetOf<String>()
        repeat(entries.length()) { index ->
            val item = entries.getJSONObject(index)
            val path = item.getString("path")
            require(BackupArchiveRules.isSafeArchivePath(path) && declared.add(path)) { "Danh sách file trong ZIP không hợp lệ." }
            val file = File(root, path)
            require(file.isFile) { "ZIP thiếu file: $path" }
            require(file.length() == item.getLong("bytes")) { "Kích thước file không khớp: $path" }
            require(sha256(file) == item.getString("sha256")) { "Checksum không khớp: $path" }
        }
        require(BackupArchiveRules.CUSTOMERS in declared && BackupArchiveRules.EVIDENCE in declared) {
            "ZIP thiếu dữ liệu chính."
        }
    }

    private fun copyPhotosToApplicationStorage(context: Context, manifest: JSONObject, root: File): Map<String, String> {
        val entries = manifest.getJSONArray("entries")
        val paths = linkedMapOf<String, String>()
        repeat(entries.length()) { index ->
            val path = entries.getJSONObject(index).getString("path")
            val targetFolder = BackupArchiveRules.photoFolderForEntry(path) ?: return@repeat
            val source = File(root, path)
            val targetDir = File(context.filesDir, targetFolder).apply { mkdirs() }
            val target = File(targetDir, File(path).name)
            source.copyTo(target, overwrite = true)
            paths[path] = target.absolutePath
        }
        return paths
    }

    private fun ZipOutputStream.writeJson(path: String, json: String): ArchiveEntryInfo {
        val bytes = json.toByteArray(Charsets.UTF_8)
        putNextEntry(ZipEntry(path))
        write(bytes)
        closeEntry()
        return ArchiveEntryInfo(path, bytes.size.toLong(), sha256(bytes))
    }

    private fun ZipOutputStream.writeWebp(plan: PhotoPlan): ArchiveEntryInfo {
        val bitmap = decodeForBackup(plan.source) ?: throw IllegalStateException("Không đọc được ảnh: ${plan.source.name}")
        val digest = MessageDigest.getInstance("SHA-256")
        var byteCount = 0L
        try {
            putNextEntry(ZipEntry(plan.archivePath))
            val output = object : OutputStream() {
                override fun write(value: Int) {
                    digest.update(value.toByte())
                    this@writeWebp.write(value)
                    byteCount += 1
                }

                override fun write(buffer: ByteArray, offset: Int, length: Int) {
                    digest.update(buffer, offset, length)
                    this@writeWebp.write(buffer, offset, length)
                    byteCount += length
                }
            }
            val format = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) Bitmap.CompressFormat.WEBP_LOSSY else Bitmap.CompressFormat.WEBP
            check(bitmap.compress(format, WEBP_QUALITY, output)) { "Không thể nén ảnh WebP: ${plan.source.name}" }
            closeEntry()
            return ArchiveEntryInfo(plan.archivePath, byteCount, digest.digest().toHex())
        } finally {
            bitmap.recycle()
        }
    }

    private fun decodeForBackup(file: File): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.path, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        val options = BitmapFactory.Options().apply {
            inSampleSize = sampleSize(bounds.outWidth, bounds.outHeight)
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        return BitmapFactory.decodeFile(file.path, options)
    }

    private fun sampleSize(width: Int, height: Int): Int {
        var sample = 1
        while (width / sample > MAX_EXPORT_DIMENSION || height / sample > MAX_EXPORT_DIMENSION) sample *= 2
        return sample
    }

    private fun sha256(file: File): String = FileInputStream(file).use { input ->
        val digest = MessageDigest.getInstance("SHA-256")
        val buffer = ByteArray(BUFFER_SIZE)
        while (true) {
            val read = input.read(buffer)
            if (read <= 0) break
            digest.update(buffer, 0, read)
        }
        digest.digest().toHex()
    }

    private fun sha256(bytes: ByteArray): String = MessageDigest.getInstance("SHA-256").digest(bytes).toHex()

    private fun ByteArray.toHex(): String = joinToString("") { "%02x".format(it.toInt() and 0xff) }

    private data class ArchiveEntryInfo(val path: String, val bytes: Long, val sha256: String) {
        fun toJson() = JSONObject().put("path", path).put("bytes", bytes).put("sha256", sha256)
    }

    private data class PhotoPlan(val source: File, val archivePath: String)

    private class ExportPhotoCatalog {
        val plans = linkedMapOf<String, PhotoPlan>()
        var missingImageCount = 0
            private set
        private var nextIndex = 1

        fun reference(originalPath: String, category: String): String? {
            if (originalPath.isBlank() || originalPath == "null") return null
            val source = File(originalPath)
            if (!source.isFile) {
                missingImageCount += 1
                return null
            }
            return plans.getOrPut(source.canonicalPath) {
                val archivePath = "photos/$category/${category}_${nextIndex++}.webp"
                PhotoPlan(source, archivePath)
            }.archivePath
        }
    }
}
