package com.example.delivery.navigation

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Một Zone là đa giác có từ ba đỉnh trở lên, không giới hạn số đỉnh; thứ tự trong danh sách là ưu tiên tuyến. */
data class DeliveryZone(
    val id: String,
    val name: String,
    val points: List<GeoPoint>,
)

object DeliveryRouteStore {
    private const val PREFS = "delivery_route_preferences"
    private const val ZONES = "delivery_zones_v1"
    private const val ROUTE_ACTIVE = "route_active"

    fun loadZones(context: Context): List<DeliveryZone> = runCatching {
        val array = JSONArray(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(ZONES, "[]"))
        List(array.length()) { index ->
            val item = array.getJSONObject(index)
            val points = item.getJSONArray("points").let { coords ->
                List(coords.length()) { point ->
                    val p = coords.getJSONObject(point)
                    GeoPoint(p.getDouble("lat"), p.getDouble("lng"))
                }
            }
            DeliveryZone(item.getString("id"), item.optString("name", "Zone ${index + 1}"), points)
        }.filter { it.points.size >= 3 }
    }.getOrDefault(emptyList())

    fun saveZones(context: Context, zones: List<DeliveryZone>) {
        require(zones.all { it.points.size >= 3 }) { "Mỗi Zone phải có ít nhất 3 điểm." }
        val array = JSONArray().apply {
            zones.forEach { zone ->
                put(JSONObject().put("id", zone.id).put("name", zone.name).put("points", JSONArray().apply {
                    zone.points.forEach { point -> put(JSONObject().put("lat", point.latitude).put("lng", point.longitude)) }
                }))
            }
        }
        check(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(ZONES, array.toString()).commit())
    }

    fun isRouteActive(context: Context): Boolean = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(ROUTE_ACTIVE, false)
    fun setRouteActive(context: Context, active: Boolean) {
        check(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(ROUTE_ACTIVE, active).commit())
    }
    fun clearRoute(context: Context) {
        setRouteActive(context, false)
    }

    fun contains(zone: DeliveryZone, latitude: Double, longitude: Double): Boolean {
        if (zone.points.size < 3) return false
        val x = longitude; val y = latitude
        var inside = false
        zone.points.indices.forEach { i ->
            val a = zone.points[i]; val b = zone.points[(i + 1) % zone.points.size]
            val intersects = ((a.latitude > y) != (b.latitude > y)) && (x < (b.longitude - a.longitude) * (y - a.latitude) / (b.latitude - a.latitude) + a.longitude)
            if (intersects) inside = !inside
        }
        return inside
    }
}
