package com.example.delivery.ui

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import com.example.delivery.model.DeliveryOrder
import com.example.delivery.navigation.GeoPoint

/** GROUP: MAP - Chỉ chịu trách nhiệm hiển thị và tương tác bản đồ. */
@Composable
internal fun DeliveryV2Map(
    state: DeliveryV2State,
    displayOrders: List<DeliveryOrder>,
    onRouteSequenceLocked: (Map<String, String>) -> Unit,
) {
    MapDeliveryScreen(
        orders = displayOrders,
        selectedNavigationOrder = state.selectedNavigationOrder,
        selectedWaybill = state.selectedWaybill,
        onRouteSequencePreview = { state.previewRouteSequence = it },
        onRouteSequenceLocked = { updated ->
            state.previewRouteSequence = null
            state.stableRouteSequence = updated
            onRouteSequenceLocked(updated)
        },
        onSelectNavigation = { order -> state.selectedNavigationOrder = order; state.selectedWaybill = order.waybill },
        onSelectOrder = { order -> state.selectedWaybill = order.waybill; state.selectedNavigationOrder = order },
        onReturnToNearest = { state.selectedNavigationOrder = null },
        onOpenDetail = { order ->
            state.selectedWaybill = order.waybill
            state.selectedNavigationOrder = order
            state.detailSearchQuery = order.waybill
            state.tab = DeliveryTab.DETAIL
        },
        locationGranted = state.locationGranted,
        onLocationChanged = { latitude, longitude ->
            state.currentGps = GeoPoint(latitude, longitude)
            state.currentGpsUpdatedAt = System.currentTimeMillis()
        },
        modifier = Modifier.alpha(if (state.tab == DeliveryTab.MAP) 1f else 0f),
    )
}
