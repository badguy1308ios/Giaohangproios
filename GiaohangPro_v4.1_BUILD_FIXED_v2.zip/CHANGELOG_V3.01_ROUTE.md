# Cập nhật v3.01 — Tuyến Giao Hàng

Đã thay thế luồng “Điểm Neo và Vùng Giao Hàng” bằng màn hình “Tuyến Giao Hàng”. Màn hình mới có nút Tạo tuyến/Xóa tuyến với popup xác nhận, quản lý nhiều Zone, mỗi Zone gồm bốn đỉnh, sửa lại từng đỉnh trên popup bản đồ, xóa Zone và đổi ưu tiên Zone.

Đã bổ sung `DeliveryRouteStore` để lưu Zone và trạng thái tuyến bền vững bằng SharedPreferences. Khi tạo tuyến, các đơn có cùng SĐT được gom cùng một STT; thứ tự được ưu tiên theo Zone rồi theo tọa độ. Khi xóa tuyến, toàn bộ STT bị xóa. Khi nạp batch MVĐ mới, STT của batch được reset. Đơn mới chỉ tự nối cuối tuyến khi tuyến đã được tạo và SĐT có tọa độ khách hàng.

Giao diện Chi tiết đơn đã gộp các MVĐ trùng SĐT thành một block, cộng tổng COD và dùng chung nút Gọi/Zalo/SMS; thao tác Đã giao/Giao lại vẫn nằm riêng trên từng MVĐ. Danh sách mã hiển thị được rút về TT500, TT506, TT507, TT508, TT505; đơn Tới kho lấy có thể thao tác Đã giao và Giao lại.

## Kiểm thử

Build debug đã được thử bằng Gradle. Sandbox hiện không có Android SDK hợp lệ nên Gradle dừng ở bước xác định SDK, chưa tạo APK mới. Hãy mở source bằng Android Studio hoặc cung cấp Android SDK để chạy `:app:assembleDebug`.

## Bổ sung v3.2

Đã thêm xoá toàn bộ đơn hàng trong Xử lý đơn với xác nhận Có/Không; khi xác nhận, đơn được xoá khỏi Chi tiết đơn và Bản đồ, tuyến hiện tại được tắt.

Đã thêm Lưu STT và Khôi phục STT bằng CSV. Khôi phục bỏ qua MVĐ không còn trong danh sách và các MVĐ hẹn lại/không liên lạc được, từ chối nhận, thất bại 3 ca hoặc tới kho lấy.

Đã thêm tên Zone khi tạo hoặc sửa Zone. Khi chọn Giao lại, MVĐ luôn nhận STT mới bằng STT cuối cùng cộng một và state được dùng chung giữa Chi tiết đơn và Bản đồ.

## Kiểm thử v3.2

`testDebugUnitTest`: 88 test thành công. `assembleRelease`: build thành công.

## Bổ sung gom MVĐ cùng SĐT

Khi tìm kiếm chính xác một MVĐ, bao gồm mã được quét từ QR hoặc nhập trực tiếp, ứng dụng mở toàn bộ các MVĐ có cùng SĐT trong một block. Block dùng chung các nút Gọi, Zalo và SMS, hiển thị tổng COD; các nút Đã giao và Thất bại vẫn xử lý riêng trên từng MVĐ.
