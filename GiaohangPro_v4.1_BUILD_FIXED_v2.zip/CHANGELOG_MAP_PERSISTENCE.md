# Bản vá duy trì bản đồ khi chuyển tab

## Phạm vi

Bản vá này chỉ xử lý vòng đời tab bản đồ trong màn hình chính của ứng dụng giao hàng. Mục tiêu là giữ cùng một `MapView` trong composition khi người dùng chuyển giữa các tab **Bản đồ**, **Chi tiết** và **Khách hàng**.

## Nguyên nhân

`DeliveryV2Screen` trước đây chỉ gọi `MapDeliveryScreen` trong nhánh `DeliveryTab.MAP`. Khi chuyển sang tab khác, composable bản đồ bị tháo khỏi composition; `NativeMapView` nhận `onDispose` và gọi `mapView.onDestroy()`. Khi quay lại tab Bản đồ, một `MapView` mới được tạo và style bản đồ phải tải lại.

## Thay đổi

`MapDeliveryScreen` hiện được gọi liên tục trong khối nội dung ba tab. Khi tab hiện tại không phải Bản đồ, lớp bản đồ chỉ được ẩn bằng `Modifier.alpha(0f)`; composable, `MapView`, listener vị trí và trạng thái camera vẫn được giữ nguyên. Nội dung Chi tiết/Khách hàng được vẽ ở lớp phía trên.

Do đó, việc chuyển tab không còn làm hủy và khởi tạo lại bản đồ. Khi quay lại tab Bản đồ, camera và trạng thái bản đồ được giữ theo phiên hiện tại.

## Kiểm thử

Đã kiểm tra tĩnh các điểm chính:

- `MapDeliveryScreen` không còn nằm trong nhánh điều kiện chỉ chạy ở tab Bản đồ.
- Khối tab luôn compose `MapDeliveryScreen` và chỉ thay đổi alpha theo tab hiện tại.
- Không thay đổi API dữ liệu, logic đơn hàng, hoặc cơ chế render marker/route.

Lệnh `./gradlew test assembleDebug --no-daemon` đã được thử nhưng không thể hoàn tất trong sandbox vì Android SDK không tồn tại tại `/home/ubuntu/android-sdk`, là đường dẫn được khai báo trong `local.properties`. Source cần được build lại trên máy có Android SDK hợp lệ.
