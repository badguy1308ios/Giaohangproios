# Phân tích từng dòng — `com/example/delivery/contact/ZaloPhone.kt`

> Tài liệu đọc/debug: mã gốc theo từng dòng + giải thích. Không dùng trực tiếp để compile.

### Dòng 1
```kotlin
package com.example.delivery.contact
```
**Giải thích:** Khai báo package, xác định namespace của file.

### Dòng 2
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 3
```kotlin
/** Chuẩn hóa số Việt Nam để Zalo nhận diện liên hệ theo đầu số quốc tế 84. */
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 4
```kotlin
fun zaloPhoneNumber(rawPhone: String): String? {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 5
```kotlin
    val digits = rawPhone.filter(Char::isDigit)
```
**Giải thích:** Lọc dữ liệu theo điều kiện; chỉ giữ phần tử thỏa điều kiện.

### Dòng 6
```kotlin
    val international = when {
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 7
```kotlin
        digits.startsWith("0084") -> digits.removePrefix("00")
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 8
```kotlin
        digits.startsWith("84") -> digits
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 9
```kotlin
        digits.startsWith("0") -> "84${digits.drop(1)}"
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 10
```kotlin
        else -> digits
```
**Giải thích:** Nhánh thay thế khi điều kiện if trước đó sai.

### Dòng 11
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 12
```kotlin
    return international.takeIf { it.startsWith("84") && it.length in 11..12 }
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 13
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 14
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 15
```kotlin
/** Số dạng E.164 mà Android Danh bạ truyền cho các ứng dụng nhắn tin. */
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 16
```kotlin
fun zaloContactPhone(rawPhone: String): String? = zaloPhoneNumber(rawPhone)?.let { "+$it" }
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

