# Phân tích từng dòng — `com/example/delivery/map/GoongMapStyleLoader.kt`

> Tài liệu đọc/debug: mã gốc theo từng dòng + giải thích. Không dùng trực tiếp để compile.

### Dòng 1
```kotlin
package com.example.delivery.map
```
**Giải thích:** Khai báo package, xác định namespace của file.

### Dòng 2
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 3
```kotlin
import android.content.Context
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 4
```kotlin
import com.example.delivery.R
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 5
```kotlin
import com.example.delivery.navigation.GoongApiConfig
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 6
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 7
```kotlin
/**
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 8
```kotlin
 * Nạp style GOONG cho MapLibre và thay API key trong style bằng BuildConfig.
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 9
```kotlin
 *
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 10
```kotlin
 * Lý do tách riêng:
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 11
```kotlin
 * - Tập trung toàn bộ logic Map Tiles API vào một chỗ.
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 12
```kotlin
 * - Không để API key hard-code trong goong_map_style.json.
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 13
```kotlin
 * - Các màn hình bản đồ chỉ cần gọi load(context).
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 14
```kotlin
 */
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 15
```kotlin
internal object GoongMapStyleLoader {
```
**Giải thích:** Khai báo object dùng làm singleton/namespace cho logic dùng chung.

### Dòng 16
```kotlin
    fun load(context: Context): String {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 17
```kotlin
        val key = GoongApiConfig.mapTilesKey
```
**Giải thích:** Biến đổi từng phần tử của danh sách sang giá trị mới.

### Dòng 18
```kotlin
        check(key.isNotBlank()) { "Thiếu GOONG_MAP_TILES_KEY" }
```
**Giải thích:** Điều kiện bảo vệ/invariant; nếu sai sẽ phát sinh lỗi để ngăn dữ liệu không hợp lệ.

### Dòng 19
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 20
```kotlin
        return context.resources
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 21
```kotlin
            .openRawResource(R.raw.goong_map_style)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 22
```kotlin
            .bufferedReader()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 23
```kotlin
            .use { it.readText() }
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 24
```kotlin
            .replace("__GOONG_MAP_TILES_KEY__", key)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 25
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 26
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

