# Phân tích từng dòng — `com/example/delivery/orderio/OrderImportCoordinator.kt`

> Tài liệu đọc/debug: mã gốc theo từng dòng + giải thích. Không dùng trực tiếp để compile.

### Dòng 1
```kotlin
package com.example.delivery.orderio
```
**Giải thích:** Khai báo package, xác định namespace của file.

### Dòng 2
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 3
```kotlin
import com.example.delivery.customer.CustomerProfile
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 4
```kotlin
import com.example.delivery.customer.customerPhoneKey
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 5
```kotlin
import com.example.delivery.model.DeliveryStatus
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 6
```kotlin
import com.example.delivery.model.DeliveryOrder
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 7
```kotlin
import com.example.delivery.model.isPickupAtWarehouse
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 8
```kotlin
import com.example.delivery.model.isTemporaryFailure
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 9
```kotlin
import com.example.delivery.model.normalizedCoordinates
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 10
```kotlin
import java.util.Locale
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 11
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 12
```kotlin
data class OrderMergeResult(
```
**Giải thích:** Khai báo lớp; gom dữ liệu hoặc hành vi liên quan vào một đơn vị.

### Dòng 13
```kotlin
    val orders: List<DeliveryOrder>,
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 14
```kotlin
    val addedOrders: List<DeliveryOrder>,
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 15
```kotlin
    val ignoredDuplicateCount: Int,
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 16
```kotlin
    val restoredProductCount: Int = 0,
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 17
```kotlin
    val reactivatedCount: Int = 0,
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 18
```kotlin
    val removedNotInLatestImportCount: Int = 0,
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 19
```kotlin
)
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 20
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 21
```kotlin
/** Ghép đơn từ file vào danh sách hiện có mà không bao giờ thay thế dữ liệu của MVĐ đã lưu. */
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 22
```kotlin
object OrderImportCoordinator {
```
**Giải thích:** Khai báo object dùng làm singleton/namespace cho logic dùng chung.

### Dòng 23
```kotlin
    /**
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 24
```kotlin
     * Nạp một danh sách MVĐ mới cho ca hiện tại. Chỉ các MVĐ có trong file được giữ trên
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 25
```kotlin
     * Chi tiết/Bản đồ; khách hàng và lịch sử không thuộc danh sách orders nên không bị xóa.
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 26
```kotlin
     */
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 27
```kotlin
    fun replaceWithImportedBatch(
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 28
```kotlin
        existingOrders: List<DeliveryOrder>,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 29
```kotlin
        importedOrders: List<DeliveryOrder>,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 30
```kotlin
        customerProfiles: List<CustomerProfile> = emptyList(),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 31
```kotlin
    ): OrderMergeResult {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 32
```kotlin
        val existingByWaybill = existingOrders.associateBy { it.waybillKey() }
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 33
```kotlin
        val accepted = mutableListOf<DeliveryOrder>()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 34
```kotlin
        val added = mutableListOf<DeliveryOrder>()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 35
```kotlin
        val temporaryIndexes = mutableListOf<Int>()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 36
```kotlin
        val importedKeys = mutableSetOf<String>()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 37
```kotlin
        var duplicates = 0
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 38
```kotlin
        var restoredProducts = 0
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 39
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 40
```kotlin
        importedOrders.forEach { imported ->
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 41
```kotlin
            val waybillKey = imported.waybillKey()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 42
```kotlin
            if (!importedKeys.add(waybillKey)) return@forEach
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 43
```kotlin
            val saved = existingByWaybill[waybillKey]
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 44
```kotlin
            if (saved == null) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 45
```kotlin
                val newOrder = imported.withCustomerAddress(customerProfiles).normalizedCoordinates()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 46
```kotlin
                accepted += newOrder
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 47
```kotlin
                added += newOrder
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 48
```kotlin
            } else {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 49
```kotlin
                duplicates++
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 50
```kotlin
                val preserved = if (saved.product.isBlank() && imported.product.isNotBlank()) {
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 51
```kotlin
                    restoredProducts++
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 52
```kotlin
                    saved.copy(product = imported.product.trim())
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 53
```kotlin
                } else {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 54
```kotlin
                    saved
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 55
```kotlin
                }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 56
```kotlin
                accepted += preserved
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 57
```kotlin
                if (preserved.isTemporaryFailure() || preserved.isPickupAtWarehouse()) temporaryIndexes += accepted.lastIndex
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 58
```kotlin
            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 59
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 60
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 61
```kotlin
        // Nhập đơn không tự đánh STT. Kể cả đơn có tọa độ hoặc được kích hoạt lại,
```
**Giải thích:** Chú thích hiện có; không tạo hành vi chạy.

### Dòng 62
```kotlin
        // người dùng phải chủ động tạo/cập nhật tuyến mới để app sinh STT.
```
**Giải thích:** Chú thích hiện có; không tạo hành vi chạy.

### Dòng 63
```kotlin
        temporaryIndexes.forEach { index ->
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 64
```kotlin
            val order = accepted[index]
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 65
```kotlin
            accepted[index] = order.copy(
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 66
```kotlin
                status = DeliveryStatus.TT500,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 67
```kotlin
                sequence = 0,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 68
```kotlin
                sequenceLabel = null,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 69
```kotlin
                requiresRedelivery = false,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 70
```kotlin
                wasRedelivered = false,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 71
```kotlin
                failureReason = null,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 72
```kotlin
            )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 73
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 74
```kotlin
        accepted.indices.forEach { index ->
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 75
```kotlin
            accepted[index] = accepted[index].copy(sequence = 0, sequenceLabel = null)
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 76
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 77
```kotlin
        val removed = existingOrders.count { it.waybillKey() !in importedKeys }
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 78
```kotlin
        return OrderMergeResult(
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 79
```kotlin
            orders = accepted,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 80
```kotlin
            addedOrders = added,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 81
```kotlin
            ignoredDuplicateCount = duplicates,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 82
```kotlin
            restoredProductCount = restoredProducts,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 83
```kotlin
            reactivatedCount = temporaryIndexes.size,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 84
```kotlin
            removedNotInLatestImportCount = removed,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 85
```kotlin
        )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 86
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 87
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 88
```kotlin
    fun appendNew(
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 89
```kotlin
        existingOrders: List<DeliveryOrder>,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 90
```kotlin
        importedOrders: List<DeliveryOrder>,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 91
```kotlin
        customerProfiles: List<CustomerProfile> = emptyList(),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 92
```kotlin
    ): OrderMergeResult {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 93
```kotlin
        val mergedOrders = existingOrders.toMutableList()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 94
```kotlin
        val indexByWaybill = existingOrders.mapIndexed { index, order -> order.waybillKey() to index }.toMap().toMutableMap()
```
**Giải thích:** Biến đổi từng phần tử của danh sách sang giá trị mới.

### Dòng 95
```kotlin
        val added = mutableListOf<DeliveryOrder>()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 96
```kotlin
        var duplicates = 0
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 97
```kotlin
        var restoredProducts = 0
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 98
```kotlin
        importedOrders.forEach { imported ->
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 99
```kotlin
            val waybillKey = imported.waybillKey()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 100
```kotlin
            val existingIndex = indexByWaybill[waybillKey]
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 101
```kotlin
            if (existingIndex == null) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 102
```kotlin
                val accepted = imported.withCustomerAddress(customerProfiles).normalizedCoordinates()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 103
```kotlin
                indexByWaybill[waybillKey] = mergedOrders.size
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 104
```kotlin
                mergedOrders += accepted
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 105
```kotlin
                added += accepted
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 106
```kotlin
            } else {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 107
```kotlin
                duplicates++
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 108
```kotlin
                val existing = mergedOrders[existingIndex]
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 109
```kotlin
                if (existing.product.isBlank() && imported.product.isNotBlank()) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 110
```kotlin
                    mergedOrders[existingIndex] = existing.copy(product = imported.product.trim())
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 111
```kotlin
                    restoredProducts++
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 112
```kotlin
                }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 113
```kotlin
            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 114
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 115
```kotlin
        return OrderMergeResult(mergedOrders, added, duplicates, restoredProducts)
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 116
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 117
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 118
```kotlin
    private fun DeliveryOrder.waybillKey(): String = waybill.trim().lowercase(Locale.ROOT)
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 119
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 120
```kotlin
    private fun DeliveryOrder.withCustomerAddress(profiles: List<CustomerProfile>): DeliveryOrder {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 121
```kotlin
        val targetPhone = phone.customerPhoneKey()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 122
```kotlin
        if (targetPhone.isBlank()) return this
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 123
```kotlin
        val matchedProfile = profiles.firstOrNull { profile ->
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 124
```kotlin
            profile.phones.any { savedPhone -> savedPhone.number.customerPhoneKey() == targetPhone }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 125
```kotlin
        } ?: return this
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 126
```kotlin
        val savedAddress = matchedProfile.primaryAddress
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 127
```kotlin
        if (savedAddress.address.isBlank()) return this
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 128
```kotlin
        return copy(
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 129
```kotlin
            address = savedAddress.address,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 130
```kotlin
            latitude = savedAddress.latitude ?: latitude,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 131
```kotlin
            longitude = savedAddress.longitude ?: longitude,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 132
```kotlin
        )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 133
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 134
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 135
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

