# Phân tích từng dòng — `com/example/delivery/orderio/OrderFileCodec.kt`

> Tài liệu đọc/debug: mã gốc theo từng dòng + giải thích. Không dùng trực tiếp để compile.

### Dòng 1
```kotlin
package com.example.delivery.orderio
```
**Giải thích:** Khai báo package, xác định namespace của file.

### Dòng 2
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 3
```kotlin
import android.content.Context
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 4
```kotlin
import com.example.delivery.model.DeliveryFailureReason
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 5
```kotlin
import com.example.delivery.model.DeliveryOrder
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 6
```kotlin
import com.example.delivery.model.sequenceText
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 7
```kotlin
import com.example.delivery.model.DeliveryStatus
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 8
```kotlin
import org.json.JSONArray
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 9
```kotlin
import org.json.JSONObject
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 10
```kotlin
import org.w3c.dom.Element
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 11
```kotlin
import java.io.ByteArrayInputStream
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 12
```kotlin
import java.io.InputStream
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 13
```kotlin
import java.nio.charset.StandardCharsets
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 14
```kotlin
import java.text.Normalizer
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 15
```kotlin
import java.util.Locale
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 16
```kotlin
import java.util.zip.ZipInputStream
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 17
```kotlin
import javax.xml.parsers.DocumentBuilderFactory
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 18
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 19
```kotlin
private fun String.isValidSequenceLabel(): Boolean {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 20
```kotlin
    val parts = trim().split('.', limit = 2)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 21
```kotlin
    return parts.size == 2 && parts[0].toIntOrNull()?.let { it > 0 } == true &&
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 22
```kotlin
        (parts[1].equals("n", true) || parts[1].toIntOrNull()?.let { it > 0 } == true)
```
**Giải thích:** Xử lý giá trị nullable an toàn; khối chỉ chạy khi giá trị tồn tại.

### Dòng 23
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 24
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 25
```kotlin
data class OrderImportResult(
```
**Giải thích:** Khai báo lớp; gom dữ liệu hoặc hành vi liên quan vào một đơn vị.

### Dòng 26
```kotlin
    val orders: List<DeliveryOrder>,
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 27
```kotlin
    val skippedRows: Int,
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 28
```kotlin
)
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 29
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 30
```kotlin
/** Đọc danh sách đơn từ CSV, TXT hoặc bảng tính XLSX đầu tiên trong tệp. */
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 31
```kotlin
object OrderFileCodec {
```
**Giải thích:** Khai báo object dùng làm singleton/namespace cho logic dùng chung.

### Dòng 32
```kotlin
    private val headerAliases = mapOf(
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 33
```kotlin
        "waybill" to setOf("mavandon", "waybill", "tracking", "madon", "orderid"),
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 34
```kotlin
        "customer" to setOf("tenkhachhang", "khachhang", "customer", "nguoinhan", "tennguoinhan"),
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 35
```kotlin
        "phone" to setOf("sdt", "sodienthoai", "phone", "mobile", "dienthoai"),
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 36
```kotlin
        "address" to setOf("diachi", "address", "diachinguoinhan"),
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 37
```kotlin
        "product" to setOf("hanghoa", "sanpham", "product", "noidung", "tenhang", "mathang", "tenhanghoa", "tensanpham", "motahang", "motasanpham", "chitietsanpham", "thongtinhanghoa", "item"),
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 38
```kotlin
        "cod" to setOf("cod", "sotien", "tiencod", "amount", "tienthu", "thanhtoan"),
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 39
```kotlin
        "service" to setOf("dichvu", "service"),
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 40
```kotlin
        "status" to setOf("trangthai", "status"),
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 41
```kotlin
        "sequence" to setOf("stt", "sequence", "thutu"),
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 42
```kotlin
        "latitude" to setOf("latitude", "lat", "vido"),
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 43
```kotlin
        "longitude" to setOf("longitude", "lng", "lon", "kinhdo"),
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 44
```kotlin
        "requiresRedelivery" to setOf("giaolai", "requiresredelivery"),
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 45
```kotlin
        "wasRedelivered" to setOf("dagiaolai", "wasredelivered"),
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 46
```kotlin
        "failureReason" to setOf("lydothatbai", "failurereason", "reason"),
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 47
```kotlin
        "failureCount" to setOf("solanthatbai", "failurecount", "attempts"),
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 48
```kotlin
        "delivered" to setOf("dagiao", "delivered"),
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 49
```kotlin
    )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 50
```kotlin
    private val defaultColumnKeys = listOf("waybill", "customer", "phone", "address", "product", "cod", "service", "status", "sequence", "latitude", "longitude", "requiresRedelivery", "wasRedelivered", "failureReason", "failureCount", "delivered")
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 51
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 52
```kotlin
    fun import(fileName: String, input: InputStream): OrderImportResult {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 53
```kotlin
        val extension = fileName.substringAfterLast('.', "").lowercase(Locale.ROOT)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 54
```kotlin
        val rows = when (extension) {
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 55
```kotlin
            "csv", "txt" -> parseDelimited(input.readBytes().toString(StandardCharsets.UTF_8))
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 56
```kotlin
            "xlsx" -> parseXlsx(input)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 57
```kotlin
            else -> error("Chỉ hỗ trợ tệp CSV, XLSX hoặc TXT.")
```
**Giải thích:** Nhánh thay thế khi điều kiện if trước đó sai.

### Dòng 58
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 59
```kotlin
        return rows.toOrders()
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 60
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 61
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 62
```kotlin
    fun exportCsv(orders: List<DeliveryOrder>): String = buildString {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 63
```kotlin
        append('\uFEFF')
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 64
```kotlin
        appendCsvRow(listOf("Mã vận đơn", "Tên khách hàng", "SĐT", "Địa chỉ", "Hàng hóa", "COD", "Dịch vụ", "Trạng thái", "STT", "Vĩ độ", "Kinh độ", "Giao lại", "Đã giao lại", "Lý do thất bại", "Số lần thất bại", "Đã giao"))
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 65
```kotlin
        orders.forEach { order ->
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 66
```kotlin
            appendCsvRow(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 67
```kotlin
                listOf(
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 68
```kotlin
                    order.waybill,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 69
```kotlin
                    order.customer,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 70
```kotlin
                    order.phone,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 71
```kotlin
                    order.address,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 72
```kotlin
                    order.product,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 73
```kotlin
                    order.cod.toString(),
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 74
```kotlin
                    order.service,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 75
```kotlin
                    order.status.name,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 76
```kotlin
                    order.sequenceText(),
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 77
```kotlin
                    order.latitude.toString(),
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 78
```kotlin
                    order.longitude.toString(),
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 79
```kotlin
                    order.requiresRedelivery.toString(),
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 80
```kotlin
                    order.wasRedelivered.toString(),
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 81
```kotlin
                    order.failureReason?.name.orEmpty(),
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 82
```kotlin
                    order.failureCount.toString(),
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 83
```kotlin
                    order.delivered.toString(),
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 84
```kotlin
                ),
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 85
```kotlin
            )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 86
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 87
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 88
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 89
```kotlin
    internal fun parseDelimited(rawText: String): List<List<String>> {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 90
```kotlin
        val text = rawText.removePrefix("\uFEFF")
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 91
```kotlin
        val firstLine = text.lineSequence().firstOrNull { it.isNotBlank() }.orEmpty()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 92
```kotlin
        val separator = listOf(',', ';', '\t', '|').maxByOrNull { candidate -> firstLine.count { it == candidate } } ?: ','
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 93
```kotlin
        val rows = mutableListOf<List<String>>()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 94
```kotlin
        val cells = mutableListOf<String>()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 95
```kotlin
        val value = StringBuilder()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 96
```kotlin
        var quoted = false
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 97
```kotlin
        var index = 0
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 98
```kotlin
        fun finishRow() {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 99
```kotlin
            cells += value.toString().trim()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 100
```kotlin
            value.clear()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 101
```kotlin
            if (cells.any { it.isNotBlank() }) rows += cells.toList()
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 102
```kotlin
            cells.clear()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 103
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 104
```kotlin
        while (index < text.length) {
```
**Giải thích:** Vòng lặp; thực hiện khối nhiều lần theo tập dữ liệu/điều kiện.

### Dòng 105
```kotlin
            when (val character = text[index]) {
```
**Giải thích:** Rẽ nhánh nhiều trường hợp dựa trên giá trị/điều kiện.

### Dòng 106
```kotlin
                '"' -> {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 107
```kotlin
                    if (quoted && index + 1 < text.length && text[index + 1] == '"') {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 108
```kotlin
                        value.append('"')
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 109
```kotlin
                        index++
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 110
```kotlin
                    } else if (quoted) {
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 111
```kotlin
                        quoted = false
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 112
```kotlin
                    } else if (value.isEmpty()) {
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 113
```kotlin
                        quoted = true
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 114
```kotlin
                    } else {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 115
```kotlin
                        value.append(character)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 116
```kotlin
                    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 117
```kotlin
                }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 118
```kotlin
                separator -> if (quoted) value.append(character) else {
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 119
```kotlin
                    cells += value.toString().trim()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 120
```kotlin
                    value.clear()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 121
```kotlin
                }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 122
```kotlin
                '\n' -> if (quoted) value.append(character) else finishRow()
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 123
```kotlin
                '\r' -> Unit
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 124
```kotlin
                else -> value.append(character)
```
**Giải thích:** Nhánh thay thế khi điều kiện if trước đó sai.

### Dòng 125
```kotlin
            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 126
```kotlin
            index++
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 127
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 128
```kotlin
        if (value.isNotEmpty() || cells.isNotEmpty()) finishRow()
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 129
```kotlin
        return rows
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 130
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 131
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 132
```kotlin
    private fun List<List<String>>.toOrders(): OrderImportResult {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 133
```kotlin
        val usableRows = filter { row -> row.any { it.isNotBlank() } }
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 134
```kotlin
        require(usableRows.isNotEmpty()) { "Tệp đơn hàng đang trống." }
```
**Giải thích:** Điều kiện bảo vệ/invariant; nếu sai sẽ phát sinh lỗi để ngăn dữ liệu không hợp lệ.

### Dòng 135
```kotlin
        val firstRowKeys = usableRows.first().map(::normalizeHeader)
```
**Giải thích:** Biến đổi từng phần tử của danh sách sang giá trị mới.

### Dòng 136
```kotlin
        val hasHeader = firstRowKeys.any { key -> headerAliases.values.any { key in it } }
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 137
```kotlin
        val mapping = if (hasHeader) {
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 138
```kotlin
            headerAliases.mapNotNull { (canonical, aliases) ->
```
**Giải thích:** Biến đổi từng phần tử của danh sách sang giá trị mới.

### Dòng 139
```kotlin
                firstRowKeys.indexOfFirst { header ->
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 140
```kotlin
                    header in aliases || aliases.any { alias -> alias.length >= 4 && header.contains(alias) }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 141
```kotlin
                }.takeIf { it >= 0 }?.let { canonical to it }
```
**Giải thích:** Chọn/loại giá trị theo điều kiện, trả null nếu không thỏa.

### Dòng 142
```kotlin
            }.toMap()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 143
```kotlin
        } else defaultColumnKeys.mapIndexed { index, key -> key to index }.toMap()
```
**Giải thích:** Biến đổi từng phần tử của danh sách sang giá trị mới.

### Dòng 144
```kotlin
        val sourceRows = if (hasHeader) usableRows.drop(1) else usableRows
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 145
```kotlin
        var skipped = 0
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 146
```kotlin
        val parsed = sourceRows.mapNotNull { row ->
```
**Giải thích:** Biến đổi từng phần tử của danh sách sang giá trị mới.

### Dòng 147
```kotlin
            fun value(key: String): String = mapping[key]?.let { row.getOrNull(it).orEmpty().trim() }.orEmpty()
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 148
```kotlin
            fun productValue(): String = value("product").ifBlank {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 149
```kotlin
                val productColumn = firstRowKeys.indexOfFirst { header ->
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 150
```kotlin
                    header in headerAliases.getValue("product") || header.contains("mathang") || header.contains("hanghoa")
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 151
```kotlin
                }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 152
```kotlin
                row.getOrNull(productColumn).orEmpty().trim()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 153
```kotlin
            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 154
```kotlin
            val waybill = value("waybill")
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 155
```kotlin
            if (waybill.isBlank()) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 156
```kotlin
                skipped++
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 157
```kotlin
                null
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 158
```kotlin
            } else {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 159
```kotlin
                DeliveryOrder(
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 160
```kotlin
                    waybill = waybill,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 161
```kotlin
                    customer = value("customer"),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 162
```kotlin
                    phone = value("phone"),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 163
```kotlin
                    address = value("address"),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 164
```kotlin
                    product = productValue(),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 165
```kotlin
                    cod = value("cod").toMoney(),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 166
```kotlin
                    service = value("service"),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 167
```kotlin
                    status = value("status").toDeliveryStatus(),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 168
```kotlin
                    sequence = value("sequence").substringBefore('.').toIntOrNull() ?: 0,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 169
```kotlin
                    latitude = value("latitude").toCoordinate() ?: 0.0,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 170
```kotlin
                    longitude = value("longitude").toCoordinate() ?: 0.0,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 171
```kotlin
                    requiresRedelivery = value("requiresRedelivery").toBooleanValue(),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 172
```kotlin
                    wasRedelivered = value("wasRedelivered").toBooleanValue(),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 173
```kotlin
                    failureReason = DeliveryFailureReason.entries.firstOrNull { it.name.equals(value("failureReason"), ignoreCase = true) },
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 174
```kotlin
                    failureCount = value("failureCount").toIntOrNull()?.coerceAtLeast(0) ?: 0,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 175
```kotlin
                    delivered = value("delivered").toBooleanValue() || value("status").equals("TT515", ignoreCase = true),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 176
```kotlin
                    sequenceLabel = value("sequence").takeIf { it.contains('.') && it.isValidSequenceLabel() },
```
**Giải thích:** Chọn/loại giá trị theo điều kiện, trả null nếu không thỏa.

### Dòng 177
```kotlin
                )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 178
```kotlin
            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 179
```kotlin
        }.distinctBy { it.waybill }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 180
```kotlin
        require(parsed.isNotEmpty()) { "Không tìm thấy Mã vận đơn hợp lệ. Hãy dùng cột 'Mã vận đơn' hoặc để mã ở cột đầu tiên." }
```
**Giải thích:** Điều kiện bảo vệ/invariant; nếu sai sẽ phát sinh lỗi để ngăn dữ liệu không hợp lệ.

### Dòng 181
```kotlin
        return OrderImportResult(parsed, skipped + (sourceRows.size - parsed.size - skipped).coerceAtLeast(0))
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 182
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 183
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 184
```kotlin
    private fun parseXlsx(input: InputStream): List<List<String>> {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 185
```kotlin
        var sharedStrings = emptyList<String>()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 186
```kotlin
        var sheetBytes: ByteArray? = null
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 187
```kotlin
        ZipInputStream(input.buffered()).use { zip ->
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 188
```kotlin
            while (true) {
```
**Giải thích:** Vòng lặp; thực hiện khối nhiều lần theo tập dữ liệu/điều kiện.

### Dòng 189
```kotlin
                val entry = zip.nextEntry ?: break
```
**Giải thích:** Xử lý lỗi/ngoại lệ; kiểm tra nhánh này khi thao tác mạng hoặc hệ thống thất bại.

### Dòng 190
```kotlin
                when {
```
**Giải thích:** Rẽ nhánh nhiều trường hợp dựa trên giá trị/điều kiện.

### Dòng 191
```kotlin
                    entry.name == "xl/sharedStrings.xml" -> sharedStrings = parseSharedStrings(zip.readBytes())
```
**Giải thích:** Xử lý lỗi/ngoại lệ; kiểm tra nhánh này khi thao tác mạng hoặc hệ thống thất bại.

### Dòng 192
```kotlin
                    entry.name.startsWith("xl/worksheets/") && entry.name.endsWith(".xml") && sheetBytes == null -> sheetBytes = zip.readBytes()
```
**Giải thích:** Xử lý lỗi/ngoại lệ; kiểm tra nhánh này khi thao tác mạng hoặc hệ thống thất bại.

### Dòng 193
```kotlin
                }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 194
```kotlin
                zip.closeEntry()
```
**Giải thích:** Xử lý lỗi/ngoại lệ; kiểm tra nhánh này khi thao tác mạng hoặc hệ thống thất bại.

### Dòng 195
```kotlin
            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 196
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 197
```kotlin
        return parseWorksheet(sheetBytes ?: error("Không tìm thấy bảng tính trong tệp XLSX."), sharedStrings)
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 198
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 199
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 200
```kotlin
    private fun parseSharedStrings(bytes: ByteArray): List<String> {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 201
```kotlin
        val items = xmlDocument(bytes).getElementsByTagName("si")
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 202
```kotlin
        return List(items.length) { index -> items.item(index).textContent.orEmpty() }
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 203
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 204
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 205
```kotlin
    private fun parseWorksheet(bytes: ByteArray, sharedStrings: List<String>): List<List<String>> {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 206
```kotlin
        val rowNodes = xmlDocument(bytes).getElementsByTagName("row")
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 207
```kotlin
        val rows = mutableListOf<List<String>>()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 208
```kotlin
        for (rowIndex in 0 until rowNodes.length) {
```
**Giải thích:** Vòng lặp; thực hiện khối nhiều lần theo tập dữ liệu/điều kiện.

### Dòng 209
```kotlin
            val row = rowNodes.item(rowIndex) as? Element ?: continue
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 210
```kotlin
            val rowValues = mutableMapOf<Int, String>()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 211
```kotlin
            val cells = row.getElementsByTagName("c")
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 212
```kotlin
            for (cellIndex in 0 until cells.length) {
```
**Giải thích:** Vòng lặp; thực hiện khối nhiều lần theo tập dữ liệu/điều kiện.

### Dòng 213
```kotlin
                val cell = cells.item(cellIndex) as? Element ?: continue
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 214
```kotlin
                val column = cell.getAttribute("r").toColumnIndex().takeIf { it >= 0 } ?: rowValues.size
```
**Giải thích:** Chọn/loại giá trị theo điều kiện, trả null nếu không thỏa.

### Dòng 215
```kotlin
                val raw = cell.textContent.orEmpty()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 216
```kotlin
                val resolved = if (cell.getAttribute("t") == "s") raw.toIntOrNull()?.let { sharedStrings.getOrNull(it) }.orEmpty() else raw
```
**Giải thích:** Xử lý giá trị nullable an toàn; khối chỉ chạy khi giá trị tồn tại.

### Dòng 217
```kotlin
                rowValues[column] = resolved
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 218
```kotlin
            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 219
```kotlin
            if (rowValues.isNotEmpty()) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 220
```kotlin
                val lastColumn = rowValues.keys.maxOrNull() ?: -1
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 221
```kotlin
                rows += List(lastColumn + 1) { column -> rowValues[column].orEmpty() }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 222
```kotlin
            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 223
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 224
```kotlin
        return rows
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 225
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 226
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 227
```kotlin
    private fun xmlDocument(bytes: ByteArray) = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(ByteArrayInputStream(bytes))
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 228
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 229
```kotlin
    private fun String.toColumnIndex(): Int {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 230
```kotlin
        val letters = takeWhile(Char::isLetter).uppercase(Locale.ROOT)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 231
```kotlin
        if (letters.isBlank()) return -1
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 232
```kotlin
        return letters.fold(0) { result, character -> result * 26 + (character - 'A' + 1) } - 1
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 233
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 234
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 235
```kotlin
    private fun String.toMoney(): Long = filter { it.isDigit() || it == '-' }.toLongOrNull() ?: 0L
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 236
```kotlin
    private fun String.toCoordinate(): Double? = trim().replace(',', '.').toDoubleOrNull()
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 237
```kotlin
    private fun String.toDeliveryStatus(): DeliveryStatus = DeliveryStatus.entries.firstOrNull { it.name.equals(trim(), ignoreCase = true) } ?: DeliveryStatus.TT500
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 238
```kotlin
    private fun String.toBooleanValue(): Boolean = trim().lowercase(Locale.ROOT) in setOf("true", "1", "yes", "co", "có")
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 239
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 240
```kotlin
    private fun normalizeHeader(value: String): String = Normalizer.normalize(value.trim(), Normalizer.Form.NFD)
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 241
```kotlin
        .replace("\\p{Mn}+".toRegex(), "")
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 242
```kotlin
        .lowercase(Locale.ROOT)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 243
```kotlin
        .replace('đ', 'd')
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 244
```kotlin
        .replace("[^a-z0-9]".toRegex(), "")
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 245
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 246
```kotlin
    private fun StringBuilder.appendCsvRow(values: List<String>) {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 247
```kotlin
        append(values.joinToString(",") { value -> "\"${value.replace("\"", "\"\"")}\"" })
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 248
```kotlin
        append("\r\n")
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 249
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 250
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 251
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 252
```kotlin
/** Lưu danh sách đơn được nhập để vẫn còn sau khi đóng và mở lại ứng dụng. */
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 253
```kotlin
object DeliveryOrderStore {
```
**Giải thích:** Khai báo object dùng làm singleton/namespace cho logic dùng chung.

### Dòng 254
```kotlin
    private const val PREF = "delivery_orders_v1"
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 255
```kotlin
    private const val KEY = "items"
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 256
```kotlin
    private const val INITIALIZED_KEY = "initialized"
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 257
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 258
```kotlin
    fun hasBeenInitialized(context: Context): Boolean =
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 259
```kotlin
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getBoolean(INITIALIZED_KEY, false)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 260
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 261
```kotlin
    fun load(context: Context): List<DeliveryOrder> = runCatching {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 262
```kotlin
        val array = JSONArray(context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, "[]"))
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 263
```kotlin
        List(array.length()) { array.getJSONObject(it).toOrder() }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 264
```kotlin
    }.getOrDefault(emptyList())
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 265
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 266
```kotlin
    fun replace(context: Context, values: List<DeliveryOrder>) {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 267
```kotlin
        val uniqueOrders = values.filter { it.waybill.isNotBlank() }.distinctBy { it.waybill }
```
**Giải thích:** Lọc dữ liệu theo điều kiện; chỉ giữ phần tử thỏa điều kiện.

### Dòng 268
```kotlin
        val saved = context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 269
```kotlin
            .putString(KEY, JSONArray(uniqueOrders.map { it.toJson() }).toString())
```
**Giải thích:** Biến đổi từng phần tử của danh sách sang giá trị mới.

### Dòng 270
```kotlin
            .putBoolean(INITIALIZED_KEY, true)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 271
```kotlin
            .commit()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 272
```kotlin
        check(saved) { "Không thể lưu danh sách đơn hàng." }
```
**Giải thích:** Điều kiện bảo vệ/invariant; nếu sai sẽ phát sinh lỗi để ngăn dữ liệu không hợp lệ.

### Dòng 273
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 274
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 275
```kotlin
    private fun String.isValidSequenceLabel(): Boolean {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 276
```kotlin
        val parts = trim().split('.', limit = 2)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 277
```kotlin
        return parts.size == 2 && parts[0].toIntOrNull()?.let { it > 0 } == true &&
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 278
```kotlin
            (parts[1].equals("n", true) || parts[1].toIntOrNull()?.let { it > 0 } == true)
```
**Giải thích:** Xử lý giá trị nullable an toàn; khối chỉ chạy khi giá trị tồn tại.

### Dòng 279
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 280
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 281
```kotlin
    private fun DeliveryOrder.toJson() = JSONObject()
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 282
```kotlin
        .put("waybill", waybill)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 283
```kotlin
        .put("customer", customer)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 284
```kotlin
        .put("phone", phone)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 285
```kotlin
        .put("address", address)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 286
```kotlin
        .put("product", product)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 287
```kotlin
        .put("cod", cod)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 288
```kotlin
        .put("service", service)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 289
```kotlin
        .put("status", status.name)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 290
```kotlin
        .put("sequence", sequence)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 291
```kotlin
        .put("sequenceLabel", sequenceLabel)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 292
```kotlin
        .put("latitude", latitude)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 293
```kotlin
        .put("longitude", longitude)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 294
```kotlin
        .put("requiresRedelivery", requiresRedelivery)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 295
```kotlin
        .put("wasRedelivered", wasRedelivered)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 296
```kotlin
        .put("failureReason", failureReason?.name)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 297
```kotlin
        .put("failureCount", failureCount)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 298
```kotlin
        .put("delivered", delivered)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 299
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 300
```kotlin
    private fun JSONObject.toOrder() = DeliveryOrder(
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 301
```kotlin
        waybill = getString("waybill"),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 302
```kotlin
        customer = optString("customer"),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 303
```kotlin
        phone = optString("phone"),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 304
```kotlin
        address = optString("address"),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 305
```kotlin
        product = optString("product"),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 306
```kotlin
        cod = optLong("cod"),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 307
```kotlin
        service = optString("service"),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 308
```kotlin
        status = optString("status").toDeliveryStatus(),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 309
```kotlin
        sequence = optString("sequence").substringBefore('.').toIntOrNull() ?: optInt("sequence"),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 310
```kotlin
        latitude = optDouble("latitude", 10.7769),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 311
```kotlin
        longitude = optDouble("longitude", 106.7009),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 312
```kotlin
        requiresRedelivery = optBoolean("requiresRedelivery"),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 313
```kotlin
        wasRedelivered = optBoolean("wasRedelivered"),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 314
```kotlin
        failureReason = DeliveryFailureReason.entries.firstOrNull { it.name.equals(optString("failureReason"), ignoreCase = true) },
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 315
```kotlin
        failureCount = optInt("failureCount").coerceAtLeast(0),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 316
```kotlin
        delivered = optBoolean("delivered", optString("status").equals("TT515", ignoreCase = true)),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 317
```kotlin
        sequenceLabel = optString("sequenceLabel").takeIf { it.isValidSequenceLabel() },
```
**Giải thích:** Chọn/loại giá trị theo điều kiện, trả null nếu không thỏa.

### Dòng 318
```kotlin
    )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 319
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 320
```kotlin
    private fun String.toDeliveryStatus(): DeliveryStatus = DeliveryStatus.entries.firstOrNull { it.name.equals(trim(), ignoreCase = true) } ?: DeliveryStatus.TT500
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 321
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

