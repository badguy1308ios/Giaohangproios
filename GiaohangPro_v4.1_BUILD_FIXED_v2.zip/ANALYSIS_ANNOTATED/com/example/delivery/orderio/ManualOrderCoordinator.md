# Phân tích từng dòng — `com/example/delivery/orderio/ManualOrderCoordinator.kt`

> Tài liệu đọc/debug: mã gốc theo từng dòng + giải thích. Không dùng trực tiếp để compile.

### Dòng 1
```kotlin
package com.example.delivery.orderio
```
**Giải thích:** Khai báo package, xác định namespace của file.

### Dòng 2
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 3
```kotlin
import com.example.delivery.customer.CustomerProfile
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 4
```kotlin
import com.example.delivery.model.DeliveryOrder
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 5
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 6
```kotlin
/** Áp dụng quy tắc thêm tay: chỉ đơn khớp SĐT có tọa độ đã lưu mới được gán số cuối tuyến. */
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 7
```kotlin
object ManualOrderCoordinator {
```
**Giải thích:** Khai báo object dùng làm singleton/namespace cho logic dùng chung.

### Dòng 8
```kotlin
    fun place(draft: DeliveryOrder, profiles: List<CustomerProfile>, existingOrders: List<DeliveryOrder>, routeActive: Boolean = true): DeliveryOrder {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 9
```kotlin
        require(draft.waybill.trim().isNotBlank()) { "Vui lòng nhập mã vận đơn." }
```
**Giải thích:** Điều kiện bảo vệ/invariant; nếu sai sẽ phát sinh lỗi để ngăn dữ liệu không hợp lệ.

### Dòng 10
```kotlin
        require(existingOrders.none { it.waybill.equals(draft.waybill.trim(), ignoreCase = true) }) { "Mã vận đơn đã tồn tại." }
```
**Giải thích:** Điều kiện bảo vệ/invariant; nếu sai sẽ phát sinh lỗi để ngăn dữ liệu không hợp lệ.

### Dòng 11
```kotlin
        val phoneKey = draft.phone.phoneKey()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 12
```kotlin
        val profile = profiles.firstOrNull { candidate ->
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 13
```kotlin
            phoneKey.isNotBlank() && candidate.phones.any { it.number.phoneKey() == phoneKey }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 14
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 15
```kotlin
        val locatedAddress = profile?.addresses?.firstOrNull { address ->
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 16
```kotlin
            address.latitude?.isFinite() == true && address.longitude?.isFinite() == true
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 17
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 18
```kotlin
        val hasCoordinates = locatedAddress != null
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 19
```kotlin
        return draft.copy(
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 20
```kotlin
            waybill = draft.waybill.trim(),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 21
```kotlin
            customer = draft.customer.trim().ifBlank { profile?.displayName.orEmpty() },
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 22
```kotlin
            phone = draft.phone.trim(),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 23
```kotlin
            address = draft.address.trim().ifBlank { locatedAddress?.address.orEmpty() },
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 24
```kotlin
            latitude = locatedAddress?.latitude ?: 0.0,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 25
```kotlin
            longitude = locatedAddress?.longitude ?: 0.0,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 26
```kotlin
            // Đơn mới không tự nối vào tuyến; người dùng chủ động chèn STT bằng Sửa/Lưu.
```
**Giải thích:** Chú thích hiện có; không tạo hành vi chạy.

### Dòng 27
```kotlin
            sequence = 0,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 28
```kotlin
        )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 29
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 30
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 31
```kotlin
    private fun String.phoneKey(): String = filter(Char::isDigit)
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 32
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

