# Phân tích từng dòng — `com/example/delivery/orderio/SttSequenceFileCodec.kt`

> Tài liệu đọc/debug: mã gốc theo từng dòng + giải thích. Không dùng trực tiếp để compile.

### Dòng 1
```kotlin
package com.example.delivery.orderio
```
**Giải thích:** Khai báo package, xác định namespace của file.

### Dòng 2
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 3
```kotlin
import com.example.delivery.model.DeliveryOrder
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 4
```kotlin
import com.example.delivery.model.isPickupAtWarehouse
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 5
```kotlin
import com.example.delivery.model.isTerminalFailure
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 6
```kotlin
import com.example.delivery.model.isTemporaryFailure
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 7
```kotlin
import java.io.InputStream
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 8
```kotlin
import java.nio.charset.StandardCharsets
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 9
```kotlin
import java.text.Normalizer
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 10
```kotlin
import java.util.Locale
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 11
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 12
```kotlin
data class SttSequenceEntry(val waybill: String, val sequence: Int)
```
**Giải thích:** Khai báo lớp; gom dữ liệu hoặc hành vi liên quan vào một đơn vị.

### Dòng 13
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 14
```kotlin
data class SttRestoreResult(
```
**Giải thích:** Khai báo lớp; gom dữ liệu hoặc hành vi liên quan vào một đơn vị.

### Dòng 15
```kotlin
    val orders: List<DeliveryOrder>,
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 16
```kotlin
    val restoredCount: Int,
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 17
```kotlin
    val skippedMissingCount: Int,
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 18
```kotlin
    val skippedStatusCount: Int,
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 19
```kotlin
)
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 20
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 21
```kotlin
object SttSequenceFileCodec {
```
**Giải thích:** Khai báo object dùng làm singleton/namespace cho logic dùng chung.

### Dòng 22
```kotlin
    fun exportCsv(orders: List<DeliveryOrder>): String = buildString {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 23
```kotlin
        append('\uFEFF')
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 24
```kotlin
        append("\"Mã vận đơn\",\"STT\"\r\n")
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 25
```kotlin
        orders.filter { it.sequence > 0 }.forEach { order ->
```
**Giải thích:** Lọc dữ liệu theo điều kiện; chỉ giữ phần tử thỏa điều kiện.

### Dòng 26
```kotlin
            appendCsvRow(order.waybill, order.sequence.toString())
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 27
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 28
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 29
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 30
```kotlin
    fun import(input: InputStream): List<SttSequenceEntry> {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 31
```kotlin
        val rows = OrderFileCodec.parseDelimited(input.readBytes().toString(StandardCharsets.UTF_8))
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 32
```kotlin
        require(rows.isNotEmpty()) { "Tệp STT đang trống." }
```
**Giải thích:** Điều kiện bảo vệ/invariant; nếu sai sẽ phát sinh lỗi để ngăn dữ liệu không hợp lệ.

### Dòng 33
```kotlin
        val first = rows.first().map { value -> value.normalizeHeader() }
```
**Giải thích:** Biến đổi từng phần tử của danh sách sang giá trị mới.

### Dòng 34
```kotlin
        val waybillIndex = first.indexOfFirst { it in setOf("mavandon", "waybill", "tracking", "madon", "orderid") }
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 35
```kotlin
        val sequenceIndex = first.indexOfFirst { it in setOf("stt", "sequence", "thutu") }
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 36
```kotlin
        val hasHeader = waybillIndex >= 0 || sequenceIndex >= 0
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 37
```kotlin
        val wb = if (hasHeader) waybillIndex else 0
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 38
```kotlin
        val seq = if (hasHeader) sequenceIndex else 1
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 39
```kotlin
        require(wb >= 0 && seq >= 0) { "Tệp STT phải có cột Mã vận đơn và STT." }
```
**Giải thích:** Điều kiện bảo vệ/invariant; nếu sai sẽ phát sinh lỗi để ngăn dữ liệu không hợp lệ.

### Dòng 40
```kotlin
        return rows.drop(if (hasHeader) 1 else 0).mapNotNull { row ->
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 41
```kotlin
            val waybill = row.getOrNull(wb).orEmpty().trim()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 42
```kotlin
            val sequence = row.getOrNull(seq)?.trim()?.toIntOrNull()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 43
```kotlin
            if (waybill.isBlank() || sequence == null || sequence <= 0) null else SttSequenceEntry(waybill, sequence)
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 44
```kotlin
        }.distinctBy { it.waybill.lowercase(Locale.ROOT) }.also {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 45
```kotlin
            require(it.isNotEmpty()) { "Không tìm thấy Mã vận đơn và STT hợp lệ." }
```
**Giải thích:** Điều kiện bảo vệ/invariant; nếu sai sẽ phát sinh lỗi để ngăn dữ liệu không hợp lệ.

### Dòng 46
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 47
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 48
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 49
```kotlin
    fun restore(orders: List<DeliveryOrder>, entries: List<SttSequenceEntry>): SttRestoreResult {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 50
```kotlin
        val byWaybill = entries.associateBy { it.waybill.trim().lowercase(Locale.ROOT) }
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 51
```kotlin
        var restored = 0
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 52
```kotlin
        var missing = 0
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 53
```kotlin
        var skipped = 0
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 54
```kotlin
        val result = orders.map { order ->
```
**Giải thích:** Biến đổi từng phần tử của danh sách sang giá trị mới.

### Dòng 55
```kotlin
            val entry = byWaybill[order.waybill.trim().lowercase(Locale.ROOT)]
```
**Giải thích:** Xử lý lỗi/ngoại lệ; kiểm tra nhánh này khi thao tác mạng hoặc hệ thống thất bại.

### Dòng 56
```kotlin
            when {
```
**Giải thích:** Rẽ nhánh nhiều trường hợp dựa trên giá trị/điều kiện.

### Dòng 57
```kotlin
                entry == null -> order
```
**Giải thích:** Xử lý lỗi/ngoại lệ; kiểm tra nhánh này khi thao tác mạng hoặc hệ thống thất bại.

### Dòng 58
```kotlin
                order.isTemporaryFailure() || order.isTerminalFailure() || order.isPickupAtWarehouse() -> {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 59
```kotlin
                    skipped++
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 60
```kotlin
                    order
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 61
```kotlin
                }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 62
```kotlin
                else -> {
```
**Giải thích:** Nhánh thay thế khi điều kiện if trước đó sai.

### Dòng 63
```kotlin
                    restored++
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 64
```kotlin
                    order.copy(sequence = entry.sequence)
```
**Giải thích:** Xử lý lỗi/ngoại lệ; kiểm tra nhánh này khi thao tác mạng hoặc hệ thống thất bại.

### Dòng 65
```kotlin
                }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 66
```kotlin
            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 67
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 68
```kotlin
        entries.forEach { entry ->
```
**Giải thích:** Xử lý lỗi/ngoại lệ; kiểm tra nhánh này khi thao tác mạng hoặc hệ thống thất bại.

### Dòng 69
```kotlin
            if (orders.none { order -> order.waybill.equals(entry.waybill, ignoreCase = true) }) missing++
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 70
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 71
```kotlin
        return SttRestoreResult(result, restored, missing, skipped)
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 72
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 73
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 74
```kotlin
    private fun String.normalizeHeader(): String = Normalizer.normalize(trim(), Normalizer.Form.NFD)
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 75
```kotlin
        .replace("\\p{Mn}+".toRegex(), "")
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 76
```kotlin
        .lowercase(Locale.ROOT)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 77
```kotlin
        .replace('đ', 'd')
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 78
```kotlin
        .replace("[^a-z0-9]".toRegex(), "")
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 79
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 80
```kotlin
    private fun StringBuilder.appendCsvRow(waybill: String, sequence: String) {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 81
```kotlin
        append("\"").append(waybill.replace("\"", "\"\""))
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 82
```kotlin
            .append("\",\"").append(sequence).append("\"\r\n")
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 83
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 84
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

