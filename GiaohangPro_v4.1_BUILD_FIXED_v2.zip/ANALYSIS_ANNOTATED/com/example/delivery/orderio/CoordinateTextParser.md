# Phân tích từng dòng — `com/example/delivery/orderio/CoordinateTextParser.kt`

> Tài liệu đọc/debug: mã gốc theo từng dòng + giải thích. Không dùng trực tiếp để compile.

### Dòng 1
```kotlin
package com.example.delivery.orderio
```
**Giải thích:** Khai báo package, xác định namespace của file.

### Dòng 2
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 3
```kotlin
data class ParsedCoordinates(val latitude: Double, val longitude: Double)
```
**Giải thích:** Khai báo lớp; gom dữ liệu hoặc hành vi liên quan vào một đơn vị.

### Dòng 4
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 5
```kotlin
/** Nhận hai số tọa độ theo thứ tự vĩ độ/kinh độ hoặc kinh độ/vĩ độ và tự xác định theo miền hợp lệ. */
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 6
```kotlin
object CoordinateTextParser {
```
**Giải thích:** Khai báo object dùng làm singleton/namespace cho logic dùng chung.

### Dòng 7
```kotlin
    private val coordinateNumber = Regex("[-+]?\\d+(?:[.,]\\d+)?")
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 8
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 9
```kotlin
    fun parse(raw: String): ParsedCoordinates? {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 10
```kotlin
        val values = values(raw)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 11
```kotlin
        if (values.size < 2) return null
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 12
```kotlin
        val first = values[0]
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 13
```kotlin
        val second = values[1]
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 14
```kotlin
        return when {
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 15
```kotlin
            first in -90.0..90.0 && second in -180.0..180.0 -> ParsedCoordinates(first, second)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 16
```kotlin
            first in -180.0..180.0 && second in -90.0..90.0 -> ParsedCoordinates(second, first)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 17
```kotlin
            else -> null
```
**Giải thích:** Nhánh thay thế khi điều kiện if trước đó sai.

### Dòng 18
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 19
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 20
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 21
```kotlin
    /** Dùng riêng cho ô Kinh độ: hiểu vị trí thứ nhất là Kinh độ, vị trí thứ hai là Vĩ độ. */
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 22
```kotlin
    fun parseLongitudeThenLatitude(raw: String): ParsedCoordinates? {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 23
```kotlin
        val values = values(raw)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 24
```kotlin
        if (values.size < 2) return null
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 25
```kotlin
        val longitude = values[0]
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 26
```kotlin
        val latitude = values[1]
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 27
```kotlin
        return ParsedCoordinates(latitude, longitude).takeIf {
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 28
```kotlin
            it.latitude in -90.0..90.0 && it.longitude in -180.0..180.0
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 29
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 30
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 31
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 32
```kotlin
    private fun values(raw: String): List<Double> = coordinateNumber.findAll(raw)
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 33
```kotlin
        .mapNotNull { match -> match.value.replace(',', '.').toDoubleOrNull() }
```
**Giải thích:** Biến đổi từng phần tử của danh sách sang giá trị mới.

### Dòng 34
```kotlin
        .take(2)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 35
```kotlin
        .toList()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 36
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

