# Phân tích từng dòng — `com/example/delivery/orderio/CoordinateUpdateCoordinator.kt`

> Tài liệu đọc/debug: mã gốc theo từng dòng + giải thích. Không dùng trực tiếp để compile.

### Dòng 1
```kotlin
package com.example.delivery.orderio
```
**Giải thích:** Khai báo package, xác định namespace của file.

### Dòng 2
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 3
```kotlin
import com.example.delivery.customer.CustomerProfile
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 4
```kotlin
import com.example.delivery.model.DeliveryOrder
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 5
```kotlin
import com.example.delivery.model.canReceiveRouteSequence
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 6
```kotlin
import com.example.delivery.model.nextActiveSequence
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 7
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 8
```kotlin
data class CoordinateUpdateRequest(
```
**Giải thích:** Khai báo lớp; gom dữ liệu hoặc hành vi liên quan vào một đơn vị.

### Dòng 9
```kotlin
    val reference: String,
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 10
```kotlin
    val latitude: Double,
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 11
```kotlin
    val longitude: Double,
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 12
```kotlin
)
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 13
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 14
```kotlin
data class CoordinateUpdateResult(
```
**Giải thích:** Khai báo lớp; gom dữ liệu hoặc hành vi liên quan vào một đơn vị.

### Dòng 15
```kotlin
    val profiles: List<CustomerProfile>,
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 16
```kotlin
    val orders: List<DeliveryOrder>,
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 17
```kotlin
    val updatedProfileIds: Set<String>,
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 18
```kotlin
    val updatedWaybills: Set<String>,
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 19
```kotlin
)
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 20
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 21
```kotlin
/** Cập nhật theo MVĐ hoặc SĐT; đơn chưa có số thứ tự được đưa vào cuối tuyến sau khi có tọa độ. */
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 22
```kotlin
object CoordinateUpdateCoordinator {
```
**Giải thích:** Khai báo object dùng làm singleton/namespace cho logic dùng chung.

### Dòng 23
```kotlin
    fun update(
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 24
```kotlin
        request: CoordinateUpdateRequest,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 25
```kotlin
        profiles: List<CustomerProfile>,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 26
```kotlin
        orders: List<DeliveryOrder>,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 27
```kotlin
    ): CoordinateUpdateResult {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 28
```kotlin
        require(request.reference.trim().isNotBlank()) { "Vui lòng nhập SĐT hoặc mã vận đơn." }
```
**Giải thích:** Điều kiện bảo vệ/invariant; nếu sai sẽ phát sinh lỗi để ngăn dữ liệu không hợp lệ.

### Dòng 29
```kotlin
        require(request.latitude in -90.0..90.0 && request.longitude in -180.0..180.0) { "Tọa độ không hợp lệ." }
```
**Giải thích:** Điều kiện bảo vệ/invariant; nếu sai sẽ phát sinh lỗi để ngăn dữ liệu không hợp lệ.

### Dòng 30
```kotlin
        val reference = request.reference.trim()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 31
```kotlin
        val phoneReference = normalizePhone(reference)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 32
```kotlin
        val matchedOrders = orders.filter { order ->
```
**Giải thích:** Lọc dữ liệu theo điều kiện; chỉ giữ phần tử thỏa điều kiện.

### Dòng 33
```kotlin
            order.waybill.equals(reference, ignoreCase = true) ||
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 34
```kotlin
                (phoneReference.isNotBlank() && normalizePhone(order.phone) == phoneReference)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 35
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 36
```kotlin
        val relevantPhones = (matchedOrders.map { it.phone } + reference.takeIf { phoneReference.isNotBlank() }.orEmpty())
```
**Giải thích:** Biến đổi từng phần tử của danh sách sang giá trị mới.

### Dòng 37
```kotlin
            .map(::normalizePhone)
```
**Giải thích:** Biến đổi từng phần tử của danh sách sang giá trị mới.

### Dòng 38
```kotlin
            .filter(String::isNotBlank)
```
**Giải thích:** Lọc dữ liệu theo điều kiện; chỉ giữ phần tử thỏa điều kiện.

### Dòng 39
```kotlin
            .toSet()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 40
```kotlin
        val updatedProfiles = profiles.map { profile ->
```
**Giải thích:** Biến đổi từng phần tử của danh sách sang giá trị mới.

### Dòng 41
```kotlin
            if (profile.phones.any { normalizePhone(it.number) in relevantPhones }) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 42
```kotlin
                val primaryIndex = profile.addresses.indexOfFirst { it.isPrimary }.takeIf { it >= 0 } ?: 0
```
**Giải thích:** Chọn/loại giá trị theo điều kiện, trả null nếu không thỏa.

### Dòng 43
```kotlin
                profile.copy(
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 44
```kotlin
                    addresses = profile.addresses.mapIndexed { index, address ->
```
**Giải thích:** Biến đổi từng phần tử của danh sách sang giá trị mới.

### Dòng 45
```kotlin
                        if (index == primaryIndex) address.copy(latitude = request.latitude, longitude = request.longitude) else address
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 46
```kotlin
                    },
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 47
```kotlin
                )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 48
```kotlin
            } else profile
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 49
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 50
```kotlin
        val updatedProfileIds = profiles.zip(updatedProfiles)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 51
```kotlin
            .filter { (before, after) -> before != after }
```
**Giải thích:** Lọc dữ liệu theo điều kiện; chỉ giữ phần tử thỏa điều kiện.

### Dòng 52
```kotlin
            .map { (_, after) -> after.id }
```
**Giải thích:** Biến đổi từng phần tử của danh sách sang giá trị mới.

### Dòng 53
```kotlin
            .toSet()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 54
```kotlin
        val matchedWaybills = matchedOrders.map { it.waybill }.toSet()
```
**Giải thích:** Biến đổi từng phần tử của danh sách sang giá trị mới.

### Dòng 55
```kotlin
        require(matchedWaybills.isNotEmpty() || updatedProfileIds.isNotEmpty()) { "Không tìm thấy khách hàng hoặc mã vận đơn tương ứng." }
```
**Giải thích:** Điều kiện bảo vệ/invariant; nếu sai sẽ phát sinh lỗi để ngăn dữ liệu không hợp lệ.

### Dòng 56
```kotlin
        var nextSequence = orders.filter { it.waybill !in matchedWaybills }.nextActiveSequence()
```
**Giải thích:** Lọc dữ liệu theo điều kiện; chỉ giữ phần tử thỏa điều kiện.

### Dòng 57
```kotlin
        val updatedOrders = orders.map { order ->
```
**Giải thích:** Biến đổi từng phần tử của danh sách sang giá trị mới.

### Dòng 58
```kotlin
            if (order.waybill !in matchedWaybills) order else order.copy(
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 59
```kotlin
                latitude = request.latitude,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 60
```kotlin
                longitude = request.longitude,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 61
```kotlin
                sequence = when {
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 62
```kotlin
                    !order.canReceiveRouteSequence() -> 0
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 63
```kotlin
                    order.sequence > 0 -> order.sequence
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 64
```kotlin
                    else -> nextSequence++
```
**Giải thích:** Nhánh thay thế khi điều kiện if trước đó sai.

### Dòng 65
```kotlin
                },
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 66
```kotlin
            )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 67
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 68
```kotlin
        return CoordinateUpdateResult(updatedProfiles, updatedOrders, updatedProfileIds, matchedWaybills)
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 69
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 70
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 71
```kotlin
    private fun normalizePhone(value: String): String = value.filter(Char::isDigit)
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 72
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

