# Phân tích từng dòng — `com/example/delivery/MainActivity.kt`

> Tài liệu đọc/debug: mã gốc theo từng dòng + giải thích. Không dùng trực tiếp để compile.

### Dòng 1
```kotlin
package com.example.delivery
```
**Giải thích:** Khai báo package, xác định namespace của file.

### Dòng 2
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 3
```kotlin
import android.content.ClipData
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 4
```kotlin
import android.content.ClipboardManager
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 5
```kotlin
import android.content.Context
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 6
```kotlin
import android.content.Intent
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 7
```kotlin
import android.location.Location
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 8
```kotlin
import android.location.LocationManager
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 9
```kotlin
import android.net.Uri
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 10
```kotlin
import android.os.Bundle
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 11
```kotlin
import android.provider.OpenableColumns
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 12
```kotlin
import android.widget.Toast
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 13
```kotlin
import androidx.activity.ComponentActivity
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 14
```kotlin
import androidx.activity.compose.setContent
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 15
```kotlin
import androidx.activity.result.contract.ActivityResultContracts
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 16
```kotlin
import androidx.compose.foundation.Image
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 17
```kotlin
import androidx.compose.foundation.background
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 18
```kotlin
import androidx.compose.foundation.layout.Arrangement
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 19
```kotlin
import androidx.compose.foundation.layout.Row
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 20
```kotlin
import androidx.compose.foundation.layout.fillMaxSize
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 21
```kotlin
import androidx.compose.foundation.text.selection.SelectionContainer
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 22
```kotlin
import androidx.compose.material3.AlertDialog
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 23
```kotlin
import androidx.compose.material3.Button
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 24
```kotlin
import androidx.compose.material3.OutlinedButton
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 25
```kotlin
import androidx.compose.material3.Text
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 26
```kotlin
import androidx.compose.runtime.Composable
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 27
```kotlin
import androidx.compose.runtime.LaunchedEffect
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 28
```kotlin
import androidx.compose.runtime.getValue
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 29
```kotlin
import androidx.compose.runtime.mutableStateListOf
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 30
```kotlin
import androidx.compose.runtime.mutableStateMapOf
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 31
```kotlin
import androidx.compose.runtime.mutableStateOf
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 32
```kotlin
import androidx.compose.runtime.remember
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 33
```kotlin
import androidx.compose.runtime.setValue
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 34
```kotlin
import androidx.compose.ui.Modifier
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 35
```kotlin
import androidx.compose.ui.graphics.Color
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 36
```kotlin
import androidx.compose.ui.layout.ContentScale
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 37
```kotlin
import androidx.compose.ui.res.painterResource
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 38
```kotlin
import androidx.compose.ui.unit.dp
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 39
```kotlin
import androidx.core.content.ContextCompat
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 40
```kotlin
import androidx.core.view.WindowCompat
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 41
```kotlin
import androidx.core.view.WindowInsetsCompat
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 42
```kotlin
import androidx.core.view.WindowInsetsControllerCompat
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 43
```kotlin
import androidx.lifecycle.lifecycleScope
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 44
```kotlin
import com.example.delivery.backup.CustomerBackupArchive
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 45
```kotlin
import com.example.delivery.backup.CustomerBackupResult
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 46
```kotlin
import com.example.delivery.history.DeliveryPhotoHistory
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 47
```kotlin
import com.example.delivery.history.PaymentChannel
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 48
```kotlin
import com.example.delivery.history.ProofPhotoType
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 49
```kotlin
import com.example.delivery.history.TransferEvidence
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 50
```kotlin
import com.example.delivery.integration.VtmanExportContract
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 51
```kotlin
import com.example.delivery.location.RealtimeLocationPolicy
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 52
```kotlin
import com.example.delivery.navigation.DeliveryRouteStore
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 53
```kotlin
import com.example.delivery.navigation.DeliveryZone
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 54
```kotlin
import com.example.delivery.navigation.GeoPoint
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 55
```kotlin
import com.example.delivery.navigation.routeOrdersFrom
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 56
```kotlin
import com.example.delivery.navigation.distanceMeters
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 57
```kotlin
import com.example.delivery.navigation.routeOrdersFromZones
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 58
```kotlin
import com.example.delivery.navigation.orderRouteGroupsByZoneAndGeo
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 59
```kotlin
import com.example.delivery.customer.CustomerProfile
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 60
```kotlin
import com.example.delivery.customer.CustomerProfileStore
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 61
```kotlin
import com.example.delivery.customer.mergeOrderCustomers
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 62
```kotlin
import com.example.delivery.debug.CrashDiagnostic
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 63
```kotlin
import com.example.delivery.model.DeliveryOrder
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 64
```kotlin
import com.example.delivery.model.DeliveryStatus
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 65
```kotlin
import com.example.delivery.model.formatVnd
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 66
```kotlin
import com.example.delivery.model.isRouteActive
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 67
```kotlin
import com.example.delivery.model.canReceiveRouteSequence
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 68
```kotlin
import com.example.delivery.model.hasStoredCoordinates
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 69
```kotlin
import com.example.delivery.model.withSequenceLabel
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 70
```kotlin
import com.example.delivery.model.withSharedPhoneSequence
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 71
```kotlin
import com.example.delivery.model.phoneGroupKey
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 72
```kotlin
import com.example.delivery.model.deliveryOutcome
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 73
```kotlin
import com.example.delivery.model.csvStatus
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 74
```kotlin
import com.example.delivery.model.normalizedCoordinates
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 75
```kotlin
import com.example.delivery.model.nextActiveSequence
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 76
```kotlin
import com.example.delivery.model.sampleOrders
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 77
```kotlin
import com.example.delivery.orderio.DeliveryOrderStore
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 78
```kotlin
import com.example.delivery.orderio.CoordinateUpdateCoordinator
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 79
```kotlin
import com.example.delivery.orderio.CoordinateUpdateRequest
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 80
```kotlin
import com.example.delivery.orderio.CustomerCoordinateSyncCoordinator
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 81
```kotlin
import com.example.delivery.orderio.ManualOrderCoordinator
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 82
```kotlin
import com.example.delivery.orderio.OrderDeletionCoordinator
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 83
```kotlin
import com.example.delivery.orderio.OrderFileCodec
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 84
```kotlin
import com.example.delivery.orderio.OrderImportCoordinator
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 85
```kotlin
import com.example.delivery.orderio.OrderImportResult
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 86
```kotlin
import com.example.delivery.orderio.SttSequenceFileCodec
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 87
```kotlin
import com.example.delivery.ui.DeliveryV2Screen
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 88
```kotlin
import com.example.delivery.ui.RouteCreationMode
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 89
```kotlin
import com.example.delivery.ui.TransferPhotoState
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 90
```kotlin
import kotlinx.coroutines.delay
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 91
```kotlin
import java.io.File
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 92
```kotlin
import java.nio.charset.StandardCharsets
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 93
```kotlin
import java.text.SimpleDateFormat
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 94
```kotlin
import java.util.Date
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 95
```kotlin
import java.util.Locale
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 96
```kotlin
import kotlinx.coroutines.Dispatchers
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 97
```kotlin
import kotlinx.coroutines.launch
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 98
```kotlin
import kotlinx.coroutines.withContext
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 99
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 100
```kotlin
private data class CaptureTarget(val order: DeliveryOrder, val type: ProofPhotoType, val file: File)
```
**Giải thích:** Khai báo lớp; gom dữ liệu hoặc hành vi liên quan vào một đơn vị.

### Dòng 101
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 102
```kotlin
class MainActivity : ComponentActivity() {
```
**Giải thích:** Khai báo lớp; gom dữ liệu hoặc hành vi liên quan vào một đơn vị.

### Dòng 103
```kotlin
    private val orders = mutableStateListOf<DeliveryOrder>()
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 104
```kotlin
    private val transferPhotos = mutableStateMapOf<String, TransferPhotoState>()
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 105
```kotlin
    private var evidence by mutableStateOf<List<TransferEvidence>>(emptyList())
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 106
```kotlin
    private var customerProfiles by mutableStateOf<List<CustomerProfile>>(emptyList())
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 107
```kotlin
    private var backupStatus by mutableStateOf<String?>(null)
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 108
```kotlin
    private var captureTarget: CaptureTarget? = null
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 109
```kotlin
    private val backupExport = registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 110
```kotlin
        uri?.let(::exportBackupTo)
```
**Giải thích:** Xử lý giá trị nullable an toàn; khối chỉ chạy khi giá trị tồn tại.

### Dòng 111
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 112
```kotlin
    private val backupImport = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 113
```kotlin
        uri?.let(::importBackupFrom)
```
**Giải thích:** Xử lý giá trị nullable an toàn; khối chỉ chạy khi giá trị tồn tại.

### Dòng 114
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 115
```kotlin
    private val orderImport = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 116
```kotlin
        uri?.let(::importOrdersFrom)
```
**Giải thích:** Xử lý giá trị nullable an toàn; khối chỉ chạy khi giá trị tồn tại.

### Dòng 117
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 118
```kotlin
    private val orderExport = registerForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 119
```kotlin
        uri?.let(::exportOrdersTo)
```
**Giải thích:** Xử lý giá trị nullable an toàn; khối chỉ chạy khi giá trị tồn tại.

### Dòng 120
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 121
```kotlin
    private val sttExport = registerForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 122
```kotlin
        uri?.let(::exportSttTo)
```
**Giải thích:** Xử lý giá trị nullable an toàn; khối chỉ chạy khi giá trị tồn tại.

### Dòng 123
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 124
```kotlin
    private val sttImport = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 125
```kotlin
        uri?.let(::importSttFrom)
```
**Giải thích:** Xử lý giá trị nullable an toàn; khối chỉ chạy khi giá trị tồn tại.

### Dòng 126
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 127
```kotlin
    private val camera = registerForActivityResult(ActivityResultContracts.TakePicture()) { saved ->
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 128
```kotlin
        val target = captureTarget ?: return@registerForActivityResult
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 129
```kotlin
        captureTarget = null
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 130
```kotlin
        if (!saved) { target.file.delete(); return@registerForActivityResult }
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 131
```kotlin
        val path = if (target.type == ProofPhotoType.DROP_OFF_WATERMARK) {
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 132
```kotlin
            val location = lastLocation()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 133
```kotlin
            DeliveryPhotoHistory.addDropOffWatermark(target.file, target.order, location?.latitude, location?.longitude)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 134
```kotlin
        } else target.file.path
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 135
```kotlin
        when (target.type) {
```
**Giải thích:** Rẽ nhánh nhiều trường hợp dựa trên giá trị/điều kiện.

### Dòng 136
```kotlin
            ProofPhotoType.BILL_CLOSEUP -> transferPhotos[target.order.waybill] = (transferPhotos[target.order.waybill] ?: TransferPhotoState()).copy(billPath = path)
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 137
```kotlin
            ProofPhotoType.DROP_OFF_WATERMARK -> transferPhotos[target.order.waybill] = (transferPhotos[target.order.waybill] ?: TransferPhotoState()).copy(dropOffPath = path)
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 138
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 139
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 140
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 141
```kotlin
    override fun onCreate(savedInstanceState: Bundle?) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 142
```kotlin
        super.onCreate(savedInstanceState)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 143
```kotlin
        WindowCompat.setDecorFitsSystemWindows(window, false)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 144
```kotlin
        val storedOrders = DeliveryOrderStore.load(this)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 145
```kotlin
        // Chỉ nạp dữ liệu mẫu ở lần chạy đầu; danh sách rỗng sau khi người dùng xóa tất cả phải được giữ nguyên.
```
**Giải thích:** Chú thích hiện có; không tạo hành vi chạy.

### Dòng 146
```kotlin
        val initialOrders = if (storedOrders.isEmpty() && !DeliveryOrderStore.hasBeenInitialized(this)) {
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 147
```kotlin
            sampleOrders().also { DeliveryOrderStore.replace(this, it) }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 148
```kotlin
        } else {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 149
```kotlin
            storedOrders
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 150
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 151
```kotlin
        val normalizedOrders = initialOrders.map(DeliveryOrder::normalizedCoordinates).withSharedPhoneSequence()
```
**Giải thích:** Biến đổi từng phần tử của danh sách sang giá trị mới.

### Dòng 152
```kotlin
        orders.addAll(normalizedOrders)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 153
```kotlin
        if (normalizedOrders != initialOrders) persistOrders()
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 154
```kotlin
        evidence = DeliveryPhotoHistory.getEvidence(this)
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 155
```kotlin
        customerProfiles = CustomerProfileStore.load(this)
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 156
```kotlin
        val systemBars = WindowCompat.getInsetsController(window, window.decorView)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 157
```kotlin
        systemBars.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 158
```kotlin
        systemBars.hide(WindowInsetsCompat.Type.systemBars())
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 159
```kotlin
        setContent {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 160
```kotlin
            var showSplash by remember { mutableStateOf(true) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 161
```kotlin
            var crashDebug by remember { mutableStateOf(CrashDiagnostic.consume(this@MainActivity)) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 162
```kotlin
            LaunchedEffect(Unit) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 163
```kotlin
                delay(1_500)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 164
```kotlin
                showSplash = false
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 165
```kotlin
                systemBars.show(WindowInsetsCompat.Type.systemBars())
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 166
```kotlin
            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 167
```kotlin
            if (showSplash) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 168
```kotlin
                DeliveryLaunchScreen()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 169
```kotlin
            } else DeliveryV2Screen(
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 170
```kotlin
                orders = orders,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 171
```kotlin
                transferPhotos = transferPhotos,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 172
```kotlin
                transferEvidence = evidence,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 173
```kotlin
                customerProfiles = customerProfiles.mergeOrderCustomers(orders),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 174
```kotlin
                onDirectDelivered = ::markDelivered,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 175
```kotlin
                onSaveTransfer = ::saveTransfer,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 176
```kotlin
                onCaptureTransferPhoto = ::captureProof,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 177
```kotlin
                onCall = ::openDial,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 178
```kotlin
                onZalo = ::openZalo,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 179
```kotlin
                onSms = ::openSms,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 180
```kotlin
                onConfirmTransferPayment = ::confirmTransferPayment,
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 181
```kotlin
                transferMessage = ::transferMessage,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 182
```kotlin
                onRouteSequenceLocked = ::lockRouteSequence,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 183
```kotlin
                onCreateRoute = ::createRoute,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 184
```kotlin
                onDeleteRoute = ::deleteRoute,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 185
```kotlin
                onSaveCustomer = { profile -> customerProfiles = CustomerProfileStore.upsert(this, profile) },
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 186
```kotlin
                onDeleteCustomer = { profile -> customerProfiles = CustomerProfileStore.delete(this, profile.id) },
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 187
```kotlin
                onGetCustomerCoordinates = { lastLocation()?.let { it.latitude to it.longitude } },
```
**Giải thích:** Xử lý giá trị nullable an toàn; khối chỉ chạy khi giá trị tồn tại.

### Dòng 188
```kotlin
                onExportBackup = ::startBackupExport,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 189
```kotlin
                onImportBackup = ::startBackupImport,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 190
```kotlin
                onImportOrders = ::startOrderImport,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 191
```kotlin
                onExportOrders = ::startOrderExport,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 192
```kotlin
                onExportStt = ::startSttExport,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 193
```kotlin
                onImportStt = ::startSttImport,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 194
```kotlin
                onAddManualOrder = ::addManualOrder,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 195
```kotlin
                onDeleteOrder = ::deleteOrder,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 196
```kotlin
                onDeleteAllOrders = ::deleteAllOrders,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 197
```kotlin
                onUpdateCoordinates = ::updateCoordinates,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 198
```kotlin
                onSyncOrdersFromCustomerCoordinates = ::syncOrdersFromCustomerCoordinates,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 199
```kotlin
                onOpenVtmanExport = ::openVtmanExport,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 200
```kotlin
                backupStatus = backupStatus,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 201
```kotlin
            )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 202
```kotlin
            crashDebug?.let { detail ->
```
**Giải thích:** Xử lý giá trị nullable an toàn; khối chỉ chạy khi giá trị tồn tại.

### Dòng 203
```kotlin
                AlertDialog(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 204
```kotlin
                    onDismissRequest = { crashDebug = null },
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 205
```kotlin
                    title = { Text("DEBUG LỖI CRASH") },
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 206
```kotlin
                    text = { SelectionContainer { Text(detail) } },
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 207
```kotlin
                    confirmButton = {
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 208
```kotlin
                        Button(onClick = {
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 209
```kotlin
                            val clipboard = getSystemService(ClipboardManager::class.java)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 210
```kotlin
                            clipboard.setPrimaryClip(ClipData.newPlainText("Giao Hàng Goong Alpha crash debug", detail))
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 211
```kotlin
                        }) { Text("Sao chép lỗi") }
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 212
```kotlin
                    },
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 213
```kotlin
                    dismissButton = {
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 214
```kotlin
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 215
```kotlin
                            OutlinedButton(onClick = { crashDebug = null }) { Text("Đóng") }
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 216
```kotlin
                            OutlinedButton(onClick = { crashDebug = null; recreate() }) { Text("Khởi động lại") }
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 217
```kotlin
                        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 218
```kotlin
                    },
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 219
```kotlin
                )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 220
```kotlin
            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 221
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 222
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 223
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 224
```kotlin
    private fun markDelivered(order: DeliveryOrder) {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 225
```kotlin
        val index = orders.indexOfFirst { it.waybill == order.waybill }
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 226
```kotlin
        if (index < 0) return
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 227
```kotlin
        val updated = orders[index].copy(
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 228
```kotlin
            status = DeliveryStatus.TT500,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 229
```kotlin
            requiresRedelivery = false,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 230
```kotlin
            failureReason = null,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 231
```kotlin
            delivered = true,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 232
```kotlin
            sequence = 0,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 233
```kotlin
            sequenceLabel = null,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 234
```kotlin
        )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 235
```kotlin
        orders.removeAt(index)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 236
```kotlin
        orders.add(updated)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 237
```kotlin
        persistOrders()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 238
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 239
```kotlin
    private fun resetRetryableOrdersForRouting() {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 240
```kotlin
        var changed = false
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 241
```kotlin
        orders.indices.forEach { index ->
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 242
```kotlin
            val order = orders[index]
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 243
```kotlin
            if (order.csvStatus() == DeliveryStatus.TT506 || order.csvStatus() == DeliveryStatus.TT507 || order.csvStatus() == DeliveryStatus.TT508) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 244
```kotlin
                orders[index] = order.copy(
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 245
```kotlin
                    status = DeliveryStatus.TT500,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 246
```kotlin
                    requiresRedelivery = false,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 247
```kotlin
                    wasRedelivered = false,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 248
```kotlin
                    failureReason = null,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 249
```kotlin
                    delivered = false,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 250
```kotlin
                )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 251
```kotlin
                changed = true
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 252
```kotlin
            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 253
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 254
```kotlin
        if (changed) persistOrders()
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 255
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 256
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 257
```kotlin
    private fun createRoute(mode: RouteCreationMode) {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 258
```kotlin
        resetRetryableOrdersForRouting()
```
**Giải thích:** Xử lý lỗi/ngoại lệ; kiểm tra nhánh này khi thao tác mạng hoặc hệ thống thất bại.

### Dòng 259
```kotlin
        val zones = DeliveryRouteStore.loadZones(this)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 260
```kotlin
        val groupKey: (DeliveryOrder) -> String = { order -> order.phone.filter(Char::isDigit).ifBlank { order.waybill } }
```
**Giải thích:** Lọc dữ liệu theo điều kiện; chỉ giữ phần tử thỏa điều kiện.

### Dòng 261
```kotlin
        val eligibleForNew = orders.filter { order ->
```
**Giải thích:** Lọc dữ liệu theo điều kiện; chỉ giữ phần tử thỏa điều kiện.

### Dòng 262
```kotlin
            order.hasStoredCoordinates() && order.canReceiveRouteSequence()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 263
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 264
```kotlin
        val eligibleForUpdate = run {
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 265
```kotlin
            val newlyLocatedKeys = orders.filter { it.hasStoredCoordinates() && it.sequence == 0 && it.canReceiveRouteSequence() }
```
**Giải thích:** Lọc dữ liệu theo điều kiện; chỉ giữ phần tử thỏa điều kiện.

### Dòng 266
```kotlin
                .map(groupKey).toSet()
```
**Giải thích:** Biến đổi từng phần tử của danh sách sang giá trị mới.

### Dòng 267
```kotlin
            orders.filter { order ->
```
**Giải thích:** Lọc dữ liệu theo điều kiện; chỉ giữ phần tử thỏa điều kiện.

### Dòng 268
```kotlin
                groupKey(order) in newlyLocatedKeys && order.hasStoredCoordinates() && order.canReceiveRouteSequence()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 269
```kotlin
            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 270
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 271
```kotlin
        val candidates = if (mode == RouteCreationMode.NEW_ROUTE) eligibleForNew else eligibleForUpdate
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 272
```kotlin
        val groups = candidates.groupBy(groupKey).values
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 273
```kotlin
        // Ưu tiên thứ tự Zone trong cùng khu vực gần nhau; tổng thể đi trái-phải,
```
**Giải thích:** Chú thích hiện có; không tạo hành vi chạy.

### Dòng 274
```kotlin
        // dưới-lên để các MVĐ gần nhau, kể cả khác Zone, nhận STT gần nhau.
```
**Giải thích:** Chú thích hiện có; không tạo hành vi chạy.

### Dòng 275
```kotlin
        val ordered = orderRouteGroupsByZoneAndGeo(groups, zones)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 276
```kotlin
        var next = if (mode == RouteCreationMode.NEW_ROUTE) 1 else orders.filter { it.isRouteActive() }.maxOfOrNull { it.sequence }?.plus(1) ?: 1
```
**Giải thích:** Lọc dữ liệu theo điều kiện; chỉ giữ phần tử thỏa điều kiện.

### Dòng 277
```kotlin
        val sequenceByWaybill = mutableMapOf<String, Int>()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 278
```kotlin
        ordered.forEach { group -> group.forEach { order -> sequenceByWaybill[order.waybill] = next }; next++ }
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 279
```kotlin
        orders.indices.forEach { index -> sequenceByWaybill[orders[index].waybill]?.let { sequence -> orders[index] = orders[index].copy(sequence = sequence, sequenceLabel = null) } }
```
**Giải thích:** Xử lý giá trị nullable an toàn; khối chỉ chạy khi giá trị tồn tại.

### Dòng 280
```kotlin
        persistOrders()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 281
```kotlin
        DeliveryRouteStore.setRouteActive(this, true)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 282
```kotlin
        val label = if (mode == RouteCreationMode.NEW_ROUTE) "Tuyến mới" else "Cập nhật tuyến"
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 283
```kotlin
        backupStatus = "Đã $label: ${ordered.size} nhóm SĐT, ${candidates.size} MVĐ được đánh STT."
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 284
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 285
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 286
```kotlin
    private fun deleteRoute() {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 287
```kotlin
        orders.indices.forEach { index -> orders[index] = orders[index].copy(sequence = 0, sequenceLabel = null) }
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 288
```kotlin
        persistOrders()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 289
```kotlin
        DeliveryRouteStore.clearRoute(this)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 290
```kotlin
        backupStatus = "Đã xóa tuyến và toàn bộ STT."
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 291
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 292
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 293
```kotlin
    private fun lockRouteSequence(sequenceByWaybill: Map<String, String>) {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 294
```kotlin
        var changed = false
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 295
```kotlin
        val labelsByPhone = orders.mapNotNull { order ->
```
**Giải thích:** Biến đổi từng phần tử của danh sách sang giá trị mới.

### Dòng 296
```kotlin
            sequenceByWaybill[order.waybill]?.trim()?.takeIf { it.isValidSequenceLabel() }?.let { order.phoneGroupKey() to it }
```
**Giải thích:** Chọn/loại giá trị theo điều kiện, trả null nếu không thỏa.

### Dòng 297
```kotlin
        }.toMap()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 298
```kotlin
        orders.indices.forEach { index ->
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 299
```kotlin
            val current = orders[index]
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 300
```kotlin
            val label = labelsByPhone[current.phoneGroupKey()] ?: sequenceByWaybill[current.waybill]?.trim()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 301
```kotlin
            if (label != null && current.hasStoredCoordinates() && !current.delivered && label.isValidSequenceLabel()) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 302
```kotlin
                val updated = current.withSequenceLabel(label)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 303
```kotlin
                if (updated.sequence != current.sequence || updated.sequenceLabel != current.sequenceLabel) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 304
```kotlin
                    orders[index] = updated
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 305
```kotlin
                    changed = true
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 306
```kotlin
                }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 307
```kotlin
            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 308
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 309
```kotlin
        if (changed) persistOrders()
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 310
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 311
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 312
```kotlin
    private fun String.isValidSequenceLabel(): Boolean {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 313
```kotlin
        val parts = trim().split('.', limit = 2)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 314
```kotlin
        return parts[0].toIntOrNull()?.let { it > 0 } == true &&
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 315
```kotlin
            (parts.size == 1 || parts[1].equals("n", true) || parts[1].toIntOrNull()?.let { it > 0 } == true)
```
**Giải thích:** Xử lý giá trị nullable an toàn; khối chỉ chạy khi giá trị tồn tại.

### Dòng 316
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 317
```kotlin
    private fun replace(order: DeliveryOrder, update: (DeliveryOrder) -> DeliveryOrder) {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 318
```kotlin
        orders.indexOfFirst { it.waybill == order.waybill }.takeIf { it >= 0 }?.let { index ->
```
**Giải thích:** Chọn/loại giá trị theo điều kiện, trả null nếu không thỏa.

### Dòng 319
```kotlin
            orders[index] = update(orders[index])
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 320
```kotlin
            persistOrders()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 321
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 322
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 323
```kotlin
    private fun captureProof(order: DeliveryOrder, type: ProofPhotoType) {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 324
```kotlin
        val file = DeliveryPhotoHistory.createOutputFile(this, order.waybill, type)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 325
```kotlin
        captureTarget = CaptureTarget(order, type, file)
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 326
```kotlin
        camera.launch(DeliveryPhotoHistory.providerUri(this, file))
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 327
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 328
```kotlin
    private fun saveTransfer(order: DeliveryOrder, channel: PaymentChannel, message: String, bill: String?, drop: String?) {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 329
```kotlin
        DeliveryPhotoHistory.upsertEvidence(this, TransferEvidence(order.waybill, order.customer, order.phone, order.cod, channel, message, bill, drop, sentConfirmed = true))
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 330
```kotlin
        evidence = DeliveryPhotoHistory.getEvidence(this)
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 331
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 332
```kotlin
    private fun confirmTransferPayment(waybill: String) {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 333
```kotlin
        val item = DeliveryPhotoHistory.confirmPaid(this, waybill) ?: return
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 334
```kotlin
        orders.indexOfFirst { it.waybill == waybill }.takeIf { it >= 0 }?.let { index ->
```
**Giải thích:** Chọn/loại giá trị theo điều kiện, trả null nếu không thỏa.

### Dòng 335
```kotlin
            orders[index] = orders[index].copy(status = DeliveryStatus.TT500, requiresRedelivery = false, failureReason = null, delivered = true)
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 336
```kotlin
            persistOrders()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 337
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 338
```kotlin
        evidence = DeliveryPhotoHistory.getEvidence(this)
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 339
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 340
```kotlin
    private fun transferMessage(order: DeliveryOrder) = "Chào anh/chị ${order.customer}, em giao đơn hàng ${order.waybill}. Tiền COD: ${order.cod.formatVnd()}. Anh/Chị chuyển tiền vào STK: 0123456789 - Ngân hàng mặc định - Giao Hàng. Nội dung chuyển khoản: ${order.waybill}. Em cảm ơn ạ!"
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 341
```kotlin
    private fun startBackupExport() {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 342
```kotlin
        val stamp = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 343
```kotlin
        backupExport.launch("giaohang_backup_$stamp.zip")
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 344
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 345
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 346
```kotlin
    private fun startBackupImport() = backupImport.launch(arrayOf("application/zip", "application/x-zip-compressed"))
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 347
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 348
```kotlin
    /** Một số trình quản lý tệp gán MIME không chuẩn cho CSV, nên mở tất cả rồi kiểm tra đuôi tệp trong OrderFileCodec. */
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 349
```kotlin
    private fun startOrderImport() = orderImport.launch(arrayOf("*/*"))
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 350
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 351
```kotlin
    private fun startOrderExport() {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 352
```kotlin
        val stamp = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 353
```kotlin
        orderExport.launch("don_hang_$stamp.csv")
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 354
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 355
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 356
```kotlin
    private fun startSttExport() {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 357
```kotlin
        val stamp = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 358
```kotlin
        sttExport.launch("stt_tuyen_giao_$stamp.csv")
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 359
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 360
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 361
```kotlin
    private fun startSttImport() = sttImport.launch(arrayOf("text/csv", "text/plain", "*/*"))
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 362
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 363
```kotlin
    private fun importOrdersFrom(uri: Uri) {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 364
```kotlin
        lifecycleScope.launch {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 365
```kotlin
            backupStatus = "Đang nhập đơn hàng…"
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 366
```kotlin
            runCatching {
```
**Giải thích:** Xử lý lỗi/ngoại lệ; kiểm tra nhánh này khi thao tác mạng hoặc hệ thống thất bại.

### Dòng 367
```kotlin
                withContext(Dispatchers.IO) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 368
```kotlin
                    contentResolver.openInputStream(uri)?.use { input ->
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 369
```kotlin
                        OrderFileCodec.import(orderDocumentName(uri), input)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 370
```kotlin
                    } ?: error("Không thể mở tệp đơn hàng.")
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 371
```kotlin
                }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 372
```kotlin
            }.onSuccess { result: OrderImportResult ->
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 373
```kotlin
                val knownCustomers = customerProfiles.mergeOrderCustomers(orders)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 374
```kotlin
                val merge = OrderImportCoordinator.replaceWithImportedBatch(orders.toList(), result.orders, knownCustomers)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 375
```kotlin
                orders.clear()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 376
```kotlin
                // replaceWithImportedBatch đã khôi phục đúng các đơn không liên lạc được,
```
**Giải thích:** Chú thích hiện có; không tạo hành vi chạy.

### Dòng 377
```kotlin
                // hẹn giao lại và tới kho nhận. Không reset trạng thái của các đơn khác tại đây.
```
**Giải thích:** Chú thích hiện có; không tạo hành vi chạy.

### Dòng 378
```kotlin
                orders.addAll(merge.orders.withSharedPhoneSequence())
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 379
```kotlin
                persistOrders()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 380
```kotlin
                customerProfiles = CustomerProfileStore.upsertMissingFromOrders(this@MainActivity, merge.addedOrders)
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 381
```kotlin
                val messages = mutableListOf("Đã nạp ${merge.orders.size} MVĐ cho danh sách hiện tại")
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 382
```kotlin
                if (merge.addedOrders.isNotEmpty()) messages += "thêm ${merge.addedOrders.size} MVĐ mới"
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 383
```kotlin
                if (merge.restoredProductCount > 0) messages += "bổ sung Hàng hóa cho ${merge.restoredProductCount} MVĐ đã có"
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 384
```kotlin
                if (merge.ignoredDuplicateCount > 0) messages += "giữ nguyên ${merge.ignoredDuplicateCount} MVĐ đã tồn tại"
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 385
```kotlin
                if (merge.reactivatedCount > 0) messages += "đưa lại ${merge.reactivatedCount} MVĐ không liên lạc được/hẹn giao lại/tới kho nhận về Đang giao"
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 386
```kotlin
                if (merge.removedNotInLatestImportCount > 0) messages += "ẩn ${merge.removedNotInLatestImportCount} MVĐ không có trong file khỏi Chi tiết và Bản đồ"
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 387
```kotlin
                if (result.skippedRows > 0) messages += "bỏ qua ${result.skippedRows} dòng không hợp lệ"
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 388
```kotlin
                backupStatus = messages.joinToString("; ") + "."
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 389
```kotlin
            }.onFailure { error ->
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 390
```kotlin
                backupStatus = "Nhập đơn hàng thất bại: ${error.message ?: "file không hợp lệ"}"
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 391
```kotlin
            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 392
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 393
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 394
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 395
```kotlin
    private fun exportSttTo(uri: Uri) {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 396
```kotlin
        val snapshot = orders.toList()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 397
```kotlin
        lifecycleScope.launch {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 398
```kotlin
            backupStatus = "Đang lưu STT…"
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 399
```kotlin
            runCatching {
```
**Giải thích:** Xử lý lỗi/ngoại lệ; kiểm tra nhánh này khi thao tác mạng hoặc hệ thống thất bại.

### Dòng 400
```kotlin
                withContext(Dispatchers.IO) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 401
```kotlin
                    contentResolver.openOutputStream(uri)?.use { output ->
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 402
```kotlin
                        output.write(SttSequenceFileCodec.exportCsv(snapshot).toByteArray(StandardCharsets.UTF_8))
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 403
```kotlin
                    } ?: error("Không thể tạo tệp CSV STT.")
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 404
```kotlin
                }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 405
```kotlin
            }.onSuccess {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 406
```kotlin
                backupStatus = "Đã lưu STT của ${snapshot.count { it.sequence > 0 }} mã vận đơn."
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 407
```kotlin
            }.onFailure { error ->
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 408
```kotlin
                backupStatus = "Lưu STT thất bại: ${error.message ?: "lỗi không xác định"}"
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 409
```kotlin
            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 410
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 411
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 412
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 413
```kotlin
    private fun importSttFrom(uri: Uri) {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 414
```kotlin
        lifecycleScope.launch {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 415
```kotlin
            backupStatus = "Đang khôi phục STT…"
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 416
```kotlin
            runCatching {
```
**Giải thích:** Xử lý lỗi/ngoại lệ; kiểm tra nhánh này khi thao tác mạng hoặc hệ thống thất bại.

### Dòng 417
```kotlin
                withContext(Dispatchers.IO) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 418
```kotlin
                    contentResolver.openInputStream(uri)?.use { SttSequenceFileCodec.import(it) }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 419
```kotlin
                        ?: error("Không thể mở tệp STT.")
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 420
```kotlin
                }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 421
```kotlin
            }.map { entries -> SttSequenceFileCodec.restore(orders.toList(), entries) }
```
**Giải thích:** Biến đổi từng phần tử của danh sách sang giá trị mới.

### Dòng 422
```kotlin
                .onSuccess { result ->
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 423
```kotlin
                    orders.clear()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 424
```kotlin
                    orders.addAll(result.orders.withSharedPhoneSequence())
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 425
```kotlin
                    persistOrders()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 426
```kotlin
                    if (result.restoredCount > 0) DeliveryRouteStore.setRouteActive(this@MainActivity, true)
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 427
```kotlin
                    backupStatus = "Đã khôi phục ${result.restoredCount} STT; bỏ qua ${result.skippedMissingCount} MVĐ không còn trong danh sách và ${result.skippedStatusCount} MVĐ không đủ điều kiện."
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 428
```kotlin
                }.onFailure { error ->
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 429
```kotlin
                    backupStatus = "Khôi phục STT thất bại: ${error.message ?: "tệp không hợp lệ"}"
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 430
```kotlin
                }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 431
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 432
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 433
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 434
```kotlin
    private fun exportOrdersTo(uri: Uri) {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 435
```kotlin
        val snapshot = orders.toList()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 436
```kotlin
        lifecycleScope.launch {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 437
```kotlin
            backupStatus = "Đang xuất đơn hàng…"
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 438
```kotlin
            runCatching {
```
**Giải thích:** Xử lý lỗi/ngoại lệ; kiểm tra nhánh này khi thao tác mạng hoặc hệ thống thất bại.

### Dòng 439
```kotlin
                withContext(Dispatchers.IO) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 440
```kotlin
                    contentResolver.openOutputStream(uri)?.use { output ->
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 441
```kotlin
                        output.write(OrderFileCodec.exportCsv(snapshot).toByteArray(StandardCharsets.UTF_8))
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 442
```kotlin
                    } ?: error("Không thể tạo tệp CSV.")
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 443
```kotlin
                }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 444
```kotlin
            }.onSuccess {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 445
```kotlin
                backupStatus = "Đã xuất ${snapshot.size} đơn hàng ra CSV."
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 446
```kotlin
            }.onFailure { error ->
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 447
```kotlin
                backupStatus = "Xuất đơn hàng thất bại: ${error.message ?: "lỗi không xác định"}"
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 448
```kotlin
            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 449
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 450
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 451
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 452
```kotlin
    private fun addManualOrder(draft: DeliveryOrder) {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 453
```kotlin
        runCatching {
```
**Giải thích:** Xử lý lỗi/ngoại lệ; kiểm tra nhánh này khi thao tác mạng hoặc hệ thống thất bại.

### Dòng 454
```kotlin
            val placed = ManualOrderCoordinator.place(draft, customerProfiles.mergeOrderCustomers(orders), orders, DeliveryRouteStore.isRouteActive(this))
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 455
```kotlin
            orders.add(placed)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 456
```kotlin
            persistOrders()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 457
```kotlin
            customerProfiles = CustomerProfileStore.upsertMissingFromOrders(this, listOf(placed))
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 458
```kotlin
            backupStatus = if (placed.sequence > 0) {
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 459
```kotlin
                "Đã thêm ${placed.waybill} với số thứ tự ${placed.sequence}."
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 460
```kotlin
            } else {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 461
```kotlin
                "Đã thêm ${placed.waybill} ở đầu danh sách; hãy bổ sung tọa độ khách hàng để xếp tuyến."
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 462
```kotlin
            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 463
```kotlin
        }.onFailure { error ->
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 464
```kotlin
            backupStatus = "Không thể thêm mã vận đơn: ${error.message ?: "dữ liệu không hợp lệ"}"
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 465
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 466
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 467
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 468
```kotlin
    private fun deleteAllOrders() {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 469
```kotlin
        runCatching {
```
**Giải thích:** Xử lý lỗi/ngoại lệ; kiểm tra nhánh này khi thao tác mạng hoặc hệ thống thất bại.

### Dòng 470
```kotlin
            val count = orders.size
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 471
```kotlin
            // Không ghi outcome vào lịch sử: yêu cầu là xóa sạch, không để lại dấu vết MVD.
```
**Giải thích:** Chú thích hiện có; không tạo hành vi chạy.

### Dòng 472
```kotlin
            orders.clear()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 473
```kotlin
            transferPhotos.clear()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 474
```kotlin
            DeliveryOrderStore.replace(this, emptyList())
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 475
```kotlin
            DeliveryPhotoHistory.clearAll(this)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 476
```kotlin
            DeliveryRouteStore.clearRoute(this)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 477
```kotlin
            evidence = emptyList()
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 478
```kotlin
            backupStatus = "Đã xóa vĩnh viễn toàn bộ $count đơn hàng, trạng thái và lịch sử hình ảnh."
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 479
```kotlin
        }.onFailure { error ->
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 480
```kotlin
            backupStatus = "Xóa toàn bộ đơn hàng thất bại: ${error.message ?: "không xác định"}"
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 481
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 482
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 483
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 484
```kotlin
    private fun deleteOrder(waybill: String) {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 485
```kotlin
        runCatching {
```
**Giải thích:** Xử lý lỗi/ngoại lệ; kiểm tra nhánh này khi thao tác mạng hoặc hệ thống thất bại.

### Dòng 486
```kotlin
            val deleted = orders.firstOrNull { it.waybill.equals(waybill.trim(), ignoreCase = true) }
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 487
```kotlin
                ?: error("Không tìm thấy mã vận đơn cần xóa.")
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 488
```kotlin
            // Lưu hẳn khách trước khi bỏ đơn, để khách không bị mất khi đây là đơn duy nhất của họ.
```
**Giải thích:** Chú thích hiện có; không tạo hành vi chạy.

### Dòng 489
```kotlin
            customerProfiles = CustomerProfileStore.upsertMissingFromOrders(this, listOf(deleted))
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 490
```kotlin
            val remaining = OrderDeletionCoordinator.delete(waybill, orders)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 491
```kotlin
            orders.clear()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 492
```kotlin
            orders.addAll(remaining)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 493
```kotlin
            persistOrders()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 494
```kotlin
            backupStatus = "Đã xóa đơn ${deleted.waybill}. Thông tin khách hàng vẫn được giữ lại."
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 495
```kotlin
        }.onFailure { error ->
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 496
```kotlin
            backupStatus = "Không thể xóa đơn: ${error.message ?: "dữ liệu không hợp lệ"}"
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 497
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 498
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 499
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 500
```kotlin
    private fun updateCoordinates(request: CoordinateUpdateRequest) {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 501
```kotlin
        runCatching {
```
**Giải thích:** Xử lý lỗi/ngoại lệ; kiểm tra nhánh này khi thao tác mạng hoặc hệ thống thất bại.

### Dòng 502
```kotlin
            val result = CoordinateUpdateCoordinator.update(request, customerProfiles.mergeOrderCustomers(orders), orders)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 503
```kotlin
            orders.clear()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 504
```kotlin
            orders.addAll(result.orders)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 505
```kotlin
            persistOrders()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 506
```kotlin
            customerProfiles = CustomerProfileStore.replace(this, result.profiles)
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 507
```kotlin
            val ordersText = result.updatedWaybills.size.takeIf { it > 0 }?.let { "$it đơn" }
```
**Giải thích:** Chọn/loại giá trị theo điều kiện, trả null nếu không thỏa.

### Dòng 508
```kotlin
            val customersText = result.updatedProfileIds.size.takeIf { it > 0 }?.let { "$it khách hàng" }
```
**Giải thích:** Chọn/loại giá trị theo điều kiện, trả null nếu không thỏa.

### Dòng 509
```kotlin
            backupStatus = "Đã cập nhật tọa độ cho ${listOfNotNull(ordersText, customersText).joinToString(" và ")}."
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 510
```kotlin
        }.onFailure { error ->
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 511
```kotlin
            backupStatus = "Cập nhật tọa độ thất bại: ${error.message ?: "dữ liệu không hợp lệ"}"
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 512
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 513
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 514
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 515
```kotlin
    private fun syncOrdersFromCustomerCoordinates() {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 516
```kotlin
        runCatching {
```
**Giải thích:** Xử lý lỗi/ngoại lệ; kiểm tra nhánh này khi thao tác mạng hoặc hệ thống thất bại.

### Dòng 517
```kotlin
            val profiles = customerProfiles.mergeOrderCustomers(orders)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 518
```kotlin
            val result = CustomerCoordinateSyncCoordinator.sync(profiles, orders)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 519
```kotlin
            orders.clear()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 520
```kotlin
            orders.addAll(result.orders)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 521
```kotlin
            persistOrders()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 522
```kotlin
            customerProfiles = CustomerProfileStore.replace(this, profiles)
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 523
```kotlin
            backupStatus = when {
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 524
```kotlin
                result.phoneMatchedWaybills.isEmpty() -> "Không có đơn nào khớp SĐT khách hàng đã lưu tọa độ."
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 525
```kotlin
                else -> "Đã rà ${result.phoneMatchedWaybills.size} đơn theo SĐT; cập nhật ${result.coordinateUpdatedWaybills.size} tọa độ và xếp lại ${result.resequencedWaybills.size} đơn."
```
**Giải thích:** Nhánh thay thế khi điều kiện if trước đó sai.

### Dòng 526
```kotlin
            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 527
```kotlin
        }.onFailure { error ->
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 528
```kotlin
            backupStatus = "Rà soát SĐT thất bại: ${error.message ?: "dữ liệu không hợp lệ"}"
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 529
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 530
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 531
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 532
```kotlin
    private fun orderDocumentName(uri: Uri): String = contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 533
```kotlin
        if (cursor.moveToFirst()) cursor.getString(0) else null
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 534
```kotlin
    } ?: uri.lastPathSegment.orEmpty()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 535
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 536
```kotlin
    private fun persistOrders() = DeliveryOrderStore.replace(this, orders.toList())
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 537
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 538
```kotlin
    private fun openVtmanExport() {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 539
```kotlin
        val launchIntent = packageManager.getLaunchIntentForPackage(VtmanExportContract.packageName)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 540
```kotlin
        if (launchIntent == null) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 541
```kotlin
            Toast.makeText(this, VtmanExportContract.unavailableMessage, Toast.LENGTH_LONG).show()
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 542
```kotlin
        } else {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 543
```kotlin
            startActivity(launchIntent)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 544
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 545
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 546
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 547
```kotlin
    private fun exportBackupTo(uri: Uri) {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 548
```kotlin
        lifecycleScope.launch {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 549
```kotlin
            backupStatus = "Đang xuất file ZIP…"
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 550
```kotlin
            runCatching {
```
**Giải thích:** Xử lý lỗi/ngoại lệ; kiểm tra nhánh này khi thao tác mạng hoặc hệ thống thất bại.

### Dòng 551
```kotlin
                withContext(Dispatchers.IO) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 552
```kotlin
                    contentResolver.openOutputStream(uri)?.use { CustomerBackupArchive.export(this@MainActivity, it) }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 553
```kotlin
                        ?: error("Không thể tạo file ZIP.")
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 554
```kotlin
                }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 555
```kotlin
            }.onSuccess { result -> backupStatus = result.exportMessage() }
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 556
```kotlin
                .onFailure { backupStatus = "Xuất ZIP thất bại: ${it.message ?: "lỗi không xác định"}" }
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 557
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 558
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 559
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 560
```kotlin
    private fun importBackupFrom(uri: Uri) {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 561
```kotlin
        lifecycleScope.launch {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 562
```kotlin
            backupStatus = "Đang kiểm tra và nhập file ZIP…"
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 563
```kotlin
            runCatching {
```
**Giải thích:** Xử lý lỗi/ngoại lệ; kiểm tra nhánh này khi thao tác mạng hoặc hệ thống thất bại.

### Dòng 564
```kotlin
                withContext(Dispatchers.IO) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 565
```kotlin
                    contentResolver.openInputStream(uri)?.use { CustomerBackupArchive.import(this@MainActivity, it) }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 566
```kotlin
                        ?: error("Không thể mở file ZIP.")
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 567
```kotlin
                }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 568
```kotlin
            }.onSuccess { result ->
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 569
```kotlin
                refreshBackupData()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 570
```kotlin
                backupStatus = result.importMessage()
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 571
```kotlin
            }.onFailure { backupStatus = "Nhập ZIP thất bại: ${it.message ?: "file không hợp lệ"}" }
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 572
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 573
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 574
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 575
```kotlin
    private fun refreshBackupData() {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 576
```kotlin
        evidence = DeliveryPhotoHistory.getEvidence(this)
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 577
```kotlin
        customerProfiles = CustomerProfileStore.load(this)
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 578
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 579
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 580
```kotlin
    private fun CustomerBackupResult.exportMessage() = "Đã xuất ZIP: $customerCount khách, $imageCount ảnh WebP" + if (missingImageCount > 0) "; thiếu $missingImageCount ảnh không còn trên máy." else "."
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 581
```kotlin
    private fun CustomerBackupResult.importMessage() = "Đã nhập ZIP: $customerCount khách, $imageCount ảnh."
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 582
```kotlin
    private fun openDial(order: DeliveryOrder) = startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${order.phone}")))
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 583
```kotlin
    private fun openSms(order: DeliveryOrder, message: String) = startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${order.phone}")).putExtra("sms_body", message))
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 584
```kotlin
    private fun openZalo(order: DeliveryOrder, ignoredMessage: String) {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 585
```kotlin
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("zalo://conversation?phone=${order.phone}"))
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 586
```kotlin
        runCatching { startActivity(intent) }.getOrElse {
```
**Giải thích:** Xử lý lỗi/ngoại lệ; kiểm tra nhánh này khi thao tác mạng hoặc hệ thống thất bại.

### Dòng 587
```kotlin
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://zalo.me/${order.phone}")))
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 588
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 589
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 590
```kotlin
    private fun lastLocation() = runCatching {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 591
```kotlin
        val manager = getSystemService(LocationManager::class.java)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 592
```kotlin
        val now = System.currentTimeMillis()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 593
```kotlin
        val candidates: List<Location> = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 594
```kotlin
            .mapNotNull { provider -> runCatching { manager.getLastKnownLocation(provider) }.getOrNull() }
```
**Giải thích:** Biến đổi từng phần tử của danh sách sang giá trị mới.

### Dòng 595
```kotlin
            .filter { location -> RealtimeLocationPolicy.isUsableForCustomer(location.time, location.accuracy, now) }
```
**Giải thích:** Lọc dữ liệu theo điều kiện; chỉ giữ phần tử thỏa điều kiện.

### Dòng 596
```kotlin
        candidates.minWithOrNull(compareBy<Location> { it.accuracy }.thenByDescending { it.time })
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 597
```kotlin
    }.getOrNull()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 598
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 599
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 600
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 601
```kotlin
@Composable
```
**Giải thích:** Đánh dấu hàm là Jetpack Compose UI; Compose có thể gọi và tái dựng hàm này.

### Dòng 602
```kotlin
private fun DeliveryLaunchScreen() {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 603
```kotlin
    Image(
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 604
```kotlin
        painter = painterResource(com.example.delivery.R.drawable.delivery_splash),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 605
```kotlin
        contentDescription = "Đang tải ứng dụng giao hàng",
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 606
```kotlin
        modifier = Modifier.fillMaxSize().background(Color.White),
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 607
```kotlin
        contentScale = ContentScale.Fit,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 608
```kotlin
    )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 609
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

