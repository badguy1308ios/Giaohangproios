# Phân tích từng dòng — `com/example/delivery/model/DeliveryOrder.kt`

> Tài liệu đọc/debug: mã gốc theo từng dòng + giải thích. Không dùng trực tiếp để compile.

### Dòng 1
```kotlin
package com.example.delivery.model
```
**Giải thích:** Khai báo package, xác định namespace của file.

### Dòng 2
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 3
```kotlin
import java.text.NumberFormat
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 4
```kotlin
import java.util.Locale
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 5
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 6
```kotlin
enum class DeliveryStatus {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 7
```kotlin
    TT500, TT505, TT506, TT507, TT508, TT515;
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 8
```kotlin
    companion object { fun label(status: DeliveryStatus) = status.name }
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 9
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 10
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 11
```kotlin
enum class DeliveryOutcome {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 12
```kotlin
    ACTIVE,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 13
```kotlin
    DELIVERED,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 14
```kotlin
    TEMPORARY_FAILURE,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 15
```kotlin
    TERMINAL_FAILURE,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 16
```kotlin
    PICKUP_AT_WAREHOUSE,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 17
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 18
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 19
```kotlin
enum class DeliveryFailureReason(val label: String, val outcome: DeliveryOutcome) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 20
```kotlin
    NO_CONTACT("Không liên lạc được", DeliveryOutcome.TEMPORARY_FAILURE),
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 21
```kotlin
    RESCHEDULED("Hẹn giao lại", DeliveryOutcome.TEMPORARY_FAILURE),
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 22
```kotlin
    REFUSED("Từ chối nhận", DeliveryOutcome.TERMINAL_FAILURE),
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 23
```kotlin
    THREE_ATTEMPTS("Giao thất bại 3 ca", DeliveryOutcome.TERMINAL_FAILURE),
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 24
```kotlin
    PICKUP_AT_WAREHOUSE("Tới kho lấy", DeliveryOutcome.PICKUP_AT_WAREHOUSE),
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 25
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 26
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 27
```kotlin
data class DeliveryOrder(
```
**Giải thích:** Khai báo lớp; gom dữ liệu hoặc hành vi liên quan vào một đơn vị.

### Dòng 28
```kotlin
    val waybill: String,
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 29
```kotlin
    val customer: String,
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 30
```kotlin
    val phone: String,
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 31
```kotlin
    val address: String,
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 32
```kotlin
    val product: String,
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 33
```kotlin
    val cod: Long,
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 34
```kotlin
    val service: String,
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 35
```kotlin
    val status: DeliveryStatus = DeliveryStatus.TT500,
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 36
```kotlin
    val sequence: Int = 0,
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 37
```kotlin
    val latitude: Double = 10.7769,
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 38
```kotlin
    val longitude: Double = 106.7009,
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 39
```kotlin
    val requiresRedelivery: Boolean = false,
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 40
```kotlin
    val wasRedelivered: Boolean = false,
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 41
```kotlin
    val failureReason: DeliveryFailureReason? = null,
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 42
```kotlin
    val failureCount: Int = 0,
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 43
```kotlin
    val delivered: Boolean = false,
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 44
```kotlin
    /** Nhãn STT đầy đủ; null nghĩa là dùng sequence nguyên để tương thích dữ liệu cũ. */
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 45
```kotlin
    val sequenceLabel: String? = null,
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 46
```kotlin
)
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 47
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 48
```kotlin
fun Long.formatVnd(): String = NumberFormat.getNumberInstance(Locale("vi", "VN")).format(this) + " đ"
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 49
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 50
```kotlin
/** Mã trạng thái trong CSV là nguồn hiển thị chính; dữ liệu cũ được suy ra từ các cờ đã lưu. */
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 51
```kotlin
fun DeliveryOrder.csvStatus(): DeliveryStatus = when {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 52
```kotlin
    status == DeliveryStatus.TT515 -> DeliveryStatus.TT500
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 53
```kotlin
    status != DeliveryStatus.TT500 -> status
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 54
```kotlin
    failureReason?.outcome == DeliveryOutcome.TEMPORARY_FAILURE || requiresRedelivery -> DeliveryStatus.TT506
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 55
```kotlin
    failureReason?.outcome == DeliveryOutcome.PICKUP_AT_WAREHOUSE -> DeliveryStatus.TT507
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 56
```kotlin
    failureReason?.outcome == DeliveryOutcome.TERMINAL_FAILURE -> DeliveryStatus.TT505
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 57
```kotlin
    wasRedelivered -> DeliveryStatus.TT508
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 58
```kotlin
    else -> DeliveryStatus.TT500
```
**Giải thích:** Nhánh thay thế khi điều kiện if trước đó sai.

### Dòng 59
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 60
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 61
```kotlin
/** Tương thích dữ liệu cũ: trạng thái nghiệp vụ được suy ra từ mã CSV và các cờ đã lưu. */
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 62
```kotlin
fun DeliveryOrder.deliveryOutcome(): DeliveryOutcome = when {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 63
```kotlin
    delivered || status == DeliveryStatus.TT515 -> DeliveryOutcome.DELIVERED
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 64
```kotlin
    else -> when (csvStatus()) {
```
**Giải thích:** Nhánh thay thế khi điều kiện if trước đó sai.

### Dòng 65
```kotlin
    DeliveryStatus.TT506 -> DeliveryOutcome.TEMPORARY_FAILURE
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 66
```kotlin
    DeliveryStatus.TT507 -> DeliveryOutcome.PICKUP_AT_WAREHOUSE
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 67
```kotlin
    DeliveryStatus.TT505 -> DeliveryOutcome.TERMINAL_FAILURE
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 68
```kotlin
    else -> DeliveryOutcome.ACTIVE
```
**Giải thích:** Nhánh thay thế khi điều kiện if trước đó sai.

### Dòng 69
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 70
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 71
```kotlin
fun DeliveryOrder.statusLabel(): String = when (deliveryOutcome()) {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 72
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 73
```kotlin
    DeliveryOutcome.ACTIVE -> if (wasRedelivered) "Đang giao lại" else "Đang giao"
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 74
```kotlin
    DeliveryOutcome.DELIVERED -> "Đã giao"
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 75
```kotlin
    DeliveryOutcome.TEMPORARY_FAILURE -> "Thất bại tạm thời"
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 76
```kotlin
    DeliveryOutcome.TERMINAL_FAILURE -> "Giao thất bại"
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 77
```kotlin
    DeliveryOutcome.PICKUP_AT_WAREHOUSE -> "Tới kho lấy"
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 78
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 79
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 80
```kotlin
/** TT500, TT506, TT507, TT508 vẫn được xếp tuyến; chỉ TT505 bị loại khỏi STT. */
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 81
```kotlin
fun DeliveryOrder.canReceiveRouteSequence(): Boolean = !delivered && status != DeliveryStatus.TT515 && csvStatus() != DeliveryStatus.TT505
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 82
```kotlin
fun DeliveryOrder.sequenceText(): String = sequenceLabel?.trim()?.takeIf { it.isNotBlank() } ?: sequence.takeIf { it > 0 }?.toString().orEmpty()
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 83
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 84
```kotlin
/** Khóa nhóm ổn định: bỏ ký tự định dạng của SĐT, dùng MVĐ nếu SĐT trống. */
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 85
```kotlin
fun DeliveryOrder.phoneGroupKey(): String = phone.filter(Char::isDigit).ifBlank { waybill.trim().lowercase(Locale.ROOT) }
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 86
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 87
```kotlin
/** Sửa dữ liệu cũ để mọi MVĐ cùng SĐT có đúng một STT hiển thị/lưu trữ. */
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 88
```kotlin
fun List<DeliveryOrder>.withSharedPhoneSequence(): List<DeliveryOrder> {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 89
```kotlin
    val canonical = filter { it.sequenceText().isNotBlank() }
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 90
```kotlin
        .groupBy { it.phoneGroupKey() }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 91
```kotlin
        .mapValues { (_, group) -> group.minWith(compareBy<DeliveryOrder> { it.sequenceSortValue() }.thenBy { it.waybill }).sequenceText() }
```
**Giải thích:** Biến đổi từng phần tử của danh sách sang giá trị mới.

### Dòng 92
```kotlin
    return map { order -> canonical[order.phoneGroupKey()]?.let(order::withSequenceLabel) ?: order }
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 93
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 94
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 95
```kotlin
/** Khóa sắp xếp: STT nguyên đứng trước nhánh, `5.n` đứng sau các nhánh cụ thể của 5. */
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 96
```kotlin
fun DeliveryOrder.sequenceSortValue(): Long = sequenceText().let { text ->
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 97
```kotlin
    if (text.isBlank()) Long.MAX_VALUE
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 98
```kotlin
    else {
```
**Giải thích:** Nhánh thay thế khi điều kiện if trước đó sai.

### Dòng 99
```kotlin
        val parts = text.split('.', limit = 2)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 100
```kotlin
        val major = parts[0].toIntOrNull() ?: Int.MAX_VALUE
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 101
```kotlin
        val minor = parts.getOrNull(1)?.let { if (it.equals("n", true)) 999_999 else it.toIntOrNull() ?: 999_998 } ?: 0
```
**Giải thích:** Xử lý giá trị nullable an toàn; khối chỉ chạy khi giá trị tồn tại.

### Dòng 102
```kotlin
        major.toLong() * 1_000_000L + minor
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 103
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 104
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 105
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 106
```kotlin
fun DeliveryOrder.isRouteActive(): Boolean = canReceiveRouteSequence() && sequenceText().isNotBlank()
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 107
```kotlin
fun DeliveryOrder.isPickupAtWarehouse(): Boolean = deliveryOutcome() == DeliveryOutcome.PICKUP_AT_WAREHOUSE
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 108
```kotlin
/** Chỉ hiển thị năm mã trạng thái nghiệp vụ đã thống nhất. */
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 109
```kotlin
fun DeliveryOrder.detailStatusLabel(): String = when (csvStatus()) {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 110
```kotlin
    DeliveryStatus.TT500 -> "TT500"
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 111
```kotlin
    DeliveryStatus.TT506 -> "TT506 · Hẹn lại / Không liên lạc được"
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 112
```kotlin
    DeliveryStatus.TT507 -> "TT507 · Tới kho nhận"
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 113
```kotlin
    DeliveryStatus.TT508 -> "TT508 · Giao lại"
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 114
```kotlin
    DeliveryStatus.TT505 -> "TT505 · Từ chối nhận / Giao thất bại 3 ca"
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 115
```kotlin
    DeliveryStatus.TT515 -> "TT500"
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 116
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 117
```kotlin
fun DeliveryOrder.isMapVisible(): Boolean = hasStoredCoordinates() && isRouteActive()
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 118
```kotlin
fun DeliveryOrder.isTemporaryFailure(): Boolean = deliveryOutcome() == DeliveryOutcome.TEMPORARY_FAILURE
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 119
```kotlin
fun DeliveryOrder.isTerminalFailure(): Boolean = deliveryOutcome() == DeliveryOutcome.TERMINAL_FAILURE
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 120
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 121
```kotlin
/** Một cặp tọa độ an toàn để truyền cho MapLibre và dịch vụ chỉ đường. */
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 122
```kotlin
fun isMapCoordinatePair(latitude: Double, longitude: Double): Boolean =
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 123
```kotlin
    latitude.isFinite() && longitude.isFinite() && latitude in -90.0..90.0 && longitude in -180.0..180.0
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 124
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 125
```kotlin
/** Tọa độ 0,0 biểu thị đơn chưa được người dùng lưu vị trí khách hàng. */
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 126
```kotlin
fun DeliveryOrder.hasStoredCoordinates(): Boolean = isMapCoordinatePair(latitude, longitude) && (latitude != 0.0 || longitude != 0.0)
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 127
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 128
```kotlin
/**
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 129
```kotlin
 * Khôi phục dữ liệu cũ từng dán ngược Kinh độ, Vĩ độ. Cặp không thể sửa an toàn
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 130
```kotlin
 * được đổi thành 0,0 để không thể làm MapLibre crash.
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 131
```kotlin
 */
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 132
```kotlin
fun DeliveryOrder.normalizedCoordinates(): DeliveryOrder = when {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 133
```kotlin
    isMapCoordinatePair(latitude, longitude) -> this
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 134
```kotlin
    isMapCoordinatePair(longitude, latitude) -> copy(latitude = longitude, longitude = latitude)
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 135
```kotlin
    else -> copy(latitude = 0.0, longitude = 0.0)
```
**Giải thích:** Nhánh thay thế khi điều kiện if trước đó sai.

### Dòng 136
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 137
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 138
```kotlin
fun List<DeliveryOrder>.nextActiveSequence(): Int = filter { it.isRouteActive() }
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 139
```kotlin
    .maxOfOrNull { it.sequence }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 140
```kotlin
    ?.plus(1)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 141
```kotlin
    ?: 1
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 142
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 143
```kotlin
/** Thứ tự nghiệp vụ chung: chưa tọa độ, đang giao, giao lại, kho lấy, tạm thời, hoàn toàn, đã giao. */
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 144
```kotlin
fun List<DeliveryOrder>.dispatchDisplayOrder(): List<DeliveryOrder> = sortedWith(
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 145
```kotlin
    compareBy<DeliveryOrder> {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 146
```kotlin
        when {
```
**Giải thích:** Rẽ nhánh nhiều trường hợp dựa trên giá trị/điều kiện.

### Dòng 147
```kotlin
            it.deliveryOutcome() == DeliveryOutcome.ACTIVE && !it.hasStoredCoordinates() -> 0
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 148
```kotlin
            it.isRouteActive() -> 1
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 149
```kotlin
            it.isPickupAtWarehouse() -> 2
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 150
```kotlin
            it.isTemporaryFailure() -> 3
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 151
```kotlin
            it.isTerminalFailure() -> 4
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 152
```kotlin
            it.deliveryOutcome() == DeliveryOutcome.DELIVERED -> 5
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 153
```kotlin
            else -> 5
```
**Giải thích:** Nhánh thay thế khi điều kiện if trước đó sai.

### Dòng 154
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 155
```kotlin
    }.thenBy { it.sequenceSortValue() }.thenBy { it.waybill },
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 156
```kotlin
)
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 157
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 158
```kotlin
/** Áp dụng số route đã chốt; đơn đã xử lý không còn số, các đơn còn lại không bị tái đánh số. */
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 159
```kotlin
fun List<DeliveryOrder>.withStableRouteSequence(sequenceByWaybill: Map<String, Int>): List<DeliveryOrder> =
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 160
```kotlin
    map { order ->
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 161
```kotlin
        val sequence = sequenceByWaybill[order.waybill]
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 162
```kotlin
        if (sequence != null) order.copy(sequence = sequence, sequenceLabel = null) else order
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 163
```kotlin
    }.dispatchDisplayOrder()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 164
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 165
```kotlin
fun List<DeliveryOrder>.withStableRouteLabels(sequenceByWaybill: Map<String, String>): List<DeliveryOrder> =
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 166
```kotlin
    map { order ->
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 167
```kotlin
        val label = sequenceByWaybill[order.waybill]
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 168
```kotlin
        if (label != null) order.withSequenceLabel(label) else order
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 169
```kotlin
    }.dispatchDisplayOrder()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 170
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 171
```kotlin
/**
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 172
```kotlin
 * Chèn STT mới vào tuyến và dồn các đơn phía sau sang STT kế tiếp.
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 173
```kotlin
 * Đơn vừa sửa được ưu tiên trước khi gặp STT trùng; các nhánh hợp lệ được giữ
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 174
```kotlin
 * nguyên nếu không xung đột, còn nhánh bị đẩy sẽ nhận số kế tiếp để không trùng.
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 175
```kotlin
 */
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 176
```kotlin
fun List<DeliveryOrder>.resequenceDraftLabels(
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 177
```kotlin
    drafts: Map<String, String>,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 178
```kotlin
    original: Map<String, String>,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 179
```kotlin
): Map<String, String> {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 180
```kotlin
    val routable = filter { it.canReceiveRouteSequence() && it.hasStoredCoordinates() }
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 181
```kotlin
    val ranked = routable.groupBy { it.phoneGroupKey() }.values.mapIndexed { index, group ->
```
**Giải thích:** Biến đổi từng phần tử của danh sách sang giá trị mới.

### Dòng 182
```kotlin
        val order = group.first()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 183
```kotlin
        val label = group.map { drafts[it.waybill]?.trim().orEmpty().ifBlank { original[it.waybill].orEmpty().ifBlank { it.sequenceText() } } }
```
**Giải thích:** Biến đổi từng phần tử của danh sách sang giá trị mới.

### Dòng 184
```kotlin
            .firstOrNull { it.isNotBlank() } ?: ""
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 185
```kotlin
        Triple(group, label, index)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 186
```kotlin
    }.filter { it.second.isNotBlank() && it.second.toSequenceSortValue() != null }
```
**Giải thích:** Lọc dữ liệu theo điều kiện; chỉ giữ phần tử thỏa điều kiện.

### Dòng 187
```kotlin
        .sortedWith(compareBy<Triple<List<DeliveryOrder>, String, Int>> { it.second.toSequenceSortValue() }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 188
```kotlin
            .thenBy { if (it.first.any { order -> original[order.waybill] != it.second }) 0 else 1 }
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 189
```kotlin
            .thenBy { it.third })
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 190
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 191
```kotlin
    val result = linkedMapOf<String, String>()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 192
```kotlin
    var previousSort = Long.MIN_VALUE
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 193
```kotlin
    var nextMajor = 0
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 194
```kotlin
    ranked.forEach { (group, preferred, _) ->
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 195
```kotlin
        val preferredSort = preferred.toSequenceSortValue() ?: return@forEach
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 196
```kotlin
        val assigned = if (preferredSort > previousSort) {
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 197
```kotlin
            preferred
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 198
```kotlin
        } else {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 199
```kotlin
            var candidate = maxOf(nextMajor + 1, (previousSort / 1_000_000L).toInt() + 1)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 200
```kotlin
            while (result.values.any { it.toSequenceSortValue() == candidate.toLong() * 1_000_000L }) candidate += 1
```
**Giải thích:** Vòng lặp; thực hiện khối nhiều lần theo tập dữ liệu/điều kiện.

### Dòng 201
```kotlin
            candidate.toString()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 202
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 203
```kotlin
        group.forEach { result[it.waybill] = assigned }
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 204
```kotlin
        previousSort = assigned.toSequenceSortValue() ?: previousSort
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 205
```kotlin
        nextMajor = maxOf(nextMajor, (previousSort / 1_000_000L).toInt())
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 206
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 207
```kotlin
    return drafts + result
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 208
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 209
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 210
```kotlin
private fun String.toSequenceSortValue(): Long? {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 211
```kotlin
    val parts = trim().split('.', limit = 2)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 212
```kotlin
    val major = parts.firstOrNull()?.toIntOrNull() ?: return null
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 213
```kotlin
    if (major <= 0) return null
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 214
```kotlin
    val minor = parts.getOrNull(1)?.let { if (it.equals("n", true)) 999_999 else it.toIntOrNull() ?: return null } ?: 0
```
**Giải thích:** Xử lý giá trị nullable an toàn; khối chỉ chạy khi giá trị tồn tại.

### Dòng 215
```kotlin
    if (minor <= 0 && parts.size > 1) return null
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 216
```kotlin
    return major.toLong() * 1_000_000L + minor
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 217
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 218
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 219
```kotlin
fun DeliveryOrder.withSequenceLabel(label: String): DeliveryOrder {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 220
```kotlin
    val normalized = label.trim()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 221
```kotlin
    val major = normalized.substringBefore('.').toIntOrNull() ?: 0
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 222
```kotlin
    return copy(sequence = major, sequenceLabel = normalized.takeIf { it.contains('.') })
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 223
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 224
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 225
```kotlin
fun List<DeliveryOrder>.filterForDetail(query: String, showDelivered: Boolean, showUnsuccessful: Boolean): List<DeliveryOrder> {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 226
```kotlin
    val normalized = query.trim().lowercase()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 227
```kotlin
    val matched = filter { order ->
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 228
```kotlin
        normalized.isBlank() || listOf(order.waybill, order.customer, order.phone, order.cod.toString(), order.cod.formatVnd())
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 229
```kotlin
            .any { it.lowercase().contains(normalized) }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 230
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 231
```kotlin
    val filtered = when {
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 232
```kotlin
        showDelivered -> matched.filter { it.deliveryOutcome() == DeliveryOutcome.DELIVERED }
```
**Giải thích:** Lọc dữ liệu theo điều kiện; chỉ giữ phần tử thỏa điều kiện.

### Dòng 233
```kotlin
        showUnsuccessful -> matched.filter { it.isTemporaryFailure() || it.isTerminalFailure() }
```
**Giải thích:** Lọc dữ liệu theo điều kiện; chỉ giữ phần tử thỏa điều kiện.

### Dòng 234
```kotlin
        else -> matched
```
**Giải thích:** Nhánh thay thế khi điều kiện if trước đó sai.

### Dòng 235
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 236
```kotlin
    return filtered.dispatchDisplayOrder()
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 237
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 238
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 239
```kotlin
fun sampleOrders() = listOf(
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 240
```kotlin
    DeliveryOrder("LT250001", "Nguyễn Minh An", "0900001001", "12 Lê Duẩn, thị trấn Long Thành, Đồng Nai", "Thùng nước giặt 3.5L", 28000, "GBP", DeliveryStatus.TT500, 1, 10.7803, 106.9501),
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 241
```kotlin
    DeliveryOrder("LT250002", "Trần Thu Hà", "0900001002", "45 Lê Duẩn, thị trấn Long Thành, Đồng Nai", "Sữa tắm chăm sóc da", 135000, "PTTX", DeliveryStatus.TT506, 2, 10.7821, 106.9518),
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 242
```kotlin
    DeliveryOrder("LT250003", "Lê Quốc Bảo", "0900001003", "28 Nguyễn Văn Cừ, thị trấn Long Thành, Đồng Nai", "Phụ kiện điện thoại", 78000, "GH1P", DeliveryStatus.TT507, 3, 10.7758, 106.9529),
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 243
```kotlin
    DeliveryOrder("LT250004", "Phạm Ngọc Lan", "0900001004", "67 Nguyễn Văn Cừ, thị trấn Long Thành, Đồng Nai", "Bình giữ nhiệt 1L", 92000, "GBP", DeliveryStatus.TT500, 4, 10.7735, 106.9486),
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 244
```kotlin
    DeliveryOrder("LT250005", "Võ Thanh Tâm", "0900001005", "16 Trần Phú, thị trấn Long Thành, Đồng Nai", "Hộp cơm điện", 215000, "PTTX", DeliveryStatus.TT508, 5, 10.7774, 106.9447),
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 245
```kotlin
    DeliveryOrder("LT250006", "Đặng Mỹ Duyên", "0900001006", "92 Trần Phú, thị trấn Long Thành, Đồng Nai", "Áo khoác chống nắng", 168000, "GH1P", DeliveryStatus.TT506, 6, 10.7843, 106.9434),
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 246
```kotlin
    DeliveryOrder("LT250007", "Bùi Hoàng Nam", "0900001007", "08 Quốc lộ 51, xã An Phước, Long Thành, Đồng Nai", "Dầu nhớt xe máy", 125000, "GBP", DeliveryStatus.TT500, 7, 10.7990, 106.9404),
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 247
```kotlin
    DeliveryOrder("LT250008", "Đỗ Thảo Vy", "0900001008", "120 Quốc lộ 51, xã An Phước, Long Thành, Đồng Nai", "Thực phẩm khô", 186000, "PTTX", DeliveryStatus.TT507, 8, 10.8068, 106.9370),
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 248
```kotlin
    DeliveryOrder("LT250009", "Hồ Gia Huy", "0900001009", "35 ĐT 769, xã Lộc An, Long Thành, Đồng Nai", "Tai nghe Bluetooth", 359000, "GH1P", DeliveryStatus.TT506, 9, 10.7712, 106.9716),
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 249
```kotlin
    DeliveryOrder("LT250010", "Ngô Khánh Linh", "0900001010", "88 ĐT 769, xã Lộc An, Long Thành, Đồng Nai", "Máy xay mini", 245000, "GBP", DeliveryStatus.TT500, 10, 10.7649, 106.9788),
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 250
```kotlin
    DeliveryOrder("LT250011", "Dương Quốc Khánh", "0900001011", "14 Đường Cầu Mây, xã Long Đức, Long Thành, Đồng Nai", "Bộ dụng cụ sửa xe", 312000, "PTTX", DeliveryStatus.TT508, 11, 10.7586, 106.9252),
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 251
```kotlin
    DeliveryOrder("LT250012", "Lý Bảo Trân", "0900001012", "56 Đường Cầu Mây, xã Long Đức, Long Thành, Đồng Nai", "Chăn hè 1.8m", 275000, "GH1P", DeliveryStatus.TT500, 12, 10.7541, 106.9185),
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 252
```kotlin
    DeliveryOrder("LT250013", "Mai Tuấn Kiệt", "0900001013", "21 Đường Hùng Vương, thị trấn Long Thành, Đồng Nai", "Đèn bàn LED", 149000, "GBP", DeliveryStatus.TT506, 13, 10.7897, 106.9549),
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 253
```kotlin
    DeliveryOrder("LT250014", "Tạ Hồng Phúc", "0900001014", "73 Đường Hùng Vương, thị trấn Long Thành, Đồng Nai", "Balo laptop", 420000, "PTTX", DeliveryStatus.TT507, 14, 10.7923, 106.9571),
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 254
```kotlin
    DeliveryOrder("LT250015", "Cao Thu Trang", "0900001015", "18 Đường Nguyễn Huệ, thị trấn Long Thành, Đồng Nai", "Hộp đựng thực phẩm", 86000, "GH1P", DeliveryStatus.TT500, 15, 10.7865, 106.9460),
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 255
```kotlin
    DeliveryOrder("LT250016", "Quách Nhật Minh", "0900001016", "90 Đường Nguyễn Huệ, thị trấn Long Thành, Đồng Nai", "Bàn phím không dây", 535000, "GBP", DeliveryStatus.TT508, 16, 10.7908, 106.9406),
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 256
```kotlin
    DeliveryOrder("LT250017", "Châu Kim Ngân", "0900001017", "31 Đường Suối Trầu, xã Suối Trầu, Long Thành, Đồng Nai", "Mỹ phẩm chăm sóc tóc", 198000, "PTTX", DeliveryStatus.TT506, 17, 10.8031, 106.9316),
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 257
```kotlin
    DeliveryOrder("LT250018", "Tống Anh Khoa", "0900001018", "76 Đường Suối Trầu, xã Suối Trầu, Long Thành, Đồng Nai", "Máy sấy tóc", 389000, "GH1P", DeliveryStatus.TT500, 18, 10.8097, 106.9364),
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 258
```kotlin
    DeliveryOrder("LT250019", "La Mỹ Hạnh", "0900001019", "22 Đường Bàu Cạn, xã Bàu Cạn, Long Thành, Đồng Nai", "Thùng sữa hạt", 264000, "GBP", DeliveryStatus.TT507, 19, 10.7606, 106.9217),
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 259
```kotlin
    DeliveryOrder("LT250020", "Triệu Đức Thành", "0900001020", "95 Đường Bàu Cạn, xã Bàu Cạn, Long Thành, Đồng Nai", "Quạt để bàn", 335000, "PTTX", DeliveryStatus.TT508, 20, 10.7554, 106.9248),
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 260
```kotlin
)
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

