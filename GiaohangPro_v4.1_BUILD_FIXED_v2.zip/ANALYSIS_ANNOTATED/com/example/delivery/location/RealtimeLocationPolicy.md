# Phân tích từng dòng — `com/example/delivery/location/RealtimeLocationPolicy.kt`

> Tài liệu đọc/debug: mã gốc theo từng dòng + giải thích. Không dùng trực tiếp để compile.

### Dòng 1
```kotlin
package com.example.delivery.location
```
**Giải thích:** Khai báo package, xác định namespace của file.

### Dòng 2
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 3
```kotlin
object RealtimeLocationPolicy {
```
**Giải thích:** Khai báo object dùng làm singleton/namespace cho logic dùng chung.

### Dòng 4
```kotlin
    const val MAX_LAST_KNOWN_AGE_MS = 2 * 60 * 1000L
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 5
```kotlin
    const val MAX_CUSTOMER_LOCATION_ACCURACY_METERS = 75f
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 6
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 7
```kotlin
    fun isFreshLastKnown(locationTimeMillis: Long, nowMillis: Long): Boolean =
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 8
```kotlin
        locationTimeMillis > 0 && nowMillis >= locationTimeMillis && nowMillis - locationTimeMillis <= MAX_LAST_KNOWN_AGE_MS
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 9
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 10
```kotlin
    fun shouldAccept(currentTimeMillis: Long?, candidateTimeMillis: Long): Boolean =
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 11
```kotlin
        currentTimeMillis == null || candidateTimeMillis >= currentTimeMillis
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 12
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 13
```kotlin
    /** Không lưu điểm GPS cũ hoặc có bán kính sai số lớn cho địa chỉ khách. */
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 14
```kotlin
    fun isUsableForCustomer(locationTimeMillis: Long, accuracyMeters: Float, nowMillis: Long): Boolean =
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 15
```kotlin
        isFreshLastKnown(locationTimeMillis, nowMillis) && accuracyMeters.isFinite() && accuracyMeters in 0f..MAX_CUSTOMER_LOCATION_ACCURACY_METERS
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 16
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

