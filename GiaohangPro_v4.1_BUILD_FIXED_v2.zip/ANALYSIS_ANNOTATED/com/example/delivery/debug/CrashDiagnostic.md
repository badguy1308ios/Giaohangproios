# Phân tích từng dòng — `com/example/delivery/debug/CrashDiagnostic.kt`

> Tài liệu đọc/debug: mã gốc theo từng dòng + giải thích. Không dùng trực tiếp để compile.

### Dòng 1
```kotlin
package com.example.delivery.debug
```
**Giải thích:** Khai báo package, xác định namespace của file.

### Dòng 2
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 3
```kotlin
import android.content.Context
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 4
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 5
```kotlin
/** Lưu lỗi crash gần nhất để hiển thị một lần khi người dùng mở lại ứng dụng. */
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 6
```kotlin
object CrashDiagnostic {
```
**Giải thích:** Khai báo object dùng làm singleton/namespace cho logic dùng chung.

### Dòng 7
```kotlin
    private const val preferencesName = "delivery_crash_diagnostic"
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 8
```kotlin
    private const val crashDetailKey = "last_crash_detail"
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 9
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 10
```kotlin
    fun record(context: Context, thread: Thread, error: Throwable) {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 11
```kotlin
        runCatching {
```
**Giải thích:** Xử lý lỗi/ngoại lệ; kiểm tra nhánh này khi thao tác mạng hoặc hệ thống thất bại.

### Dòng 12
```kotlin
            context.getSharedPreferences(preferencesName, Context.MODE_PRIVATE)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 13
```kotlin
                .edit()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 14
```kotlin
                .putString(crashDetailKey, CrashDiagnosticFormatter.format(thread.name, error))
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 15
```kotlin
                .commit()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 16
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 17
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 18
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 19
```kotlin
    fun consume(context: Context): String? {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 20
```kotlin
        val preferences = context.getSharedPreferences(preferencesName, Context.MODE_PRIVATE)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 21
```kotlin
        val detail = preferences.getString(crashDetailKey, null) ?: return null
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 22
```kotlin
        preferences.edit().remove(crashDetailKey).apply()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 23
```kotlin
        return detail
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 24
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 25
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 26
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 27
```kotlin
internal object CrashDiagnosticFormatter {
```
**Giải thích:** Khai báo object dùng làm singleton/namespace cho logic dùng chung.

### Dòng 28
```kotlin
    fun format(threadName: String, error: Throwable): String {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 29
```kotlin
        val type = error.javaClass.simpleName.ifBlank { "không xác định" }
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 30
```kotlin
        val message = error.message?.take(240) ?: "không có"
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 31
```kotlin
        val trace = error.stackTraceToString().lineSequence().take(8).joinToString("\n").take(900)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 32
```kotlin
        return "Bước lỗi: ứng dụng bị dừng đột ngột.\nLuồng: $threadName\nLoại lỗi: $type\nChi tiết: $message\n\nDấu vết:\n$trace\n\nChọn Sao chép lỗi và gửi lại nội dung này để kiểm tra tiếp."
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 33
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 34
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

