# Phân tích từng dòng — `com/example/delivery/backup/CustomerBackupArchive.kt`

> Tài liệu đọc/debug: mã gốc theo từng dòng + giải thích. Không dùng trực tiếp để compile.

### Dòng 1
```kotlin
package com.example.delivery.backup
```
**Giải thích:** Khai báo package, xác định namespace của file.

### Dòng 2
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 3
```kotlin
import android.content.Context
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 4
```kotlin
import android.graphics.Bitmap
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 5
```kotlin
import android.graphics.BitmapFactory
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 6
```kotlin
import android.os.Build
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 7
```kotlin
import com.example.delivery.customer.CustomerProfileStore
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 8
```kotlin
import com.example.delivery.history.DeliveryPhotoHistory
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 9
```kotlin
import org.json.JSONArray
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 10
```kotlin
import org.json.JSONObject
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 11
```kotlin
import java.io.BufferedInputStream
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 12
```kotlin
import java.io.BufferedOutputStream
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 13
```kotlin
import java.io.File
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 14
```kotlin
import java.io.FileInputStream
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 15
```kotlin
import java.io.FileOutputStream
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 16
```kotlin
import java.io.InputStream
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 17
```kotlin
import java.io.OutputStream
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 18
```kotlin
import java.security.MessageDigest
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 19
```kotlin
import java.util.zip.ZipEntry
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 20
```kotlin
import java.util.zip.ZipInputStream
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 21
```kotlin
import java.util.zip.ZipOutputStream
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 22
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 23
```kotlin
internal object BackupArchiveRules {
```
**Giải thích:** Khai báo object dùng làm singleton/namespace cho logic dùng chung.

### Dòng 24
```kotlin
    const val FORMAT = "giaohang-customer-backup"
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 25
```kotlin
    const val SCHEMA_VERSION = 1
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 26
```kotlin
    const val MANIFEST = "manifest.json"
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 27
```kotlin
    const val CUSTOMERS = "customers.json"
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 28
```kotlin
    const val EVIDENCE = "transfer_evidence.json"
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 29
```kotlin
    const val MAX_ENTRY_COUNT = 5_000
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 30
```kotlin
    const val MAX_UNCOMPRESSED_BYTES = 350L * 1024L * 1024L
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 31
```kotlin
    const val MAX_JSON_BYTES = 5L * 1024L * 1024L
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 32
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 33
```kotlin
    fun isSafeArchivePath(path: String): Boolean {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 34
```kotlin
        if (path.isBlank() || path.startsWith('/') || path.startsWith('\\')) return false
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 35
```kotlin
        if (':' in path) return false
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 36
```kotlin
        return path.split('/').none { it.isBlank() || it == "." || it == ".." }
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 37
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 38
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 39
```kotlin
    fun photoFolderForEntry(path: String): String? = when {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 40
```kotlin
        path.startsWith("photos/customer_gate/") -> "customer_gate"
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 41
```kotlin
        path.startsWith("photos/bill/") -> "delivery_confirmation"
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 42
```kotlin
        path.startsWith("photos/drop_off/") -> "delivery_confirmation"
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 43
```kotlin
        else -> null
```
**Giải thích:** Nhánh thay thế khi điều kiện if trước đó sai.

### Dòng 44
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 45
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 46
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 47
```kotlin
data class CustomerBackupResult(
```
**Giải thích:** Khai báo lớp; gom dữ liệu hoặc hành vi liên quan vào một đơn vị.

### Dòng 48
```kotlin
    val customerCount: Int,
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 49
```kotlin
    val evidenceCount: Int,
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 50
```kotlin
    val imageCount: Int,
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 51
```kotlin
    val missingImageCount: Int = 0,
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 52
```kotlin
)
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 53
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 54
```kotlin
/**
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 55
```kotlin
 * Xuất và nhập snapshot dữ liệu Khách hàng và evidence chuyển khoản. Ảnh luôn được chuyển sang WebP
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 56
```kotlin
 * trong gói ZIP; dữ liệu đang chạy của ứng dụng tiếp tục dùng file ảnh riêng.
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 57
```kotlin
 */
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 58
```kotlin
object CustomerBackupArchive {
```
**Giải thích:** Khai báo object dùng làm singleton/namespace cho logic dùng chung.

### Dòng 59
```kotlin
    private const val WEBP_QUALITY = 84
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 60
```kotlin
    private const val MAX_EXPORT_DIMENSION = 1920
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 61
```kotlin
    private const val BUFFER_SIZE = 32 * 1024
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 62
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 63
```kotlin
    fun export(context: Context, output: OutputStream): CustomerBackupResult {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 64
```kotlin
        val catalog = ExportPhotoCatalog()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 65
```kotlin
        val customersJson = rewriteCustomersForExport(CustomerProfileStore.snapshotJson(context), catalog)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 66
```kotlin
        val evidenceJson = rewriteEvidenceForExport(DeliveryPhotoHistory.snapshotEvidenceJson(context), catalog)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 67
```kotlin
        val entries = mutableListOf<ArchiveEntryInfo>()
```
**Giải thích:** Xử lý lỗi/ngoại lệ; kiểm tra nhánh này khi thao tác mạng hoặc hệ thống thất bại.

### Dòng 68
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 69
```kotlin
        ZipOutputStream(BufferedOutputStream(output, BUFFER_SIZE)).use { zip ->
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 70
```kotlin
            entries += zip.writeJson(BackupArchiveRules.CUSTOMERS, customersJson)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 71
```kotlin
            entries += zip.writeJson(BackupArchiveRules.EVIDENCE, evidenceJson)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 72
```kotlin
            catalog.plans.values.forEach { plan -> entries += zip.writeWebp(plan) }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 73
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 74
```kotlin
            val manifest = JSONObject()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 75
```kotlin
                .put("format", BackupArchiveRules.FORMAT)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 76
```kotlin
                .put("schemaVersion", BackupArchiveRules.SCHEMA_VERSION)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 77
```kotlin
                .put("createdAt", System.currentTimeMillis())
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 78
```kotlin
                .put("customers", JSONArray(customersJson).length())
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 79
```kotlin
                .put("transferEvidence", JSONArray(evidenceJson).length())
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 80
```kotlin
                .put("images", catalog.plans.size)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 81
```kotlin
                .put("missingImages", catalog.missingImageCount)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 82
```kotlin
                .put("entries", JSONArray(entries.map { it.toJson() }))
```
**Giải thích:** Biến đổi từng phần tử của danh sách sang giá trị mới.

### Dòng 83
```kotlin
            zip.writeJson(BackupArchiveRules.MANIFEST, manifest.toString())
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 84
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 85
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 86
```kotlin
        return CustomerBackupResult(
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 87
```kotlin
            customerCount = JSONArray(customersJson).length(),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 88
```kotlin
            evidenceCount = JSONArray(evidenceJson).length(),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 89
```kotlin
            imageCount = catalog.plans.size,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 90
```kotlin
            missingImageCount = catalog.missingImageCount,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 91
```kotlin
        )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 92
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 93
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 94
```kotlin
    fun import(context: Context, input: InputStream): CustomerBackupResult {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 95
```kotlin
        val temporaryRoot = File(context.cacheDir, "customer_backup_import_${System.nanoTime()}")
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 96
```kotlin
        try {
```
**Giải thích:** Xử lý lỗi/ngoại lệ; kiểm tra nhánh này khi thao tác mạng hoặc hệ thống thất bại.

### Dòng 97
```kotlin
            temporaryRoot.mkdirs()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 98
```kotlin
            extractZip(input, temporaryRoot)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 99
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 100
```kotlin
            val manifestFile = File(temporaryRoot, BackupArchiveRules.MANIFEST)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 101
```kotlin
            val customerFile = File(temporaryRoot, BackupArchiveRules.CUSTOMERS)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 102
```kotlin
            val evidenceFile = File(temporaryRoot, BackupArchiveRules.EVIDENCE)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 103
```kotlin
            require(manifestFile.isFile && customerFile.isFile && evidenceFile.isFile) {
```
**Giải thích:** Điều kiện bảo vệ/invariant; nếu sai sẽ phát sinh lỗi để ngăn dữ liệu không hợp lệ.

### Dòng 104
```kotlin
                "ZIP thiếu file dữ liệu bắt buộc."
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 105
```kotlin
            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 106
```kotlin
            require(manifestFile.length() <= BackupArchiveRules.MAX_JSON_BYTES && customerFile.length() <= BackupArchiveRules.MAX_JSON_BYTES && evidenceFile.length() <= BackupArchiveRules.MAX_JSON_BYTES) {
```
**Giải thích:** Điều kiện bảo vệ/invariant; nếu sai sẽ phát sinh lỗi để ngăn dữ liệu không hợp lệ.

### Dòng 107
```kotlin
                "Dữ liệu JSON trong ZIP vượt giới hạn cho phép."
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 108
```kotlin
            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 109
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 110
```kotlin
            val manifest = JSONObject(manifestFile.readText(Charsets.UTF_8))
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 111
```kotlin
            validateManifest(manifest, temporaryRoot)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 112
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 113
```kotlin
            val customerRaw = customerFile.readText(Charsets.UTF_8)
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 114
```kotlin
            val evidenceRaw = evidenceFile.readText(Charsets.UTF_8)
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 115
```kotlin
            CustomerProfileStore.validateBackupJson(customerRaw)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 116
```kotlin
            DeliveryPhotoHistory.validateBackupJson(evidenceRaw)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 117
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 118
```kotlin
            val photoPaths = copyPhotosToApplicationStorage(context, manifest, temporaryRoot)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 119
```kotlin
            val customerJson = rewriteCustomersForImport(customerRaw, photoPaths)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 120
```kotlin
            val evidenceJson = rewriteEvidenceForImport(evidenceRaw, photoPaths)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 121
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 122
```kotlin
            CustomerProfileStore.validateBackupJson(customerJson)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 123
```kotlin
            DeliveryPhotoHistory.validateBackupJson(evidenceJson)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 124
```kotlin
            CustomerProfileStore.replaceFromBackupJson(context, customerJson)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 125
```kotlin
            DeliveryPhotoHistory.replaceFromBackupJson(context, evidenceJson)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 126
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 127
```kotlin
            return CustomerBackupResult(
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 128
```kotlin
                customerCount = JSONArray(customerJson).length(),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 129
```kotlin
                evidenceCount = JSONArray(evidenceJson).length(),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 130
```kotlin
                    imageCount = photoPaths.size,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 131
```kotlin
            )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 132
```kotlin
        } finally {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 133
```kotlin
            temporaryRoot.deleteRecursively()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 134
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 135
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 136
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 137
```kotlin
    private fun rewriteCustomersForExport(raw: String, catalog: ExportPhotoCatalog): String {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 138
```kotlin
        val customers = JSONArray(raw)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 139
```kotlin
        repeat(customers.length()) { customerIndex ->
```
**Giải thích:** Vòng lặp; thực hiện khối nhiều lần theo tập dữ liệu/điều kiện.

### Dòng 140
```kotlin
            val addresses = customers.getJSONObject(customerIndex).optJSONArray("addresses") ?: JSONArray()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 141
```kotlin
            repeat(addresses.length()) { addressIndex ->
```
**Giải thích:** Vòng lặp; thực hiện khối nhiều lần theo tập dữ liệu/điều kiện.

### Dòng 142
```kotlin
                val address = addresses.getJSONObject(addressIndex)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 143
```kotlin
                address.put("housePhoto", catalog.reference(address.optString("housePhoto"), "customer_gate"))
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 144
```kotlin
            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 145
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 146
```kotlin
        return customers.toString()
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 147
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 148
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 149
```kotlin
    private fun rewriteEvidenceForExport(raw: String, catalog: ExportPhotoCatalog): String {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 150
```kotlin
        val evidence = JSONArray(raw)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 151
```kotlin
        repeat(evidence.length()) { index ->
```
**Giải thích:** Vòng lặp; thực hiện khối nhiều lần theo tập dữ liệu/điều kiện.

### Dòng 152
```kotlin
            evidence.getJSONObject(index).apply {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 153
```kotlin
                put("bill", catalog.reference(optString("bill"), "bill"))
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 154
```kotlin
                put("drop", catalog.reference(optString("drop"), "drop_off"))
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 155
```kotlin
            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 156
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 157
```kotlin
        return evidence.toString()
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 158
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 159
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 160
```kotlin
    private fun rewriteCustomersForImport(raw: String, photoPaths: Map<String, String>): String {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 161
```kotlin
        val customers = JSONArray(raw)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 162
```kotlin
        repeat(customers.length()) { customerIndex ->
```
**Giải thích:** Vòng lặp; thực hiện khối nhiều lần theo tập dữ liệu/điều kiện.

### Dòng 163
```kotlin
            val addresses = customers.getJSONObject(customerIndex).optJSONArray("addresses") ?: JSONArray()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 164
```kotlin
            repeat(addresses.length()) { addressIndex ->
```
**Giải thích:** Vòng lặp; thực hiện khối nhiều lần theo tập dữ liệu/điều kiện.

### Dòng 165
```kotlin
                val address = addresses.getJSONObject(addressIndex)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 166
```kotlin
                address.put("housePhoto", resolvePhotoPath(address.optString("housePhoto"), photoPaths))
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 167
```kotlin
            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 168
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 169
```kotlin
        return customers.toString()
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 170
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 171
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 172
```kotlin
    private fun rewriteEvidenceForImport(raw: String, photoPaths: Map<String, String>): String {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 173
```kotlin
        val evidence = JSONArray(raw)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 174
```kotlin
        repeat(evidence.length()) { index ->
```
**Giải thích:** Vòng lặp; thực hiện khối nhiều lần theo tập dữ liệu/điều kiện.

### Dòng 175
```kotlin
            evidence.getJSONObject(index).apply {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 176
```kotlin
                put("bill", resolvePhotoPath(optString("bill"), photoPaths))
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 177
```kotlin
                put("drop", resolvePhotoPath(optString("drop"), photoPaths))
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 178
```kotlin
            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 179
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 180
```kotlin
        return evidence.toString()
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 181
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 182
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 183
```kotlin
    private fun resolvePhotoPath(reference: String, photoPaths: Map<String, String>): String? {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 184
```kotlin
        if (reference.isBlank() || reference == "null") return null
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 185
```kotlin
        return photoPaths[reference] ?: throw IllegalArgumentException("ZIP tham chiếu ảnh không tồn tại: $reference")
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 186
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 187
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 188
```kotlin
    private fun extractZip(input: InputStream, root: File) {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 189
```kotlin
        val rootPath = root.canonicalPath + File.separator
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 190
```kotlin
        var entryCount = 0
```
**Giải thích:** Xử lý lỗi/ngoại lệ; kiểm tra nhánh này khi thao tác mạng hoặc hệ thống thất bại.

### Dòng 191
```kotlin
        var totalBytes = 0L
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 192
```kotlin
        val names = mutableSetOf<String>()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 193
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 194
```kotlin
        ZipInputStream(BufferedInputStream(input, BUFFER_SIZE)).use { zip ->
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 195
```kotlin
            var entry = zip.nextEntry
```
**Giải thích:** Xử lý lỗi/ngoại lệ; kiểm tra nhánh này khi thao tác mạng hoặc hệ thống thất bại.

### Dòng 196
```kotlin
            while (entry != null) {
```
**Giải thích:** Vòng lặp; thực hiện khối nhiều lần theo tập dữ liệu/điều kiện.

### Dòng 197
```kotlin
                entryCount += 1
```
**Giải thích:** Xử lý lỗi/ngoại lệ; kiểm tra nhánh này khi thao tác mạng hoặc hệ thống thất bại.

### Dòng 198
```kotlin
                require(entryCount <= BackupArchiveRules.MAX_ENTRY_COUNT) { "ZIP có quá nhiều file." }
```
**Giải thích:** Điều kiện bảo vệ/invariant; nếu sai sẽ phát sinh lỗi để ngăn dữ liệu không hợp lệ.

### Dòng 199
```kotlin
                require(BackupArchiveRules.isSafeArchivePath(entry.name) && names.add(entry.name)) { "ZIP có đường dẫn không an toàn." }
```
**Giải thích:** Điều kiện bảo vệ/invariant; nếu sai sẽ phát sinh lỗi để ngăn dữ liệu không hợp lệ.

### Dòng 200
```kotlin
                val destination = File(root, entry.name)
```
**Giải thích:** Xử lý lỗi/ngoại lệ; kiểm tra nhánh này khi thao tác mạng hoặc hệ thống thất bại.

### Dòng 201
```kotlin
                require(destination.canonicalPath.startsWith(rootPath)) { "ZIP có đường dẫn không an toàn." }
```
**Giải thích:** Điều kiện bảo vệ/invariant; nếu sai sẽ phát sinh lỗi để ngăn dữ liệu không hợp lệ.

### Dòng 202
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 203
```kotlin
                if (entry.isDirectory) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 204
```kotlin
                    destination.mkdirs()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 205
```kotlin
                } else {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 206
```kotlin
                    destination.parentFile?.mkdirs()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 207
```kotlin
                    FileOutputStream(destination).use { target ->
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 208
```kotlin
                        val buffer = ByteArray(BUFFER_SIZE)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 209
```kotlin
                        while (true) {
```
**Giải thích:** Vòng lặp; thực hiện khối nhiều lần theo tập dữ liệu/điều kiện.

### Dòng 210
```kotlin
                            val read = zip.read(buffer)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 211
```kotlin
                            if (read <= 0) break
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 212
```kotlin
                            totalBytes += read
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 213
```kotlin
                            require(totalBytes <= BackupArchiveRules.MAX_UNCOMPRESSED_BYTES) { "ZIP vượt giới hạn dung lượng giải nén." }
```
**Giải thích:** Điều kiện bảo vệ/invariant; nếu sai sẽ phát sinh lỗi để ngăn dữ liệu không hợp lệ.

### Dòng 214
```kotlin
                            target.write(buffer, 0, read)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 215
```kotlin
                        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 216
```kotlin
                    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 217
```kotlin
                }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 218
```kotlin
                zip.closeEntry()
```
**Giải thích:** Xử lý lỗi/ngoại lệ; kiểm tra nhánh này khi thao tác mạng hoặc hệ thống thất bại.

### Dòng 219
```kotlin
                entry = zip.nextEntry
```
**Giải thích:** Xử lý lỗi/ngoại lệ; kiểm tra nhánh này khi thao tác mạng hoặc hệ thống thất bại.

### Dòng 220
```kotlin
            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 221
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 222
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 223
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 224
```kotlin
    private fun validateManifest(manifest: JSONObject, root: File) {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 225
```kotlin
        require(manifest.optString("format") == BackupArchiveRules.FORMAT) { "Không phải file sao lưu Giao Hàng hợp lệ." }
```
**Giải thích:** Điều kiện bảo vệ/invariant; nếu sai sẽ phát sinh lỗi để ngăn dữ liệu không hợp lệ.

### Dòng 226
```kotlin
        require(manifest.optInt("schemaVersion") == BackupArchiveRules.SCHEMA_VERSION) { "Phiên bản file sao lưu chưa được hỗ trợ." }
```
**Giải thích:** Điều kiện bảo vệ/invariant; nếu sai sẽ phát sinh lỗi để ngăn dữ liệu không hợp lệ.

### Dòng 227
```kotlin
        val entries = manifest.optJSONArray("entries") ?: throw IllegalArgumentException("ZIP thiếu danh sách kiểm tra.")
```
**Giải thích:** Chủ động phát sinh ngoại lệ để báo lỗi không thể tiếp tục.

### Dòng 228
```kotlin
        val declared = mutableSetOf<String>()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 229
```kotlin
        repeat(entries.length()) { index ->
```
**Giải thích:** Vòng lặp; thực hiện khối nhiều lần theo tập dữ liệu/điều kiện.

### Dòng 230
```kotlin
            val item = entries.getJSONObject(index)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 231
```kotlin
            val path = item.getString("path")
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 232
```kotlin
            require(BackupArchiveRules.isSafeArchivePath(path) && declared.add(path)) { "Danh sách file trong ZIP không hợp lệ." }
```
**Giải thích:** Điều kiện bảo vệ/invariant; nếu sai sẽ phát sinh lỗi để ngăn dữ liệu không hợp lệ.

### Dòng 233
```kotlin
            val file = File(root, path)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 234
```kotlin
            require(file.isFile) { "ZIP thiếu file: $path" }
```
**Giải thích:** Điều kiện bảo vệ/invariant; nếu sai sẽ phát sinh lỗi để ngăn dữ liệu không hợp lệ.

### Dòng 235
```kotlin
            require(file.length() == item.getLong("bytes")) { "Kích thước file không khớp: $path" }
```
**Giải thích:** Điều kiện bảo vệ/invariant; nếu sai sẽ phát sinh lỗi để ngăn dữ liệu không hợp lệ.

### Dòng 236
```kotlin
            require(sha256(file) == item.getString("sha256")) { "Checksum không khớp: $path" }
```
**Giải thích:** Điều kiện bảo vệ/invariant; nếu sai sẽ phát sinh lỗi để ngăn dữ liệu không hợp lệ.

### Dòng 237
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 238
```kotlin
        require(BackupArchiveRules.CUSTOMERS in declared && BackupArchiveRules.EVIDENCE in declared) {
```
**Giải thích:** Điều kiện bảo vệ/invariant; nếu sai sẽ phát sinh lỗi để ngăn dữ liệu không hợp lệ.

### Dòng 239
```kotlin
            "ZIP thiếu dữ liệu chính."
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 240
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 241
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 242
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 243
```kotlin
    private fun copyPhotosToApplicationStorage(context: Context, manifest: JSONObject, root: File): Map<String, String> {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 244
```kotlin
        val entries = manifest.getJSONArray("entries")
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 245
```kotlin
        val paths = linkedMapOf<String, String>()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 246
```kotlin
        repeat(entries.length()) { index ->
```
**Giải thích:** Vòng lặp; thực hiện khối nhiều lần theo tập dữ liệu/điều kiện.

### Dòng 247
```kotlin
            val path = entries.getJSONObject(index).getString("path")
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 248
```kotlin
            val targetFolder = BackupArchiveRules.photoFolderForEntry(path) ?: return@repeat
```
**Giải thích:** Xử lý lỗi/ngoại lệ; kiểm tra nhánh này khi thao tác mạng hoặc hệ thống thất bại.

### Dòng 249
```kotlin
            val source = File(root, path)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 250
```kotlin
            val targetDir = File(context.filesDir, targetFolder).apply { mkdirs() }
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 251
```kotlin
            val target = File(targetDir, File(path).name)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 252
```kotlin
            source.copyTo(target, overwrite = true)
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 253
```kotlin
            paths[path] = target.absolutePath
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 254
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 255
```kotlin
        return paths
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 256
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 257
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 258
```kotlin
    private fun ZipOutputStream.writeJson(path: String, json: String): ArchiveEntryInfo {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 259
```kotlin
        val bytes = json.toByteArray(Charsets.UTF_8)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 260
```kotlin
        putNextEntry(ZipEntry(path))
```
**Giải thích:** Xử lý lỗi/ngoại lệ; kiểm tra nhánh này khi thao tác mạng hoặc hệ thống thất bại.

### Dòng 261
```kotlin
        write(bytes)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 262
```kotlin
        closeEntry()
```
**Giải thích:** Xử lý lỗi/ngoại lệ; kiểm tra nhánh này khi thao tác mạng hoặc hệ thống thất bại.

### Dòng 263
```kotlin
        return ArchiveEntryInfo(path, bytes.size.toLong(), sha256(bytes))
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 264
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 265
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 266
```kotlin
    private fun ZipOutputStream.writeWebp(plan: PhotoPlan): ArchiveEntryInfo {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 267
```kotlin
        val bitmap = decodeForBackup(plan.source) ?: throw IllegalStateException("Không đọc được ảnh: ${plan.source.name}")
```
**Giải thích:** Chủ động phát sinh ngoại lệ để báo lỗi không thể tiếp tục.

### Dòng 268
```kotlin
        val digest = MessageDigest.getInstance("SHA-256")
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 269
```kotlin
        var byteCount = 0L
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 270
```kotlin
        try {
```
**Giải thích:** Xử lý lỗi/ngoại lệ; kiểm tra nhánh này khi thao tác mạng hoặc hệ thống thất bại.

### Dòng 271
```kotlin
            putNextEntry(ZipEntry(plan.archivePath))
```
**Giải thích:** Xử lý lỗi/ngoại lệ; kiểm tra nhánh này khi thao tác mạng hoặc hệ thống thất bại.

### Dòng 272
```kotlin
            val output = object : OutputStream() {
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 273
```kotlin
                override fun write(value: Int) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 274
```kotlin
                    digest.update(value.toByte())
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 275
```kotlin
                    this@writeWebp.write(value)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 276
```kotlin
                    byteCount += 1
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 277
```kotlin
                }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 278
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 279
```kotlin
                override fun write(buffer: ByteArray, offset: Int, length: Int) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 280
```kotlin
                    digest.update(buffer, offset, length)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 281
```kotlin
                    this@writeWebp.write(buffer, offset, length)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 282
```kotlin
                    byteCount += length
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 283
```kotlin
                }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 284
```kotlin
            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 285
```kotlin
            val format = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) Bitmap.CompressFormat.WEBP_LOSSY else Bitmap.CompressFormat.WEBP
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 286
```kotlin
            check(bitmap.compress(format, WEBP_QUALITY, output)) { "Không thể nén ảnh WebP: ${plan.source.name}" }
```
**Giải thích:** Điều kiện bảo vệ/invariant; nếu sai sẽ phát sinh lỗi để ngăn dữ liệu không hợp lệ.

### Dòng 287
```kotlin
            closeEntry()
```
**Giải thích:** Xử lý lỗi/ngoại lệ; kiểm tra nhánh này khi thao tác mạng hoặc hệ thống thất bại.

### Dòng 288
```kotlin
            return ArchiveEntryInfo(plan.archivePath, byteCount, digest.digest().toHex())
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 289
```kotlin
        } finally {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 290
```kotlin
            bitmap.recycle()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 291
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 292
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 293
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 294
```kotlin
    private fun decodeForBackup(file: File): Bitmap? {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 295
```kotlin
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 296
```kotlin
        BitmapFactory.decodeFile(file.path, bounds)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 297
```kotlin
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 298
```kotlin
        val options = BitmapFactory.Options().apply {
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 299
```kotlin
            inSampleSize = sampleSize(bounds.outWidth, bounds.outHeight)
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 300
```kotlin
            inPreferredConfig = Bitmap.Config.ARGB_8888
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 301
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 302
```kotlin
        return BitmapFactory.decodeFile(file.path, options)
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 303
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 304
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 305
```kotlin
    private fun sampleSize(width: Int, height: Int): Int {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 306
```kotlin
        var sample = 1
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 307
```kotlin
        while (width / sample > MAX_EXPORT_DIMENSION || height / sample > MAX_EXPORT_DIMENSION) sample *= 2
```
**Giải thích:** Vòng lặp; thực hiện khối nhiều lần theo tập dữ liệu/điều kiện.

### Dòng 308
```kotlin
        return sample
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 309
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 310
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 311
```kotlin
    private fun sha256(file: File): String = FileInputStream(file).use { input ->
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 312
```kotlin
        val digest = MessageDigest.getInstance("SHA-256")
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 313
```kotlin
        val buffer = ByteArray(BUFFER_SIZE)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 314
```kotlin
        while (true) {
```
**Giải thích:** Vòng lặp; thực hiện khối nhiều lần theo tập dữ liệu/điều kiện.

### Dòng 315
```kotlin
            val read = input.read(buffer)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 316
```kotlin
            if (read <= 0) break
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 317
```kotlin
            digest.update(buffer, 0, read)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 318
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 319
```kotlin
        digest.digest().toHex()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 320
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 321
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 322
```kotlin
    private fun sha256(bytes: ByteArray): String = MessageDigest.getInstance("SHA-256").digest(bytes).toHex()
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 323
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 324
```kotlin
    private fun ByteArray.toHex(): String = joinToString("") { "%02x".format(it.toInt() and 0xff) }
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 325
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 326
```kotlin
    private data class ArchiveEntryInfo(val path: String, val bytes: Long, val sha256: String) {
```
**Giải thích:** Khai báo lớp; gom dữ liệu hoặc hành vi liên quan vào một đơn vị.

### Dòng 327
```kotlin
        fun toJson() = JSONObject().put("path", path).put("bytes", bytes).put("sha256", sha256)
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 328
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 329
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 330
```kotlin
    private data class PhotoPlan(val source: File, val archivePath: String)
```
**Giải thích:** Khai báo lớp; gom dữ liệu hoặc hành vi liên quan vào một đơn vị.

### Dòng 331
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 332
```kotlin
    private class ExportPhotoCatalog {
```
**Giải thích:** Khai báo lớp; gom dữ liệu hoặc hành vi liên quan vào một đơn vị.

### Dòng 333
```kotlin
        val plans = linkedMapOf<String, PhotoPlan>()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 334
```kotlin
        var missingImageCount = 0
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 335
```kotlin
            private set
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 336
```kotlin
        private var nextIndex = 1
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 337
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 338
```kotlin
        fun reference(originalPath: String, category: String): String? {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 339
```kotlin
            if (originalPath.isBlank() || originalPath == "null") return null
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 340
```kotlin
            val source = File(originalPath)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 341
```kotlin
            if (!source.isFile) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 342
```kotlin
                missingImageCount += 1
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 343
```kotlin
                return null
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 344
```kotlin
            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 345
```kotlin
            return plans.getOrPut(source.canonicalPath) {
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 346
```kotlin
                val archivePath = "photos/$category/${category}_${nextIndex++}.webp"
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 347
```kotlin
                PhotoPlan(source, archivePath)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 348
```kotlin
            }.archivePath
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 349
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 350
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 351
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

