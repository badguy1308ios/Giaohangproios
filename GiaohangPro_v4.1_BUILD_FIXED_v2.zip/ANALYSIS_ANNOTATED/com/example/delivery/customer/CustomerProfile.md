# Phân tích từng dòng — `com/example/delivery/customer/CustomerProfile.kt`

> Tài liệu đọc/debug: mã gốc theo từng dòng + giải thích. Không dùng trực tiếp để compile.

### Dòng 1
```kotlin
package com.example.delivery.customer
```
**Giải thích:** Khai báo package, xác định namespace của file.

### Dòng 2
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 3
```kotlin
import android.content.Context
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 4
```kotlin
import com.example.delivery.model.DeliveryOrder
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 5
```kotlin
import com.example.delivery.model.hasStoredCoordinates
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 6
```kotlin
import com.example.delivery.model.isMapCoordinatePair
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 7
```kotlin
import org.json.JSONArray
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 8
```kotlin
import org.json.JSONObject
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 9
```kotlin
import java.text.Normalizer
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 10
```kotlin
import java.util.Locale
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 11
```kotlin
import java.util.UUID
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 12
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 13
```kotlin
enum class CustomerContactMethod(val label: String) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 14
```kotlin
    CALL("Gọi"),
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 15
```kotlin
    SMS("SMS"),
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 16
```kotlin
    ZALO("Zalo"),
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 17
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 18
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 19
```kotlin
data class CustomerPhone(
```
**Giải thích:** Khai báo lớp; gom dữ liệu hoặc hành vi liên quan vào một đơn vị.

### Dòng 20
```kotlin
    val number: String,
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 21
```kotlin
    val isPrimary: Boolean = false,
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 22
```kotlin
    val methods: Set<CustomerContactMethod> = setOf(CustomerContactMethod.CALL, CustomerContactMethod.SMS, CustomerContactMethod.ZALO),
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 23
```kotlin
)
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 24
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 25
```kotlin
data class CustomerAddress(
```
**Giải thích:** Khai báo lớp; gom dữ liệu hoặc hành vi liên quan vào một đơn vị.

### Dòng 26
```kotlin
    val address: String,
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 27
```kotlin
    val latitude: Double? = null,
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 28
```kotlin
    val longitude: Double? = null,
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 29
```kotlin
    val isPrimary: Boolean = false,
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 30
```kotlin
    val housePhotoPath: String? = null,
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 31
```kotlin
)
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 32
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 33
```kotlin
/** Chuẩn hóa tọa độ khách đã lưu nhầm theo thứ tự Kinh độ, Vĩ độ. */
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 34
```kotlin
fun CustomerAddress.normalizedCoordinates(): CustomerAddress = when {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 35
```kotlin
    latitude == null || longitude == null -> this
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 36
```kotlin
    isMapCoordinatePair(latitude, longitude) -> this
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 37
```kotlin
    isMapCoordinatePair(longitude, latitude) -> copy(latitude = longitude, longitude = latitude)
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 38
```kotlin
    else -> copy(latitude = null, longitude = null)
```
**Giải thích:** Nhánh thay thế khi điều kiện if trước đó sai.

### Dòng 39
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 40
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 41
```kotlin
data class CustomerProfile(
```
**Giải thích:** Khai báo lớp; gom dữ liệu hoặc hành vi liên quan vào một đơn vị.

### Dòng 42
```kotlin
    val id: String = UUID.randomUUID().toString(),
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 43
```kotlin
    val name: String = "",
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 44
```kotlin
    val names: List<String> = emptyList(),
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 45
```kotlin
    val phones: List<CustomerPhone> = listOf(CustomerPhone("", isPrimary = true)),
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 46
```kotlin
    val addresses: List<CustomerAddress> = listOf(CustomerAddress("", isPrimary = true)),
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 47
```kotlin
    val note: String = "",
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 48
```kotlin
) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 49
```kotlin
    val displayName: String get() = names.firstOrNull { it.isNotBlank() } ?: name
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 50
```kotlin
    val primaryPhone: CustomerPhone
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 51
```kotlin
        get() = phones.firstOrNull { it.isPrimary }
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 52
```kotlin
            ?: phones.firstOrNull()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 53
```kotlin
            ?: CustomerPhone(number = "", isPrimary = true)
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 54
```kotlin
    val primaryAddress: CustomerAddress
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 55
```kotlin
        get() = addresses.firstOrNull { it.isPrimary }
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 56
```kotlin
            ?: addresses.firstOrNull()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 57
```kotlin
            ?: CustomerAddress(address = "", isPrimary = true)
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 58
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 59
```kotlin
    fun normalized(): CustomerProfile {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 60
```kotlin
        val cleanNames = (names + name).map(String::trim).filter(String::isNotBlank).distinct()
```
**Giải thích:** Lọc dữ liệu theo điều kiện; chỉ giữ phần tử thỏa điều kiện.

### Dòng 61
```kotlin
        val cleanPhones = phones.map { it.copy(number = it.number.trim()) }.filter { it.number.isNotBlank() }
```
**Giải thích:** Lọc dữ liệu theo điều kiện; chỉ giữ phần tử thỏa điều kiện.

### Dòng 62
```kotlin
        val normalizedPhones = cleanPhones.map { phone ->
```
**Giải thích:** Biến đổi từng phần tử của danh sách sang giá trị mới.

### Dòng 63
```kotlin
            phone.copy(methods = phone.methods.ifEmpty {
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 64
```kotlin
                if (cleanPhones.size == 1) CustomerContactMethod.entries.toSet()
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 65
```kotlin
                else setOf(CustomerContactMethod.CALL)
```
**Giải thích:** Nhánh thay thế khi điều kiện if trước đó sai.

### Dòng 66
```kotlin
            })
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 67
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 68
```kotlin
        val cleanAddresses = addresses.map { it.normalizedCoordinates().copy(address = it.address.trim()) }.filter { it.address.isNotBlank() }
```
**Giải thích:** Lọc dữ liệu theo điều kiện; chỉ giữ phần tử thỏa điều kiện.

### Dòng 69
```kotlin
        val primaryPhoneIndex = cleanPhones.indexOfFirst { it.isPrimary }.takeIf { it >= 0 } ?: 0
```
**Giải thích:** Chọn/loại giá trị theo điều kiện, trả null nếu không thỏa.

### Dòng 70
```kotlin
        val primaryAddressIndex = cleanAddresses.indexOfFirst { it.isPrimary }.takeIf { it >= 0 } ?: 0
```
**Giải thích:** Chọn/loại giá trị theo điều kiện, trả null nếu không thỏa.

### Dòng 71
```kotlin
        return copy(
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 72
```kotlin
            name = cleanNames.firstOrNull().orEmpty(),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 73
```kotlin
            names = cleanNames,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 74
```kotlin
            phones = normalizedPhones.mapIndexed { index, phone -> phone.copy(isPrimary = index == primaryPhoneIndex) },
```
**Giải thích:** Biến đổi từng phần tử của danh sách sang giá trị mới.

### Dòng 75
```kotlin
            addresses = cleanAddresses.mapIndexed { index, address -> address.copy(isPrimary = index == primaryAddressIndex) },
```
**Giải thích:** Biến đổi từng phần tử của danh sách sang giá trị mới.

### Dòng 76
```kotlin
            note = note.trim(),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 77
```kotlin
        )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 78
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 79
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 80
```kotlin
    fun isValid(): Boolean = (names.any { it.isNotBlank() } || name.isNotBlank()) && phones.any { it.number.isNotBlank() } && addresses.any { it.address.isNotBlank() }
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 81
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 82
```kotlin
    companion object {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 83
```kotlin
        fun empty() = CustomerProfile()
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 84
```kotlin
        fun fromOrder(order: DeliveryOrder) = CustomerProfile(
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 85
```kotlin
            id = "order-${order.phone.customerPhoneKey()}",
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 86
```kotlin
            name = order.customer,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 87
```kotlin
            names = listOf(order.customer),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 88
```kotlin
            phones = listOf(CustomerPhone(order.phone, isPrimary = true)),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 89
```kotlin
            addresses = listOf(
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 90
```kotlin
                CustomerAddress(
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 91
```kotlin
                    address = order.address,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 92
```kotlin
                    latitude = order.latitude.takeIf { order.hasStoredCoordinates() },
```
**Giải thích:** Chọn/loại giá trị theo điều kiện, trả null nếu không thỏa.

### Dòng 93
```kotlin
                    longitude = order.longitude.takeIf { order.hasStoredCoordinates() },
```
**Giải thích:** Chọn/loại giá trị theo điều kiện, trả null nếu không thỏa.

### Dòng 94
```kotlin
                    isPrimary = true,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 95
```kotlin
                ),
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 96
```kotlin
            ),
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 97
```kotlin
        )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 98
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 99
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 100
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 101
```kotlin
/** Chỉ tạo hồ sơ mới khi dòng đơn có đủ tên, SĐT và địa chỉ để người dùng bổ sung sau. */
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 102
```kotlin
fun List<CustomerProfile>.missingProfilesFromOrders(orders: List<DeliveryOrder>): List<CustomerProfile> {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 103
```kotlin
    val savedPhones = flatMap { profile -> profile.phones.map { it.number.customerPhoneKey() } }.filter(String::isNotBlank).toSet()
```
**Giải thích:** Lọc dữ liệu theo điều kiện; chỉ giữ phần tử thỏa điều kiện.

### Dòng 104
```kotlin
    return orders
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 105
```kotlin
        .filter { order -> order.phone.customerPhoneKey().isNotBlank() && order.customer.isNotBlank() && order.address.isNotBlank() }
```
**Giải thích:** Lọc dữ liệu theo điều kiện; chỉ giữ phần tử thỏa điều kiện.

### Dòng 106
```kotlin
        .distinctBy { it.phone.customerPhoneKey() }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 107
```kotlin
        .filter { order -> order.phone.customerPhoneKey() !in savedPhones }
```
**Giải thích:** Lọc dữ liệu theo điều kiện; chỉ giữ phần tử thỏa điều kiện.

### Dòng 108
```kotlin
        .map(CustomerProfile::fromOrder)
```
**Giải thích:** Biến đổi từng phần tử của danh sách sang giá trị mới.

### Dòng 109
```kotlin
        .map(CustomerProfile::normalized)
```
**Giải thích:** Biến đổi từng phần tử của danh sách sang giá trị mới.

### Dòng 110
```kotlin
        .filter(CustomerProfile::isValid)
```
**Giải thích:** Lọc dữ liệu theo điều kiện; chỉ giữ phần tử thỏa điều kiện.

### Dòng 111
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 112
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 113
```kotlin
/** Chuẩn hóa 0xxx, 84xxx, +84xxx và 0084xxx về cùng định danh khách hàng. */
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 114
```kotlin
internal fun String.customerPhoneKey(): String {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 115
```kotlin
    val digits = filter(Char::isDigit)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 116
```kotlin
    return when {
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 117
```kotlin
        digits.startsWith("0084") && digits.length > 4 -> "0${digits.drop(4)}"
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 118
```kotlin
        digits.startsWith("84") && digits.length > 2 -> "0${digits.drop(2)}"
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 119
```kotlin
        else -> digits
```
**Giải thích:** Nhánh thay thế khi điều kiện if trước đó sai.

### Dòng 120
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 121
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 122
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 123
```kotlin
fun List<CustomerProfile>.mergeOrderCustomers(orders: List<DeliveryOrder>): List<CustomerProfile> {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 124
```kotlin
    val savedByPhone = flatMap { profile ->
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 125
```kotlin
        profile.phones.mapNotNull { phone -> phone.number.customerPhoneKey().takeIf(String::isNotBlank)?.let { it to profile } }
```
**Giải thích:** Biến đổi từng phần tử của danh sách sang giá trị mới.

### Dòng 126
```kotlin
    }.toMap()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 127
```kotlin
    val orderPhoneKeys = orders.map { it.phone.customerPhoneKey() }.filter(String::isNotBlank).toSet()
```
**Giải thích:** Lọc dữ liệu theo điều kiện; chỉ giữ phần tử thỏa điều kiện.

### Dòng 128
```kotlin
    val derived = orders
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 129
```kotlin
        .filter { it.phone.customerPhoneKey().isNotBlank() }
```
**Giải thích:** Lọc dữ liệu theo điều kiện; chỉ giữ phần tử thỏa điều kiện.

### Dòng 130
```kotlin
        .distinctBy { it.phone.customerPhoneKey() }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 131
```kotlin
        .map { order -> savedByPhone[order.phone.customerPhoneKey()] ?: CustomerProfile.fromOrder(order) }
```
**Giải thích:** Biến đổi từng phần tử của danh sách sang giá trị mới.

### Dòng 132
```kotlin
    val manual = filter { profile -> profile.phones.none { it.number.customerPhoneKey() in orderPhoneKeys } }
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 133
```kotlin
    return (derived + manual)
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 134
```kotlin
        .distinctBy { profile -> profile.phones.firstOrNull()?.number?.customerPhoneKey().orEmpty().ifBlank { profile.id } }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 135
```kotlin
        .sortedBy { it.displayName.lowercase() }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 136
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 137
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 138
```kotlin
fun List<CustomerProfile>.withoutCustomer(customerId: String): List<CustomerProfile> = filterNot { it.id == customerId }
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 139
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 140
```kotlin
fun CustomerProfile.matchesSearch(query: String): Boolean {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 141
```kotlin
    val textQuery = query.searchKey()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 142
```kotlin
    if (textQuery.isBlank()) return true
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 143
```kotlin
    val digitsQuery = query.filter(Char::isDigit)
```
**Giải thích:** Lọc dữ liệu theo điều kiện; chỉ giữ phần tử thỏa điều kiện.

### Dòng 144
```kotlin
    val textMatches = (names + name + addresses.map { it.address }).any { value -> value.searchKey().contains(textQuery) }
```
**Giải thích:** Biến đổi từng phần tử của danh sách sang giá trị mới.

### Dòng 145
```kotlin
    val phoneMatches = phones.any { phone ->
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 146
```kotlin
        phone.number.searchKey().contains(textQuery) || (digitsQuery.isNotBlank() && phone.number.filter(Char::isDigit).contains(digitsQuery))
```
**Giải thích:** Lọc dữ liệu theo điều kiện; chỉ giữ phần tử thỏa điều kiện.

### Dòng 147
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 148
```kotlin
    return textMatches || phoneMatches
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 149
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 150
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 151
```kotlin
private fun String.searchKey(): String = Normalizer.normalize(trim(), Normalizer.Form.NFD)
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 152
```kotlin
    .replace("\\p{Mn}+".toRegex(), "")
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 153
```kotlin
    .lowercase(Locale.ROOT)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 154
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 155
```kotlin
object CustomerProfileStore {
```
**Giải thích:** Khai báo object dùng làm singleton/namespace cho logic dùng chung.

### Dòng 156
```kotlin
    private const val PREF = "customer_profiles_v2"
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 157
```kotlin
    private const val KEY = "items"
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 158
```kotlin
    private const val DELETED_PREFIX = "deleted_"
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 159
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 160
```kotlin
    fun load(context: Context): List<CustomerProfile> = runCatching {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 161
```kotlin
        val array = JSONArray(context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, "[]"))
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 162
```kotlin
        List(array.length()) { array.getJSONObject(it).toProfile() }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 163
```kotlin
    }.getOrDefault(emptyList())
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 164
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 165
```kotlin
    fun upsert(context: Context, profile: CustomerProfile): List<CustomerProfile> {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 166
```kotlin
        val normalized = profile.normalized()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 167
```kotlin
        require(normalized.isValid()) { "Hồ sơ khách hàng chưa đủ thông tin" }
```
**Giải thích:** Điều kiện bảo vệ/invariant; nếu sai sẽ phát sinh lỗi để ngăn dữ liệu không hợp lệ.

### Dòng 168
```kotlin
        val updated = load(context).filterNot { it.id == normalized.id } + normalized
```
**Giải thích:** Lọc dữ liệu theo điều kiện; chỉ giữ phần tử thỏa điều kiện.

### Dòng 169
```kotlin
        return persist(context, updated)
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 170
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 171
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 172
```kotlin
    /** Lưu hẳn các khách mới phát hiện từ dữ liệu đơn, không chỉ hiển thị tạm theo danh sách đơn. */
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 173
```kotlin
    fun upsertMissingFromOrders(context: Context, orders: List<DeliveryOrder>): List<CustomerProfile> {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 174
```kotlin
        val current = load(context)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 175
```kotlin
        val missing = current.missingProfilesFromOrders(orders)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 176
```kotlin
        return if (missing.isEmpty()) current else persist(context, current + missing)
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 177
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 178
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 179
```kotlin
    /** Lưu toàn bộ hồ sơ sau khi một thao tác hệ thống đã cập nhật tọa độ liên quan. */
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 180
```kotlin
    fun replace(context: Context, profiles: List<CustomerProfile>): List<CustomerProfile> = persist(context, profiles)
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 181
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 182
```kotlin
    private fun persist(context: Context, profiles: List<CustomerProfile>): List<CustomerProfile> {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 183
```kotlin
        val normalized = profiles.map(CustomerProfile::normalized).distinctBy(CustomerProfile::id)
```
**Giải thích:** Biến đổi từng phần tử của danh sách sang giá trị mới.

### Dòng 184
```kotlin
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 185
```kotlin
            .putString(KEY, JSONArray(normalized.map { it.toJson() }).toString())
```
**Giải thích:** Biến đổi từng phần tử của danh sách sang giá trị mới.

### Dòng 186
```kotlin
            .apply()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 187
```kotlin
        return normalized
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 188
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 189
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 190
```kotlin
    /** Xóa hồ sơ đã lưu và đánh dấu ẩn để hồ sơ suy ra từ đơn hàng cũng không hiện lại. */
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 191
```kotlin
    fun delete(context: Context, customerId: String): List<CustomerProfile> {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 192
```kotlin
        val updated = load(context).withoutCustomer(customerId)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 193
```kotlin
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 194
```kotlin
            .putString(KEY, JSONArray(updated.map { it.toJson() }).toString())
```
**Giải thích:** Biến đổi từng phần tử của danh sách sang giá trị mới.

### Dòng 195
```kotlin
            .putBoolean("$DELETED_PREFIX$customerId", true)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 196
```kotlin
            .apply()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 197
```kotlin
        return updated
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 198
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 199
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 200
```kotlin
    fun isDeleted(context: Context, customerId: String): Boolean = context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getBoolean("$DELETED_PREFIX$customerId", false)
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 201
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 202
```kotlin
    /** JSON nguyên bản dùng cho archive; đường dẫn ảnh sẽ được module backup thay bằng path tương đối. */
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 203
```kotlin
    fun snapshotJson(context: Context): String = context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 204
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 205
```kotlin
    fun validateBackupJson(raw: String) {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 206
```kotlin
        val values = JSONArray(raw)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 207
```kotlin
        List(values.length()) { values.getJSONObject(it).toProfile() }.forEach { profile ->
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 208
```kotlin
            require(profile.isValid()) { "Một hồ sơ khách hàng trong ZIP chưa đủ thông tin." }
```
**Giải thích:** Điều kiện bảo vệ/invariant; nếu sai sẽ phát sinh lỗi để ngăn dữ liệu không hợp lệ.

### Dòng 209
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 210
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 211
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 212
```kotlin
    fun replaceFromBackupJson(context: Context, raw: String) {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 213
```kotlin
        validateBackupJson(raw)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 214
```kotlin
        val preferences = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 215
```kotlin
        val editor = preferences.edit().putString(KEY, JSONArray(raw).toString())
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 216
```kotlin
        preferences.all.keys.filter { it.startsWith(DELETED_PREFIX) }.forEach(editor::remove)
```
**Giải thích:** Lọc dữ liệu theo điều kiện; chỉ giữ phần tử thỏa điều kiện.

### Dòng 217
```kotlin
        check(editor.commit()) {
```
**Giải thích:** Điều kiện bảo vệ/invariant; nếu sai sẽ phát sinh lỗi để ngăn dữ liệu không hợp lệ.

### Dòng 218
```kotlin
            "Không thể lưu dữ liệu khách hàng sau khi nhập ZIP."
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 219
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 220
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 221
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 222
```kotlin
    private fun CustomerProfile.toJson() = JSONObject()
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 223
```kotlin
        .put("id", id)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 224
```kotlin
        .put("name", name)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 225
```kotlin
        .put("names", JSONArray(names))
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 226
```kotlin
        .put("note", note)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 227
```kotlin
        .put("phones", JSONArray(phones.map { phone -> JSONObject().put("number", phone.number).put("primary", phone.isPrimary).put("methods", JSONArray(phone.methods.map { it.name })) }))
```
**Giải thích:** Biến đổi từng phần tử của danh sách sang giá trị mới.

### Dòng 228
```kotlin
        .put("addresses", JSONArray(addresses.map { address -> JSONObject().put("address", address.address).put("lat", address.latitude).put("lng", address.longitude).put("primary", address.isPrimary).put("housePhoto", address.housePhotoPath) }))
```
**Giải thích:** Biến đổi từng phần tử của danh sách sang giá trị mới.

### Dòng 229
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 230
```kotlin
    private fun JSONObject.toProfile(): CustomerProfile {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 231
```kotlin
        val phoneArray = getJSONArray("phones")
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 232
```kotlin
        val addressArray = getJSONArray("addresses")
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 233
```kotlin
        return CustomerProfile(
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 234
```kotlin
            id = getString("id"),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 235
```kotlin
            name = optString("name"),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 236
```kotlin
            names = optJSONArray("names")?.let { array -> List(array.length()) { array.optString(it) } }.orEmpty(),
```
**Giải thích:** Xử lý giá trị nullable an toàn; khối chỉ chạy khi giá trị tồn tại.

### Dòng 237
```kotlin
            phones = List(phoneArray.length()) { index ->
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 238
```kotlin
                val item = phoneArray.getJSONObject(index)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 239
```kotlin
                CustomerPhone(item.getString("number"), item.optBoolean("primary"), item.optJSONArray("methods")?.let { methods -> List(methods.length()) { CustomerContactMethod.valueOf(methods.getString(it)) }.toSet() } ?: setOf(CustomerContactMethod.CALL))
```
**Giải thích:** Xử lý giá trị nullable an toàn; khối chỉ chạy khi giá trị tồn tại.

### Dòng 240
```kotlin
            },
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 241
```kotlin
            addresses = List(addressArray.length()) { index ->
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 242
```kotlin
                val item = addressArray.getJSONObject(index)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 243
```kotlin
                CustomerAddress(item.getString("address"), item.optDouble("lat").takeIf { !it.isNaN() }, item.optDouble("lng").takeIf { !it.isNaN() }, item.optBoolean("primary"), item.optString("housePhoto").takeIf { it.isNotBlank() && it != "null" })
```
**Giải thích:** Chọn/loại giá trị theo điều kiện, trả null nếu không thỏa.

### Dòng 244
```kotlin
            },
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 245
```kotlin
            note = optString("note"),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 246
```kotlin
        ).normalized()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 247
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 248
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

