# Phân tích từng dòng — `com/example/delivery/history/DeliveryPhotoHistory.kt`

> Tài liệu đọc/debug: mã gốc theo từng dòng + giải thích. Không dùng trực tiếp để compile.

### Dòng 1
```kotlin
package com.example.delivery.history
```
**Giải thích:** Khai báo package, xác định namespace của file.

### Dòng 2
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 3
```kotlin
import android.content.Context
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 4
```kotlin
import android.graphics.Bitmap
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 5
```kotlin
import android.graphics.BitmapFactory
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 6
```kotlin
import android.graphics.Canvas
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 7
```kotlin
import android.graphics.Color
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 8
```kotlin
import android.graphics.Paint
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 9
```kotlin
import androidx.core.content.FileProvider
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 10
```kotlin
import com.example.delivery.model.DeliveryOrder
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 11
```kotlin
import org.json.JSONArray
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 12
```kotlin
import org.json.JSONObject
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 13
```kotlin
import java.io.File
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 14
```kotlin
import java.io.FileOutputStream
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 15
```kotlin
import java.text.SimpleDateFormat
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 16
```kotlin
import java.util.Date
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 17
```kotlin
import java.util.Locale
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 18
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 19
```kotlin
enum class ProofPhotoType { BILL_CLOSEUP, DROP_OFF_WATERMARK }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 20
```kotlin
enum class PaymentChannel { ZALO, SMS }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 21
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 22
```kotlin
data class TransferEvidence(
```
**Giải thích:** Khai báo lớp; gom dữ liệu hoặc hành vi liên quan vào một đơn vị.

### Dòng 23
```kotlin
    val waybill: String,
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 24
```kotlin
    val customer: String,
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 25
```kotlin
    val phone: String,
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 26
```kotlin
    val cod: Long,
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 27
```kotlin
    val channel: PaymentChannel,
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 28
```kotlin
    val message: String,
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 29
```kotlin
    val billPhotoPath: String? = null,
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 30
```kotlin
    val dropOffPhotoPath: String? = null,
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 31
```kotlin
    val sentConfirmed: Boolean = false,
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 32
```kotlin
    val paidConfirmed: Boolean = false,
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 33
```kotlin
    val createdAt: Long = System.currentTimeMillis(),
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 34
```kotlin
    val confirmedAt: Long? = null,
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 35
```kotlin
)
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 36
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 37
```kotlin
object DeliveryPhotoHistory {
```
**Giải thích:** Khai báo object dùng làm singleton/namespace cho logic dùng chung.

### Dòng 38
```kotlin
    private const val EVIDENCE_PREF = "transfer_evidence_v1"
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 39
```kotlin
    private val dateFormat = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US)
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 40
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 41
```kotlin
    fun createOutputFile(context: Context, waybill: String, type: ProofPhotoType): File {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 42
```kotlin
        val dir = File(context.filesDir, "delivery_confirmation").apply { mkdirs() }
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 43
```kotlin
        return File(dir, "${waybill}_${type.name.lowercase()}_${dateFormat.format(Date())}.jpg")
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 44
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 45
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 46
```kotlin
    fun createCustomerGateFile(context: Context, customerId: String): File {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 47
```kotlin
        val dir = File(context.filesDir, "customer_gate").apply { mkdirs() }
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 48
```kotlin
        return File(dir, "${customerId}_${dateFormat.format(Date())}.jpg")
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 49
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 50
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 51
```kotlin
    fun providerUri(context: Context, file: File) = FileProvider.getUriForFile(context, "${context.packageName}.deliveryphotos", file)
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 52
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 53
```kotlin
    fun addDropOffWatermark(file: File, order: DeliveryOrder, latitude: Double?, longitude: Double?): String {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 54
```kotlin
        val original = BitmapFactory.decodeFile(file.path) ?: return file.path
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 55
```kotlin
        val bitmap = original.copy(Bitmap.Config.ARGB_8888, true)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 56
```kotlin
        val canvas = Canvas(bitmap)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 57
```kotlin
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 58
```kotlin
        val stamp = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("vi", "VN")).format(Date())
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 59
```kotlin
        val coordinates = if (latitude != null && longitude != null) String.format(Locale.US, "%.5f, %.5f", latitude, longitude) else "Chưa có GPS"
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 60
```kotlin
        paint.color = Color.argb(185, 0, 0, 0)
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 61
```kotlin
        canvas.drawRect(0f, (bitmap.height - 106).coerceAtLeast(0).toFloat(), bitmap.width.toFloat(), bitmap.height.toFloat(), paint)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 62
```kotlin
        paint.color = Color.WHITE
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 63
```kotlin
        paint.textSize = (bitmap.width / 29f).coerceAtLeast(18f)
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 64
```kotlin
        canvas.drawText(order.waybill, 18f, bitmap.height - 70f, paint)
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 65
```kotlin
        paint.textSize = (bitmap.width / 36f).coerceAtLeast(15f)
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 66
```kotlin
        canvas.drawText("$stamp • $coordinates", 18f, bitmap.height - 32f, paint)
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 67
```kotlin
        FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.JPEG, 92, it) }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 68
```kotlin
        original.recycle(); bitmap.recycle()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 69
```kotlin
        return file.path
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 70
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 71
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 72
```kotlin
    fun getEvidence(context: Context): List<TransferEvidence> = readEvidence(context).sortedByDescending { it.createdAt }
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 73
```kotlin
    fun upsertEvidence(context: Context, evidence: TransferEvidence) { writeEvidence(context, readEvidence(context).filterNot { it.waybill == evidence.waybill } + evidence) }
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 74
```kotlin
    fun confirmPaid(context: Context, waybill: String): TransferEvidence? {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 75
```kotlin
        val current = readEvidence(context).firstOrNull { it.waybill == waybill } ?: return null
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 76
```kotlin
        val confirmed = current.copy(paidConfirmed = true, confirmedAt = System.currentTimeMillis())
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 77
```kotlin
        upsertEvidence(context, confirmed)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 78
```kotlin
        return confirmed
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 79
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 80
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 81
```kotlin
    fun snapshotEvidenceJson(context: Context): String = context.getSharedPreferences(EVIDENCE_PREF, Context.MODE_PRIVATE).getString("items", "[]") ?: "[]"
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 82
```kotlin
    fun validateBackupJson(evidenceRaw: String) {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 83
```kotlin
        val evidence = JSONArray(evidenceRaw)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 84
```kotlin
        List(evidence.length()) { evidence.getJSONObject(it).toEvidence() }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 85
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 86
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 87
```kotlin
    /** Xóa vĩnh viễn dữ liệu bằng chứng/lịch sử và ảnh giao nhận; không tạo lại bản ghi outcome. */
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 88
```kotlin
    fun clearAll(context: Context) {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 89
```kotlin
        val evidence = readEvidence(context)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 90
```kotlin
        val paths = evidence.flatMap { listOfNotNull(it.billPhotoPath, it.dropOffPhotoPath) }.distinct()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 91
```kotlin
        paths.map(::File).forEach { it.delete() }
```
**Giải thích:** Biến đổi từng phần tử của danh sách sang giá trị mới.

### Dòng 92
```kotlin
        File(context.filesDir, "delivery_confirmation").deleteRecursively()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 93
```kotlin
        check(context.getSharedPreferences(EVIDENCE_PREF, Context.MODE_PRIVATE).edit().clear().commit()) {
```
**Giải thích:** Điều kiện bảo vệ/invariant; nếu sai sẽ phát sinh lỗi để ngăn dữ liệu không hợp lệ.

### Dòng 94
```kotlin
            "Không thể xóa bằng chứng giao hàng."
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 95
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 96
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 97
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 98
```kotlin
    fun replaceFromBackupJson(context: Context, evidenceRaw: String) {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 99
```kotlin
        validateBackupJson(evidenceRaw)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 100
```kotlin
        val evidenceSaved = context.getSharedPreferences(EVIDENCE_PREF, Context.MODE_PRIVATE).edit().putString("items", JSONArray(evidenceRaw).toString()).commit()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 101
```kotlin
        check(evidenceSaved) { "Không thể lưu bằng chứng chuyển khoản sau khi nhập ZIP." }
```
**Giải thích:** Điều kiện bảo vệ/invariant; nếu sai sẽ phát sinh lỗi để ngăn dữ liệu không hợp lệ.

### Dòng 102
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 103
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 104
```kotlin
    private fun readEvidence(context: Context): List<TransferEvidence> = runCatching {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 105
```kotlin
        val arr = JSONArray(context.getSharedPreferences(EVIDENCE_PREF, Context.MODE_PRIVATE).getString("items", "[]"))
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 106
```kotlin
        List(arr.length()) { index -> arr.getJSONObject(index).toEvidence() }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 107
```kotlin
    }.getOrDefault(emptyList())
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 108
```kotlin
    private fun writeEvidence(context: Context, values: List<TransferEvidence>) { context.getSharedPreferences(EVIDENCE_PREF, Context.MODE_PRIVATE).edit().putString("items", JSONArray(values.map { it.toJson() }).toString()).apply() }
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 109
```kotlin
    private fun TransferEvidence.toJson() = JSONObject().put("waybill", waybill).put("customer", customer).put("phone", phone).put("cod", cod).put("channel", channel.name).put("message", message).put("bill", billPhotoPath).put("drop", dropOffPhotoPath).put("sent", sentConfirmed).put("paid", paidConfirmed).put("created", createdAt).put("confirmed", confirmedAt)
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 110
```kotlin
    private fun JSONObject.toEvidence() = TransferEvidence(getString("waybill"), getString("customer"), getString("phone"), getLong("cod"), PaymentChannel.valueOf(getString("channel")), getString("message"), optString("bill").takeIf { it.isNotBlank() && it != "null" }, optString("drop").takeIf { it.isNotBlank() && it != "null" }, optBoolean("sent"), optBoolean("paid"), getLong("created"), optLong("confirmed").takeIf { it > 0 })
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 111
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 112
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

