# Phân tích từng dòng — `com/example/delivery/navigation/GoongApiConfig.kt`

> Tài liệu đọc/debug: mã gốc theo từng dòng + giải thích. Không dùng trực tiếp để compile.

### Dòng 1
```kotlin
package com.example.delivery.navigation
```
**Giải thích:** Khai báo package, xác định namespace của file.

### Dòng 2
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 3
```kotlin
import com.example.delivery.BuildConfig
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 4
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 5
```kotlin
/**
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 6
```kotlin
 * GOONG API CONFIGURATION — đặt ở đầu package navigation để dễ tìm và kiểm tra.
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 7
```kotlin
 *
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 8
```kotlin
 * API #1: Map Tiles/Style: tiles.goong.io (MapLibre dùng style JSON + các tile/font/sprite resource).
```
**Giải thích:** Khu vực tích hợp GOONG API; kiểm tra endpoint và API key khi lỗi bản đồ/tuyến.

### Dòng 9
```kotlin
 * API #2: Directions REST: rsapi.goong.io/Direction (tính tuyến đường giữa hai điểm).
```
**Giải thích:** Khu vực tích hợp GOONG API; kiểm tra endpoint và API key khi lỗi bản đồ/tuyến.

### Dòng 10
```kotlin
 *
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 11
```kotlin
 * API key thật không đặt trong source. Gradle lấy từ local.properties:
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 12
```kotlin
 * GOONG_MAP_TILES_KEY và GOONG_REST_API_KEY.
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 13
```kotlin
 */
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 14
```kotlin
internal object GoongApiConfig {
```
**Giải thích:** Khai báo object dùng làm singleton/namespace cho logic dùng chung.

### Dòng 15
```kotlin
    /** GOONG Map Tiles key được Gradle đưa vào BuildConfig từ local.properties. */
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 16
```kotlin
    val mapTilesKey: String
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 17
```kotlin
        get() = BuildConfig.GOONG_MAP_TILES_KEY
```
**Giải thích:** Khu vực tích hợp GOONG API; kiểm tra endpoint và API key khi lỗi bản đồ/tuyến.

### Dòng 18
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 19
```kotlin
    /** GOONG REST Directions key được Gradle đưa vào BuildConfig từ local.properties. */
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 20
```kotlin
    val restApiKey: String
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 21
```kotlin
        get() = BuildConfig.GOONG_REST_API_KEY
```
**Giải thích:** Khu vực tích hợp GOONG API; kiểm tra endpoint và API key khi lỗi bản đồ/tuyến.

### Dòng 22
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 23
```kotlin
    /** Endpoint REST dùng để gọi API Directions. */
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 24
```kotlin
    const val directionsEndpoint = "https://rsapi.goong.io/Direction"
```
**Giải thích:** Khu vực tích hợp GOONG API; kiểm tra endpoint và API key khi lỗi bản đồ/tuyến.

### Dòng 25
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 26
```kotlin
    /** Base domain của hệ thống Map Tiles GOONG, dùng để kiểm tra/cấu hình style. */
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 27
```kotlin
    const val mapTilesEndpoint = "https://tiles.goong.io/"
```
**Giải thích:** Khu vực tích hợp GOONG API; kiểm tra endpoint và API key khi lỗi bản đồ/tuyến.

### Dòng 28
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

