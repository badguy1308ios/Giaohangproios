# Phân tích từng dòng — `com/example/delivery/navigation/GoongDirectionsRepository.kt`

> Tài liệu đọc/debug: mã gốc theo từng dòng + giải thích. Không dùng trực tiếp để compile.

### Dòng 1
```kotlin
package com.example.delivery.navigation
```
**Giải thích:** Khai báo package, xác định namespace của file.

### Dòng 2
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 3
```kotlin
import android.net.Uri
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 4
```kotlin
import kotlinx.coroutines.delay
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 5
```kotlin
import kotlinx.coroutines.Dispatchers
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 6
```kotlin
import kotlinx.coroutines.withContext
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 7
```kotlin
import org.json.JSONObject
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 8
```kotlin
import java.io.IOException
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 9
```kotlin
import java.net.HttpURLConnection
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 10
```kotlin
import java.net.URL
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 11
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 12
```kotlin
data class GeoPoint(val latitude: Double, val longitude: Double)
```
**Giải thích:** Khai báo lớp; gom dữ liệu hoặc hành vi liên quan vào một đơn vị.

### Dòng 13
```kotlin
data class GoongRoute(val points: List<GeoPoint>)
```
**Giải thích:** Khai báo lớp; gom dữ liệu hoặc hành vi liên quan vào một đơn vị.

### Dòng 14
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 15
```kotlin
class GoongDirectionsRepository {
```
**Giải thích:** Khai báo lớp; gom dữ liệu hoặc hành vi liên quan vào một đơn vị.

### Dòng 16
```kotlin
    suspend fun directions(origin: GeoPoint, destination: GeoPoint): Result<GoongRoute> = withContext(Dispatchers.IO) {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 17
```kotlin
        val key = GoongApiConfig.restApiKey
```
**Giải thích:** Khu vực tích hợp GOONG API; kiểm tra endpoint và API key khi lỗi bản đồ/tuyến.

### Dòng 18
```kotlin
        if (key.isBlank()) return@withContext Result.failure(IllegalStateException("Thiếu GOONG_REST_API_KEY"))
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 19
```kotlin
        var lastError: Throwable? = null
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 20
```kotlin
        repeat(3) { attempt ->
```
**Giải thích:** Vòng lặp; thực hiện khối nhiều lần theo tập dữ liệu/điều kiện.

### Dòng 21
```kotlin
            try {
```
**Giải thích:** Xử lý lỗi/ngoại lệ; kiểm tra nhánh này khi thao tác mạng hoặc hệ thống thất bại.

### Dòng 22
```kotlin
                return@withContext Result.success(requestDirections(origin, destination, key))
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 23
```kotlin
            } catch (error: Throwable) {
```
**Giải thích:** Xử lý lỗi/ngoại lệ; kiểm tra nhánh này khi thao tác mạng hoặc hệ thống thất bại.

### Dòng 24
```kotlin
                lastError = error
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 25
```kotlin
                if (attempt < 2) delay(450L * (attempt + 1))
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 26
```kotlin
            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 27
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 28
```kotlin
        Result.failure(lastError ?: IOException("Goong Directions không trả được tuyến đường"))
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 29
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 30
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 31
```kotlin
    private fun requestDirections(origin: GeoPoint, destination: GeoPoint, key: String): GoongRoute {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 32
```kotlin
        val url = Uri.parse(GoongApiConfig.directionsEndpoint).buildUpon()
```
**Giải thích:** Khu vực tích hợp GOONG API; kiểm tra endpoint và API key khi lỗi bản đồ/tuyến.

### Dòng 33
```kotlin
            .appendQueryParameter("origin", "${origin.latitude},${origin.longitude}")
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 34
```kotlin
            .appendQueryParameter("destination", "${destination.latitude},${destination.longitude}")
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 35
```kotlin
            .appendQueryParameter("vehicle", "car")
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 36
```kotlin
            .appendQueryParameter("api_key", key)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 37
```kotlin
            .build().toString()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 38
```kotlin
        val connection = URL(url).openConnection() as HttpURLConnection
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 39
```kotlin
        connection.connectTimeout = 10_000
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 40
```kotlin
        connection.readTimeout = 12_000
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 41
```kotlin
        connection.requestMethod = "GET"
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 42
```kotlin
        return try {
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 43
```kotlin
            if (connection.responseCode !in 200..299) throw IOException("Goong Directions HTTP ${connection.responseCode}")
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 44
```kotlin
            val body = connection.inputStream.bufferedReader().use { it.readText() }
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 45
```kotlin
            val route = JSONObject(body).optJSONArray("routes")?.optJSONObject(0)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 46
```kotlin
            val encoded = route?.optJSONObject("overview_polyline")?.optString("points") ?: route?.optString("overview_polyline")
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 47
```kotlin
            val points = encoded?.takeIf { it.isNotBlank() }?.let(::decodePolyline).orEmpty()
```
**Giải thích:** Chọn/loại giá trị theo điều kiện, trả null nếu không thỏa.

### Dòng 48
```kotlin
            require(points.size >= 2) { "Goong Directions không có overview_polyline" }
```
**Giải thích:** Điều kiện bảo vệ/invariant; nếu sai sẽ phát sinh lỗi để ngăn dữ liệu không hợp lệ.

### Dòng 49
```kotlin
            GoongRoute(points)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 50
```kotlin
        } finally {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 51
```kotlin
            connection.disconnect()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 52
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 53
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 54
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 55
```kotlin
    companion object {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 56
```kotlin
        fun decodePolyline(encoded: String): List<GeoPoint> {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 57
```kotlin
            val points = mutableListOf<GeoPoint>()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 58
```kotlin
            var index = 0
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 59
```kotlin
            var latitude = 0
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 60
```kotlin
            var longitude = 0
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 61
```kotlin
            while (index < encoded.length) {
```
**Giải thích:** Vòng lặp; thực hiện khối nhiều lần theo tập dữ liệu/điều kiện.

### Dòng 62
```kotlin
                fun decodeValue(): Int {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 63
```kotlin
                    var shift = 0
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 64
```kotlin
                    var result = 0
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 65
```kotlin
                    while (index < encoded.length) {
```
**Giải thích:** Vòng lặp; thực hiện khối nhiều lần theo tập dữ liệu/điều kiện.

### Dòng 66
```kotlin
                        val value = encoded[index++].code - 63
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 67
```kotlin
                        result = result or ((value and 0x1f) shl shift)
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 68
```kotlin
                        shift += 5
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 69
```kotlin
                        if (value < 0x20) break
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 70
```kotlin
                    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 71
```kotlin
                    return if ((result and 1) != 0) (result shr 1).inv() else result shr 1
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 72
```kotlin
                }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 73
```kotlin
                latitude += decodeValue()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 74
```kotlin
                longitude += decodeValue()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 75
```kotlin
                points += GeoPoint(latitude / 1e5, longitude / 1e5)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 76
```kotlin
            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 77
```kotlin
            return points
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 78
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 79
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 80
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

