# Phân tích từng dòng — `com/example/delivery/navigation/AnchorPointStore.kt`

> Tài liệu đọc/debug: mã gốc theo từng dòng + giải thích. Không dùng trực tiếp để compile.

### Dòng 1
```kotlin
package com.example.delivery.navigation
```
**Giải thích:** Khai báo package, xác định namespace của file.

### Dòng 2
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 3
```kotlin
import android.content.Context
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 4
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 5
```kotlin
/** Điểm Neo của tuyến giao, được giữ lại cho đến khi người dùng đặt điểm mới. */
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 6
```kotlin
object AnchorPointStore {
```
**Giải thích:** Khai báo object dùng làm singleton/namespace cho logic dùng chung.

### Dòng 7
```kotlin
    private const val PREFERENCES = "delivery_route_preferences"
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 8
```kotlin
    private const val KEY_LATITUDE = "anchor_latitude"
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 9
```kotlin
    private const val KEY_LONGITUDE = "anchor_longitude"
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 10
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 11
```kotlin
    fun load(context: Context): GeoPoint? {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 12
```kotlin
        val preferences = context.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 13
```kotlin
        val latitude = preferences.getString(KEY_LATITUDE, null)?.toDoubleOrNull()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 14
```kotlin
        val longitude = preferences.getString(KEY_LONGITUDE, null)?.toDoubleOrNull()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 15
```kotlin
        return if (latitude.isValidLatitude() && longitude.isValidLongitude()) {
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 16
```kotlin
            GeoPoint(latitude!!, longitude!!)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 17
```kotlin
        } else {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 18
```kotlin
            null
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 19
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 20
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 21
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 22
```kotlin
    /** Ghi đồng bộ để điểm Neo không bị mất nếu app dừng đột ngột ngay sau khi chọn. */
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 23
```kotlin
    fun save(context: Context, point: GeoPoint) {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 24
```kotlin
        require(point.latitude.isValidLatitude()) { "Vĩ độ điểm Neo không hợp lệ." }
```
**Giải thích:** Điều kiện bảo vệ/invariant; nếu sai sẽ phát sinh lỗi để ngăn dữ liệu không hợp lệ.

### Dòng 25
```kotlin
        require(point.longitude.isValidLongitude()) { "Kinh độ điểm Neo không hợp lệ." }
```
**Giải thích:** Điều kiện bảo vệ/invariant; nếu sai sẽ phát sinh lỗi để ngăn dữ liệu không hợp lệ.

### Dòng 26
```kotlin
        val saved = context.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE).edit()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 27
```kotlin
            .putString(KEY_LATITUDE, point.latitude.toString())
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 28
```kotlin
            .putString(KEY_LONGITUDE, point.longitude.toString())
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 29
```kotlin
            .commit()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 30
```kotlin
        check(saved) { "Không thể lưu điểm Neo." }
```
**Giải thích:** Điều kiện bảo vệ/invariant; nếu sai sẽ phát sinh lỗi để ngăn dữ liệu không hợp lệ.

### Dòng 31
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 32
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 33
```kotlin
    private fun Double?.isValidLatitude(): Boolean = this != null && isFinite() && this in -90.0..90.0
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 34
```kotlin
    private fun Double?.isValidLongitude(): Boolean = this != null && isFinite() && this in -180.0..180.0
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 35
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

