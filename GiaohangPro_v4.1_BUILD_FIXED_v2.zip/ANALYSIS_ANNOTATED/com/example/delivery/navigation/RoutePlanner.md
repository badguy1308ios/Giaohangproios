# Phân tích từng dòng — `com/example/delivery/navigation/RoutePlanner.kt`

> Tài liệu đọc/debug: mã gốc theo từng dòng + giải thích. Không dùng trực tiếp để compile.

### Dòng 1
```kotlin
package com.example.delivery.navigation
```
**Giải thích:** Khai báo package, xác định namespace của file.

### Dòng 2
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 3
```kotlin
import com.example.delivery.model.DeliveryOrder
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 4
```kotlin
import com.example.delivery.model.dispatchDisplayOrder
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 5
```kotlin
import com.example.delivery.model.hasStoredCoordinates
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 6
```kotlin
import com.example.delivery.model.isRouteActive
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 7
```kotlin
import com.example.delivery.model.sequenceText
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 8
```kotlin
import com.example.delivery.model.sequenceSortValue
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 9
```kotlin
import com.example.delivery.model.phoneGroupKey
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 10
```kotlin
import kotlin.math.atan2
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 11
```kotlin
import kotlin.math.cos
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 12
```kotlin
import kotlin.math.sin
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 13
```kotlin
import kotlin.math.sqrt
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 14
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 15
```kotlin
private const val EARTH_RADIUS_METERS = 6_371_000.0
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 16
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 17
```kotlin
/** Ưu tiên điểm Neo đã lưu; GPS chỉ là phương án thay thế khi chưa có điểm Neo. */
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 18
```kotlin
fun preferredRouteOrigin(anchorPoint: GeoPoint?, currentLocation: GeoPoint?, fallback: GeoPoint?): GeoPoint? =
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 19
```kotlin
    anchorPoint ?: currentLocation ?: fallback
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 20
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 21
```kotlin
fun distanceMeters(from: GeoPoint, to: GeoPoint): Double {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 22
```kotlin
    val deltaLatitude = Math.toRadians(to.latitude - from.latitude)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 23
```kotlin
    val deltaLongitude = Math.toRadians(to.longitude - from.longitude)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 24
```kotlin
    val latitudeOne = Math.toRadians(from.latitude)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 25
```kotlin
    val latitudeTwo = Math.toRadians(to.latitude)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 26
```kotlin
    val haversine = sin(deltaLatitude / 2) * sin(deltaLatitude / 2) +
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 27
```kotlin
        cos(latitudeOne) * cos(latitudeTwo) * sin(deltaLongitude / 2) * sin(deltaLongitude / 2)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 28
```kotlin
    return EARTH_RADIUS_METERS * 2 * atan2(sqrt(haversine), sqrt(1 - haversine))
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 29
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 30
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 31
```kotlin
/**
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 32
```kotlin
 * Lập tuyến hai bước: chọn điểm kế gần nhất từ GPS hiện tại, sau đó tối ưu toàn cục
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 33
```kotlin
 * bằng 2-opt và phép chuyển điểm. Phép chuyển điểm xử lý các trường hợp greedy
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 34
```kotlin
 * chen một điểm xa vào giữa một cụm giao gần nhau.
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 35
```kotlin
 */
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 36
```kotlin
fun routeOrdersFrom(origin: GeoPoint, orders: List<DeliveryOrder>): List<DeliveryOrder> = routeOrdersFromZones(origin, orders, emptyList())
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 37
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 38
```kotlin
/**
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 39
```kotlin
 * Sắp xếp các block SĐT theo kinh độ tăng dần (trái sang phải), sau đó vĩ độ
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 40
```kotlin
 * tăng dần (dưới lên trên). Trong cùng ô địa lý lân cận, Zone được ưu tiên
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 41
```kotlin
 * theo thứ tự trong danh sách Zone để không tách các MVĐ gần nhau quá xa.
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 42
```kotlin
 */
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 43
```kotlin
fun orderRouteGroupsByZoneAndGeo(groups: Collection<List<DeliveryOrder>>, zones: List<DeliveryZone>): List<List<DeliveryOrder>> {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 44
```kotlin
    if (groups.size <= 1) return groups.toList()
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 45
```kotlin
    fun center(group: List<DeliveryOrder>) = GeoPoint(group.map { it.latitude }.average(), group.map { it.longitude }.average())
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 46
```kotlin
    fun zoneRank(group: List<DeliveryOrder>): Int = zones.indexOfFirst { zone ->
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 47
```kotlin
        group.any { order -> DeliveryRouteStore.contains(zone, order.latitude, order.longitude) }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 48
```kotlin
    }.let { if (it < 0) Int.MAX_VALUE else it }
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 49
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 50
```kotlin
    val remaining = groups.toMutableList()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 51
```kotlin
    val ordered = mutableListOf<List<DeliveryOrder>>()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 52
```kotlin
    var cursorGroup = remaining.minWithOrNull(compareBy<List<DeliveryOrder>>(
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 53
```kotlin
        { group -> center(group).longitude },
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 54
```kotlin
        { group -> center(group).latitude },
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 55
```kotlin
        { group -> zoneRank(group) },
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 56
```kotlin
        { group -> group.minOf { it.waybill } },
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 57
```kotlin
    )) ?: return emptyList()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 58
```kotlin
    remaining.remove(cursorGroup)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 59
```kotlin
    ordered += cursorGroup
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 60
```kotlin
    var cursor = center(cursorGroup)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 61
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 62
```kotlin
    while (remaining.isNotEmpty()) {
```
**Giải thích:** Vòng lặp; thực hiện khối nhiều lần theo tập dữ liệu/điều kiện.

### Dòng 63
```kotlin
        val next = remaining.minWithOrNull(compareBy<List<DeliveryOrder>>(
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 64
```kotlin
            { group ->
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 65
```kotlin
                val target = center(group)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 66
```kotlin
                val travel = distanceMeters(cursor, target)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 67
```kotlin
                // Giữ chiều trái-phải: chỉ chấp nhận đi lùi khi quãng đường ngắn hơn rõ rệt.
```
**Giải thích:** Chú thích hiện có; không tạo hành vi chạy.

### Dòng 68
```kotlin
                val backward = ((cursor.longitude - target.longitude).coerceAtLeast(0.0)) * 111_000.0
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 69
```kotlin
                travel + backward * 2.0
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 70
```kotlin
            },
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 71
```kotlin
            { group -> zoneRank(group) },
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 72
```kotlin
            { group -> center(group).longitude },
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 73
```kotlin
            { group -> center(group).latitude },
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 74
```kotlin
            { group -> group.minOf { it.waybill } },
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 75
```kotlin
        )) ?: break
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 76
```kotlin
        ordered += next
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 77
```kotlin
        cursor = center(next)
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 78
```kotlin
        remaining.remove(next)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 79
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 80
```kotlin
    return ordered
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 81
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 82
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 83
```kotlin
/** Lập tuyến theo ưu tiên Zone; trong mỗi Zone sắp gần đến xa, ngoài Zone xếp sau. */
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 84
```kotlin
fun routeOrdersFromZones(origin: GeoPoint, orders: List<DeliveryOrder>, zones: List<DeliveryZone>): List<DeliveryOrder> {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 85
```kotlin
    val candidates = orders.filter { it.isRouteActive() && it.hasStoredCoordinates() }
```
**Giải thích:** Lọc dữ liệu theo điều kiện; chỉ giữ phần tử thỏa điều kiện.

### Dòng 86
```kotlin
    val groups = candidates.groupBy { it.phoneGroupKey() }.values
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 87
```kotlin
    val orderedGroups = if (zones.isEmpty()) nearestNeighborGroups(origin, groups) else orderRouteGroupsByZoneAndGeo(groups, zones)
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 88
```kotlin
    return orderedGroups.flatMapIndexed { index, group ->
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 89
```kotlin
        group.sortedWith(compareBy<DeliveryOrder> { it.longitude }.thenBy { it.latitude }.thenBy { it.waybill })
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 90
```kotlin
            .map { it.copy(sequence = index + 1) }
```
**Giải thích:** Biến đổi từng phần tử của danh sách sang giá trị mới.

### Dòng 91
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 92
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 93
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 94
```kotlin
private fun nearestNeighborGroups(origin: GeoPoint, groups: Collection<List<DeliveryOrder>>): List<List<DeliveryOrder>> {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 95
```kotlin
    val remaining = groups.toMutableList()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 96
```kotlin
    val result = mutableListOf<List<DeliveryOrder>>()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 97
```kotlin
    var cursor = origin
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 98
```kotlin
    while (remaining.isNotEmpty()) {
```
**Giải thích:** Vòng lặp; thực hiện khối nhiều lần theo tập dữ liệu/điều kiện.

### Dòng 99
```kotlin
        val next = remaining.minByOrNull { group -> group.minOf { distanceMeters(cursor, GeoPoint(it.latitude, it.longitude)) } } ?: break
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 100
```kotlin
        result += next
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 101
```kotlin
        cursor = next.minBy { distanceMeters(cursor, GeoPoint(it.latitude, it.longitude)) }.let { GeoPoint(it.latitude, it.longitude) }
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 102
```kotlin
        remaining.remove(next)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 103
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 104
```kotlin
    return result
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 105
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 106
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 107
```kotlin
private fun nearestNeighbor(origin: GeoPoint, orders: List<DeliveryOrder>): List<DeliveryOrder> {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 108
```kotlin
    val remaining = orders.toMutableList()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 109
```kotlin
    val result = mutableListOf<DeliveryOrder>()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 110
```kotlin
    var cursor = origin
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 111
```kotlin
    while (remaining.isNotEmpty()) {
```
**Giải thích:** Vòng lặp; thực hiện khối nhiều lần theo tập dữ liệu/điều kiện.

### Dòng 112
```kotlin
        val next = remaining.minByOrNull { distanceMeters(cursor, GeoPoint(it.latitude, it.longitude)) } ?: break
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 113
```kotlin
        result += next
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 114
```kotlin
        cursor = GeoPoint(next.latitude, next.longitude)
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 115
```kotlin
        remaining.remove(next)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 116
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 117
```kotlin
    return result
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 118
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 119
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 120
```kotlin
/** Đảo các đoạn tuyến khi việc đảo làm giảm tổng quãng đường đi thực tế. */
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 121
```kotlin
private fun optimizeRoute(origin: GeoPoint, initial: List<DeliveryOrder>): List<DeliveryOrder> {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 122
```kotlin
    if (initial.size < 3) return initial
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 123
```kotlin
    var route = initial
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 124
```kotlin
    var bestDistance = routeDistanceMeters(origin, route)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 125
```kotlin
    var improved = true
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 126
```kotlin
    while (improved) {
```
**Giải thích:** Vòng lặp; thực hiện khối nhiều lần theo tập dữ liệu/điều kiện.

### Dòng 127
```kotlin
        improved = false
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 128
```kotlin
        var bestCandidate = route
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 129
```kotlin
        var bestCandidateDistance = bestDistance
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 130
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 131
```kotlin
        // Thử toàn bộ phép đảo đoạn 2-opt, chọn ứng viên tốt nhất của lượt hiện tại.
```
**Giải thích:** Chú thích hiện có; không tạo hành vi chạy.

### Dòng 132
```kotlin
        for (start in 0 until route.lastIndex) {
```
**Giải thích:** Vòng lặp; thực hiện khối nhiều lần theo tập dữ liệu/điều kiện.

### Dòng 133
```kotlin
            for (end in start + 1..route.lastIndex) {
```
**Giải thích:** Vòng lặp; thực hiện khối nhiều lần theo tập dữ liệu/điều kiện.

### Dòng 134
```kotlin
                val candidate = route.toMutableList().apply { subList(start, end + 1).reverse() }
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 135
```kotlin
                val candidateDistance = routeDistanceMeters(origin, candidate)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 136
```kotlin
                if (candidateDistance + 0.5 < bestCandidateDistance) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 137
```kotlin
                    bestCandidate = candidate
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 138
```kotlin
                    bestCandidateDistance = candidateDistance
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 139
```kotlin
                }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 140
```kotlin
            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 141
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 142
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 143
```kotlin
        // Thử đưa từng điểm ra khỏi vị trí cũ và chèn vào vị trí khác. Đây là bước
```
**Giải thích:** Chú thích hiện có; không tạo hành vi chạy.

### Dòng 144
```kotlin
        // giữ các điểm sát nhau thành một cụm ngay cả khi nearest-neighbor ban đầu bị chen.
```
**Giải thích:** Chú thích hiện có; không tạo hành vi chạy.

### Dòng 145
```kotlin
        for (from in route.indices) {
```
**Giải thích:** Vòng lặp; thực hiện khối nhiều lần theo tập dữ liệu/điều kiện.

### Dòng 146
```kotlin
            val without = route.toMutableList().apply { removeAt(from) }
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 147
```kotlin
            for (insertion in 0..without.size) {
```
**Giải thích:** Vòng lặp; thực hiện khối nhiều lần theo tập dữ liệu/điều kiện.

### Dòng 148
```kotlin
                val candidate = without.toMutableList().apply { add(insertion, route[from]) }
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 149
```kotlin
                val candidateDistance = routeDistanceMeters(origin, candidate)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 150
```kotlin
                if (candidateDistance + 0.5 < bestCandidateDistance) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 151
```kotlin
                    bestCandidate = candidate
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 152
```kotlin
                    bestCandidateDistance = candidateDistance
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 153
```kotlin
                }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 154
```kotlin
            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 155
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 156
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 157
```kotlin
        if (bestCandidateDistance + 0.5 < bestDistance) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 158
```kotlin
            route = bestCandidate
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 159
```kotlin
            bestDistance = bestCandidateDistance
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 160
```kotlin
            improved = true
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 161
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 162
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 163
```kotlin
    return route
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 164
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 165
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 166
```kotlin
fun routeDistanceMeters(origin: GeoPoint, route: List<DeliveryOrder>): Double {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 167
```kotlin
    var total = 0.0
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 168
```kotlin
    var cursor = origin
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 169
```kotlin
    route.forEach { order ->
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 170
```kotlin
        val next = GeoPoint(order.latitude, order.longitude)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 171
```kotlin
        total += distanceMeters(cursor, next)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 172
```kotlin
        cursor = next
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 173
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 174
```kotlin
    return total
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 175
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 176
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 177
```kotlin
/**
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 178
```kotlin
 * Trả về đúng một danh sách để mọi tab dùng chung: các điểm GPS đang giao được
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 179
```kotlin
 * đánh số nearest-neighbor, sau đó là đơn thất bại không số, rồi đơn đã giao không số.
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 180
```kotlin
 */
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 181
```kotlin
fun routeOrdersForDisplay(origin: GeoPoint, orders: List<DeliveryOrder>): List<DeliveryOrder> {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 182
```kotlin
    val active = routeOrdersFrom(origin, orders)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 183
```kotlin
    val inactive = orders.filterNot { it.isRouteActive() }.dispatchDisplayOrder()
```
**Giải thích:** Lọc dữ liệu theo điều kiện; chỉ giữ phần tử thỏa điều kiện.

### Dòng 184
```kotlin
    return active + inactive
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 185
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 186
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 187
```kotlin
/**
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 188
```kotlin
 * Khôi phục bản đồ STT đã commit trong DeliveryOrderStore. Không dùng GPS để
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 189
```kotlin
 * tính lại khi bản đồ đã có STT; việc đổi tuyến phải đi qua thao tác xác nhận.
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 190
```kotlin
 */
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 191
```kotlin
fun List<DeliveryOrder>.persistedRouteSequence(): Map<String, Int> =
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 192
```kotlin
    filter { it.isRouteActive() && it.hasStoredCoordinates() && it.sequence > 0 && it.sequenceLabel == null }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 193
```kotlin
        .sortedWith(compareBy<DeliveryOrder> { it.sequence }.thenBy { it.waybill })
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 194
```kotlin
        .associate { it.waybill to it.sequence }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 195
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 196
```kotlin
fun List<DeliveryOrder>.persistedRouteLabels(): Map<String, String> =
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 197
```kotlin
    filter { it.isRouteActive() && it.hasStoredCoordinates() }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 198
```kotlin
        .sortedWith(compareBy<DeliveryOrder> { it.sequenceSortValue() }.thenBy { it.waybill })
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 199
```kotlin
        .associate { it.waybill to it.sequenceText() }
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

