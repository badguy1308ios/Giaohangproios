# Phân tích từng dòng — `com/example/delivery/integration/VtmanExportContract.kt`

> Tài liệu đọc/debug: mã gốc theo từng dòng + giải thích. Không dùng trực tiếp để compile.

### Dòng 1
```kotlin
package com.example.delivery.integration
```
**Giải thích:** Khai báo package, xác định namespace của file.

### Dòng 2
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 3
```kotlin
object VtmanExportContract {
```
**Giải thích:** Khai báo object dùng làm singleton/namespace cho logic dùng chung.

### Dòng 4
```kotlin
    const val packageName = "com.vtman.waybillscanner"
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 5
```kotlin
    const val unavailableMessage = "Chưa cài VTMan Export. Hãy cài công cụ trước rồi mở lại mục này."
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 6
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

