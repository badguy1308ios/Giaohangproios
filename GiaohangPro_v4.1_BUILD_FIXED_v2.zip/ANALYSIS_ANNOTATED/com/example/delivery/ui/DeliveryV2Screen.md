# Phân tích từng dòng — `com/example/delivery/ui/DeliveryV2Screen.kt`

> Tài liệu đọc/debug: mã gốc theo từng dòng + giải thích. Không dùng trực tiếp để compile.

### Dòng 1
```kotlin
package com.example.delivery.ui
```
**Giải thích:** Khai báo package, xác định namespace của file.

### Dòng 2
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 3
```kotlin
import android.Manifest
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 4
```kotlin
import android.app.Activity
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 5
```kotlin
import android.content.Context
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 6
```kotlin
import android.widget.Toast
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 7
```kotlin
import android.content.Intent
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 8
```kotlin
import android.content.pm.PackageManager
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 9
```kotlin
import android.graphics.BitmapFactory
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 10
```kotlin
import android.net.Uri
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 11
```kotlin
import androidx.activity.compose.BackHandler
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 12
```kotlin
import androidx.activity.compose.rememberLauncherForActivityResult
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 13
```kotlin
import androidx.activity.result.contract.ActivityResultContracts
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 14
```kotlin
import androidx.compose.foundation.Image
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 15
```kotlin
import androidx.compose.foundation.background
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 16
```kotlin
import androidx.compose.foundation.border
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 17
```kotlin
import androidx.compose.foundation.clickable
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 18
```kotlin
import androidx.compose.foundation.ExperimentalFoundationApi
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 19
```kotlin
import androidx.compose.foundation.interaction.MutableInteractionSource
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 20
```kotlin
import androidx.compose.foundation.layout.Arrangement
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 21
```kotlin
import androidx.compose.foundation.layout.Box
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 22
```kotlin
import androidx.compose.foundation.layout.Column
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 23
```kotlin
import androidx.compose.foundation.layout.Row
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 24
```kotlin
import androidx.compose.foundation.layout.Spacer
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 25
```kotlin
import androidx.compose.foundation.layout.fillMaxSize
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 26
```kotlin
import androidx.compose.foundation.layout.fillMaxHeight
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 27
```kotlin
import androidx.compose.foundation.layout.fillMaxWidth
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 28
```kotlin
import androidx.compose.foundation.layout.height
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 29
```kotlin
import androidx.compose.foundation.layout.heightIn
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 30
```kotlin
import androidx.compose.foundation.layout.imePadding
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 31
```kotlin
import androidx.compose.foundation.layout.navigationBarsPadding
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 32
```kotlin
import androidx.compose.foundation.layout.offset
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 33
```kotlin
import androidx.compose.foundation.layout.padding
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 34
```kotlin
import androidx.compose.foundation.layout.size
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 35
```kotlin
import androidx.compose.foundation.layout.width
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 36
```kotlin
import androidx.compose.foundation.layout.statusBarsPadding
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 37
```kotlin
import androidx.compose.foundation.rememberScrollState
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 38
```kotlin
import androidx.compose.foundation.relocation.BringIntoViewRequester
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 39
```kotlin
import androidx.compose.foundation.relocation.bringIntoViewRequester
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 40
```kotlin
import androidx.compose.foundation.verticalScroll
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 41
```kotlin
import androidx.compose.foundation.lazy.LazyColumn
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 42
```kotlin
import androidx.compose.foundation.lazy.items
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 43
```kotlin
import androidx.compose.foundation.lazy.itemsIndexed
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 44
```kotlin
import androidx.compose.foundation.lazy.rememberLazyListState
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 45
```kotlin
import androidx.compose.foundation.shape.RoundedCornerShape
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 46
```kotlin
import androidx.compose.material.icons.Icons
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 47
```kotlin
import androidx.compose.material.icons.filled.ArrowUpward
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 48
```kotlin
import androidx.compose.material.icons.filled.Map
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 49
```kotlin
import androidx.compose.material.icons.filled.Add
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 50
```kotlin
import androidx.compose.material.icons.filled.ArrowDropDown
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 51
```kotlin
import androidx.compose.material.icons.filled.CameraAlt
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 52
```kotlin
import androidx.compose.material.icons.filled.Close
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 53
```kotlin
import androidx.compose.material.icons.filled.Delete
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 54
```kotlin
import androidx.compose.material.icons.filled.Edit
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 55
```kotlin
import androidx.compose.material.icons.filled.LocationOn
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 56
```kotlin
import androidx.compose.material.icons.filled.Navigation
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 57
```kotlin
import androidx.compose.material.icons.filled.Pause
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 58
```kotlin
import androidx.compose.material.icons.filled.People
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 59
```kotlin
import androidx.compose.material.icons.filled.Phone
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 60
```kotlin
import androidx.compose.material.icons.filled.ReceiptLong
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 61
```kotlin
import androidx.compose.material.icons.filled.Remove
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 62
```kotlin
import androidx.compose.material.icons.filled.Settings
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 63
```kotlin
import androidx.compose.material.icons.filled.Sms
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 64
```kotlin
import androidx.compose.material3.AlertDialog
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 65
```kotlin
import androidx.compose.material3.Button
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 66
```kotlin
import androidx.compose.material3.ButtonDefaults
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 67
```kotlin
import androidx.compose.material3.Card
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 68
```kotlin
import androidx.compose.material3.CardDefaults
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 69
```kotlin
import androidx.compose.material3.Checkbox
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 70
```kotlin
import androidx.compose.material3.DropdownMenu
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 71
```kotlin
import androidx.compose.material3.DropdownMenuItem
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 72
```kotlin
import androidx.compose.material3.Icon
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 73
```kotlin
import androidx.compose.material3.IconButton
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 74
```kotlin
import androidx.compose.material3.OutlinedButton
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 75
```kotlin
import androidx.compose.material3.OutlinedTextField
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 76
```kotlin
import androidx.compose.material3.Surface
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 77
```kotlin
import androidx.compose.material3.Text
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 78
```kotlin
import androidx.compose.runtime.Composable
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 79
```kotlin
import androidx.compose.runtime.LaunchedEffect
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 80
```kotlin
import androidx.compose.runtime.getValue
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 81
```kotlin
import androidx.compose.runtime.mutableStateOf
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 82
```kotlin
import androidx.compose.runtime.remember
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 83
```kotlin
import androidx.compose.runtime.saveable.rememberSaveable
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 84
```kotlin
import androidx.compose.runtime.setValue
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 85
```kotlin
import androidx.compose.ui.Alignment
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 86
```kotlin
import androidx.compose.ui.Modifier
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 87
```kotlin
import androidx.compose.ui.draw.clip
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 88
```kotlin
import androidx.compose.ui.draw.alpha
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 89
```kotlin
import androidx.compose.ui.focus.onFocusChanged
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 90
```kotlin
import androidx.compose.ui.platform.LocalFocusManager
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 91
```kotlin
import androidx.compose.foundation.text.KeyboardActions
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 92
```kotlin
import androidx.compose.foundation.text.KeyboardOptions
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 93
```kotlin
import androidx.compose.ui.text.input.ImeAction
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 94
```kotlin
import androidx.compose.ui.graphics.Color
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 95
```kotlin
import androidx.compose.ui.graphics.asImageBitmap
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 96
```kotlin
import androidx.compose.ui.layout.ContentScale
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 97
```kotlin
import androidx.compose.ui.platform.LocalContext
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 98
```kotlin
import androidx.compose.ui.text.font.FontWeight
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 99
```kotlin
import androidx.compose.ui.unit.dp
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 100
```kotlin
import androidx.compose.ui.unit.sp
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 101
```kotlin
import androidx.compose.ui.window.Dialog
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 102
```kotlin
import androidx.compose.ui.window.DialogProperties
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 103
```kotlin
import androidx.core.content.ContextCompat
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 104
```kotlin
import com.example.delivery.history.DeliveryPhotoHistory
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 105
```kotlin
import com.example.delivery.history.PaymentChannel
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 106
```kotlin
import com.example.delivery.history.ProofPhotoType
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 107
```kotlin
import com.example.delivery.history.TransferEvidence
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 108
```kotlin
import com.example.delivery.orderio.CoordinateUpdateRequest
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 109
```kotlin
import com.example.delivery.orderio.CoordinateTextParser
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 110
```kotlin
import com.example.delivery.location.RealtimeLocationPolicy
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 111
```kotlin
import com.example.delivery.customer.CustomerAddress
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 112
```kotlin
import com.example.delivery.customer.CustomerContactMethod
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 113
```kotlin
import com.example.delivery.customer.CustomerPhone
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 114
```kotlin
import com.example.delivery.customer.CustomerProfile
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 115
```kotlin
import com.example.delivery.customer.CustomerProfileStore
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 116
```kotlin
import com.example.delivery.customer.matchesSearch
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 117
```kotlin
import com.example.delivery.model.DeliveryOrder
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 118
```kotlin
import com.example.delivery.model.DeliveryOutcome
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 119
```kotlin
import com.example.delivery.model.DeliveryStatus
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 120
```kotlin
import com.example.delivery.model.hasStoredCoordinates
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 121
```kotlin
import com.example.delivery.model.canReceiveRouteSequence
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 122
```kotlin
import com.example.delivery.model.dispatchDisplayOrder
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 123
```kotlin
import com.example.delivery.model.formatVnd
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 124
```kotlin
import com.example.delivery.model.isMapVisible
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 125
```kotlin
import com.example.delivery.model.isPickupAtWarehouse
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 126
```kotlin
import com.example.delivery.model.isRouteActive
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 127
```kotlin
import com.example.delivery.model.statusLabel
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 128
```kotlin
import com.example.delivery.model.withStableRouteLabels
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 129
```kotlin
import com.example.delivery.model.resequenceDraftLabels
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 130
```kotlin
import com.example.delivery.model.sequenceText
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 131
```kotlin
import com.example.delivery.model.sequenceSortValue
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 132
```kotlin
import com.example.delivery.model.csvStatus
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 133
```kotlin
import com.example.delivery.navigation.DeliveryRouteStore
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 134
```kotlin
import com.example.delivery.navigation.DeliveryZone
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 135
```kotlin
import com.example.delivery.navigation.GeoPoint
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 136
```kotlin
import com.example.delivery.navigation.persistedRouteLabels
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 137
```kotlin
import com.example.delivery.navigation.preferredRouteOrigin
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 138
```kotlin
import com.example.delivery.navigation.routeOrdersFrom
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 139
```kotlin
import kotlinx.coroutines.delay
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 140
```kotlin
import java.util.Locale
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 141
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 142
```kotlin
private enum class DeliveryTab { MAP, DETAIL, CUSTOMERS }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 143
```kotlin
data class TransferPhotoState(val billPath: String? = null, val dropOffPath: String? = null)
```
**Giải thích:** Khai báo lớp; gom dữ liệu hoặc hành vi liên quan vào một đơn vị.

### Dòng 144
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 145
```kotlin
@Composable
```
**Giải thích:** Đánh dấu hàm là Jetpack Compose UI; Compose có thể gọi và tái dựng hàm này.

### Dòng 146
```kotlin
fun DeliveryV2Screen(
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 147
```kotlin
    orders: List<DeliveryOrder>,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 148
```kotlin
    transferPhotos: Map<String, TransferPhotoState>,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 149
```kotlin
    transferEvidence: List<TransferEvidence>,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 150
```kotlin
    customerProfiles: List<CustomerProfile>,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 151
```kotlin
    onDirectDelivered: (DeliveryOrder) -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 152
```kotlin
    onSaveTransfer: (DeliveryOrder, PaymentChannel, String, String?, String?) -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 153
```kotlin
    onCaptureTransferPhoto: (DeliveryOrder, ProofPhotoType) -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 154
```kotlin
    onCall: (DeliveryOrder) -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 155
```kotlin
    onZalo: (DeliveryOrder, String) -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 156
```kotlin
    onSms: (DeliveryOrder, String) -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 157
```kotlin
    onConfirmTransferPayment: (String) -> Unit,
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 158
```kotlin
    transferMessage: (DeliveryOrder) -> String,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 159
```kotlin
    onRouteSequenceLocked: (Map<String, String>) -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 160
```kotlin
    onCreateRoute: (RouteCreationMode) -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 161
```kotlin
    onDeleteRoute: () -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 162
```kotlin
    onSaveCustomer: (CustomerProfile) -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 163
```kotlin
    onDeleteCustomer: (CustomerProfile) -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 164
```kotlin
    onGetCustomerCoordinates: () -> Pair<Double, Double>?,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 165
```kotlin
    onExportBackup: () -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 166
```kotlin
    onImportBackup: () -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 167
```kotlin
    onImportOrders: () -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 168
```kotlin
    onExportOrders: () -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 169
```kotlin
    onExportStt: () -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 170
```kotlin
    onImportStt: () -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 171
```kotlin
    onAddManualOrder: (DeliveryOrder) -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 172
```kotlin
    onDeleteOrder: (String) -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 173
```kotlin
    onDeleteAllOrders: () -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 174
```kotlin
    onUpdateCoordinates: (CoordinateUpdateRequest) -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 175
```kotlin
    onSyncOrdersFromCustomerCoordinates: () -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 176
```kotlin
    onOpenVtmanExport: () -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 177
```kotlin
    backupStatus: String?,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 178
```kotlin
) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 179
```kotlin
    var tab by rememberSaveable { mutableStateOf(DeliveryTab.MAP) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 180
```kotlin
    var selectedNavigationOrder by remember { mutableStateOf<DeliveryOrder?>(null) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 181
```kotlin
    var selectedWaybill by rememberSaveable { mutableStateOf<String?>(null) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 182
```kotlin
    var detailScrollTopRequest by remember { mutableStateOf(0) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 183
```kotlin
    var detailSearchQuery by rememberSaveable { mutableStateOf("") }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 184
```kotlin
    var scannerOpen by remember { mutableStateOf(false) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 185
```kotlin
    var settingsOpen by remember { mutableStateOf(false) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 186
```kotlin
    var backupOpen by remember { mutableStateOf(false) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 187
```kotlin
    var cashAuditOpen by remember { mutableStateOf(false) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 188
```kotlin
    var transferCheckOpen by remember { mutableStateOf(false) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 189
```kotlin
    var orderManagementOpen by remember { mutableStateOf(false) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 190
```kotlin
    var coordinateUpdateOpen by remember { mutableStateOf(false) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 191
```kotlin
    var routeScreenOpen by remember { mutableStateOf(false) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 192
```kotlin
    var completingOrder by remember { mutableStateOf<DeliveryOrder?>(null) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 193
```kotlin
    var focusPhone by remember { mutableStateOf<String?>(null) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 194
```kotlin
    var currentGps by remember { mutableStateOf<GeoPoint?>(null) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 195
```kotlin
    var currentGpsUpdatedAt by remember { mutableStateOf(0L) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 196
```kotlin
    // Khởi tạo từ sequence đã được DeliveryOrderStore commit. Vì vậy sau crash,
```
**Giải thích:** Chú thích hiện có; không tạo hành vi chạy.

### Dòng 197
```kotlin
    // GPS mới về cũng không thể tự đánh lại STT đã xác nhận trước đó.
```
**Giải thích:** Chú thích hiện có; không tạo hành vi chạy.

### Dòng 198
```kotlin
    var stableRouteSequence by remember { mutableStateOf(orders.persistedRouteLabels()) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 199
```kotlin
    var previewRouteSequence by remember { mutableStateOf<Map<String, String>?>(null) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 200
```kotlin
    LaunchedEffect(orders.isEmpty()) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 201
```kotlin
        if (orders.isEmpty()) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 202
```kotlin
            stableRouteSequence = emptyMap()
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 203
```kotlin
            previewRouteSequence = null
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 204
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 205
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 206
```kotlin
    val context = LocalContext.current
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 207
```kotlin
    var lastBackPressedAt by remember { mutableStateOf(0L) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 208
```kotlin
    BackHandler {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 209
```kotlin
        when {
```
**Giải thích:** Rẽ nhánh nhiều trường hợp dựa trên giá trị/điều kiện.

### Dòng 210
```kotlin
            scannerOpen -> scannerOpen = false
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 211
```kotlin
            routeScreenOpen -> { routeScreenOpen = false; settingsOpen = true }
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 212
```kotlin
            coordinateUpdateOpen -> { coordinateUpdateOpen = false; orderManagementOpen = true }
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 213
```kotlin
            orderManagementOpen -> { orderManagementOpen = false; settingsOpen = true }
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 214
```kotlin
            backupOpen -> { backupOpen = false; settingsOpen = true }
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 215
```kotlin
            cashAuditOpen -> { cashAuditOpen = false; settingsOpen = true }
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 216
```kotlin
            transferCheckOpen -> { transferCheckOpen = false; settingsOpen = true }
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 217
```kotlin
            settingsOpen -> settingsOpen = false
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 218
```kotlin
            else -> {
```
**Giải thích:** Nhánh thay thế khi điều kiện if trước đó sai.

### Dòng 219
```kotlin
                val now = System.currentTimeMillis()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 220
```kotlin
                if (now - lastBackPressedAt <= 1_800L) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 221
```kotlin
                    (context as? Activity)?.finish()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 222
```kotlin
                } else {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 223
```kotlin
                    lastBackPressedAt = now
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 224
```kotlin
                    Toast.makeText(context, "Nhấn Back lần nữa để thoát ứng dụng", Toast.LENGTH_SHORT).show()
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 225
```kotlin
                }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 226
```kotlin
            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 227
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 228
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 229
```kotlin
    var zones by remember(context) { mutableStateOf(DeliveryRouteStore.loadZones(context)) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 230
```kotlin
    val locationPreferences = remember(context) { context.getSharedPreferences("location_permission", Context.MODE_PRIVATE) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 231
```kotlin
    var locationGranted by remember(context) {
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 232
```kotlin
        mutableStateOf(
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 233
```kotlin
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 234
```kotlin
                ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 235
```kotlin
        )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 236
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 237
```kotlin
    val locationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { permissions ->
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 238
```kotlin
        locationGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true || permissions[Manifest.permission.ACCESS_COARSE_LOCATION] == true
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 239
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 240
```kotlin
        LaunchedEffect(Unit) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 241
```kotlin
        if (!locationGranted && !locationPreferences.getBoolean("asked_once", false)) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 242
```kotlin
            locationPreferences.edit().putBoolean("asked_once", true).apply()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 243
```kotlin
            locationPermission.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 244
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 245
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 246
```kotlin
    fun confirmRouteChange() {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 247
```kotlin
        val fallback = orders.filter { it.isRouteActive() && it.hasStoredCoordinates() }
```
**Giải thích:** Lọc dữ liệu theo điều kiện; chỉ giữ phần tử thỏa điều kiện.

### Dòng 248
```kotlin
            .minByOrNull { if (it.sequence > 0) it.sequence else Int.MAX_VALUE }
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 249
```kotlin
            ?.let { GeoPoint(it.latitude, it.longitude) }
```
**Giải thích:** Xử lý giá trị nullable an toàn; khối chỉ chạy khi giá trị tồn tại.

### Dòng 250
```kotlin
        val origin = preferredRouteOrigin(null, currentGps, fallback)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 251
```kotlin
        if (origin == null) return
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 252
```kotlin
            val confirmed = routeOrdersFrom(origin, orders.filter(DeliveryOrder::hasStoredCoordinates))
```
**Giải thích:** Lọc dữ liệu theo điều kiện; chỉ giữ phần tử thỏa điều kiện.

### Dòng 253
```kotlin
            .associate { it.waybill to it.sequenceText() }
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 254
```kotlin
        stableRouteSequence = confirmed
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 255
```kotlin
        onRouteSequenceLocked(confirmed)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 256
```kotlin
        selectedNavigationOrder = null
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 257
```kotlin
        coordinateUpdateOpen = false
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 258
```kotlin
        orderManagementOpen = false
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 259
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 260
```kotlin
    if (scannerOpen) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 261
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 262
```kotlin
        BarcodeScannerScreen(onCodeScanned = { code -> detailSearchQuery = code; scannerOpen = false; tab = DeliveryTab.DETAIL }, onDismiss = { scannerOpen = false })
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 263
```kotlin
        return
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 264
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 265
```kotlin
    if (settingsOpen) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 266
```kotlin
        SettingsScreen(
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 267
```kotlin
            evidence = transferEvidence,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 268
```kotlin
            onConfirmPayment = onConfirmTransferPayment,
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 269
```kotlin
            onOpenCashAudit = { settingsOpen = false; cashAuditOpen = true },
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 270
```kotlin
            onOpenBackup = { settingsOpen = false; backupOpen = true },
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 271
```kotlin
            onOpenVtmanExport = onOpenVtmanExport,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 272
```kotlin
            onOpenTransferCheck = { settingsOpen = false; transferCheckOpen = true },
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 273
```kotlin
            onOpenOrderManagement = { settingsOpen = false; orderManagementOpen = true },
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 274
```kotlin
            onOpenAnchorPoint = { settingsOpen = false; routeScreenOpen = true },
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 275
```kotlin
            onClose = { settingsOpen = false },
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 276
```kotlin
        )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 277
```kotlin
        return
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 278
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 279
```kotlin
    if (routeScreenOpen) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 280
```kotlin
        DeliveryRouteScreen(
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 281
```kotlin
            zones = zones,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 282
```kotlin
            onZonesChanged = { updated -> zones = updated; DeliveryRouteStore.saveZones(context, updated) },
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 283
```kotlin
            onCreateRoute = onCreateRoute,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 284
```kotlin
            onDeleteRoute = onDeleteRoute,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 285
```kotlin
            onClose = { routeScreenOpen = false; settingsOpen = true },
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 286
```kotlin
        )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 287
```kotlin
        return
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 288
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 289
```kotlin
    if (orderManagementOpen) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 290
```kotlin
        OrderManagementScreen(
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 291
```kotlin
            status = backupStatus,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 292
```kotlin
            onAddManualOrder = onAddManualOrder,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 293
```kotlin
            onDeleteOrder = onDeleteOrder,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 294
```kotlin
            onDeleteAllOrders = onDeleteAllOrders,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 295
```kotlin
            onOpenCoordinateUpdate = { orderManagementOpen = false; coordinateUpdateOpen = true },
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 296
```kotlin
            onConfirmRouteChange = { confirmRouteChange() },
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 297
```kotlin
            onClose = { orderManagementOpen = false; settingsOpen = true },
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 298
```kotlin
        )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 299
```kotlin
        return
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 300
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 301
```kotlin
    if (backupOpen) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 302
```kotlin
        BackupDataScreen(
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 303
```kotlin
            onExportBackup = onExportBackup,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 304
```kotlin
            onImportBackup = onImportBackup,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 305
```kotlin
            onImportOrders = onImportOrders,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 306
```kotlin
            onExportOrders = onExportOrders,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 307
```kotlin
            onExportStt = onExportStt,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 308
```kotlin
            onImportStt = onImportStt,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 309
```kotlin
            backupStatus = backupStatus,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 310
```kotlin
            onClose = { backupOpen = false; settingsOpen = true },
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 311
```kotlin
        )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 312
```kotlin
        return
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 313
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 314
```kotlin
    if (cashAuditOpen) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 315
```kotlin
        CashAuditScreen(onClose = { cashAuditOpen = false; settingsOpen = true })
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 316
```kotlin
        return
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 317
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 318
```kotlin
    if (transferCheckOpen) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 319
```kotlin
        TransferCheckScreen(onClose = { transferCheckOpen = false; settingsOpen = true })
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 320
```kotlin
        return
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 321
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 322
```kotlin
    if (coordinateUpdateOpen) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 323
```kotlin
        CoordinateUpdateScreen(
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 324
```kotlin
            status = backupStatus,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 325
```kotlin
            onSave = onUpdateCoordinates,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 326
```kotlin
            onConfirmRouteChange = {
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 327
```kotlin
                onSyncOrdersFromCustomerCoordinates()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 328
```kotlin
                confirmRouteChange()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 329
```kotlin
            },
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 330
```kotlin
            onClose = { coordinateUpdateOpen = false; orderManagementOpen = true },
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 331
```kotlin
        )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 332
```kotlin
        return
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 333
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 334
```kotlin
    LaunchedEffect(currentGps, orders, stableRouteSequence, zones) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 335
```kotlin
        if (stableRouteSequence.isEmpty()) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 336
```kotlin
            val fallback = orders.filter { it.isRouteActive() && it.hasStoredCoordinates() }
```
**Giải thích:** Lọc dữ liệu theo điều kiện; chỉ giữ phần tử thỏa điều kiện.

### Dòng 337
```kotlin
                .minByOrNull { if (it.sequence > 0) it.sequence else Int.MAX_VALUE }
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 338
```kotlin
                ?.let { GeoPoint(it.latitude, it.longitude) }
```
**Giải thích:** Xử lý giá trị nullable an toàn; khối chỉ chạy khi giá trị tồn tại.

### Dòng 339
```kotlin
            val origin = preferredRouteOrigin(null, currentGps, fallback)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 340
```kotlin
            if (origin != null) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 341
```kotlin
                val initial = routeOrdersFrom(origin, orders.filter(DeliveryOrder::hasStoredCoordinates))
```
**Giải thích:** Lọc dữ liệu theo điều kiện; chỉ giữ phần tử thỏa điều kiện.

### Dòng 342
```kotlin
                    .associate { it.waybill to it.sequenceText() }
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 343
```kotlin
                stableRouteSequence = initial
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 344
```kotlin
                onRouteSequenceLocked(initial)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 345
```kotlin
            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 346
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 347
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 348
```kotlin
        val displayOrders = orders.withStableRouteLabels(previewRouteSequence ?: stableRouteSequence)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 349
```kotlin
        Column(Modifier.fillMaxSize().background(AppBackground).statusBarsPadding().navigationBarsPadding()) {
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 350
```kotlin
        Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 351
```kotlin
            IconButton(onClick = { settingsOpen = true }) { Icon(Icons.Filled.Settings, "Cài đặt", tint = Color(0xFF12385F)) }
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 352
```kotlin
            Text("GIAO HÀNG THEO CÁCH CỦA BẠN", modifier = Modifier.weight(1f), color = Color(0xFFE57B22), fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 353
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 354
```kotlin
        Box(Modifier.weight(1f)) {
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 355
```kotlin
            // Giữ bản đồ luôn trong composition. Khi đổi tab chỉ ẩn lớp hiển thị,
```
**Giải thích:** Chú thích hiện có; không tạo hành vi chạy.

### Dòng 356
```kotlin
            // không tháo MapView nên không gọi onDestroy và không tải lại style/map tiles.
```
**Giải thích:** Chú thích hiện có; không tạo hành vi chạy.

### Dòng 357
```kotlin
            MapDeliveryScreen(
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 358
```kotlin
                orders = displayOrders,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 359
```kotlin
                selectedNavigationOrder = selectedNavigationOrder,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 360
```kotlin
                selectedWaybill = selectedWaybill,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 361
```kotlin
                onRouteSequencePreview = { previewRouteSequence = it },
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 362
```kotlin
                onRouteSequenceLocked = { updated -> previewRouteSequence = null; stableRouteSequence = updated; onRouteSequenceLocked(updated) },
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 363
```kotlin
                onSelectNavigation = { selectedNavigationOrder = it; selectedWaybill = it.waybill },
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 364
```kotlin
                onSelectOrder = { order -> selectedWaybill = order.waybill; selectedNavigationOrder = order },
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 365
```kotlin
                onReturnToNearest = { selectedNavigationOrder = null },
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 366
```kotlin
                onOpenDetail = { order -> selectedWaybill = order.waybill; selectedNavigationOrder = order; detailSearchQuery = order.waybill; tab = DeliveryTab.DETAIL },
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 367
```kotlin
                locationGranted = locationGranted,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 368
```kotlin
                onLocationChanged = { latitude, longitude ->
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 369
```kotlin
                    currentGps = GeoPoint(latitude, longitude)
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 370
```kotlin
                    currentGpsUpdatedAt = System.currentTimeMillis()
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 371
```kotlin
                },
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 372
```kotlin
                modifier = Modifier.fillMaxSize().padding(top = 8.dp).alpha(if (tab == DeliveryTab.MAP) 1f else 0f),
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 373
```kotlin
            )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 374
```kotlin
            if (tab != DeliveryTab.MAP) when (tab) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 375
```kotlin
            DeliveryTab.DETAIL -> OrderDetailScreen(
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 376
```kotlin
                orders = displayOrders,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 377
```kotlin
                searchQuery = detailSearchQuery,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 378
```kotlin
                onSearchChange = { detailSearchQuery = it },
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 379
```kotlin
                selectedWaybill = selectedWaybill,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 380
```kotlin
                scrollToTopRequest = detailScrollTopRequest,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 381
```kotlin
                onSelectOrder = { order -> selectedWaybill = order.waybill; selectedNavigationOrder = order },
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 382
```kotlin
                onOpenScanner = { scannerOpen = true },
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 383
```kotlin
                onDelivered = { completingOrder = it },
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 384
```kotlin
                onCall = onCall,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 385
```kotlin
                onZalo = { onZalo(it, transferMessage(it)) },
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 386
```kotlin
                onSms = { onSms(it, transferMessage(it)) },
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 387
```kotlin
                onOpenCustomer = { selectedWaybill = it.waybill; focusPhone = it.phone; tab = DeliveryTab.CUSTOMERS },
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 388
```kotlin
                onNavigateOrder = { order -> selectedWaybill = order.waybill; selectedNavigationOrder = order; tab = DeliveryTab.MAP },
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 389
```kotlin
            )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 390
```kotlin
            DeliveryTab.CUSTOMERS -> CustomerList(
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 391
```kotlin
                customerProfiles.filterNot { CustomerProfileStore.isDeleted(context, it.id) },
```
**Giải thích:** Lọc dữ liệu theo điều kiện; chỉ giữ phần tử thỏa điều kiện.

### Dòng 392
```kotlin
                focusPhone,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 393
```kotlin
                onSaveCustomer,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 394
```kotlin
                onDeleteCustomer,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 395
```kotlin
            ) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 396
```kotlin
                currentGps?.takeIf { RealtimeLocationPolicy.isFreshLastKnown(currentGpsUpdatedAt, System.currentTimeMillis()) }
```
**Giải thích:** Chọn/loại giá trị theo điều kiện, trả null nếu không thỏa.

### Dòng 397
```kotlin
                    ?.let { gps -> gps.latitude to gps.longitude }
```
**Giải thích:** Xử lý giá trị nullable an toàn; khối chỉ chạy khi giá trị tồn tại.

### Dòng 398
```kotlin
                    ?: onGetCustomerCoordinates()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 399
```kotlin
            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 400
```kotlin
            DeliveryTab.MAP -> Unit
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 401
```kotlin
            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 402
```kotlin
            if (tab == DeliveryTab.DETAIL) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 403
```kotlin
                IconButton(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 404
```kotlin
                    onClick = { detailScrollTopRequest += 1 },
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 405
```kotlin
                    modifier = Modifier.align(Alignment.BottomStart).padding(start = 22.dp, bottom = 18.dp).size(62.dp).background(Color(0xFF12385F), androidx.compose.foundation.shape.CircleShape),
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 406
```kotlin
                ) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 407
```kotlin
                    Icon(Icons.Filled.ArrowUpward, contentDescription = "Về đầu danh sách", tint = Color.White, modifier = Modifier.size(31.dp))
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 408
```kotlin
                }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 409
```kotlin
            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 410
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 411
```kotlin
        Box(Modifier.fillMaxWidth()) {
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 412
```kotlin
            Row(Modifier.fillMaxWidth().background(AppSurface).padding(horizontal = 10.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 413
```kotlin
                TabButton("Bản đồ", Icons.Filled.Map, tab == DeliveryTab.MAP, Modifier.weight(1f)) { tab = DeliveryTab.MAP }
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 414
```kotlin
            TabButton("Chi tiết", Icons.Filled.ReceiptLong, tab == DeliveryTab.DETAIL, Modifier.weight(1f)) { tab = DeliveryTab.DETAIL }
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 415
```kotlin
                TabButton("Khách hàng", Icons.Filled.People, tab == DeliveryTab.CUSTOMERS, Modifier.weight(1f)) { tab = DeliveryTab.CUSTOMERS }
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 416
```kotlin
            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 417
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 418
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 419
```kotlin
    completingOrder?.let { order ->
```
**Giải thích:** Xử lý giá trị nullable an toàn; khối chỉ chạy khi giá trị tồn tại.

### Dòng 420
```kotlin
        DeliveryCompletionDialog(
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 421
```kotlin
            order = order,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 422
```kotlin
            onDismiss = { completingOrder = null },
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 423
```kotlin
            onConfirm = {
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 424
```kotlin
                val completedSequence = order.sequenceSortValue()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 425
```kotlin
                val nextCandidates = orders
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 426
```kotlin
                    .asSequence()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 427
```kotlin
                    .filter { it.waybill != order.waybill && it.isRouteActive() }
```
**Giải thích:** Lọc dữ liệu theo điều kiện; chỉ giữ phần tử thỏa điều kiện.

### Dòng 428
```kotlin
                    .sortedWith(compareBy<DeliveryOrder> { it.sequenceSortValue() }.thenBy { it.waybill })
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 429
```kotlin
                    .toList()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 430
```kotlin
                val nextOrder = nextCandidates.firstOrNull { it.sequenceSortValue() > completedSequence }
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 431
```kotlin
                    ?: nextCandidates.firstOrNull()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 432
```kotlin
                onDirectDelivered(order)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 433
```kotlin
                completingOrder = null
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 434
```kotlin
                detailSearchQuery = ""
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 435
```kotlin
                selectedWaybill = nextOrder?.waybill
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 436
```kotlin
                selectedNavigationOrder = nextOrder
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 437
```kotlin
            },
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 438
```kotlin
        )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 439
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 440
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 441
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 442
```kotlin
@Composable
```
**Giải thích:** Đánh dấu hàm là Jetpack Compose UI; Compose có thể gọi và tái dựng hàm này.

### Dòng 443
```kotlin
private fun MapDeliveryScreen(
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 444
```kotlin
    orders: List<DeliveryOrder>,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 445
```kotlin
    selectedNavigationOrder: DeliveryOrder?,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 446
```kotlin
    selectedWaybill: String?,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 447
```kotlin
    onRouteSequencePreview: (Map<String, String>?) -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 448
```kotlin
    onRouteSequenceLocked: (Map<String, String>) -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 449
```kotlin
    onSelectNavigation: (DeliveryOrder) -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 450
```kotlin
    onSelectOrder: (DeliveryOrder) -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 451
```kotlin
    onReturnToNearest: () -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 452
```kotlin
    onOpenDetail: (DeliveryOrder) -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 453
```kotlin
    locationGranted: Boolean,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 454
```kotlin
    onLocationChanged: (Double, Double) -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 455
```kotlin
    modifier: Modifier,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 456
```kotlin
) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 457
```kotlin
    val mapOrders = orders.filter(DeliveryOrder::isMapVisible)
```
**Giải thích:** Lọc dữ liệu theo điều kiện; chỉ giữ phần tử thỏa điều kiện.

### Dòng 458
```kotlin
    val activeOrders = orders.filter { it.isRouteActive() && it.hasStoredCoordinates() }
```
**Giải thích:** Lọc dữ liệu theo điều kiện; chỉ giữ phần tử thỏa điều kiện.

### Dòng 459
```kotlin
    val target = selectedNavigationOrder?.let { selected -> activeOrders.firstOrNull { it.waybill == selected.waybill } } ?: activeOrders.firstOrNull()
```
**Giải thích:** Xử lý giá trị nullable an toàn; khối chỉ chạy khi giá trị tồn tại.

### Dòng 460
```kotlin
    Box(modifier) {
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 461
```kotlin
        GoonOnlyMapScreen(
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 462
```kotlin
            orders = mapOrders,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 463
```kotlin
            selectedNavigationOrder = target,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 464
```kotlin
            locationGranted = locationGranted,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 465
```kotlin
            onLocationChanged = onLocationChanged,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 466
```kotlin
            onSelectOrder = onSelectOrder,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 467
```kotlin
            modifier = Modifier.fillMaxSize(),
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 468
```kotlin
        )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 469
```kotlin
        MapOrderSheet(
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 470
```kotlin
            orders = mapOrders,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 471
```kotlin
            target = target,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 472
```kotlin
            selectedWaybill = selectedWaybill,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 473
```kotlin
            onRouteSequencePreview = onRouteSequencePreview,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 474
```kotlin
            onRouteSequenceLocked = onRouteSequenceLocked,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 475
```kotlin
            manuallySelected = selectedNavigationOrder != null,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 476
```kotlin
            onSelectNavigation = onSelectNavigation,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 477
```kotlin
            onSelectOrder = onSelectOrder,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 478
```kotlin
            onReturnToNearest = onReturnToNearest,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 479
```kotlin
            onOpenDetail = onOpenDetail,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 480
```kotlin
            modifier = Modifier.fillMaxWidth().fillMaxHeight(0.44f).align(Alignment.BottomCenter),
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 481
```kotlin
        )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 482
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 483
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 484
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 485
```kotlin
@Composable
```
**Giải thích:** Đánh dấu hàm là Jetpack Compose UI; Compose có thể gọi và tái dựng hàm này.

### Dòng 486
```kotlin
private fun MapOrderSheet(
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 487
```kotlin
    orders: List<DeliveryOrder>,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 488
```kotlin
    target: DeliveryOrder?,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 489
```kotlin
    selectedWaybill: String?,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 490
```kotlin
    onRouteSequencePreview: (Map<String, String>?) -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 491
```kotlin
    onRouteSequenceLocked: (Map<String, String>) -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 492
```kotlin
    manuallySelected: Boolean,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 493
```kotlin
    onSelectNavigation: (DeliveryOrder) -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 494
```kotlin
    onSelectOrder: (DeliveryOrder) -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 495
```kotlin
    onReturnToNearest: () -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 496
```kotlin
    onOpenDetail: (DeliveryOrder) -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 497
```kotlin
    modifier: Modifier,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 498
```kotlin
) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 499
```kotlin
    val listState = rememberLazyListState()
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 500
```kotlin
    val focusManager = LocalFocusManager.current
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 501
```kotlin
    var editingSequence by remember { mutableStateOf(false) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 502
```kotlin
    var saveSequenceConfirmation by remember { mutableStateOf(false) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 503
```kotlin
    var sequenceDrafts by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 504
```kotlin
    var previewSequenceSort by remember { mutableStateOf(false) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 505
```kotlin
    val displayedOrders = if (editingSequence && previewSequenceSort) orders.withStableRouteLabels(sequenceDrafts) else orders
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 506
```kotlin
    LaunchedEffect(selectedWaybill, orders) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 507
```kotlin
        val index = selectedOrderIndex(orders, selectedWaybill)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 508
```kotlin
        if (index >= 0) listState.animateScrollToItem(index)
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 509
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 510
```kotlin
    Card(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 511
```kotlin
        modifier = modifier.fillMaxWidth(),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 512
```kotlin
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 513
```kotlin
        colors = CardDefaults.cardColors(containerColor = AppSurface),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 514
```kotlin
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 515
```kotlin
    ) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 516
```kotlin
        Column(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 12.dp)) {
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 517
```kotlin
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 518
```kotlin
                Text("${orders.count { it.isRouteActive() }} ĐANG GIAO", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 11.sp, modifier = Modifier.background(Color(0xFFFF7043), RoundedCornerShape(16.dp)).padding(horizontal = 11.dp, vertical = 9.dp).weight(1f))
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 519
```kotlin
                Button(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 520
```kotlin
                    onClick = {
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 521
```kotlin
                        if (editingSequence) saveSequenceConfirmation = true
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 522
```kotlin
                        else {
```
**Giải thích:** Nhánh thay thế khi điều kiện if trước đó sai.

### Dòng 523
```kotlin
                            sequenceDrafts = orders.associate { it.waybill to it.sequenceText() }
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 524
```kotlin
                            previewSequenceSort = false
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 525
```kotlin
                            editingSequence = true
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 526
```kotlin
                        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 527
```kotlin
                    },
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 528
```kotlin
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E73BE)),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 529
```kotlin
                    modifier = Modifier.height(38.dp),
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 530
```kotlin
                ) { Text(if (editingSequence) "Lưu" else "Sửa", fontSize = 12.sp) }
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 531
```kotlin
            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 532
```kotlin
            LazyColumn(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 533
```kotlin
                state = listState,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 534
```kotlin
                modifier = Modifier.weight(1f).fillMaxWidth().padding(top = 9.dp),
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 535
```kotlin
                verticalArrangement = Arrangement.spacedBy(7.dp),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 536
```kotlin
            ) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 537
```kotlin
                items(displayedOrders, key = { it.waybill }) { order ->
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 538
```kotlin
                    val selected = order.waybill == selectedWaybill
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 539
```kotlin
                    val active = order.waybill == target?.waybill
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 540
```kotlin
                    val navigable = order.isRouteActive()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 541
```kotlin
                    Row(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 542
```kotlin
                        modifier = Modifier.fillMaxWidth().background(if (selected) Color(0xFFE4F0FB) else if (active) Color(0xFFFBEDE3) else AppSurfaceMuted, RoundedCornerShape(15.dp)).clickable(onClick = { onSelectOrder(order); onOpenDetail(order) }).padding(11.dp),
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 543
```kotlin
                        verticalAlignment = Alignment.CenterVertically,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 544
```kotlin
                    ) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 545
```kotlin
                        if (editingSequence && order.canReceiveRouteSequence() && order.hasStoredCoordinates()) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 546
```kotlin
                            OutlinedTextField(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 547
```kotlin
                                value = sequenceDrafts[order.waybill].orEmpty(),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 548
```kotlin
                                onValueChange = { value ->
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 549
```kotlin
                                    val filtered = value.lowercase().filter { it.isDigit() || it == '.' || it == 'n' }
```
**Giải thích:** Lọc dữ liệu theo điều kiện; chỉ giữ phần tử thỏa điều kiện.

### Dòng 550
```kotlin
                                    sequenceDrafts = sequenceDrafts + (order.waybill to filtered)
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 551
```kotlin
                                },
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 552
```kotlin
                                modifier = Modifier.width(62.dp).onFocusChanged { focus ->
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 553
```kotlin
                                    if (!focus.isFocused) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 554
```kotlin
                                        val original = orders.associate { it.waybill to it.sequenceText() }
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 555
```kotlin
                                        val reindexed = orders.resequenceDraftLabels(sequenceDrafts, original)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 556
```kotlin
                                        sequenceDrafts = reindexed
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 557
```kotlin
                                        previewSequenceSort = true
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 558
```kotlin
                                        onRouteSequencePreview(reindexed)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 559
```kotlin
                                    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 560
```kotlin
                                },
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 561
```kotlin
                                singleLine = true,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 562
```kotlin
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 563
```kotlin
                                keyboardActions = KeyboardActions(onDone = { focusManager.clearFocus(force = true) }),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 564
```kotlin
                                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 12.sp, fontWeight = FontWeight.Bold),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 565
```kotlin
                            )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 566
```kotlin
                        } else if (order.sequenceText().isNotBlank()) {
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 567
```kotlin
                            Text(order.sequenceText(), color = Color.White, fontWeight = FontWeight.ExtraBold, modifier = Modifier.background(sequenceColor(order), RoundedCornerShape(50)).padding(horizontal = 12.dp, vertical = 8.dp))
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 568
```kotlin
                            IconButton(enabled = navigable, onClick = { if (active && manuallySelected) onReturnToNearest() else onSelectNavigation(order) }) {
```
**Giải thích:** Điều kiện UI: quyết định nút/điều khiển có được phép thao tác hay không.

### Dòng 569
```kotlin
                                Icon(if (active && manuallySelected) Icons.Filled.Pause else Icons.Filled.Navigation, if (active && manuallySelected) "Tạm dừng" else "Dẫn đường", tint = Color(0xFF12385F))
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 570
```kotlin
                            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 571
```kotlin
                        } else if (order.isPickupAtWarehouse()) {
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 572
```kotlin
                            Text("KHO", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 10.sp, modifier = Modifier.background(Color(0xFF6B47A1), RoundedCornerShape(50)).padding(horizontal = 8.dp, vertical = 9.dp))
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 573
```kotlin
                        } else {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 574
```kotlin
                            Spacer(Modifier.width(42.dp))
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 575
```kotlin
                        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 576
```kotlin
                        Column(Modifier.weight(1f).padding(start = 10.dp)) {
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 577
```kotlin
                            Row(verticalAlignment = Alignment.CenterVertically) {
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 578
```kotlin
                                Text(order.waybill, color = Color(0xFF12385F), fontWeight = FontWeight.ExtraBold, fontSize = 13.sp, modifier = Modifier.weight(1f))
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 579
```kotlin
                                Text(order.cod.formatVnd(), color = Color(0xFFFF7043), fontWeight = FontWeight.ExtraBold, fontSize = 12.sp)
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 580
```kotlin
                            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 581
```kotlin
                            Text("${order.customer} · ${order.statusLabel()}", color = Color(0xFF68727C), fontSize = 11.sp)
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 582
```kotlin
                        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 583
```kotlin
                    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 584
```kotlin
                }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 585
```kotlin
            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 586
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 587
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 588
```kotlin
    if (saveSequenceConfirmation) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 589
```kotlin
        AlertDialog(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 590
```kotlin
            onDismissRequest = { saveSequenceConfirmation = false },
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 591
```kotlin
            title = { Text("Xác nhận lưu STT") },
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 592
```kotlin
            text = { Text("Bạn có muốn lưu thay đổi không?") },
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 593
```kotlin
            confirmButton = {
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 594
```kotlin
                Button(onClick = {
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 595
```kotlin
                    val original = orders.associate { it.waybill to it.sequenceText() }
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 596
```kotlin
                    val reindexed = orders.resequenceDraftLabels(sequenceDrafts, original)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 597
```kotlin
                    val updated = reindexed.mapNotNull { (waybill, value) ->
```
**Giải thích:** Biến đổi từng phần tử của danh sách sang giá trị mới.

### Dòng 598
```kotlin
                        val normalized = value.trim()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 599
```kotlin
                        val parts = normalized.split('.', limit = 2)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 600
```kotlin
                        val valid = parts[0].toIntOrNull()?.let { it > 0 } == true &&
```
**Giải thích:** Xử lý giá trị nullable an toàn; khối chỉ chạy khi giá trị tồn tại.

### Dòng 601
```kotlin
                            (parts.size == 1 || parts[1].equals("n", true) || parts[1].toIntOrNull()?.let { it > 0 } == true)
```
**Giải thích:** Xử lý giá trị nullable an toàn; khối chỉ chạy khi giá trị tồn tại.

### Dòng 602
```kotlin
                        normalized.takeIf { valid }?.let { waybill to it }
```
**Giải thích:** Chọn/loại giá trị theo điều kiện, trả null nếu không thỏa.

### Dòng 603
```kotlin
                    }.toMap()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 604
```kotlin
                    onRouteSequenceLocked(updated)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 605
```kotlin
                    previewSequenceSort = false
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 606
```kotlin
                    saveSequenceConfirmation = false
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 607
```kotlin
                    editingSequence = false
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 608
```kotlin
                    sequenceDrafts = emptyMap()
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 609
```kotlin
                }) { Text("Có") }
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 610
```kotlin
            },
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 611
```kotlin
            dismissButton = { OutlinedButton(onClick = { onRouteSequencePreview(null); previewSequenceSort = false; saveSequenceConfirmation = false; editingSequence = false; sequenceDrafts = emptyMap() }) { Text("Không") } },
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 612
```kotlin
        )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 613
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 614
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 615
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 616
```kotlin
private fun sequenceColor(order: DeliveryOrder): Color = when {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 617
```kotlin
    order.isPickupAtWarehouse() -> Color(0xFF6B47A1)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 618
```kotlin
    else -> Color(0xFF1E73BE)
```
**Giải thích:** Nhánh thay thế khi điều kiện if trước đó sai.

### Dòng 619
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 620
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 621
```kotlin
@Composable
```
**Giải thích:** Đánh dấu hàm là Jetpack Compose UI; Compose có thể gọi và tái dựng hàm này.

### Dòng 622
```kotlin
private fun TabButton(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 623
```kotlin
    val interactionSource = remember { MutableInteractionSource() }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 624
```kotlin
    Row(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 625
```kotlin
        modifier = modifier.background(if (selected) Color(0xFF12385F) else Color.Transparent, RoundedCornerShape(10.dp)).clickable(interactionSource = interactionSource, indication = null, onClick = onClick).padding(vertical = 9.dp),
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 626
```kotlin
        horizontalArrangement = Arrangement.Center,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 627
```kotlin
        verticalAlignment = Alignment.CenterVertically,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 628
```kotlin
    ) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 629
```kotlin
        Icon(icon, null, tint = if (selected) Color.White else Color(0xFF12385F))
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 630
```kotlin
        Spacer(Modifier.width(5.dp)); Text(label, color = if (selected) Color.White else Color(0xFF12385F), fontSize = 11.sp, fontWeight = FontWeight.Bold)
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 631
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 632
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 633
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 634
```kotlin
@Composable
```
**Giải thích:** Đánh dấu hàm là Jetpack Compose UI; Compose có thể gọi và tái dựng hàm này.

### Dòng 635
```kotlin
private fun CustomerList(
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 636
```kotlin
    profiles: List<CustomerProfile>,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 637
```kotlin
    focusPhone: String?,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 638
```kotlin
    onSaveCustomer: (CustomerProfile) -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 639
```kotlin
    onDeleteCustomer: (CustomerProfile) -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 640
```kotlin
    onGetCustomerCoordinates: () -> Pair<Double, Double>?,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 641
```kotlin
) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 642
```kotlin
    var searchQuery by rememberSaveable { mutableStateOf("") }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 643
```kotlin
    var editor by remember { mutableStateOf<CustomerProfile?>(null) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 644
```kotlin
    var deleteConfirmation by remember { mutableStateOf<CustomerProfile?>(null) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 645
```kotlin
    var detailProfile by remember { mutableStateOf<CustomerProfile?>(null) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 646
```kotlin
    val context = LocalContext.current
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 647
```kotlin
    val listState = rememberLazyListState()
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 648
```kotlin
    val filteredProfiles = profiles.filter { it.matchesSearch(searchQuery) }
```
**Giải thích:** Lọc dữ liệu theo điều kiện; chỉ giữ phần tử thỏa điều kiện.

### Dòng 649
```kotlin
    LaunchedEffect(focusPhone, profiles) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 650
```kotlin
        if (!focusPhone.isNullOrBlank()) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 651
```kotlin
            searchQuery = ""
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 652
```kotlin
            val index = profiles.indexOfFirst { profile -> profile.phones.any { it.number == focusPhone } }
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 653
```kotlin
            if (index >= 0) listState.scrollToItem(index)
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 654
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 655
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 656
```kotlin
    Box(Modifier.fillMaxSize().background(AppBackground)) {
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 657
```kotlin
        Column(Modifier.fillMaxSize()) {
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 658
```kotlin
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 659
```kotlin
                Column(Modifier.weight(1f)) {
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 660
```kotlin
                    Text("KHÁCH HÀNG", color = Color(0xFF12385F), fontWeight = FontWeight.ExtraBold, fontSize = 19.sp)
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 661
```kotlin
                    Text("${filteredProfiles.size}/${profiles.size} khách trong danh sách", color = Color(0xFF6F7A84), fontSize = 12.sp)
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 662
```kotlin
                }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 663
```kotlin
            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 664
```kotlin
            OutlinedTextField(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 665
```kotlin
                value = searchQuery,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 666
```kotlin
                onValueChange = { searchQuery = it },
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 667
```kotlin
                label = { Text("Tìm tên, SĐT, địa chỉ", fontSize = 12.sp) },
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 668
```kotlin
                singleLine = true,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 669
```kotlin
                trailingIcon = {
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 670
```kotlin
                    if (searchQuery.isNotBlank()) IconButton(onClick = { searchQuery = "" }) { Icon(Icons.Filled.Close, "Xóa tìm kiếm") }
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 671
```kotlin
                },
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 672
```kotlin
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 3.dp).heightIn(min = 54.dp),
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 673
```kotlin
            )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 674
```kotlin
            LazyColumn(Modifier.weight(1f), state = listState, verticalArrangement = Arrangement.spacedBy(7.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 8.dp)) {
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 675
```kotlin
                if (filteredProfiles.isEmpty()) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 676
```kotlin
                    item { Text("Không tìm thấy khách hàng phù hợp.", color = Color(0xFF68727C), fontSize = 13.sp, modifier = Modifier.fillMaxWidth().padding(top = 24.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center) }
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 677
```kotlin
                } else {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 678
```kotlin
                    itemsIndexed(filteredProfiles, key = { index, profile -> customerListItemKey(profile, index) }) { _, profile ->
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 679
```kotlin
                        CustomerPrimaryNameRow(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 680
```kotlin
                            name = profile.displayName,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 681
```kotlin
                            highlighted = profile.phones.any { it.number == focusPhone },
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 682
```kotlin
                            onOpen = { detailProfile = profile },
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 683
```kotlin
                        )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 684
```kotlin
                    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 685
```kotlin
                }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 686
```kotlin
            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 687
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 688
```kotlin
        IconButton(onClick = { editor = CustomerProfile.empty() }, modifier = Modifier.align(Alignment.BottomStart).padding(start = 22.dp, bottom = 18.dp).size(62.dp).background(Color(0xFF1E73BE), RoundedCornerShape(50))) {
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 689
```kotlin
            Icon(Icons.Filled.Add, "Thêm khách hàng", tint = Color.White, modifier = Modifier.size(31.dp))
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 690
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 691
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 692
```kotlin
    detailProfile?.let { profile ->
```
**Giải thích:** Xử lý giá trị nullable an toàn; khối chỉ chạy khi giá trị tồn tại.

### Dòng 693
```kotlin
        CustomerDetailDialog(
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 694
```kotlin
            profile = profile,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 695
```kotlin
            onDismiss = { detailProfile = null },
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 696
```kotlin
            onEdit = { editor = profile },
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 697
```kotlin
            onDelete = { deleteConfirmation = profile },
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 698
```kotlin
            onOpenMap = { address -> openCustomerAddressInMap(context, address) },
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 699
```kotlin
            onNavigate = { address -> navigateToCustomerAddress(context, address) },
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 700
```kotlin
            onCall = { openCustomerChannel(context, profile, CustomerContactMethod.CALL) },
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 701
```kotlin
            onOpenZalo = { openCustomerChannel(context, profile, CustomerContactMethod.ZALO) },
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 702
```kotlin
            onOpenSms = { openCustomerChannel(context, profile, CustomerContactMethod.SMS) },
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 703
```kotlin
        )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 704
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 705
```kotlin
    editor?.let { profile -> CustomerEditorDialog(profile, onDismiss = { editor = null }, onSave = { saved -> onSaveCustomer(saved); detailProfile = saved; editor = null }, onGetCustomerCoordinates = onGetCustomerCoordinates) }
```
**Giải thích:** Xử lý giá trị nullable an toàn; khối chỉ chạy khi giá trị tồn tại.

### Dòng 706
```kotlin
    deleteConfirmation?.let { profile ->
```
**Giải thích:** Xử lý giá trị nullable an toàn; khối chỉ chạy khi giá trị tồn tại.

### Dòng 707
```kotlin
        AlertDialog(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 708
```kotlin
            onDismissRequest = { deleteConfirmation = null },
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 709
```kotlin
            title = { Text("Xóa khách hàng?") },
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 710
```kotlin
            text = { Text("Bạn có chắc chắn muốn xóa hồ sơ ${profile.displayName}? Thông tin khách hàng sẽ không còn xuất hiện trong danh sách.") },
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 711
```kotlin
            confirmButton = {
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 712
```kotlin
                Button(onClick = { onDeleteCustomer(profile); detailProfile = null; deleteConfirmation = null }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC23D35))) { Text("Xóa") }
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 713
```kotlin
            },
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 714
```kotlin
            dismissButton = { OutlinedButton(onClick = { deleteConfirmation = null }) { Text("Hủy") } },
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 715
```kotlin
        )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 716
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 717
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 718
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 719
```kotlin
/**
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 720
```kotlin
 * Hồ sơ cũ có thể mang id trùng do từng được sinh từ SĐT. Ghép index vào key
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 721
```kotlin
 * chỉ để bảo vệ LazyColumn; dữ liệu chính đã được gộp theo SĐT ở model.
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 722
```kotlin
 */
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 723
```kotlin
internal fun customerListItemKey(profile: CustomerProfile, index: Int): String = "customer|${profile.id}|$index"
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 724
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 725
```kotlin
@Composable
```
**Giải thích:** Đánh dấu hàm là Jetpack Compose UI; Compose có thể gọi và tái dựng hàm này.

### Dòng 726
```kotlin
private fun CustomerPrimaryNameRow(name: String, highlighted: Boolean, onOpen: () -> Unit) {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 727
```kotlin
    Row(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 728
```kotlin
        modifier = Modifier
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 729
```kotlin
            .fillMaxWidth()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 730
```kotlin
            .background(if (highlighted) Color(0xFFFBEDE3) else AppSurface, RoundedCornerShape(14.dp))
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 731
```kotlin
            .border(1.dp, if (highlighted) Color(0xFFE5B37A) else Color(0xFFE0E6EA), RoundedCornerShape(14.dp))
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 732
```kotlin
            .clickable(onClick = onOpen)
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 733
```kotlin
            .padding(horizontal = 14.dp, vertical = 15.dp),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 734
```kotlin
        verticalAlignment = Alignment.CenterVertically,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 735
```kotlin
    ) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 736
```kotlin
        Icon(Icons.Filled.People, null, tint = Color(0xFF12385F), modifier = Modifier.size(24.dp))
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 737
```kotlin
        Text(name, color = Color(0xFF182B3D), fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, modifier = Modifier.weight(1f).padding(start = 10.dp))
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 738
```kotlin
        Icon(Icons.Filled.Navigation, "Mở chi tiết khách hàng", tint = Color(0xFF698092), modifier = Modifier.size(20.dp))
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 739
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 740
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 741
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 742
```kotlin
@Composable
```
**Giải thích:** Đánh dấu hàm là Jetpack Compose UI; Compose có thể gọi và tái dựng hàm này.

### Dòng 743
```kotlin
private fun CustomerDetailDialog(
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 744
```kotlin
    profile: CustomerProfile,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 745
```kotlin
    onDismiss: () -> Unit,
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 746
```kotlin
    onEdit: () -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 747
```kotlin
    onDelete: () -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 748
```kotlin
    onOpenMap: (CustomerAddress) -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 749
```kotlin
    onNavigate: (CustomerAddress) -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 750
```kotlin
    onCall: () -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 751
```kotlin
    onOpenZalo: () -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 752
```kotlin
    onOpenSms: () -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 753
```kotlin
) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 754
```kotlin
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 755
```kotlin
        Surface(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 756
```kotlin
            modifier = Modifier.fillMaxSize().navigationBarsPadding().padding(6.dp),
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 757
```kotlin
            shape = RoundedCornerShape(18.dp),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 758
```kotlin
            color = AppBackground,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 759
```kotlin
        ) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 760
```kotlin
            Column(Modifier.fillMaxSize()) {
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 761
```kotlin
                Row(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 762
```kotlin
                    modifier = Modifier.fillMaxWidth().background(AppSurface).padding(horizontal = 10.dp, vertical = 7.dp),
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 763
```kotlin
                    verticalAlignment = Alignment.CenterVertically,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 764
```kotlin
                ) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 765
```kotlin
                    Text("CHI TIẾT KHÁCH HÀNG", color = Color(0xFF12385F), fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, modifier = Modifier.weight(1f))
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 766
```kotlin
                    IconButton(onClick = onEdit) { Icon(Icons.Filled.Edit, "Sửa khách hàng", tint = Color(0xFF1E73BE)) }
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 767
```kotlin
                    IconButton(onClick = onDelete) { Icon(Icons.Filled.Delete, "Xóa khách hàng", tint = Color(0xFFC23D35)) }
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 768
```kotlin
                    IconButton(onClick = onDismiss) { Icon(Icons.Filled.Close, "Đóng chi tiết", tint = Color(0xFF40515E)) }
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 769
```kotlin
                }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 770
```kotlin
                LazyColumn(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 771
```kotlin
                    modifier = Modifier.weight(1f),
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 772
```kotlin
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 773
```kotlin
                ) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 774
```kotlin
                    item {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 775
```kotlin
                        CustomerHousePhotosAtTop(profile)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 776
```kotlin
                    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 777
```kotlin
                    item {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 778
```kotlin
                        CustomerProfileBlock(
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 779
```kotlin
                            profile = profile,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 780
```kotlin
                            onOpenMap = onOpenMap,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 781
```kotlin
                            onNavigate = onNavigate,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 782
```kotlin
                            onCall = onCall,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 783
```kotlin
                            onOpenZalo = onOpenZalo,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 784
```kotlin
                            onOpenSms = onOpenSms,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 785
```kotlin
                        )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 786
```kotlin
                    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 787
```kotlin
                }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 788
```kotlin
            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 789
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 790
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 791
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 792
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 793
```kotlin
@Composable
```
**Giải thích:** Đánh dấu hàm là Jetpack Compose UI; Compose có thể gọi và tái dựng hàm này.

### Dòng 794
```kotlin
private fun CustomerProfileBlock(
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 795
```kotlin
    profile: CustomerProfile,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 796
```kotlin
    onOpenMap: (CustomerAddress) -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 797
```kotlin
    onNavigate: (CustomerAddress) -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 798
```kotlin
    onCall: () -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 799
```kotlin
    onOpenZalo: () -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 800
```kotlin
    onOpenSms: () -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 801
```kotlin
) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 802
```kotlin
    val names = profile.names.ifEmpty { listOf(profile.displayName) }.filter(String::isNotBlank)
```
**Giải thích:** Lọc dữ liệu theo điều kiện; chỉ giữ phần tử thỏa điều kiện.

### Dòng 803
```kotlin
    val phones = profile.phones.filter { it.number.isNotBlank() }
```
**Giải thích:** Lọc dữ liệu theo điều kiện; chỉ giữ phần tử thỏa điều kiện.

### Dòng 804
```kotlin
    val addresses = profile.addresses.filter { it.address.isNotBlank() }
```
**Giải thích:** Lọc dữ liệu theo điều kiện; chỉ giữ phần tử thỏa điều kiện.

### Dòng 805
```kotlin
    Column(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 806
```kotlin
        Modifier
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 807
```kotlin
            .fillMaxWidth()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 808
```kotlin
            .background(AppSurface, RoundedCornerShape(20.dp))
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 809
```kotlin
            .border(1.dp, Color(0xFFE0E6EA), RoundedCornerShape(20.dp))
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 810
```kotlin
            .padding(12.dp),
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 811
```kotlin
        verticalArrangement = Arrangement.spacedBy(6.dp),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 812
```kotlin
    ) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 813
```kotlin
        names.forEachIndexed { index, name ->
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 814
```kotlin
            Text(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 815
```kotlin
                text = name,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 816
```kotlin
                color = Color(0xFF182B3D),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 817
```kotlin
                fontWeight = FontWeight.ExtraBold,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 818
```kotlin
                fontSize = 15.sp,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 819
```kotlin
                modifier = Modifier.padding(start = 33.dp),
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 820
```kotlin
            )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 821
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 822
```kotlin
        phones.forEachIndexed { index, phone ->
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 823
```kotlin
            Row(verticalAlignment = Alignment.CenterVertically) {
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 824
```kotlin
                if (index == 0) Icon(Icons.Filled.Phone, "Số điện thoại", tint = Color(0xFF12385F), modifier = Modifier.size(24.dp)) else Spacer(Modifier.width(24.dp))
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 825
```kotlin
                Text(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 826
```kotlin
                    text = phone.number,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 827
```kotlin
                    color = Color(0xFF182B3D),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 828
```kotlin
                    fontWeight = FontWeight.Bold,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 829
```kotlin
                    fontSize = 14.sp,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 830
```kotlin
                    modifier = Modifier.padding(start = 8.dp),
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 831
```kotlin
                )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 832
```kotlin
            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 833
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 834
```kotlin
        addresses.forEachIndexed { index, address ->
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 835
```kotlin
            CustomerAddressDisplayRow(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 836
```kotlin
                address = address,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 837
```kotlin
                index = index,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 838
```kotlin
                total = addresses.size,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 839
```kotlin
                onOpenMap = { onOpenMap(address) },
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 840
```kotlin
                onNavigate = { onNavigate(address) },
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 841
```kotlin
            )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 842
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 843
```kotlin
        Row(Modifier.fillMaxWidth().padding(top = 2.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 844
```kotlin
            OutlinedButton(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 845
```kotlin
                onClick = onCall,
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 846
```kotlin
                modifier = Modifier.weight(1f).height(42.dp),
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 847
```kotlin
                enabled = phones.any { CustomerContactMethod.CALL in it.methods },
```
**Giải thích:** Điều kiện UI: quyết định nút/điều khiển có được phép thao tác hay không.

### Dòng 848
```kotlin
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF12385F)),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 849
```kotlin
            ) { Icon(Icons.Filled.Phone, null, modifier = Modifier.size(18.dp)); Text(" Gọi", fontSize = 14.sp, fontWeight = FontWeight.ExtraBold) }
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 850
```kotlin
            OutlinedButton(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 851
```kotlin
                onClick = onOpenZalo,
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 852
```kotlin
                modifier = Modifier.weight(1f).height(42.dp),
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 853
```kotlin
                enabled = phones.any { CustomerContactMethod.ZALO in it.methods },
```
**Giải thích:** Điều kiện UI: quyết định nút/điều khiển có được phép thao tác hay không.

### Dòng 854
```kotlin
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF1474B5)),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 855
```kotlin
            ) { Text("Zalo", fontSize = 14.sp, fontWeight = FontWeight.ExtraBold) }
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 856
```kotlin
            OutlinedButton(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 857
```kotlin
                onClick = onOpenSms,
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 858
```kotlin
                modifier = Modifier.weight(1f).height(42.dp),
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 859
```kotlin
                enabled = phones.any { CustomerContactMethod.SMS in it.methods },
```
**Giải thích:** Điều kiện UI: quyết định nút/điều khiển có được phép thao tác hay không.

### Dòng 860
```kotlin
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF12385F)),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 861
```kotlin
            ) { Icon(Icons.Filled.Sms, null, modifier = Modifier.size(18.dp)); Text(" SMS", fontSize = 14.sp, fontWeight = FontWeight.ExtraBold) }
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 862
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 863
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 864
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 865
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 866
```kotlin
@Composable
```
**Giải thích:** Đánh dấu hàm là Jetpack Compose UI; Compose có thể gọi và tái dựng hàm này.

### Dòng 867
```kotlin
private fun CustomerAddressDisplayRow(
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 868
```kotlin
    address: CustomerAddress,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 869
```kotlin
    index: Int,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 870
```kotlin
    total: Int,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 871
```kotlin
    onOpenMap: () -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 872
```kotlin
    onNavigate: () -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 873
```kotlin
) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 874
```kotlin
    Column(Modifier.fillMaxWidth().padding(top = 3.dp)) {
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 875
```kotlin
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 876
```kotlin
            Icon(Icons.Filled.LocationOn, "Địa chỉ", tint = Color(0xFF12385F), modifier = Modifier.size(24.dp))
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 877
```kotlin
            Column(Modifier.weight(1f).padding(start = 8.dp)) {
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 878
```kotlin
                Text(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 879
```kotlin
                    text = if (total == 1) address.address else "${address.address} (địa chỉ ${index + 1})",
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 880
```kotlin
                    color = Color(0xFF182B3D),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 881
```kotlin
                    fontWeight = FontWeight.ExtraBold,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 882
```kotlin
                    fontSize = 14.sp,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 883
```kotlin
                )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 884
```kotlin
                val coordinate = if (address.latitude != null && address.longitude != null) {
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 885
```kotlin
                    String.format(java.util.Locale.US, "Tọa độ: %.4f, %.4f", address.latitude, address.longitude)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 886
```kotlin
                } else {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 887
```kotlin
                    "Chưa có tọa độ"
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 888
```kotlin
                }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 889
```kotlin
                Text(coordinate, color = Color(0xFF66737E), fontSize = 10.sp, modifier = Modifier.padding(top = 1.dp))
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 890
```kotlin
            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 891
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 892
```kotlin
        Row(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 893
```kotlin
            Modifier.fillMaxWidth().padding(start = 32.dp, top = 4.dp),
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 894
```kotlin
            horizontalArrangement = Arrangement.spacedBy(6.dp),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 895
```kotlin
        ) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 896
```kotlin
            OutlinedButton(onClick = onOpenMap, enabled = address.latitude != null && address.longitude != null, modifier = Modifier.height(36.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 9.dp)) { Icon(Icons.Filled.LocationOn, "Xem vị trí", modifier = Modifier.size(18.dp)); Text(" Vị trí", fontSize = 11.sp) }
```
**Giải thích:** Điều kiện UI: quyết định nút/điều khiển có được phép thao tác hay không.

### Dòng 897
```kotlin
            OutlinedButton(onClick = onNavigate, enabled = address.latitude != null && address.longitude != null, modifier = Modifier.height(36.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 9.dp)) { Icon(Icons.Filled.Navigation, "Chỉ đường", modifier = Modifier.size(18.dp)); Text(" Chỉ đường", fontSize = 11.sp) }
```
**Giải thích:** Điều kiện UI: quyết định nút/điều khiển có được phép thao tác hay không.

### Dòng 898
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 899
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 900
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 901
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 902
```kotlin
@Composable
```
**Giải thích:** Đánh dấu hàm là Jetpack Compose UI; Compose có thể gọi và tái dựng hàm này.

### Dòng 903
```kotlin
private fun CustomerHousePhotosAtTop(profile: CustomerProfile) {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 904
```kotlin
    val photos = profile.addresses.mapNotNull { address -> address.housePhotoPath?.takeIf(String::isNotBlank)?.let { path -> address to path } }
```
**Giải thích:** Biến đổi từng phần tử của danh sách sang giá trị mới.

### Dòng 905
```kotlin
    if (photos.isNotEmpty()) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 906
```kotlin
        Column(Modifier.fillMaxWidth().padding(bottom = 10.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 907
```kotlin
            photos.forEachIndexed { index, (address, path) ->
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 908
```kotlin
                val bitmap = remember(path) { BitmapFactory.decodeFile(path) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 909
```kotlin
                if (bitmap != null) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 910
```kotlin
                    if (photos.size > 1) Text("Ảnh nhà • Địa chỉ ${index + 1}", color = Color(0xFF40515E), fontWeight = FontWeight.Bold, fontSize = 12.sp)
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 911
```kotlin
                    Image(
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 912
```kotlin
                        bitmap = bitmap.asImageBitmap(),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 913
```kotlin
                        contentDescription = "Ảnh nhà khách ${address.address}",
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 914
```kotlin
                        contentScale = ContentScale.Fit,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 915
```kotlin
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)),
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 916
```kotlin
                    )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 917
```kotlin
                }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 918
```kotlin
            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 919
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 920
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 921
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 922
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 923
```kotlin
private fun openCustomerAddressInMap(context: Context, address: CustomerAddress) {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 924
```kotlin
    val latitude = address.latitude ?: return
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 925
```kotlin
    val longitude = address.longitude ?: return
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 926
```kotlin
    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("geo:$latitude,$longitude?q=$latitude,$longitude(${Uri.encode(address.address)})"))
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 927
```kotlin
    if (intent.resolveActivity(context.packageManager) != null) context.startActivity(intent)
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 928
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 929
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 930
```kotlin
private fun navigateToCustomerAddress(context: Context, address: CustomerAddress) {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 931
```kotlin
    val latitude = address.latitude ?: return
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 932
```kotlin
    val longitude = address.longitude ?: return
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 933
```kotlin
    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/dir/?api=1&destination=$latitude,$longitude"))
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 934
```kotlin
    if (intent.resolveActivity(context.packageManager) != null) context.startActivity(intent)
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 935
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 936
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 937
```kotlin
private fun openCustomerChannel(context: Context, profile: CustomerProfile, method: CustomerContactMethod) {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 938
```kotlin
    val phone = profile.phones.firstOrNull { method in it.methods }?.number
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 939
```kotlin
    if (phone.isNullOrBlank()) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 940
```kotlin
        Toast.makeText(context, "Số điện thoại không chọn dùng ${method.label}", Toast.LENGTH_SHORT).show()
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 941
```kotlin
        return
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 942
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 943
```kotlin
    when (method) {
```
**Giải thích:** Rẽ nhánh nhiều trường hợp dựa trên giá trị/điều kiện.

### Dòng 944
```kotlin
        CustomerContactMethod.CALL -> openCustomerCall(context, phone)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 945
```kotlin
        CustomerContactMethod.ZALO -> openCustomerZalo(context, phone)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 946
```kotlin
        CustomerContactMethod.SMS -> openCustomerSms(context, phone)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 947
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 948
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 949
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 950
```kotlin
private fun openCustomerCall(context: Context, phone: String) {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 951
```kotlin
    val cleanPhone = phone.filter(Char::isDigit)
```
**Giải thích:** Lọc dữ liệu theo điều kiện; chỉ giữ phần tử thỏa điều kiện.

### Dòng 952
```kotlin
    if (cleanPhone.isBlank()) return
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 953
```kotlin
    val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$cleanPhone"))
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 954
```kotlin
    if (intent.resolveActivity(context.packageManager) != null) context.startActivity(intent)
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 955
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 956
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 957
```kotlin
private fun openCustomerZalo(context: Context, phone: String) {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 958
```kotlin
    val cleanPhone = phone.filter(Char::isDigit)
```
**Giải thích:** Lọc dữ liệu theo điều kiện; chỉ giữ phần tử thỏa điều kiện.

### Dòng 959
```kotlin
    if (cleanPhone.isBlank()) return
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 960
```kotlin
    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://zalo.me/$cleanPhone"))
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 961
```kotlin
    if (intent.resolveActivity(context.packageManager) != null) context.startActivity(intent)
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 962
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 963
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 964
```kotlin
private fun openCustomerSms(context: Context, phone: String) {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 965
```kotlin
    val cleanPhone = phone.filter(Char::isDigit)
```
**Giải thích:** Lọc dữ liệu theo điều kiện; chỉ giữ phần tử thỏa điều kiện.

### Dòng 966
```kotlin
    if (cleanPhone.isBlank()) return
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 967
```kotlin
    val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$cleanPhone"))
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 968
```kotlin
    if (intent.resolveActivity(context.packageManager) != null) context.startActivity(intent)
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 969
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 970
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 971
```kotlin
@Composable
```
**Giải thích:** Đánh dấu hàm là Jetpack Compose UI; Compose có thể gọi và tái dựng hàm này.

### Dòng 972
```kotlin
private fun CustomerEditorDialog(profile: CustomerProfile, onDismiss: () -> Unit, onSave: (CustomerProfile) -> Unit, onGetCustomerCoordinates: () -> Pair<Double, Double>?) {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 973
```kotlin
    val context = LocalContext.current
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 974
```kotlin
    var names by remember(profile.id) { mutableStateOf(profile.names.ifEmpty { listOf(profile.name) }.ifEmpty { listOf("") }) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 975
```kotlin
    var note by remember(profile.id) { mutableStateOf(profile.note) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 976
```kotlin
    var phones by remember(profile.id) { mutableStateOf(profile.phones.ifEmpty { listOf(CustomerPhone("", isPrimary = true)) }) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 977
```kotlin
    var addresses by remember(profile.id) { mutableStateOf(profile.addresses.ifEmpty { listOf(CustomerAddress("", isPrimary = true)) }) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 978
```kotlin
    var gateCaptureTarget by remember(profile.id) { mutableStateOf<Pair<Int, java.io.File>?>(null) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 979
```kotlin
    var coordinatePickerTarget by remember(profile.id) { mutableStateOf<Int?>(null) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 980
```kotlin
    val gateCamera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { saved ->
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 981
```kotlin
        val target = gateCaptureTarget ?: return@rememberLauncherForActivityResult
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 982
```kotlin
        gateCaptureTarget = null
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 983
```kotlin
        if (!saved) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 984
```kotlin
            target.second.delete()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 985
```kotlin
        } else {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 986
```kotlin
            addresses = addresses.mapIndexed { index, value -> if (index == target.first) value.copy(housePhotoPath = target.second.path) else value }
```
**Giải thích:** Biến đổi từng phần tử của danh sách sang giá trị mới.

### Dòng 987
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 988
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 989
```kotlin
    val dialogShape = RoundedCornerShape(18.dp)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 990
```kotlin
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 991
```kotlin
        Box(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 992
```kotlin
            Modifier
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 993
```kotlin
                .fillMaxSize()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 994
```kotlin
                .navigationBarsPadding()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 995
```kotlin
                .imePadding()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 996
```kotlin
                .padding(start = 6.dp, top = 8.dp, end = 6.dp, bottom = 12.dp),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 997
```kotlin
        ) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 998
```kotlin
            Surface(modifier = Modifier.fillMaxSize().clip(dialogShape), shape = dialogShape, color = AppBackground) {
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 999
```kotlin
                Column(modifier = Modifier.fillMaxSize()) {
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 1000
```kotlin
                Row(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 1001
```kotlin
                    modifier = Modifier.fillMaxWidth().background(Color(0xFFEAF5F2)).padding(horizontal = 14.dp, vertical = 10.dp),
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 1002
```kotlin
                    horizontalArrangement = Arrangement.spacedBy(7.dp),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 1003
```kotlin
                    verticalAlignment = Alignment.CenterVertically,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 1004
```kotlin
                ) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 1005
```kotlin
                    Text(if (profile.displayName.isBlank()) "THÊM KHÁCH HÀNG" else "SỬA KHÁCH HÀNG", color = Color(0xFF12385F), fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, modifier = Modifier.weight(1f))
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 1006
```kotlin
                    Button(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 1007
```kotlin
                        onClick = { onSave(profile.copy(name = names.firstOrNull().orEmpty(), names = names, phones = phones, addresses = addresses, note = note).normalized()) },
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 1008
```kotlin
                        enabled = CustomerProfile(id = profile.id, name = names.firstOrNull().orEmpty(), names = names, phones = phones, addresses = addresses, note = note).normalized().isValid(),
```
**Giải thích:** Điều kiện UI: quyết định nút/điều khiển có được phép thao tác hay không.

### Dòng 1009
```kotlin
                        modifier = Modifier.height(34.dp),
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 1010
```kotlin
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E73BE)),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 1011
```kotlin
                    ) { Text("Lưu", fontSize = 11.sp) }
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 1012
```kotlin
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.height(34.dp)) { Text("Đóng", fontSize = 11.sp) }
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 1013
```kotlin
                }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 1014
```kotlin
                Column(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 1015
```kotlin
                    modifier = Modifier
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 1016
```kotlin
                        .weight(1f)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 1017
```kotlin
                        .fillMaxWidth()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 1018
```kotlin
                        .verticalScroll(rememberScrollState())
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 1019
```kotlin
                        .padding(start = 14.dp, top = 9.dp, end = 14.dp, bottom = 40.dp),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 1020
```kotlin
                    verticalArrangement = Arrangement.spacedBy(6.dp),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 1021
```kotlin
                ) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 1022
```kotlin
                    Text("1. Thông tin cơ bản", fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 1023
```kotlin
                    names.forEachIndexed { index, value ->
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 1024
```kotlin
                        Row(verticalAlignment = Alignment.CenterVertically) {
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 1025
```kotlin
                            OutlinedTextField(value = value, onValueChange = { updated -> names = names.mapIndexed { i, item -> if (i == index) updated else item } }, label = { Text(if (index == 0) "Tên khách hàng" else "Tên gọi khác", fontSize = 12.sp) }, modifier = Modifier.weight(1f).heightIn(min = 56.dp).keyboardSafeTextField(), singleLine = true)
```
**Giải thích:** Biến đổi từng phần tử của danh sách sang giá trị mới.

### Dòng 1026
```kotlin
                            if (names.size > 1) IconButton(onClick = { names = names.filterIndexed { i, _ -> i != index } }, modifier = Modifier.padding(start = 6.dp).size(40.dp).background(Color(0xFFFCE8E6), RoundedCornerShape(10.dp))) { Icon(Icons.Filled.Remove, "Xóa tên", tint = Color(0xFFC23D35)) }
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 1027
```kotlin
                        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 1028
```kotlin
                    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 1029
```kotlin
                    Button(onClick = { names = names + "" }, modifier = Modifier.fillMaxWidth().height(40.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0E7490))) { Icon(Icons.Filled.Add, null, modifier = Modifier.size(17.dp)); Text(" Thêm tên khách hàng", fontSize = 12.sp) }
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 1030
```kotlin
                    phones.forEachIndexed { index, phone ->
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 1031
```kotlin
                        PhoneEditorRow(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 1032
```kotlin
                            phone = phone,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 1033
```kotlin
                            canDelete = phones.size > 1,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 1034
```kotlin
                            onChange = { updated -> phones = phones.mapIndexed { i, value -> if (i == index) updated else value } },
```
**Giải thích:** Biến đổi từng phần tử của danh sách sang giá trị mới.

### Dòng 1035
```kotlin
                            onPrimary = { phones = phones.mapIndexed { i, value -> value.copy(isPrimary = i == index) } },
```
**Giải thích:** Biến đổi từng phần tử của danh sách sang giá trị mới.

### Dòng 1036
```kotlin
                            onDelete = {
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 1037
```kotlin
                                val remaining = phones.filterIndexed { i, _ -> i != index }
```
**Giải thích:** Lọc dữ liệu theo điều kiện; chỉ giữ phần tử thỏa điều kiện.

### Dòng 1038
```kotlin
                                phones = if (remaining.any { it.isPrimary }) remaining else remaining.mapIndexed { i, value -> value.copy(isPrimary = i == 0) }
```
**Giải thích:** Biến đổi từng phần tử của danh sách sang giá trị mới.

### Dòng 1039
```kotlin
                            },
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 1040
```kotlin
                        )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 1041
```kotlin
                    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 1042
```kotlin
                    Button(onClick = { phones = phones + CustomerPhone("") }, modifier = Modifier.fillMaxWidth().height(40.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E73BE))) { Icon(Icons.Filled.Add, null, modifier = Modifier.size(17.dp)); Text(" Thêm số điện thoại", fontSize = 12.sp) }
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 1043
```kotlin
                    Text("2. Địa chỉ & Định vị", fontWeight = FontWeight.ExtraBold, fontSize = 13.sp, modifier = Modifier.padding(top = 3.dp))
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 1044
```kotlin
                    addresses.forEachIndexed { index, address ->
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 1045
```kotlin
                        AddressEditorBlock(
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 1046
```kotlin
                            address = address,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 1047
```kotlin
                            canDelete = addresses.size > 1,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 1048
```kotlin
                            onChange = { updated -> addresses = addresses.mapIndexed { i, value -> if (i == index) updated else value } },
```
**Giải thích:** Biến đổi từng phần tử của danh sách sang giá trị mới.

### Dòng 1049
```kotlin
                            onPrimary = { addresses = addresses.mapIndexed { i, value -> value.copy(isPrimary = i == index) } },
```
**Giải thích:** Biến đổi từng phần tử của danh sách sang giá trị mới.

### Dòng 1050
```kotlin
                            onDelete = {
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 1051
```kotlin
                                val remaining = addresses.filterIndexed { i, _ -> i != index }
```
**Giải thích:** Lọc dữ liệu theo điều kiện; chỉ giữ phần tử thỏa điều kiện.

### Dòng 1052
```kotlin
                                addresses = if (remaining.any { it.isPrimary }) remaining else remaining.mapIndexed { i, value -> value.copy(isPrimary = i == 0) }
```
**Giải thích:** Biến đổi từng phần tử của danh sách sang giá trị mới.

### Dòng 1053
```kotlin
                            },
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 1054
```kotlin
                            onCaptureGate = {
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 1055
```kotlin
                                val file = DeliveryPhotoHistory.createCustomerGateFile(context, profile.id)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 1056
```kotlin
                                gateCaptureTarget = index to file
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 1057
```kotlin
                                gateCamera.launch(DeliveryPhotoHistory.providerUri(context, file))
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 1058
```kotlin
                            },
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 1059
```kotlin
                            onPickCoordinates = { coordinatePickerTarget = index },
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 1060
```kotlin
                        )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 1061
```kotlin
                    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 1062
```kotlin
                    Button(onClick = { addresses = addresses + CustomerAddress("") }, modifier = Modifier.fillMaxWidth().height(40.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF229846))) { Icon(Icons.Filled.Add, null, modifier = Modifier.size(17.dp)); Text(" Thêm địa chỉ mới", fontSize = 12.sp) }
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 1063
```kotlin
                    Text("3. Thông tin bổ sung", fontWeight = FontWeight.ExtraBold, fontSize = 13.sp, modifier = Modifier.padding(top = 3.dp))
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 1064
```kotlin
                    OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text("Ghi chú", fontSize = 12.sp) }, modifier = Modifier.fillMaxWidth().heightIn(min = 88.dp).keyboardSafeTextField())
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 1065
```kotlin
                    Spacer(Modifier.height(180.dp))
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 1066
```kotlin
                }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 1067
```kotlin
            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 1068
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 1069
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 1070
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 1071
```kotlin
    coordinatePickerTarget?.let { index ->
```
**Giải thích:** Xử lý giá trị nullable an toàn; khối chỉ chạy khi giá trị tồn tại.

### Dòng 1072
```kotlin
        addresses.getOrNull(index)?.let { address ->
```
**Giải thích:** Xử lý giá trị nullable an toàn; khối chỉ chạy khi giá trị tồn tại.

### Dòng 1073
```kotlin
            CustomerCoordinatePickerDialog(
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 1074
```kotlin
                initialLatitude = address.latitude,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 1075
```kotlin
                initialLongitude = address.longitude,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 1076
```kotlin
                onDismiss = { coordinatePickerTarget = null },
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 1077
```kotlin
                onConfirm = { latitude, longitude ->
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 1078
```kotlin
                    addresses = addresses.mapIndexed { addressIndex, value ->
```
**Giải thích:** Biến đổi từng phần tử của danh sách sang giá trị mới.

### Dòng 1079
```kotlin
                        if (addressIndex == index) value.copy(latitude = latitude, longitude = longitude) else value
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 1080
```kotlin
                    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 1081
```kotlin
                    coordinatePickerTarget = null
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 1082
```kotlin
                },
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 1083
```kotlin
            )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 1084
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 1085
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 1086
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 1087
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 1088
```kotlin
@Composable
```
**Giải thích:** Đánh dấu hàm là Jetpack Compose UI; Compose có thể gọi và tái dựng hàm này.

### Dòng 1089
```kotlin
@OptIn(ExperimentalFoundationApi::class)
```
**Giải thích:** Annotation/metadata áp dụng cho khai báo hoặc hàm ngay sau đó.

### Dòng 1090
```kotlin
private fun Modifier.keyboardSafeTextField(): Modifier {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 1091
```kotlin
    val requester = remember { BringIntoViewRequester() }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 1092
```kotlin
    var focused by remember { mutableStateOf(false) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 1093
```kotlin
    LaunchedEffect(focused) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 1094
```kotlin
        if (focused) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 1095
```kotlin
            delay(220)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 1096
```kotlin
            requester.bringIntoView()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 1097
```kotlin
            delay(260)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 1098
```kotlin
            requester.bringIntoView()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 1099
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 1100
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 1101
```kotlin
    return bringIntoViewRequester(requester).onFocusChanged { focused = it.isFocused }
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 1102
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 1103
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 1104
```kotlin
@Composable
```
**Giải thích:** Đánh dấu hàm là Jetpack Compose UI; Compose có thể gọi và tái dựng hàm này.

### Dòng 1105
```kotlin
private fun PhoneEditorRow(phone: CustomerPhone, canDelete: Boolean, onChange: (CustomerPhone) -> Unit, onPrimary: () -> Unit, onDelete: () -> Unit) {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 1106
```kotlin
    var menuExpanded by remember { mutableStateOf(false) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 1107
```kotlin
    Row(verticalAlignment = Alignment.CenterVertically) {
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 1108
```kotlin
        OutlinedTextField(value = phone.number, onValueChange = { onChange(phone.copy(number = it)) }, label = { Text("Số điện thoại", fontSize = 12.sp) }, modifier = Modifier.weight(1f).heightIn(min = 56.dp).keyboardSafeTextField(), singleLine = true, trailingIcon = {
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 1109
```kotlin
            Box {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 1110
```kotlin
                IconButton(onClick = { menuExpanded = true }) { Icon(Icons.Filled.ArrowDropDown, "Chọn Gọi, SMS, Zalo") }
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 1111
```kotlin
                DropdownMenu(expanded = menuExpanded, onDismissRequest = { menuExpanded = false }) {
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 1112
```kotlin
                    CustomerContactMethod.entries.forEach { method ->
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 1113
```kotlin
                        DropdownMenuItem(text = { Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(checked = method in phone.methods, onCheckedChange = null); Text(method.label) } }, onClick = {
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 1114
```kotlin
                            val methods = if (method in phone.methods) phone.methods - method else phone.methods + method
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 1115
```kotlin
                            onChange(phone.copy(methods = methods.ifEmpty { setOf(CustomerContactMethod.CALL) }))
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 1116
```kotlin
                        })
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 1117
```kotlin
                    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 1118
```kotlin
                }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 1119
```kotlin
            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 1120
```kotlin
        })
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 1121
```kotlin
        Checkbox(checked = phone.isPrimary, onCheckedChange = { if (it) onPrimary() })
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 1122
```kotlin
        Text("Chính", fontSize = 10.sp)
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 1123
```kotlin
        if (canDelete) IconButton(onClick = onDelete, modifier = Modifier.padding(start = 4.dp).size(38.dp).background(Color(0xFFFCE8E6), RoundedCornerShape(9.dp))) { Icon(Icons.Filled.Remove, "Xóa số điện thoại", tint = Color(0xFFC23D35)) }
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 1124
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 1125
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 1126
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 1127
```kotlin
@Composable
```
**Giải thích:** Đánh dấu hàm là Jetpack Compose UI; Compose có thể gọi và tái dựng hàm này.

### Dòng 1128
```kotlin
private fun AddressEditorBlock(address: CustomerAddress, canDelete: Boolean, onChange: (CustomerAddress) -> Unit, onPrimary: () -> Unit, onDelete: () -> Unit, onCaptureGate: () -> Unit, onPickCoordinates: () -> Unit) {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 1129
```kotlin
    var longitudeText by remember { mutableStateOf(address.longitude?.toString().orEmpty()) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 1130
```kotlin
    var latitudeText by remember { mutableStateOf(address.latitude?.toString().orEmpty()) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 1131
```kotlin
    var committedLongitude by remember { mutableStateOf(address.longitude) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 1132
```kotlin
    var committedLatitude by remember { mutableStateOf(address.latitude) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 1133
```kotlin
    LaunchedEffect(address.longitude, address.latitude) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 1134
```kotlin
        if (address.longitude != committedLongitude) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 1135
```kotlin
            longitudeText = address.longitude?.toString().orEmpty()
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 1136
```kotlin
            committedLongitude = address.longitude
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 1137
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 1138
```kotlin
        if (address.latitude != committedLatitude) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 1139
```kotlin
            latitudeText = address.latitude?.toString().orEmpty()
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 1140
```kotlin
            committedLatitude = address.latitude
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 1141
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 1142
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 1143
```kotlin
    fun applyPastedCoordinates(value: String): Boolean {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 1144
```kotlin
        val coordinates = CoordinateTextParser.parse(value) ?: return false
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 1145
```kotlin
        latitudeText = coordinates.latitude.toString()
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 1146
```kotlin
        longitudeText = coordinates.longitude.toString()
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 1147
```kotlin
        committedLatitude = coordinates.latitude
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 1148
```kotlin
        committedLongitude = coordinates.longitude
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 1149
```kotlin
        onChange(address.copy(latitude = coordinates.latitude, longitude = coordinates.longitude))
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 1150
```kotlin
        return true
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 1151
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 1152
```kotlin
    Column(Modifier.fillMaxWidth().background(Color(0xFFEAF5F2), RoundedCornerShape(10.dp)).padding(7.dp)) {
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 1153
```kotlin
        OutlinedTextField(value = address.address, onValueChange = { onChange(address.copy(address = it)) }, label = { Text("Địa chỉ", fontSize = 12.sp) }, modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp).keyboardSafeTextField(), singleLine = true)
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 1154
```kotlin
        Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 1155
```kotlin
            Checkbox(checked = address.isPrimary, onCheckedChange = { if (it) onPrimary() }, modifier = Modifier.size(34.dp))
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 1156
```kotlin
            Text("Địa chỉ chính", fontSize = 10.sp, modifier = Modifier.weight(1f))
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 1157
```kotlin
            if (canDelete) IconButton(onClick = onDelete, modifier = Modifier.size(38.dp).background(Color(0xFFFCE8E6), RoundedCornerShape(9.dp))) { Icon(Icons.Filled.Remove, "Xóa địa chỉ", tint = Color(0xFFC23D35)) }
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 1158
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 1159
```kotlin
        Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 1160
```kotlin
            OutlinedTextField(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 1161
```kotlin
                value = latitudeText,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 1162
```kotlin
                onValueChange = { value ->
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 1163
```kotlin
                    latitudeText = value
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 1164
```kotlin
                    if (!applyPastedCoordinates(value)) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 1165
```kotlin
                        val latitude = value.trim().replace(',', '.').toDoubleOrNull()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 1166
```kotlin
                        committedLatitude = latitude
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 1167
```kotlin
                        onChange(address.copy(latitude = latitude))
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 1168
```kotlin
                    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 1169
```kotlin
                },
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 1170
```kotlin
                label = { Text("Vĩ độ (dán cụm)", fontSize = 11.sp) },
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 1171
```kotlin
                placeholder = { Text("Dán 10.802462, 107.000142", fontSize = 10.sp) },
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 1172
```kotlin
                modifier = Modifier.weight(1f).heightIn(min = 56.dp).keyboardSafeTextField(),
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 1173
```kotlin
                singleLine = true,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 1174
```kotlin
            )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 1175
```kotlin
            OutlinedTextField(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 1176
```kotlin
                value = longitudeText,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 1177
```kotlin
                onValueChange = { value ->
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 1178
```kotlin
                    longitudeText = value
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 1179
```kotlin
                    val longitude = value.trim().replace(',', '.').toDoubleOrNull()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 1180
```kotlin
                    committedLongitude = longitude
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 1181
```kotlin
                    onChange(address.copy(longitude = longitude))
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 1182
```kotlin
                },
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 1183
```kotlin
                label = { Text("Kinh độ", fontSize = 11.sp) },
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 1184
```kotlin
                modifier = Modifier.weight(1f).heightIn(min = 56.dp).keyboardSafeTextField(),
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 1185
```kotlin
                singleLine = true,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 1186
```kotlin
            )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 1187
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 1188
```kotlin
        Text("Nhập tay từng ô hoặc dán cụm Google Maps theo thứ tự Vĩ độ, Kinh độ vào ô Vĩ độ bên trái.", color = Color(0xFF66737E), fontSize = 9.sp, modifier = Modifier.padding(top = 2.dp))
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 1189
```kotlin
        Row(Modifier.fillMaxWidth().padding(top = 7.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 1190
```kotlin
            Button(onClick = onCaptureGate, modifier = Modifier.weight(1f).height(42.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E73BE))) { Icon(Icons.Filled.CameraAlt, "Chụp cổng nhà", modifier = Modifier.size(18.dp)); Text(" Ảnh cổng", fontSize = 11.sp) }
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 1191
```kotlin
            Button(onClick = onPickCoordinates, modifier = Modifier.weight(1f).height(42.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF229846))) { Icon(Icons.Filled.LocationOn, "Chọn tọa độ trên bản đồ", modifier = Modifier.size(18.dp)); Text(" Lấy tọa độ", fontSize = 11.sp) }
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 1192
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 1193
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 1194
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 1195
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 1196
```kotlin
@Composable
```
**Giải thích:** Đánh dấu hàm là Jetpack Compose UI; Compose có thể gọi và tái dựng hàm này.

### Dòng 1197
```kotlin
private fun DeliveryCompletionDialog(
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 1198
```kotlin
    order: DeliveryOrder,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 1199
```kotlin
    onDismiss: () -> Unit,
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 1200
```kotlin
    onConfirm: () -> Unit,
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 1201
```kotlin
) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 1202
```kotlin
    AlertDialog(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 1203
```kotlin
        onDismissRequest = onDismiss,
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 1204
```kotlin
        title = { Text("Xác nhận giao thành công") },
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 1205
```kotlin
        text = { Text("Bạn chắc chắn giao thành công đơn hàng ${order.waybill}?", fontSize = 13.sp) },
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 1206
```kotlin
        confirmButton = {
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 1207
```kotlin
            Button(onClick = onConfirm, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF229846))) { Text("Có") }
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 1208
```kotlin
        },
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 1209
```kotlin
        dismissButton = { OutlinedButton(onClick = onDismiss) { Text("Không") } },
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 1210
```kotlin
    )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 1211
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

