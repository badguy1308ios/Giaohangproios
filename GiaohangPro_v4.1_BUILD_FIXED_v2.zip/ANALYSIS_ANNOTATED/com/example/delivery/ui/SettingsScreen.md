# Phân tích từng dòng — `com/example/delivery/ui/SettingsScreen.kt`

> Tài liệu đọc/debug: mã gốc theo từng dòng + giải thích. Không dùng trực tiếp để compile.

### Dòng 1
```kotlin
package com.example.delivery.ui
```
**Giải thích:** Khai báo package, xác định namespace của file.

### Dòng 2
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 3
```kotlin
import androidx.compose.foundation.background
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 4
```kotlin
import androidx.compose.foundation.clickable
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 5
```kotlin
import androidx.compose.foundation.layout.Column
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 6
```kotlin
import androidx.compose.foundation.layout.Row
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 7
```kotlin
import androidx.compose.foundation.layout.fillMaxSize
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 8
```kotlin
import androidx.compose.foundation.layout.fillMaxWidth
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 9
```kotlin
import androidx.compose.foundation.layout.padding
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 10
```kotlin
import androidx.compose.foundation.layout.statusBarsPadding
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 11
```kotlin
import androidx.compose.foundation.shape.RoundedCornerShape
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 12
```kotlin
import androidx.compose.material.icons.Icons
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 13
```kotlin
import androidx.compose.material.icons.filled.ArrowBack
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 14
```kotlin
import androidx.compose.material3.AlertDialog
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 15
```kotlin
import androidx.compose.material3.Button
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 16
```kotlin
import androidx.compose.material3.ButtonDefaults
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 17
```kotlin
import androidx.compose.material3.Icon
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 18
```kotlin
import androidx.compose.material3.IconButton
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 19
```kotlin
import androidx.compose.material3.OutlinedTextField
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 20
```kotlin
import androidx.compose.material3.Text
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 21
```kotlin
import androidx.compose.runtime.Composable
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 22
```kotlin
import androidx.compose.runtime.getValue
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 23
```kotlin
import androidx.compose.runtime.mutableStateOf
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 24
```kotlin
import androidx.compose.runtime.remember
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 25
```kotlin
import androidx.compose.runtime.setValue
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 26
```kotlin
import androidx.compose.ui.Alignment
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 27
```kotlin
import androidx.compose.ui.Modifier
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 28
```kotlin
import androidx.compose.ui.graphics.Color
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 29
```kotlin
import androidx.compose.ui.text.font.FontWeight
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 30
```kotlin
import androidx.compose.ui.unit.dp
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 31
```kotlin
import androidx.compose.ui.unit.sp
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 32
```kotlin
import com.example.delivery.history.TransferEvidence
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 33
```kotlin
import com.example.delivery.model.DeliveryOrder
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 34
```kotlin
import com.example.delivery.orderio.CoordinateUpdateRequest
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 35
```kotlin
import com.example.delivery.orderio.CoordinateTextParser
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 36
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 37
```kotlin
@Composable
```
**Giải thích:** Đánh dấu hàm là Jetpack Compose UI; Compose có thể gọi và tái dựng hàm này.

### Dòng 38
```kotlin
fun SettingsScreen(
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 39
```kotlin
    evidence: List<TransferEvidence>,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 40
```kotlin
    onConfirmPayment: (String) -> Unit,
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 41
```kotlin
    onOpenCashAudit: () -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 42
```kotlin
    onOpenBackup: () -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 43
```kotlin
    onOpenVtmanExport: () -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 44
```kotlin
    onOpenTransferCheck: () -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 45
```kotlin
    onOpenOrderManagement: () -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 46
```kotlin
    onOpenAnchorPoint: () -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 47
```kotlin
    onClose: () -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 48
```kotlin
) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 49
```kotlin
    Column(Modifier.fillMaxSize().background(AppBackground)) {
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 50
```kotlin
        Row(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 51
```kotlin
            Modifier.fillMaxWidth().statusBarsPadding().padding(start = 12.dp, top = 8.dp, end = 12.dp, bottom = 10.dp),
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 52
```kotlin
            verticalAlignment = Alignment.CenterVertically,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 53
```kotlin
        ) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 54
```kotlin
            IconButton(onClick = onClose) { Icon(Icons.Filled.ArrowBack, "Quay lại", tint = Color(0xFF12385F)) }
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 55
```kotlin
            Text("CÀI ĐẶT", color = Color(0xFF12385F), fontWeight = FontWeight.ExtraBold)
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 56
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 57
```kotlin
        SettingsEntry("IMPORT / EXPORT DỮ LIỆU", "Sao lưu khách hàng hoặc quản lý đơn hàng", onOpenBackup)
```
**Giải thích:** Xử lý lỗi/ngoại lệ; kiểm tra nhánh này khi thao tác mạng hoặc hệ thống thất bại.

### Dòng 58
```kotlin
        SettingsEntry("VTMAN EXPORT", "Mở công cụ nạp MVĐ, lấy SĐT và xuất CSV từ VTMan", onOpenVtmanExport)
```
**Giải thích:** Xử lý lỗi/ngoại lệ; kiểm tra nhánh này khi thao tác mạng hoặc hệ thống thất bại.

### Dòng 59
```kotlin
        SettingsEntry("XỬ LÝ ĐƠN", "Thêm đơn hàng, xóa đơn hàng hoặc cập nhật tuyến", onOpenOrderManagement)
```
**Giải thích:** Xử lý lỗi/ngoại lệ; kiểm tra nhánh này khi thao tác mạng hoặc hệ thống thất bại.

### Dòng 60
```kotlin
        SettingsEntry("TUYẾN GIAO HÀNG", "Quản lý tuyến và các vùng giao hàng", onOpenAnchorPoint)
```
**Giải thích:** Xử lý lỗi/ngoại lệ; kiểm tra nhánh này khi thao tác mạng hoặc hệ thống thất bại.

### Dòng 61
```kotlin
        SettingsEntry("BẢNG KÊ TIỀN", "Đếm tiền mặt, nhập Bank, Cước và COD", onOpenCashAudit)
```
**Giải thích:** Xử lý lỗi/ngoại lệ; kiểm tra nhánh này khi thao tác mạng hoặc hệ thống thất bại.

### Dòng 62
```kotlin
        SettingsEntry("CHECK CHUYỂN KHOẢN", null, onOpenTransferCheck)
```
**Giải thích:** Xử lý lỗi/ngoại lệ; kiểm tra nhánh này khi thao tác mạng hoặc hệ thống thất bại.

### Dòng 63
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 64
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 65
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 66
```kotlin
@Composable
```
**Giải thích:** Đánh dấu hàm là Jetpack Compose UI; Compose có thể gọi và tái dựng hàm này.

### Dòng 67
```kotlin
fun OrderManagementScreen(
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 68
```kotlin
    status: String?,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 69
```kotlin
    onAddManualOrder: (DeliveryOrder) -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 70
```kotlin
    onDeleteOrder: (String) -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 71
```kotlin
    onDeleteAllOrders: () -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 72
```kotlin
    onOpenCoordinateUpdate: () -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 73
```kotlin
    onConfirmRouteChange: () -> Unit,
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 74
```kotlin
    onClose: () -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 75
```kotlin
) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 76
```kotlin
    var manualOrderEntry by remember { mutableStateOf(false) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 77
```kotlin
    var deleteEntryOpen by remember { mutableStateOf(false) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 78
```kotlin
    var deleteWaybill by remember { mutableStateOf("") }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 79
```kotlin
    var deleteConfirmationOpen by remember { mutableStateOf(false) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 80
```kotlin
    var deleteAllConfirmationOpen by remember { mutableStateOf(false) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 81
```kotlin
    Column(Modifier.fillMaxSize().background(AppBackground)) {
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 82
```kotlin
        Row(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 83
```kotlin
            Modifier.fillMaxWidth().statusBarsPadding().padding(start = 12.dp, top = 8.dp, end = 12.dp, bottom = 10.dp),
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 84
```kotlin
            verticalAlignment = Alignment.CenterVertically,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 85
```kotlin
        ) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 86
```kotlin
            IconButton(onClick = onClose) { Icon(Icons.Filled.ArrowBack, "Quay lại Cài đặt", tint = Color(0xFF12385F)) }
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 87
```kotlin
            Text("XỬ LÝ ĐƠN", color = Color(0xFF12385F), fontWeight = FontWeight.ExtraBold)
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 88
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 89
```kotlin
        SettingsEntry("THÊM ĐƠN HÀNG", "Nhập tay mã vận đơn và thông tin người nhận", onClick = { manualOrderEntry = true })
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 90
```kotlin
        SettingsEntry("XÓA ĐƠN HÀNG", "Chỉ xóa đơn; hồ sơ và lịch sử khách hàng vẫn được giữ lại", onClick = { deleteEntryOpen = !deleteEntryOpen })
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 91
```kotlin
        if (deleteEntryOpen) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 92
```kotlin
            OutlinedTextField(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 93
```kotlin
                value = deleteWaybill,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 94
```kotlin
                onValueChange = { deleteWaybill = it },
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 95
```kotlin
                label = { Text("Mã vận đơn cần xóa") },
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 96
```kotlin
                singleLine = true,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 97
```kotlin
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 5.dp),
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 98
```kotlin
            )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 99
```kotlin
            Button(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 100
```kotlin
                enabled = deleteWaybill.isNotBlank(),
```
**Giải thích:** Điều kiện UI: quyết định nút/điều khiển có được phép thao tác hay không.

### Dòng 101
```kotlin
                onClick = { deleteConfirmationOpen = true },
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 102
```kotlin
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC23D35)),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 103
```kotlin
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 5.dp),
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 104
```kotlin
            ) { Text("Xóa đơn đã nhập") }
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 105
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 106
```kotlin
        SettingsEntry("XÓA TẤT CẢ ĐƠN HÀNG", "Xóa toàn bộ đơn trong Chi tiết đơn và Bản đồ", onClick = { deleteAllConfirmationOpen = true })
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 107
```kotlin
        status?.let { Text(it, color = Color(0xFF59636D), fontSize = 11.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) }
```
**Giải thích:** Xử lý giá trị nullable an toàn; khối chỉ chạy khi giá trị tồn tại.

### Dòng 108
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 109
```kotlin
    if (manualOrderEntry) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 110
```kotlin
        ManualOrderEntryDialog(
```
**Giải thích:** Xử lý lỗi/ngoại lệ; kiểm tra nhánh này khi thao tác mạng hoặc hệ thống thất bại.

### Dòng 111
```kotlin
            onDismiss = { manualOrderEntry = false },
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 112
```kotlin
            onSave = { order -> onAddManualOrder(order); manualOrderEntry = false },
```
**Giải thích:** Xử lý lỗi/ngoại lệ; kiểm tra nhánh này khi thao tác mạng hoặc hệ thống thất bại.

### Dòng 113
```kotlin
        )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 114
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 115
```kotlin
    if (deleteAllConfirmationOpen) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 116
```kotlin
        AlertDialog(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 117
```kotlin
            onDismissRequest = { deleteAllConfirmationOpen = false },
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 118
```kotlin
            title = { Text("Xóa tất cả đơn hàng?") },
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 119
```kotlin
            text = { Text("Bạn chắc chắn muốn xoá tất cả các đơn hàng phải không?") },
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 120
```kotlin
            confirmButton = {
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 121
```kotlin
                Button(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 122
```kotlin
                    onClick = { onDeleteAllOrders(); deleteAllConfirmationOpen = false },
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 123
```kotlin
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC23D35)),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 124
```kotlin
                ) { Text("Có") }
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 125
```kotlin
            },
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 126
```kotlin
            dismissButton = { androidx.compose.material3.OutlinedButton(onClick = { deleteAllConfirmationOpen = false }) { Text("Không") } },
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 127
```kotlin
        )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 128
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 129
```kotlin
    if (deleteConfirmationOpen) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 130
```kotlin
        AlertDialog(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 131
```kotlin
            onDismissRequest = { deleteConfirmationOpen = false },
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 132
```kotlin
            title = { Text("Xóa đơn hàng?") },
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 133
```kotlin
            text = { Text("Đơn ${deleteWaybill.trim()} sẽ bị xóa khỏi danh sách. Thông tin và lịch sử khách hàng không bị xóa.") },
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 134
```kotlin
            confirmButton = {
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 135
```kotlin
                Button(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 136
```kotlin
                    onClick = { onDeleteOrder(deleteWaybill); deleteWaybill = ""; deleteConfirmationOpen = false; deleteEntryOpen = false },
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 137
```kotlin
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC23D35)),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 138
```kotlin
                ) { Text("Xóa đơn") }
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 139
```kotlin
            },
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 140
```kotlin
            dismissButton = { androidx.compose.material3.OutlinedButton(onClick = { deleteConfirmationOpen = false }) { Text("Hủy") } },
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 141
```kotlin
        )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 142
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 143
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 144
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 145
```kotlin
@Composable
```
**Giải thích:** Đánh dấu hàm là Jetpack Compose UI; Compose có thể gọi và tái dựng hàm này.

### Dòng 146
```kotlin
private fun SettingsEntry(title: String, subtitle: String?, onClick: () -> Unit) {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 147
```kotlin
    Row(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 148
```kotlin
        Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 5.dp).background(AppSurface, RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(horizontal = 13.dp, vertical = 13.dp),
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 149
```kotlin
        verticalAlignment = Alignment.CenterVertically,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 150
```kotlin
    ) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 151
```kotlin
        Column(Modifier.weight(1f)) {
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 152
```kotlin
            Text(title, color = Color(0xFF12385F), fontWeight = FontWeight.Bold, fontSize = 13.sp)
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 153
```kotlin
            subtitle?.let { Text(it, color = Color(0xFF59636D), fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp)) }
```
**Giải thích:** Xử lý giá trị nullable an toàn; khối chỉ chạy khi giá trị tồn tại.

### Dòng 154
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 155
```kotlin
        Text("›", color = Color(0xFF12385F), fontSize = 25.sp, fontWeight = FontWeight.Bold)
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 156
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 157
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 158
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 159
```kotlin
@Composable
```
**Giải thích:** Đánh dấu hàm là Jetpack Compose UI; Compose có thể gọi và tái dựng hàm này.

### Dòng 160
```kotlin
fun CoordinateUpdateScreen(
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 161
```kotlin
    status: String?,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 162
```kotlin
    onSave: (CoordinateUpdateRequest) -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 163
```kotlin
    onConfirmRouteChange: () -> Unit,
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 164
```kotlin
    onClose: () -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 165
```kotlin
) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 166
```kotlin
    var reference by remember { mutableStateOf("") }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 167
```kotlin
    var pastedCoordinates by remember { mutableStateOf("") }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 168
```kotlin
    var latitude by remember { mutableStateOf("") }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 169
```kotlin
    var longitude by remember { mutableStateOf("") }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 170
```kotlin
    fun applyPastedCoordinates(value: String): Boolean {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 171
```kotlin
        val coordinates = CoordinateTextParser.parse(value) ?: return false
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 172
```kotlin
        latitude = coordinates.latitude.toString()
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 173
```kotlin
        longitude = coordinates.longitude.toString()
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 174
```kotlin
        return true
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 175
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 176
```kotlin
    val parsedLatitude = latitude.trim().replace(',', '.').toDoubleOrNull()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 177
```kotlin
    val parsedLongitude = longitude.trim().replace(',', '.').toDoubleOrNull()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 178
```kotlin
    val coordinatesValid = parsedLatitude != null && parsedLongitude != null && parsedLatitude in -90.0..90.0 && parsedLongitude in -180.0..180.0
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 179
```kotlin
    Column(Modifier.fillMaxSize().background(AppBackground)) {
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 180
```kotlin
        Row(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 181
```kotlin
            Modifier.fillMaxWidth().statusBarsPadding().padding(start = 12.dp, top = 8.dp, end = 12.dp, bottom = 10.dp),
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 182
```kotlin
            verticalAlignment = Alignment.CenterVertically,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 183
```kotlin
        ) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 184
```kotlin
            IconButton(onClick = onClose) { Icon(Icons.Filled.ArrowBack, "Quay lại Cài đặt", tint = Color(0xFF12385F)) }
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 185
```kotlin
            Text("CẬP NHẬT", color = Color(0xFF12385F), fontWeight = FontWeight.ExtraBold)
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 186
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 187
```kotlin
        Text("Nhập MVĐ hoặc SĐT cùng tọa độ mới; hoặc rà tất cả SĐT đã có tọa độ để đồng bộ và xếp lại tuyến.", color = Color(0xFF59636D), fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 188
```kotlin
        OutlinedTextField(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 189
```kotlin
            value = reference,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 190
```kotlin
            onValueChange = { reference = it },
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 191
```kotlin
            label = { Text("Mã vận đơn hoặc SĐT") },
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 192
```kotlin
            singleLine = true,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 193
```kotlin
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 5.dp),
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 194
```kotlin
        )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 195
```kotlin
        OutlinedTextField(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 196
```kotlin
            value = pastedCoordinates,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 197
```kotlin
            onValueChange = { value ->
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 198
```kotlin
                pastedCoordinates = value
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 199
```kotlin
                applyPastedCoordinates(value)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 200
```kotlin
            },
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 201
```kotlin
            label = { Text("Dán cụm tọa độ") },
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 202
```kotlin
            placeholder = { Text("10.7769, 106.7009 hoặc 106.7009, 10.7769", fontSize = 11.sp) },
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 203
```kotlin
            singleLine = true,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 204
```kotlin
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 5.dp),
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 205
```kotlin
        )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 206
```kotlin
        Text("Có thể dán theo thứ tự vĩ độ, kinh độ hoặc kinh độ, vĩ độ. Hai ô bên dưới vẫn nhập tay được.", color = Color(0xFF59636D), fontSize = 10.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 1.dp))
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 207
```kotlin
        OutlinedTextField(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 208
```kotlin
            value = latitude,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 209
```kotlin
            onValueChange = { value -> if (!applyPastedCoordinates(value)) latitude = value },
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 210
```kotlin
            label = { Text("Vĩ độ (Latitude)") },
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 211
```kotlin
            singleLine = true,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 212
```kotlin
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 5.dp),
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 213
```kotlin
        )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 214
```kotlin
        OutlinedTextField(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 215
```kotlin
            value = longitude,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 216
```kotlin
            onValueChange = { value -> if (!applyPastedCoordinates(value)) longitude = value },
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 217
```kotlin
            label = { Text("Kinh độ (Longitude)") },
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 218
```kotlin
            singleLine = true,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 219
```kotlin
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 5.dp),
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 220
```kotlin
        )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 221
```kotlin
        Button(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 222
```kotlin
            enabled = reference.isNotBlank() && coordinatesValid,
```
**Giải thích:** Điều kiện UI: quyết định nút/điều khiển có được phép thao tác hay không.

### Dòng 223
```kotlin
            onClick = { onSave(CoordinateUpdateRequest(reference, parsedLatitude!!, parsedLongitude!!)) },
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 224
```kotlin
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 225
```kotlin
        ) { Text("Lưu tọa độ, giữ nguyên STT") }
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 226
```kotlin
        if (!coordinatesValid && (latitude.isNotBlank() || longitude.isNotBlank())) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 227
```kotlin
            Text("Vĩ độ phải từ -90 đến 90, kinh độ từ -180 đến 180.", color = Color(0xFFC23D35), fontSize = 11.sp, modifier = Modifier.padding(horizontal = 16.dp))
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 228
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 229
```kotlin
        status?.let { Text(it, color = Color(0xFF59636D), fontSize = 11.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) }
```
**Giải thích:** Xử lý giá trị nullable an toàn; khối chỉ chạy khi giá trị tồn tại.

### Dòng 230
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 231
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 232
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 233
```kotlin
@Composable
```
**Giải thích:** Đánh dấu hàm là Jetpack Compose UI; Compose có thể gọi và tái dựng hàm này.

### Dòng 234
```kotlin
fun BackupDataScreen(
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 235
```kotlin
    onExportBackup: () -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 236
```kotlin
    onImportBackup: () -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 237
```kotlin
    onImportOrders: () -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 238
```kotlin
    onExportOrders: () -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 239
```kotlin
    onExportStt: () -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 240
```kotlin
    onImportStt: () -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 241
```kotlin
    backupStatus: String?,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 242
```kotlin
    onClose: () -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 243
```kotlin
) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 244
```kotlin
    var importConfirmationOpen by remember { mutableStateOf(false) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 245
```kotlin
    Column(Modifier.fillMaxSize().background(AppBackground)) {
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 246
```kotlin
        Row(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 247
```kotlin
            Modifier.fillMaxWidth().statusBarsPadding().padding(start = 12.dp, top = 8.dp, end = 12.dp, bottom = 10.dp),
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 248
```kotlin
            verticalAlignment = Alignment.CenterVertically,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 249
```kotlin
        ) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 250
```kotlin
            IconButton(onClick = onClose) { Icon(Icons.Filled.ArrowBack, "Quay lại Cài đặt", tint = Color(0xFF12385F)) }
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 251
```kotlin
            Text("IMPORT / EXPORT DỮ LIỆU", color = Color(0xFF12385F), fontWeight = FontWeight.ExtraBold)
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 252
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 253
```kotlin
        Button(onClick = onExportBackup, modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 7.dp)) { Text("Xuất Dữ Liệu Khách Hàng") }
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 254
```kotlin
        Button(onClick = { importConfirmationOpen = true }, modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 7.dp)) { Text("Nhập Dữ Liệu Khách Hàng") }
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 255
```kotlin
        Button(onClick = onImportOrders, modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 7.dp)) { Text("Nhập Đơn Hàng") }
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 256
```kotlin
        Button(onClick = onExportOrders, modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 7.dp)) { Text("Xuất Đơn Hàng") }
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 257
```kotlin
        Button(onClick = onExportStt, modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 7.dp)) { Text("Lưu STT") }
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 258
```kotlin
        Button(onClick = onImportStt, modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 7.dp)) { Text("Khôi phục STT") }
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 259
```kotlin
        backupStatus?.let { Text(it, modifier = Modifier.padding(horizontal = 16.dp, vertical = 5.dp), color = Color(0xFF59636D), fontSize = 11.sp) }
```
**Giải thích:** Xử lý giá trị nullable an toàn; khối chỉ chạy khi giá trị tồn tại.

### Dòng 260
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 261
```kotlin
    if (importConfirmationOpen) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 262
```kotlin
        AlertDialog(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 263
```kotlin
            onDismissRequest = { importConfirmationOpen = false },
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 264
```kotlin
            title = { Text("Nhập dữ liệu khách hàng?") },
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 265
```kotlin
            text = { Text("Dữ liệu khách hàng và lịch sử hiện có sẽ được thay bằng dữ liệu trong file ZIP.") },
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 266
```kotlin
            confirmButton = { Button(onClick = { importConfirmationOpen = false; onImportBackup() }) { Text("Chọn ZIP") } },
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 267
```kotlin
            dismissButton = { Button(onClick = { importConfirmationOpen = false }) { Text("Hủy") } },
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 268
```kotlin
        )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 269
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 270
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 271
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 272
```kotlin
@Composable
```
**Giải thích:** Đánh dấu hàm là Jetpack Compose UI; Compose có thể gọi và tái dựng hàm này.

### Dòng 273
```kotlin
fun TransferCheckScreen(onClose: () -> Unit) {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 274
```kotlin
    Column(Modifier.fillMaxSize().background(AppBackground)) {
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 275
```kotlin
        Row(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 276
```kotlin
            Modifier.fillMaxWidth().statusBarsPadding().padding(start = 12.dp, top = 8.dp, end = 12.dp, bottom = 10.dp),
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 277
```kotlin
            verticalAlignment = Alignment.CenterVertically,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 278
```kotlin
        ) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 279
```kotlin
            IconButton(onClick = onClose) { Icon(Icons.Filled.ArrowBack, "Quay lại Cài đặt", tint = Color(0xFF12385F)) }
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 280
```kotlin
            Text("CHECK CHUYỂN KHOẢN", color = Color(0xFF12385F), fontWeight = FontWeight.ExtraBold)
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 281
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 282
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 283
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

