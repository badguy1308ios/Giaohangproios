# Phân tích từng dòng — `com/example/delivery/ui/OrderDetailScreen.kt`

> Tài liệu đọc/debug: mã gốc theo từng dòng + giải thích. Không dùng trực tiếp để compile.

### Dòng 1
```kotlin
package com.example.delivery.ui
```
**Giải thích:** Khai báo package, xác định namespace của file.

### Dòng 2
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 3
```kotlin
import androidx.compose.foundation.background
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 4
```kotlin
import androidx.compose.foundation.border
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 5
```kotlin
import androidx.compose.foundation.clickable
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 6
```kotlin
import androidx.compose.foundation.rememberScrollState
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 7
```kotlin
import androidx.compose.foundation.layout.Arrangement
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 8
```kotlin
import androidx.compose.foundation.layout.Box
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 9
```kotlin
import androidx.compose.foundation.layout.Column
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 10
```kotlin
import androidx.compose.foundation.layout.Row
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 11
```kotlin
import androidx.compose.foundation.layout.Spacer
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 12
```kotlin
import androidx.compose.foundation.layout.fillMaxWidth
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 13
```kotlin
import androidx.compose.foundation.layout.height
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 14
```kotlin
import androidx.compose.foundation.layout.padding
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 15
```kotlin
import androidx.compose.foundation.layout.size
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 16
```kotlin
import androidx.compose.foundation.layout.width
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 17
```kotlin
import androidx.compose.foundation.verticalScroll
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 18
```kotlin
import androidx.compose.foundation.lazy.LazyColumn
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 19
```kotlin
import androidx.compose.foundation.lazy.items
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 20
```kotlin
import androidx.compose.foundation.lazy.rememberLazyListState
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 21
```kotlin
import androidx.compose.foundation.shape.RoundedCornerShape
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 22
```kotlin
import androidx.compose.material.icons.Icons
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 23
```kotlin
import androidx.compose.material.icons.filled.ArrowUpward
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 24
```kotlin
import androidx.compose.material.icons.filled.Call
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 25
```kotlin
import androidx.compose.material.icons.filled.CameraAlt
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 26
```kotlin
import androidx.compose.material.icons.filled.CheckCircle
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 27
```kotlin
import androidx.compose.material.icons.filled.Close
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 28
```kotlin
import androidx.compose.material.icons.filled.Message
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 29
```kotlin
import androidx.compose.material.icons.filled.Person
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 30
```kotlin
import androidx.compose.material.icons.filled.QrCodeScanner
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 31
```kotlin
import androidx.compose.material.icons.filled.Search
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 32
```kotlin
import androidx.compose.material.icons.filled.Sms
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 33
```kotlin
import androidx.compose.material.icons.filled.Wallet
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 34
```kotlin
import androidx.compose.material3.AlertDialog
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 35
```kotlin
import androidx.compose.material3.Button
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 36
```kotlin
import androidx.compose.material3.Icon
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 37
```kotlin
import androidx.compose.material3.IconButton
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 38
```kotlin
import androidx.compose.material3.OutlinedTextField
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 39
```kotlin
import androidx.compose.material3.Text
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 40
```kotlin
import androidx.compose.material3.TextButton
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 41
```kotlin
import androidx.compose.runtime.Composable
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 42
```kotlin
import androidx.compose.runtime.LaunchedEffect
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 43
```kotlin
import androidx.compose.runtime.getValue
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 44
```kotlin
import androidx.compose.runtime.mutableStateOf
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 45
```kotlin
import androidx.compose.runtime.remember
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 46
```kotlin
import androidx.compose.runtime.setValue
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 47
```kotlin
import androidx.compose.ui.Alignment
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 48
```kotlin
import androidx.compose.ui.Modifier
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 49
```kotlin
import androidx.compose.ui.graphics.Color
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 50
```kotlin
import androidx.compose.ui.text.font.FontWeight
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 51
```kotlin
import androidx.compose.ui.text.style.TextOverflow
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 52
```kotlin
import androidx.compose.ui.unit.dp
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 53
```kotlin
import androidx.compose.ui.unit.sp
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 54
```kotlin
import com.example.delivery.model.DeliveryOrder
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 55
```kotlin
import com.example.delivery.model.DeliveryOutcome
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 56
```kotlin
import com.example.delivery.model.deliveryOutcome
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 57
```kotlin
import com.example.delivery.model.detailStatusLabel
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 58
```kotlin
import com.example.delivery.model.dispatchDisplayOrder
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 59
```kotlin
import com.example.delivery.model.filterForDetail
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 60
```kotlin
import com.example.delivery.model.formatVnd
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 61
```kotlin
import com.example.delivery.model.isPickupAtWarehouse
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 62
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 63
```kotlin
private val DetailNavy = Color(0xFF12385F)
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 64
```kotlin
private val DetailGreen = Color(0xFF229846)
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 65
```kotlin
private val DetailRed = Color(0xFFC83B3B)
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 66
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 67
```kotlin
private data class ExpandedDetail(val title: String, val value: String)
```
**Giải thích:** Khai báo lớp; gom dữ liệu hoặc hành vi liên quan vào một đơn vị.

### Dòng 68
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 69
```kotlin
internal fun selectedOrderIndex(orders: List<DeliveryOrder>, selectedWaybill: String?): Int =
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 70
```kotlin
    selectedWaybill?.let { waybill -> orders.indexOfFirst { it.waybill == waybill } } ?: -1
```
**Giải thích:** Xử lý giá trị nullable an toàn; khối chỉ chạy khi giá trị tồn tại.

### Dòng 71
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 72
```kotlin
@Composable
```
**Giải thích:** Đánh dấu hàm là Jetpack Compose UI; Compose có thể gọi và tái dựng hàm này.

### Dòng 73
```kotlin
fun OrderDetailScreen(
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 74
```kotlin
    orders: List<DeliveryOrder>,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 75
```kotlin
    searchQuery: String,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 76
```kotlin
    selectedWaybill: String?,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 77
```kotlin
    onSelectOrder: (DeliveryOrder) -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 78
```kotlin
    onSearchChange: (String) -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 79
```kotlin
    onOpenScanner: () -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 80
```kotlin
    onDelivered: (DeliveryOrder) -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 81
```kotlin
    onCall: (DeliveryOrder) -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 82
```kotlin
    onZalo: (DeliveryOrder) -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 83
```kotlin
    onSms: (DeliveryOrder) -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 84
```kotlin
    onOpenCustomer: (DeliveryOrder) -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 85
```kotlin
    onNavigateOrder: (DeliveryOrder) -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 86
```kotlin
    scrollToTopRequest: Int = 0,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 87
```kotlin
) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 88
```kotlin
    var showDelivered by remember { mutableStateOf(false) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 89
```kotlin
    var expandedDetail by remember { mutableStateOf<ExpandedDetail?>(null) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 90
```kotlin
    val visible = orders.filterForDetail(searchQuery, showDelivered, false)
```
**Giải thích:** Lọc dữ liệu theo điều kiện; chỉ giữ phần tử thỏa điều kiện.

### Dòng 91
```kotlin
    val exactOrder = searchQuery.trim().takeIf { it.isNotBlank() }?.let { query ->
```
**Giải thích:** Chọn/loại giá trị theo điều kiện, trả null nếu không thỏa.

### Dòng 92
```kotlin
        orders.firstOrNull { it.waybill.equals(query, ignoreCase = true) }
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 93
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 94
```kotlin
    val visibleGroups = if (exactOrder != null) {
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 95
```kotlin
        val groupKey = exactOrder.phone.filter(Char::isDigit).ifBlank { exactOrder.waybill }
```
**Giải thích:** Lọc dữ liệu theo điều kiện; chỉ giữ phần tử thỏa điều kiện.

### Dòng 96
```kotlin
        orders.filter { it.phone.filter(Char::isDigit).ifBlank { it.waybill } == groupKey }
```
**Giải thích:** Lọc dữ liệu theo điều kiện; chỉ giữ phần tử thỏa điều kiện.

### Dòng 97
```kotlin
            .dispatchDisplayOrder()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 98
```kotlin
            .let { group -> listOf(group) }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 99
```kotlin
    } else {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 100
```kotlin
        visible.groupBy { it.phone.filter(Char::isDigit).ifBlank { it.waybill } }.values.toList()
```
**Giải thích:** Lọc dữ liệu theo điều kiện; chỉ giữ phần tử thỏa điều kiện.

### Dòng 101
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 102
```kotlin
    val displayedOrders = visibleGroups.flatten()
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 103
```kotlin
    val listState = rememberLazyListState()
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 104
```kotlin
    LaunchedEffect(selectedWaybill, searchQuery, showDelivered, orders) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 105
```kotlin
        val index = visibleGroups.indexOfFirst { group: List<DeliveryOrder> -> group.any { order -> order.waybill == selectedWaybill } }
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 106
```kotlin
        if (index >= 0) listState.animateScrollToItem(index)
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 107
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 108
```kotlin
    LaunchedEffect(scrollToTopRequest) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 109
```kotlin
        if (scrollToTopRequest > 0) listState.animateScrollToItem(0)
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 110
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 111
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 112
```kotlin
    Column(modifier = Modifier.background(AppBackground)) {
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 113
```kotlin
        Row(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 114
```kotlin
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 7.dp),
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 115
```kotlin
            verticalAlignment = Alignment.CenterVertically,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 116
```kotlin
            horizontalArrangement = Arrangement.spacedBy(7.dp),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 117
```kotlin
        ) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 118
```kotlin
            Box(modifier = Modifier.size(46.dp).background(DetailNavy, RoundedCornerShape(12.dp)).clickable(onClick = onOpenScanner), contentAlignment = Alignment.Center) {
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 119
```kotlin
                Icon(Icons.Filled.QrCodeScanner, "Quét mã QR", tint = Color.White, modifier = Modifier.size(27.dp))
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 120
```kotlin
            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 121
```kotlin
            OutlinedTextField(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 122
```kotlin
                value = searchQuery,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 123
```kotlin
                onValueChange = onSearchChange,
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 124
```kotlin
                modifier = Modifier.weight(1f),
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 125
```kotlin
                singleLine = true,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 126
```kotlin
                leadingIcon = { Icon(Icons.Filled.Search, null, modifier = Modifier.size(18.dp)) },
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 127
```kotlin
                trailingIcon = if (searchQuery.isNotBlank()) {
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 128
```kotlin
                    { IconButton(onClick = { onSearchChange("") }) { Icon(Icons.Filled.Close, "Xóa tìm kiếm", modifier = Modifier.size(18.dp)) } }
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 129
```kotlin
                } else null,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 130
```kotlin
                placeholder = { Text("Mã đơn, SĐT, khách, tiền", fontSize = 12.sp) },
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 131
```kotlin
            )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 132
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 133
```kotlin
        Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 13.dp, vertical = 3.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 134
```kotlin
            StatusToggle("Đã giao", showDelivered, DetailGreen, Modifier.width(82.dp)) { showDelivered = !showDelivered }
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 135
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 136
```kotlin
        Text("DANH SÁCH ${displayedOrders.size} ĐƠN", color = Color(0xFF78838F), fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(start = 15.dp, top = 4.dp, bottom = 6.dp))
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 137
```kotlin
        LazyColumn(state = listState, modifier = Modifier.weight(1f), contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 3.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 138
```kotlin
            items(visibleGroups, key = { group -> group.first().phone + group.first().waybill }) { group ->
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 139
```kotlin
                if (group.size > 1) GroupedOrderBlock(group, selectedWaybill, onSelectOrder, onDelivered, onCall, onZalo, onSms, onOpenCustomer, onNavigateOrder) else {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 140
```kotlin
                    val order = group.first()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 141
```kotlin
                CompactOrderCard(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 142
```kotlin
                    order = order,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 143
```kotlin
                    selected = order.waybill == selectedWaybill,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 144
```kotlin
                    onSelectOrder = { onSelectOrder(order) },
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 145
```kotlin
                    onDelivered = onDelivered,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 146
```kotlin
                    onCall = onCall,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 147
```kotlin
                    onZalo = onZalo,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 148
```kotlin
                    onSms = onSms,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 149
```kotlin
                    onOpenCustomer = onOpenCustomer,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 150
```kotlin
                    onNavigateOrder = onNavigateOrder,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 151
```kotlin
                    onExpand = { title, value -> expandedDetail = ExpandedDetail(title, value) },
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 152
```kotlin
                    )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 153
```kotlin
                }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 154
```kotlin
            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 155
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 156
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 157
```kotlin
    expandedDetail?.let { detail ->
```
**Giải thích:** Xử lý giá trị nullable an toàn; khối chỉ chạy khi giá trị tồn tại.

### Dòng 158
```kotlin
        AlertDialog(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 159
```kotlin
            onDismissRequest = { expandedDetail = null },
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 160
```kotlin
            title = { Text(detail.title) },
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 161
```kotlin
            text = { Text(detail.value) },
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 162
```kotlin
            confirmButton = {},
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 163
```kotlin
        )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 164
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 165
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 166
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 167
```kotlin
@Composable
```
**Giải thích:** Đánh dấu hàm là Jetpack Compose UI; Compose có thể gọi và tái dựng hàm này.

### Dòng 168
```kotlin
private fun StatusToggle(label: String, selected: Boolean, tint: Color, modifier: Modifier, onClick: () -> Unit) {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 169
```kotlin
    Text(label, color = if (selected) Color.White else tint, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = modifier.background(if (selected) tint else tint.copy(alpha = 0.14f), RoundedCornerShape(8.dp)).clickable(onClick = onClick).padding(vertical = 5.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 170
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 171
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 172
```kotlin
@Composable
```
**Giải thích:** Đánh dấu hàm là Jetpack Compose UI; Compose có thể gọi và tái dựng hàm này.

### Dòng 173
```kotlin
fun ManualOrderEntryDialog(onDismiss: () -> Unit, onSave: (DeliveryOrder) -> Unit) {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 174
```kotlin
    var waybill by remember { mutableStateOf("") }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 175
```kotlin
    var customer by remember { mutableStateOf("") }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 176
```kotlin
    var phone by remember { mutableStateOf("") }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 177
```kotlin
    var address by remember { mutableStateOf("") }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 178
```kotlin
    var product by remember { mutableStateOf("") }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 179
```kotlin
    var cod by remember { mutableStateOf("") }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 180
```kotlin
    var service by remember { mutableStateOf("") }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 181
```kotlin
    AlertDialog(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 182
```kotlin
        onDismissRequest = onDismiss,
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 183
```kotlin
        title = { Text("THÊM MÃ VẬN ĐƠN") },
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 184
```kotlin
        text = {
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 185
```kotlin
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 186
```kotlin
                OutlinedTextField(value = waybill, onValueChange = { waybill = it }, label = { Text("Mã vận đơn *") }, singleLine = true)
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 187
```kotlin
                OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("SĐT khách") }, singleLine = true)
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 188
```kotlin
                OutlinedTextField(value = customer, onValueChange = { customer = it }, label = { Text("Tên khách hàng") }, singleLine = true)
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 189
```kotlin
                OutlinedTextField(value = address, onValueChange = { address = it }, label = { Text("Địa chỉ") })
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 190
```kotlin
                OutlinedTextField(value = product, onValueChange = { product = it }, label = { Text("Hàng hóa") })
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 191
```kotlin
                OutlinedTextField(value = cod, onValueChange = { cod = it.filter { character -> character.isDigit() } }, label = { Text("COD") }, singleLine = true)
```
**Giải thích:** Lọc dữ liệu theo điều kiện; chỉ giữ phần tử thỏa điều kiện.

### Dòng 192
```kotlin
                OutlinedTextField(value = service, onValueChange = { service = it }, label = { Text("Dịch vụ") }, singleLine = true)
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 193
```kotlin
                Text("Nếu SĐT đã có tọa độ lưu trong Khách hàng, đơn được gán số cuối tuyến. Nếu chưa có, đơn được đưa lên đầu để bổ sung vị trí.", color = Color(0xFF68727C), fontSize = 11.sp)
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 194
```kotlin
            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 195
```kotlin
        },
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 196
```kotlin
        confirmButton = {
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 197
```kotlin
            Button(enabled = waybill.isNotBlank(), onClick = {
```
**Giải thích:** Điều kiện UI: quyết định nút/điều khiển có được phép thao tác hay không.

### Dòng 198
```kotlin
                onSave(
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 199
```kotlin
                    DeliveryOrder(
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 200
```kotlin
                        waybill = waybill,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 201
```kotlin
                        customer = customer,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 202
```kotlin
                        phone = phone,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 203
```kotlin
                        address = address,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 204
```kotlin
                        product = product,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 205
```kotlin
                        cod = cod.toLongOrNull() ?: 0L,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 206
```kotlin
                        service = service,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 207
```kotlin
                    ),
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 208
```kotlin
                )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 209
```kotlin
            }) { Text("Thêm đơn") }
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 210
```kotlin
        },
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 211
```kotlin
        dismissButton = { androidx.compose.material3.OutlinedButton(onClick = onDismiss) { Text("Hủy") } },
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 212
```kotlin
    )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 213
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 214
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 215
```kotlin
@Composable
```
**Giải thích:** Đánh dấu hàm là Jetpack Compose UI; Compose có thể gọi và tái dựng hàm này.

### Dòng 216
```kotlin
private fun GroupedOrderBlock(
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 217
```kotlin
    group: List<DeliveryOrder>, selectedWaybill: String?, onSelectOrder: (DeliveryOrder) -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 218
```kotlin
    onDelivered: (DeliveryOrder) -> Unit, onCall: (DeliveryOrder) -> Unit, onZalo: (DeliveryOrder) -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 219
```kotlin
    onSms: (DeliveryOrder) -> Unit, onOpenCustomer: (DeliveryOrder) -> Unit, onNavigateOrder: (DeliveryOrder) -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 220
```kotlin
) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 221
```kotlin
    val first = group.first()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 222
```kotlin
    Column(Modifier.fillMaxWidth().background(Color(0xFFEAF5F2), RoundedCornerShape(12.dp)).padding(6.dp)) {
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 223
```kotlin
        Text("SĐT ${first.phone} · ${group.size} MVĐ · Tổng COD ${group.sumOf { it.cod }.formatVnd()}", color = DetailNavy, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp, modifier = Modifier.padding(6.dp))
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 224
```kotlin
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 225
```kotlin
            ActionTile("Zalo", Icons.Filled.Message, Color(0xFF086AD8)) { onZalo(first) }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 226
```kotlin
            ActionTile("SMS", Icons.Filled.Sms, DetailNavy) { onSms(first) }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 227
```kotlin
            ActionTile("Gọi", Icons.Filled.Call, DetailNavy) { onCall(first) }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 228
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 229
```kotlin
        group.forEach { order -> CompactOrderCard(order, order.waybill == selectedWaybill, { onSelectOrder(order) }, onDelivered, {}, {}, {}, onOpenCustomer, onNavigateOrder, { _, _ -> }, showUtilities = false) }
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 230
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 231
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 232
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 233
```kotlin
@Composable
```
**Giải thích:** Đánh dấu hàm là Jetpack Compose UI; Compose có thể gọi và tái dựng hàm này.

### Dòng 234
```kotlin
private fun CompactOrderCard(
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 235
```kotlin
    order: DeliveryOrder,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 236
```kotlin
    selected: Boolean,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 237
```kotlin
    onSelectOrder: () -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 238
```kotlin
    onDelivered: (DeliveryOrder) -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 239
```kotlin
    onCall: (DeliveryOrder) -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 240
```kotlin
    onZalo: (DeliveryOrder) -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 241
```kotlin
    onSms: (DeliveryOrder) -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 242
```kotlin
    onOpenCustomer: (DeliveryOrder) -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 243
```kotlin
    onNavigateOrder: (DeliveryOrder) -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 244
```kotlin
    onExpand: (String, String) -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 245
```kotlin
    showUtilities: Boolean = true,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 246
```kotlin
) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 247
```kotlin
    val outcome = order.deliveryOutcome()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 248
```kotlin
    val active = outcome == DeliveryOutcome.ACTIVE || outcome == DeliveryOutcome.PICKUP_AT_WAREHOUSE
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 249
```kotlin
    Column(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 250
```kotlin
        modifier = Modifier
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 251
```kotlin
            .fillMaxWidth()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 252
```kotlin
            .background(orderBlockColor(outcome), RoundedCornerShape(12.dp))
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 253
```kotlin
            .then(if (selected) Modifier.border(2.dp, DetailNavy, RoundedCornerShape(12.dp)) else Modifier)
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 254
```kotlin
            .clickable(onClick = onSelectOrder),
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 255
```kotlin
    ) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 256
```kotlin
        Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 11.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 257
```kotlin
            if (order.sequence > 0) Text(order.sequence.toString(), color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.background(DetailNavy, RoundedCornerShape(8.dp)).clickable(onClick = { onNavigateOrder(order) }).padding(horizontal = 9.dp, vertical = 7.dp)) else Spacer(Modifier.width(39.dp))
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 258
```kotlin
            Spacer(Modifier.width(8.dp))
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 259
```kotlin
            Row(modifier = Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 260
```kotlin
                Text(order.waybill, color = orderWaybillColor(outcome), fontWeight = FontWeight.ExtraBold, fontSize = 17.sp, maxLines = 1, modifier = Modifier.weight(1f, fill = false))
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 261
```kotlin
                Text(order.detailStatusLabel(), color = orderWaybillColor(outcome), fontWeight = FontWeight.ExtraBold, fontSize = 12.sp, maxLines = 1)
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 262
```kotlin
            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 263
```kotlin
            Spacer(Modifier.width(8.dp))
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 264
```kotlin
            Text(order.cod.formatVnd(), color = DetailGreen, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 265
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 266
```kotlin
        DividerLine()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 267
```kotlin
        DetailRow(Icons.Filled.Person, "${order.customer} · ${order.phone}", onClick = { onOpenCustomer(order) })
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 268
```kotlin
        DividerLine()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 269
```kotlin
        DetailRow(Icons.Filled.Search, order.address, onClick = { onExpand("Địa chỉ", order.address) })
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 270
```kotlin
        DividerLine()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 271
```kotlin
        DetailRow(Icons.Filled.Wallet, order.product, onClick = { onExpand("Hàng hóa", order.product) })
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 272
```kotlin
        DividerLine()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 273
```kotlin
        DetailRow(Icons.Filled.Wallet, order.service)
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 274
```kotlin
        DividerLine()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 275
```kotlin
        Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 5.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 276
```kotlin
            ActionTile("Đã giao", Icons.Filled.CheckCircle, DetailGreen, enabled = active) { onDelivered(order) }
```
**Giải thích:** Điều kiện UI: quyết định nút/điều khiển có được phép thao tác hay không.

### Dòng 277
```kotlin
            if (!active) ActionTile("Đã xử lý", Icons.Filled.CheckCircle, Color(0xFF8A9299), enabled = false) {}
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 278
```kotlin
            if (showUtilities) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 279
```kotlin
                ActionTile("Zalo", Icons.Filled.Message, Color(0xFF086AD8)) { onZalo(order) }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 280
```kotlin
                ActionTile("SMS", Icons.Filled.Sms, DetailNavy) { onSms(order) }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 281
```kotlin
                ActionTile("Gọi", Icons.Filled.Call, DetailNavy) { onCall(order) }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 282
```kotlin
            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 283
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 284
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 285
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 286
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 287
```kotlin
private fun orderBlockColor(outcome: DeliveryOutcome): Color = when (outcome) {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 288
```kotlin
    DeliveryOutcome.DELIVERED -> Color(0xFFE8F6EC)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 289
```kotlin
    DeliveryOutcome.TEMPORARY_FAILURE -> Color(0xFFFFF0DE)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 290
```kotlin
    DeliveryOutcome.TERMINAL_FAILURE -> Color(0xFFFCE8E8)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 291
```kotlin
    DeliveryOutcome.PICKUP_AT_WAREHOUSE -> Color(0xFFF2ECFA)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 292
```kotlin
    DeliveryOutcome.ACTIVE -> AppSurface
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 293
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 294
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 295
```kotlin
private fun orderWaybillColor(outcome: DeliveryOutcome): Color = when (outcome) {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 296
```kotlin
    DeliveryOutcome.DELIVERED -> DetailGreen
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 297
```kotlin
    DeliveryOutcome.TEMPORARY_FAILURE -> Color(0xFFE17E18)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 298
```kotlin
    DeliveryOutcome.TERMINAL_FAILURE -> DetailRed
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 299
```kotlin
    DeliveryOutcome.PICKUP_AT_WAREHOUSE -> Color(0xFF6B47A1)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 300
```kotlin
    DeliveryOutcome.ACTIVE -> DetailNavy
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 301
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 302
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 303
```kotlin
@Composable private fun DividerLine() = Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0xFFE7EAEE)))
```
**Giải thích:** Đánh dấu hàm là Jetpack Compose UI; Compose có thể gọi và tái dựng hàm này.

### Dòng 304
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 305
```kotlin
@Composable
```
**Giải thích:** Đánh dấu hàm là Jetpack Compose UI; Compose có thể gọi và tái dựng hàm này.

### Dòng 306
```kotlin
private fun DetailRow(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String, onClick: (() -> Unit)? = null) {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 307
```kotlin
    Row(modifier = Modifier.fillMaxWidth().then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier).padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 308
```kotlin
        Icon(icon, null, tint = Color(0xFF85909A), modifier = Modifier.size(18.dp))
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 309
```kotlin
        Spacer(Modifier.width(12.dp))
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 310
```kotlin
        Text(text, color = Color(0xFF3E454C), fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 311
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 312
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 313
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 314
```kotlin
@Composable
```
**Giải thích:** Đánh dấu hàm là Jetpack Compose UI; Compose có thể gọi và tái dựng hàm này.

### Dòng 315
```kotlin
private fun ActionTile(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, tint: Color, enabled: Boolean = true, onClick: () -> Unit) {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 316
```kotlin
    Column(modifier = Modifier.width(44.dp).then(if (enabled) Modifier.clickable(onClick = onClick) else Modifier).padding(vertical = 2.dp), horizontalAlignment = Alignment.CenterHorizontally) {
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 317
```kotlin
        Icon(icon, null, tint = if (enabled) tint else Color(0xFFB8BDC2), modifier = Modifier.size(21.dp))
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 318
```kotlin
        Text(label, color = if (enabled) tint else Color(0xFF8A9299), fontSize = 8.sp, fontWeight = FontWeight.Bold, maxLines = 1)
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 319
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 320
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

