# Phân tích từng dòng — `com/example/delivery/ui/CashAuditScreen.kt`

> Tài liệu đọc/debug: mã gốc theo từng dòng + giải thích. Không dùng trực tiếp để compile.

### Dòng 1
```kotlin
package com.example.delivery.ui
```
**Giải thích:** Khai báo package, xác định namespace của file.

### Dòng 2
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 3
```kotlin
import android.content.Context
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 4
```kotlin
import androidx.compose.foundation.ExperimentalFoundationApi
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 5
```kotlin
import androidx.compose.foundation.background
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 6
```kotlin
import androidx.compose.foundation.layout.Arrangement
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 7
```kotlin
import androidx.compose.foundation.layout.Column
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 8
```kotlin
import androidx.compose.foundation.layout.Row
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 9
```kotlin
import androidx.compose.foundation.layout.Spacer
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 10
```kotlin
import androidx.compose.foundation.layout.fillMaxSize
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 11
```kotlin
import androidx.compose.foundation.layout.fillMaxWidth
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 12
```kotlin
import androidx.compose.foundation.layout.height
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 13
```kotlin
import androidx.compose.foundation.layout.imePadding
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 14
```kotlin
import androidx.compose.foundation.layout.padding
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 15
```kotlin
import androidx.compose.foundation.layout.size
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 16
```kotlin
import androidx.compose.foundation.layout.statusBarsPadding
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 17
```kotlin
import androidx.compose.foundation.layout.width
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 18
```kotlin
import androidx.compose.foundation.rememberScrollState
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 19
```kotlin
import androidx.compose.foundation.relocation.BringIntoViewRequester
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 20
```kotlin
import androidx.compose.foundation.relocation.bringIntoViewRequester
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 21
```kotlin
import androidx.compose.foundation.shape.CircleShape
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 22
```kotlin
import androidx.compose.foundation.shape.RoundedCornerShape
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 23
```kotlin
import androidx.compose.foundation.verticalScroll
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 24
```kotlin
import androidx.compose.material.icons.Icons
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 25
```kotlin
import androidx.compose.material.icons.filled.Add
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 26
```kotlin
import androidx.compose.material.icons.filled.ArrowBack
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 27
```kotlin
import androidx.compose.material.icons.filled.Remove
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 28
```kotlin
import androidx.compose.material3.Button
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 29
```kotlin
import androidx.compose.material3.ButtonDefaults
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 30
```kotlin
import androidx.compose.material3.Icon
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 31
```kotlin
import androidx.compose.material3.IconButton
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 32
```kotlin
import androidx.compose.material3.OutlinedButton
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 33
```kotlin
import androidx.compose.material3.OutlinedTextField
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 34
```kotlin
import androidx.compose.material3.Text
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 35
```kotlin
import androidx.compose.runtime.Composable
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 36
```kotlin
import androidx.compose.runtime.LaunchedEffect
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 37
```kotlin
import androidx.compose.runtime.getValue
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 38
```kotlin
import androidx.compose.runtime.mutableStateOf
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 39
```kotlin
import androidx.compose.runtime.remember
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 40
```kotlin
import androidx.compose.runtime.setValue
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 41
```kotlin
import androidx.compose.ui.Alignment
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 42
```kotlin
import androidx.compose.ui.ExperimentalComposeUiApi
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 43
```kotlin
import androidx.compose.ui.Modifier
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 44
```kotlin
import androidx.compose.ui.focus.FocusManager
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 45
```kotlin
import androidx.compose.ui.focus.FocusRequester
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 46
```kotlin
import androidx.compose.ui.focus.focusProperties
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 47
```kotlin
import androidx.compose.ui.focus.onFocusChanged
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 48
```kotlin
import androidx.compose.ui.graphics.Color
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 49
```kotlin
import androidx.compose.ui.input.key.Key
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 50
```kotlin
import androidx.compose.ui.input.key.KeyEventType
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 51
```kotlin
import androidx.compose.ui.input.key.key
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 52
```kotlin
import androidx.compose.ui.input.key.onPreviewKeyEvent
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 53
```kotlin
import androidx.compose.ui.input.key.type
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 54
```kotlin
import androidx.compose.ui.platform.LocalFocusManager
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 55
```kotlin
import androidx.compose.ui.platform.LocalContext
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 56
```kotlin
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 57
```kotlin
import androidx.compose.ui.platform.SoftwareKeyboardController
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 58
```kotlin
import androidx.compose.ui.text.TextRange
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 59
```kotlin
import androidx.compose.ui.text.font.FontWeight
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 60
```kotlin
import androidx.compose.ui.text.input.ImeAction
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 61
```kotlin
import androidx.compose.ui.text.input.KeyboardType
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 62
```kotlin
import androidx.compose.ui.text.input.TextFieldValue
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 63
```kotlin
import androidx.compose.ui.unit.dp
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 64
```kotlin
import androidx.compose.ui.unit.sp
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 65
```kotlin
import androidx.compose.foundation.text.KeyboardActions
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 66
```kotlin
import androidx.compose.foundation.text.KeyboardOptions
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 67
```kotlin
import com.example.delivery.cash.CashAuditCalculator
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 68
```kotlin
import com.example.delivery.cash.CashAuditState
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 69
```kotlin
import com.example.delivery.cash.CashAuditStatus
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 70
```kotlin
import com.example.delivery.cash.CashAuditStore
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 71
```kotlin
import kotlin.math.abs
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 72
```kotlin
import kotlinx.coroutines.delay
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 73
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 74
```kotlin
@Composable
```
**Giải thích:** Đánh dấu hàm là Jetpack Compose UI; Compose có thể gọi và tái dựng hàm này.

### Dòng 75
```kotlin
fun CashAuditScreen(onClose: () -> Unit) {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 76
```kotlin
    val context = LocalContext.current
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 77
```kotlin
    val focusManager = LocalFocusManager.current
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 78
```kotlin
    val keyboardController = LocalSoftwareKeyboardController.current
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 79
```kotlin
    val restoredState = remember(context) { CashAuditStore.load(context) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 80
```kotlin
    var counts by remember(context) { mutableStateOf(restoredState.counts) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 81
```kotlin
    var bankInput by remember(context) { mutableStateOf(moneyTextFieldValue(restoredState.bankInput)) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 82
```kotlin
    var feeInput by remember(context) { mutableStateOf(moneyTextFieldValue(restoredState.feeInput)) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 83
```kotlin
    var codInput by remember(context) { mutableStateOf(moneyTextFieldValue(restoredState.codInput)) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 84
```kotlin
    fun saveState(
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 85
```kotlin
        nextCounts: Map<Long, Int> = counts,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 86
```kotlin
        nextBank: String = bankInput.text,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 87
```kotlin
        nextFee: String = feeInput.text,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 88
```kotlin
        nextCod: String = codInput.text,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 89
```kotlin
    ) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 90
```kotlin
        CashAuditStore.save(context, CashAuditState(nextCounts, nextBank, nextFee, nextCod))
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 91
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 92
```kotlin
    val result = CashAuditCalculator.calculate(
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 93
```kotlin
        counts = counts,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 94
```kotlin
        bank = CashAuditCalculator.parseAmount(bankInput.text),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 95
```kotlin
        fee = CashAuditCalculator.parseAmount(feeInput.text),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 96
```kotlin
        cod = CashAuditCalculator.parseAmount(codInput.text),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 97
```kotlin
    )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 98
```kotlin
    val resultStyle = when (result.status) {
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 99
```kotlin
        CashAuditStatus.SURPLUS -> ResultStyle(Color(0xFFE6F5EA), Color(0xFF167B38), "DƯ")
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 100
```kotlin
        CashAuditStatus.DEFICIT -> ResultStyle(Color(0xFFFFE9E7), Color(0xFFC23D35), "THIẾU")
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 101
```kotlin
        CashAuditStatus.BALANCED -> ResultStyle(Color(0xFFE8F2FF), Color(0xFF1E73BE), "ĐÃ KHỚP")
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 102
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 103
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 104
```kotlin
    Column(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 105
```kotlin
        Modifier
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 106
```kotlin
            .fillMaxSize()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 107
```kotlin
            .background(AppBackground)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 108
```kotlin
            .statusBarsPadding()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 109
```kotlin
            .imePadding()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 110
```kotlin
            .verticalScroll(rememberScrollState())
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 111
```kotlin
            .padding(bottom = 18.dp),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 112
```kotlin
    ) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 113
```kotlin
        Row(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 114
```kotlin
            Modifier.fillMaxWidth().padding(start = 10.dp, top = 8.dp, end = 14.dp, bottom = 8.dp),
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 115
```kotlin
            verticalAlignment = Alignment.CenterVertically,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 116
```kotlin
        ) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 117
```kotlin
            IconButton(onClick = onClose) { Icon(Icons.Filled.ArrowBack, "Quay lại Cài đặt", tint = Color(0xFF12385F)) }
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 118
```kotlin
            Text("BẢNG KÊ TIỀN", modifier = Modifier.weight(1f), color = Color(0xFF12385F), fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 119
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 120
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 121
```kotlin
        Column(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 122
```kotlin
            Modifier.fillMaxWidth().padding(horizontal = 12.dp).background(resultStyle.background, RoundedCornerShape(18.dp)).padding(16.dp),
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 123
```kotlin
        ) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 124
```kotlin
            Text("KẾT QUẢ BẢNG TÍNH", color = resultStyle.foreground, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 125
```kotlin
            Text(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 126
```kotlin
                text = "${resultStyle.label} ${CashAuditCalculator.formatAmount(abs(result.difference))}đ",
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 127
```kotlin
                color = resultStyle.foreground,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 128
```kotlin
                fontSize = 27.sp,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 129
```kotlin
                fontWeight = FontWeight.ExtraBold,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 130
```kotlin
                modifier = Modifier.padding(top = 4.dp),
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 131
```kotlin
            )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 132
```kotlin
            Text("(Tiền mặt + Bank) − (Cước + COD)", color = resultStyle.foreground.copy(alpha = 0.78f), fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 133
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 134
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 135
```kotlin
        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 136
```kotlin
            Text("ĐẾM TIỀN MẶT", modifier = Modifier.weight(1f), color = Color(0xFFE57B22), fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 137
```kotlin
            OutlinedButton(onClick = {
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 138
```kotlin
                counts = CashAuditCalculator.denominations.associateWith { 0 }
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 139
```kotlin
                bankInput = moneyTextFieldValue("")
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 140
```kotlin
                feeInput = moneyTextFieldValue("")
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 141
```kotlin
                codInput = moneyTextFieldValue("")
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 142
```kotlin
                CashAuditStore.reset(context)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 143
```kotlin
                focusManager.clearFocus()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 144
```kotlin
            }, modifier = Modifier.height(36.dp)) { Text("Reset 0", fontSize = 11.sp) }
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 145
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 146
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 147
```kotlin
        Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp).background(AppSurface, RoundedCornerShape(18.dp)).padding(12.dp)) {
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 148
```kotlin
            CashAuditCalculator.denominations.forEach { denomination ->
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 149
```kotlin
                CashDenominationRow(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 150
```kotlin
                    denomination = denomination,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 151
```kotlin
                    count = counts[denomination] ?: 0,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 152
```kotlin
                    focusManager = focusManager,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 153
```kotlin
                    keyboardController = keyboardController,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 154
```kotlin
                    onCountChange = { count ->
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 155
```kotlin
                        val nextCounts = counts + (denomination to count.coerceIn(0, 999))
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 156
```kotlin
                        counts = nextCounts
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 157
```kotlin
                        saveState(nextCounts = nextCounts)
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 158
```kotlin
                    },
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 159
```kotlin
                )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 160
```kotlin
            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 161
```kotlin
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 162
```kotlin
                Text("TỔNG TIỀN MẶT", modifier = Modifier.weight(1f), color = Color(0xFF12385F), fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 163
```kotlin
                Text("${CashAuditCalculator.formatAmount(result.cashTotal)}đ", color = Color(0xFF12385F), fontWeight = FontWeight.ExtraBold, fontSize = 21.sp)
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 164
```kotlin
            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 165
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 166
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 167
```kotlin
        Text("ĐỐI SOÁT", modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp), color = Color(0xFFE57B22), fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 168
```kotlin
        Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp).background(AppSurface, RoundedCornerShape(18.dp)).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 169
```kotlin
            MoneyInputRow("Bank", bankInput, { value -> bankInput = value; saveState(nextBank = value.text) }, focusManager, keyboardController)
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 170
```kotlin
            MoneyInputRow("Cước", feeInput, { value -> feeInput = value; saveState(nextFee = value.text) }, focusManager, keyboardController)
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 171
```kotlin
            MoneyInputRow("COD", codInput, { value -> codInput = value; saveState(nextCod = value.text) }, focusManager, keyboardController)
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 172
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 173
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 174
```kotlin
        Button(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 175
```kotlin
            onClick = onClose,
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 176
```kotlin
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 16.dp).height(50.dp),
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 177
```kotlin
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E73BE)),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 178
```kotlin
            shape = RoundedCornerShape(15.dp),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 179
```kotlin
        ) { Text("Đóng bảng kê", fontWeight = FontWeight.ExtraBold) }
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 180
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 181
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 182
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 183
```kotlin
private data class ResultStyle(val background: Color, val foreground: Color, val label: String)
```
**Giải thích:** Khai báo lớp; gom dữ liệu hoặc hành vi liên quan vào một đơn vị.

### Dòng 184
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 185
```kotlin
@Composable
```
**Giải thích:** Đánh dấu hàm là Jetpack Compose UI; Compose có thể gọi và tái dựng hàm này.

### Dòng 186
```kotlin
@OptIn(ExperimentalComposeUiApi::class)
```
**Giải thích:** Annotation/metadata áp dụng cho khai báo hoặc hàm ngay sau đó.

### Dòng 187
```kotlin
private fun CashDenominationRow(
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 188
```kotlin
    denomination: Long,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 189
```kotlin
    count: Int,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 190
```kotlin
    focusManager: FocusManager,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 191
```kotlin
    keyboardController: SoftwareKeyboardController?,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 192
```kotlin
    onCountChange: (Int) -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 193
```kotlin
) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 194
```kotlin
    Row(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 195
```kotlin
        Modifier.fillMaxWidth().padding(vertical = 5.dp),
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 196
```kotlin
        verticalAlignment = Alignment.CenterVertically,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 197
```kotlin
        horizontalArrangement = Arrangement.spacedBy(7.dp),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 198
```kotlin
    ) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 199
```kotlin
        Text("${CashAuditCalculator.formatAmount(denomination)}đ", modifier = Modifier.weight(1.38f), color = Color(0xFF12385F), fontWeight = FontWeight.Bold, fontSize = 12.sp)
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 200
```kotlin
        IconButton(onClick = { onCountChange((count - 1).coerceAtLeast(0)) }, modifier = Modifier.size(38.dp).background(Color(0xFFF2F6F9), CircleShape)) { Icon(Icons.Filled.Remove, "Giảm số lượng", tint = Color(0xFF1E73BE)) }
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 201
```kotlin
        OutlinedTextField(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 202
```kotlin
            value = count.toString(),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 203
```kotlin
            onValueChange = { onCountChange(it.filter(Char::isDigit).toIntOrNull() ?: 0) },
```
**Giải thích:** Lọc dữ liệu theo điều kiện; chỉ giữ phần tử thỏa điều kiện.

### Dòng 204
```kotlin
            singleLine = true,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 205
```kotlin
            modifier = Modifier
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 206
```kotlin
                .width(58.dp)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 207
```kotlin
                .height(52.dp)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 208
```kotlin
                .focusProperties {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 209
```kotlin
                    next = FocusRequester.Cancel
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 210
```kotlin
                    previous = FocusRequester.Cancel
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 211
```kotlin
                }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 212
```kotlin
                .onPreviewKeyEvent { event ->
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 213
```kotlin
                    if (event.type == KeyEventType.KeyDown && event.key == Key.Enter) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 214
```kotlin
                        focusManager.clearFocus(force = true)
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 215
```kotlin
                        true
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 216
```kotlin
                    } else {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 217
```kotlin
                        false
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 218
```kotlin
                    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 219
```kotlin
                },
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 220
```kotlin
            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF12385F), textAlign = androidx.compose.ui.text.style.TextAlign.Center),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 221
```kotlin
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Done),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 222
```kotlin
            keyboardActions = KeyboardActions(
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 223
```kotlin
                onDone = { finishCashAuditInput(focusManager, keyboardController) },
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 224
```kotlin
                onNext = { finishCashAuditInput(focusManager, keyboardController) },
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 225
```kotlin
            ),
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 226
```kotlin
        )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 227
```kotlin
        IconButton(onClick = { onCountChange(count + 1) }, modifier = Modifier.size(38.dp).background(Color(0xFF1E73BE), CircleShape)) { Icon(Icons.Filled.Add, "Tăng số lượng", tint = Color.White) }
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 228
```kotlin
        Text("${CashAuditCalculator.formatAmount(denomination * count)}đ", modifier = Modifier.weight(1.23f), color = Color(0xFF12385F), fontWeight = FontWeight.ExtraBold, fontSize = 12.sp, textAlign = androidx.compose.ui.text.style.TextAlign.End)
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 229
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 230
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 231
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 232
```kotlin
@Composable
```
**Giải thích:** Đánh dấu hàm là Jetpack Compose UI; Compose có thể gọi và tái dựng hàm này.

### Dòng 233
```kotlin
@OptIn(ExperimentalFoundationApi::class, ExperimentalComposeUiApi::class)
```
**Giải thích:** Annotation/metadata áp dụng cho khai báo hoặc hàm ngay sau đó.

### Dòng 234
```kotlin
private fun MoneyInputRow(
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 235
```kotlin
    label: String,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 236
```kotlin
    value: TextFieldValue,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 237
```kotlin
    onValueChange: (TextFieldValue) -> Unit,
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 238
```kotlin
    focusManager: FocusManager,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 239
```kotlin
    keyboardController: SoftwareKeyboardController?,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 240
```kotlin
) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 241
```kotlin
    val requester = remember { BringIntoViewRequester() }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 242
```kotlin
    var focused by remember { mutableStateOf(false) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 243
```kotlin
    LaunchedEffect(focused) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 244
```kotlin
        if (focused) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 245
```kotlin
            delay(220)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 246
```kotlin
            requester.bringIntoView()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 247
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 248
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 249
```kotlin
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 250
```kotlin
        Text(label, modifier = Modifier.width(78.dp), color = Color(0xFF12385F), fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 251
```kotlin
        OutlinedTextField(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 252
```kotlin
            value = value,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 253
```kotlin
            onValueChange = { incoming ->
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 254
```kotlin
                val formatted = incoming.text.groupedMoneyInput()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 255
```kotlin
                onValueChange(
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 256
```kotlin
                    TextFieldValue(
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 257
```kotlin
                        text = formatted,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 258
```kotlin
                        selection = TextRange(
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 259
```kotlin
                            groupedMoneyCursorPosition(
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 260
```kotlin
                                rawText = incoming.text,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 261
```kotlin
                                selectionEnd = incoming.selection.end,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 262
```kotlin
                                formattedText = formatted,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 263
```kotlin
                            ),
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 264
```kotlin
                        ),
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 265
```kotlin
                    ),
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 266
```kotlin
                )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 267
```kotlin
            },
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 268
```kotlin
            placeholder = { Text("0", fontSize = 13.sp) },
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 269
```kotlin
            suffix = { Text("đ", fontSize = 12.sp) },
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 270
```kotlin
            singleLine = true,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 271
```kotlin
            modifier = Modifier
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 272
```kotlin
                .weight(1f)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 273
```kotlin
                .height(54.dp)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 274
```kotlin
                .bringIntoViewRequester(requester)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 275
```kotlin
                .onFocusChanged { focused = it.isFocused }
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 276
```kotlin
                .focusProperties {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 277
```kotlin
                    next = FocusRequester.Cancel
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 278
```kotlin
                    previous = FocusRequester.Cancel
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 279
```kotlin
                }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 280
```kotlin
                .onPreviewKeyEvent { event ->
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 281
```kotlin
                    if (event.type == KeyEventType.KeyDown && event.key == Key.Enter) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 282
```kotlin
                        focusManager.clearFocus(force = true)
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 283
```kotlin
                        true
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 284
```kotlin
                    } else {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 285
```kotlin
                        false
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 286
```kotlin
                    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 287
```kotlin
                },
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 288
```kotlin
            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF12385F), textAlign = androidx.compose.ui.text.style.TextAlign.End),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 289
```kotlin
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Done),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 290
```kotlin
            keyboardActions = KeyboardActions(
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 291
```kotlin
                onDone = { finishCashAuditInput(focusManager, keyboardController) },
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 292
```kotlin
                onNext = { finishCashAuditInput(focusManager, keyboardController) },
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 293
```kotlin
            ),
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 294
```kotlin
        )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 295
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 296
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 297
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 298
```kotlin
private fun finishCashAuditInput(
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 299
```kotlin
    focusManager: FocusManager,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 300
```kotlin
    keyboardController: SoftwareKeyboardController?,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 301
```kotlin
) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 302
```kotlin
    keyboardController?.hide()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 303
```kotlin
    focusManager.clearFocus(force = true)
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 304
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 305
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 306
```kotlin
private fun moneyTextFieldValue(value: String) = TextFieldValue(value, TextRange(value.length))
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 307
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 308
```kotlin
internal fun groupedMoneyCursorPosition(
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 309
```kotlin
    rawText: String,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 310
```kotlin
    selectionEnd: Int,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 311
```kotlin
    formattedText: String,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 312
```kotlin
): Int {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 313
```kotlin
    val digitsBeforeCaret = rawText.take(selectionEnd.coerceIn(0, rawText.length)).count(Char::isDigit)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 314
```kotlin
    if (digitsBeforeCaret == 0) return 0
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 315
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 316
```kotlin
    var digitsVisited = 0
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 317
```kotlin
    formattedText.forEachIndexed { index, character ->
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 318
```kotlin
        if (character.isDigit()) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 319
```kotlin
            digitsVisited += 1
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 320
```kotlin
            if (digitsVisited == digitsBeforeCaret) return index + 1
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 321
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 322
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 323
```kotlin
    return formattedText.length
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 324
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 325
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 326
```kotlin
private fun String.groupedMoneyInput(): String {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 327
```kotlin
    val digits = filter(Char::isDigit).trimStart('0')
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 328
```kotlin
    return if (digits.isBlank()) "" else CashAuditCalculator.formatAmount(digits.toLongOrNull() ?: Long.MAX_VALUE)
```
**Giải thích:** Trả kết quả khỏi hàm hiện tại.

### Dòng 329
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

