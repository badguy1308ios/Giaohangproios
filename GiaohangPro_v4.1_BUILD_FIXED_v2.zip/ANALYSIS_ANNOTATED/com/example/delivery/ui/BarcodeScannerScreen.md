# Phân tích từng dòng — `com/example/delivery/ui/BarcodeScannerScreen.kt`

> Tài liệu đọc/debug: mã gốc theo từng dòng + giải thích. Không dùng trực tiếp để compile.

### Dòng 1
```kotlin
package com.example.delivery.ui
```
**Giải thích:** Khai báo package, xác định namespace của file.

### Dòng 2
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 3
```kotlin
import android.Manifest
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 4
```kotlin
import android.content.Context
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 5
```kotlin
import android.content.pm.PackageManager
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 6
```kotlin
import android.os.Build
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 7
```kotlin
import android.os.VibrationEffect
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 8
```kotlin
import android.os.Vibrator
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 9
```kotlin
import androidx.activity.compose.rememberLauncherForActivityResult
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 10
```kotlin
import androidx.activity.result.contract.ActivityResultContracts
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 11
```kotlin
import androidx.camera.core.Camera
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 12
```kotlin
import androidx.camera.core.CameraSelector
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 13
```kotlin
import androidx.camera.core.ImageAnalysis
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 14
```kotlin
import androidx.camera.core.Preview
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 15
```kotlin
import androidx.camera.lifecycle.ProcessCameraProvider
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 16
```kotlin
import androidx.camera.view.PreviewView
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 17
```kotlin
import androidx.compose.animation.core.LinearEasing
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 18
```kotlin
import androidx.compose.animation.core.RepeatMode
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 19
```kotlin
import androidx.compose.animation.core.animateFloat
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 20
```kotlin
import androidx.compose.animation.core.infiniteRepeatable
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 21
```kotlin
import androidx.compose.animation.core.rememberInfiniteTransition
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 22
```kotlin
import androidx.compose.animation.core.tween
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 23
```kotlin
import androidx.compose.foundation.background
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 24
```kotlin
import androidx.compose.foundation.border
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 25
```kotlin
import androidx.compose.foundation.Canvas
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 26
```kotlin
import androidx.compose.foundation.layout.Box
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 27
```kotlin
import androidx.compose.foundation.layout.fillMaxSize
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 28
```kotlin
import androidx.compose.foundation.layout.fillMaxWidth
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 29
```kotlin
import androidx.compose.foundation.layout.height
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 30
```kotlin
import androidx.compose.foundation.layout.offset
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 31
```kotlin
import androidx.compose.foundation.layout.padding
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 32
```kotlin
import androidx.compose.foundation.layout.width
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 33
```kotlin
import androidx.compose.foundation.shape.RoundedCornerShape
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 34
```kotlin
import androidx.compose.material.icons.Icons
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 35
```kotlin
import androidx.compose.material.icons.filled.Close
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 36
```kotlin
import androidx.compose.material.icons.filled.FlashOn
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 37
```kotlin
import androidx.compose.material3.Icon
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 38
```kotlin
import androidx.compose.material3.IconButton
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 39
```kotlin
import androidx.compose.material3.Text
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 40
```kotlin
import androidx.compose.runtime.Composable
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 41
```kotlin
import androidx.compose.runtime.DisposableEffect
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 42
```kotlin
import androidx.compose.runtime.LaunchedEffect
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 43
```kotlin
import androidx.compose.runtime.getValue
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 44
```kotlin
import androidx.compose.runtime.mutableStateOf
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 45
```kotlin
import androidx.compose.runtime.remember
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 46
```kotlin
import androidx.compose.runtime.setValue
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 47
```kotlin
import androidx.compose.ui.Alignment
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 48
```kotlin
import androidx.compose.ui.Modifier
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 49
```kotlin
import androidx.compose.ui.geometry.Offset
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 50
```kotlin
import androidx.compose.ui.geometry.Size
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 51
```kotlin
import androidx.compose.ui.graphics.Brush
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 52
```kotlin
import androidx.compose.ui.graphics.Color
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 53
```kotlin
import androidx.compose.ui.platform.LocalContext
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 54
```kotlin
import androidx.compose.ui.platform.LocalLifecycleOwner
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 55
```kotlin
import androidx.compose.ui.unit.dp
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 56
```kotlin
import androidx.core.content.ContextCompat
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 57
```kotlin
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 58
```kotlin
import com.google.mlkit.vision.barcode.BarcodeScanning
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 59
```kotlin
import com.google.mlkit.vision.barcode.common.Barcode
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 60
```kotlin
import com.google.mlkit.vision.common.InputImage
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 61
```kotlin
import kotlinx.coroutines.delay
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 62
```kotlin
import java.util.concurrent.Executors
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 63
```kotlin
import java.util.concurrent.atomic.AtomicBoolean
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 64
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 65
```kotlin
internal const val QR_SCAN_HAPTIC_MILLIS = 45L
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 66
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 67
```kotlin
@Suppress("DEPRECATION")
```
**Giải thích:** Annotation/metadata áp dụng cho khai báo hoặc hàm ngay sau đó.

### Dòng 68
```kotlin
internal fun triggerQrScanHaptic(context: Context) {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 69
```kotlin
    val vibrator = context.getSystemService(Vibrator::class.java) ?: return
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 70
```kotlin
    if (!vibrator.hasVibrator()) return
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 71
```kotlin
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 72
```kotlin
        vibrator.vibrate(VibrationEffect.createOneShot(QR_SCAN_HAPTIC_MILLIS, VibrationEffect.DEFAULT_AMPLITUDE))
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 73
```kotlin
    } else {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 74
```kotlin
        vibrator.vibrate(QR_SCAN_HAPTIC_MILLIS)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 75
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 76
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 77
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 78
```kotlin
@Composable
```
**Giải thích:** Đánh dấu hàm là Jetpack Compose UI; Compose có thể gọi và tái dựng hàm này.

### Dòng 79
```kotlin
fun BarcodeScannerScreen(onCodeScanned: (String) -> Unit, onDismiss: () -> Unit) {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 80
```kotlin
    val context = LocalContext.current
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 81
```kotlin
    val lifecycleOwner = LocalLifecycleOwner.current
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 82
```kotlin
    var granted by remember { mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 83
```kotlin
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 84
```kotlin
    var torchEnabled by remember { mutableStateOf(false) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 85
```kotlin
    var boundCamera by remember { mutableStateOf<Camera?>(null) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 86
```kotlin
    var scannedCode by remember { mutableStateOf<String?>(null) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 87
```kotlin
    val accepted = remember { AtomicBoolean(false) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 88
```kotlin
    val executor = remember { Executors.newSingleThreadExecutor() }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 89
```kotlin
    val green = Color(0xFF00E676)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 90
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 91
```kotlin
    LaunchedEffect(Unit) { if (!granted) permission.launch(Manifest.permission.CAMERA) }
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 92
```kotlin
    LaunchedEffect(scannedCode) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 93
```kotlin
        val code = scannedCode ?: return@LaunchedEffect
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 94
```kotlin
        delay(180)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 95
```kotlin
        onCodeScanned(code)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 96
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 97
```kotlin
    DisposableEffect(Unit) { onDispose { executor.shutdown(); boundCamera?.cameraControl?.enableTorch(false) } }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 98
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 99
```kotlin
    Box(Modifier.fillMaxSize().background(Color.Black)) {
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 100
```kotlin
        if (granted) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 101
```kotlin
            androidx.compose.ui.viewinterop.AndroidView(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 102
```kotlin
                modifier = Modifier.fillMaxSize(),
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 103
```kotlin
                factory = { viewContext ->
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 104
```kotlin
                    PreviewView(viewContext).also { previewView ->
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 105
```kotlin
                        val providerFuture = ProcessCameraProvider.getInstance(context)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 106
```kotlin
                        providerFuture.addListener({
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 107
```kotlin
                            val provider = providerFuture.get()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 108
```kotlin
                            val preview = Preview.Builder().build().also { it.surfaceProvider = previewView.surfaceProvider }
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 109
```kotlin
                            val analysis = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 110
```kotlin
                            val scanner = BarcodeScanning.getClient(
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 111
```kotlin
                                BarcodeScannerOptions.Builder().setBarcodeFormats(
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 112
```kotlin
                                    Barcode.FORMAT_QR_CODE,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 113
```kotlin
                                    Barcode.FORMAT_CODE_128,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 114
```kotlin
                                    Barcode.FORMAT_CODE_39,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 115
```kotlin
                                    Barcode.FORMAT_EAN_13,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 116
```kotlin
                                    Barcode.FORMAT_EAN_8,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 117
```kotlin
                                ).build(),
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 118
```kotlin
                            )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 119
```kotlin
                            analysis.setAnalyzer(executor) { imageProxy ->
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 120
```kotlin
                                val mediaImage = imageProxy.image
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 121
```kotlin
                                if (mediaImage == null) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 122
```kotlin
                                    imageProxy.close()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 123
```kotlin
                                } else {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 124
```kotlin
                                    scanner.process(InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees))
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 125
```kotlin
                                        .addOnSuccessListener { values ->
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 126
```kotlin
                                            val code = values.firstOrNull { !it.rawValue.isNullOrBlank() }?.rawValue
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 127
```kotlin
                                            if (code != null && accepted.compareAndSet(false, true)) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 128
```kotlin
                                                ContextCompat.getMainExecutor(context).execute {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 129
```kotlin
                                                    triggerQrScanHaptic(context)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 130
```kotlin
                                                    scannedCode = code
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 131
```kotlin
                                                }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 132
```kotlin
                                            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 133
```kotlin
                                        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 134
```kotlin
                                        .addOnCompleteListener { imageProxy.close() }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 135
```kotlin
                                }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 136
```kotlin
                            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 137
```kotlin
                            provider.unbindAll()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 138
```kotlin
                            boundCamera = provider.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 139
```kotlin
                        }, ContextCompat.getMainExecutor(context))
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 140
```kotlin
                    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 141
```kotlin
                },
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 142
```kotlin
            )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 143
```kotlin
            ScannerOverlay(green, scannedCode != null)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 144
```kotlin
            IconButton(modifier = Modifier.align(Alignment.TopStart).padding(16.dp), onClick = onDismiss) { Icon(Icons.Filled.Close, "Đóng quét mã", tint = Color.White) }
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 145
```kotlin
            IconButton(modifier = Modifier.align(Alignment.TopEnd).padding(16.dp), onClick = { torchEnabled = !torchEnabled; boundCamera?.cameraControl?.enableTorch(torchEnabled) }) { Icon(Icons.Filled.FlashOn, "Đèn flash", tint = if (torchEnabled) green else Color.White) }
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 146
```kotlin
            Text("QUÉT MÃ QR", color = Color.White, modifier = Modifier.align(Alignment.TopCenter).padding(top = 22.dp))
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 147
```kotlin
            Text(if (scannedCode == null) "Đưa QR hoặc mã vạch vào khung để quét" else "Đã nhận diện mã", color = Color.White, modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 36.dp))
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 148
```kotlin
        } else {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 149
```kotlin
            Text("Cần quyền Camera để quét mã", color = Color.White, modifier = Modifier.align(Alignment.Center))
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 150
```kotlin
            IconButton(modifier = Modifier.align(Alignment.TopStart).padding(16.dp), onClick = onDismiss) { Icon(Icons.Filled.Close, "Đóng", tint = Color.White) }
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 151
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 152
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 153
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 154
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 155
```kotlin
@Composable
```
**Giải thích:** Đánh dấu hàm là Jetpack Compose UI; Compose có thể gọi và tái dựng hàm này.

### Dòng 156
```kotlin
private fun ScannerOverlay(color: Color, isSuccess: Boolean) {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 157
```kotlin
    val transition = rememberInfiniteTransition(label = "scanner")
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 158
```kotlin
    val vertical by transition.animateFloat(0f, 1f, infiniteRepeatable(tween(1750, easing = LinearEasing), RepeatMode.Reverse), label = "vertical")
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 159
```kotlin
    val accent = if (isSuccess) Color(0xFF69F0AE) else color
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 160
```kotlin
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 161
```kotlin
        Canvas(Modifier.fillMaxSize()) {
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 162
```kotlin
            val frameWidth = 296.dp.toPx()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 163
```kotlin
            val frameHeight = 220.dp.toPx()
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 164
```kotlin
            val left = (size.width - frameWidth) / 2f
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 165
```kotlin
            val top = (size.height - frameHeight) / 2f
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 166
```kotlin
            val shade = Color.Black.copy(alpha = 0.46f)
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 167
```kotlin
            drawRect(shade, size = Size(size.width, top))
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 168
```kotlin
            drawRect(shade, topLeft = Offset(0f, top + frameHeight), size = Size(size.width, size.height - top - frameHeight))
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 169
```kotlin
            drawRect(shade, topLeft = Offset(0f, top), size = Size(left, frameHeight))
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 170
```kotlin
            drawRect(shade, topLeft = Offset(left + frameWidth, top), size = Size(size.width - left - frameWidth, frameHeight))
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 171
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 172
```kotlin
        Box(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 173
```kotlin
            Modifier
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 174
```kotlin
                .width(296.dp)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 175
```kotlin
                .height(220.dp)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 176
```kotlin
                .border(if (isSuccess) 2.dp else 1.dp, if (isSuccess) accent else Color.White.copy(alpha = 0.92f), RoundedCornerShape(16.dp)),
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 177
```kotlin
        ) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 178
```kotlin
            Box(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 179
```kotlin
                Modifier
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 180
```kotlin
                    .fillMaxWidth()
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 181
```kotlin
                    .height(9.dp)
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 182
```kotlin
                    .offset(y = (202f * vertical).dp)
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 183
```kotlin
                    .background(
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 184
```kotlin
                        Brush.horizontalGradient(listOf(Color.Transparent, accent.copy(alpha = 0.2f), accent, accent.copy(alpha = 0.2f), Color.Transparent)),
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 185
```kotlin
                        RoundedCornerShape(12.dp),
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 186
```kotlin
                    ),
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 187
```kotlin
            )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 188
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 189
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 190
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

