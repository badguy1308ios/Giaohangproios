# Phân tích từng dòng — `com/example/delivery/ui/DeliveryRouteScreen.kt`

> Tài liệu đọc/debug: mã gốc theo từng dòng + giải thích. Không dùng trực tiếp để compile.

### Dòng 1
```kotlin
package com.example.delivery.ui
```
**Giải thích:** Khai báo package, xác định namespace của file.

### Dòng 2
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 3
```kotlin
import androidx.compose.foundation.background
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 4
```kotlin
import androidx.compose.foundation.clickable
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 5
```kotlin
import androidx.compose.foundation.layout.Arrangement
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 6
```kotlin
import androidx.compose.foundation.layout.Column
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 7
```kotlin
import androidx.compose.foundation.layout.Row
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 8
```kotlin
import androidx.compose.foundation.layout.fillMaxSize
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 9
```kotlin
import androidx.compose.foundation.layout.fillMaxWidth
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 10
```kotlin
import androidx.compose.foundation.layout.padding
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 11
```kotlin
import androidx.compose.foundation.lazy.LazyColumn
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 12
```kotlin
import androidx.compose.foundation.lazy.itemsIndexed
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 13
```kotlin
import androidx.compose.material.icons.Icons
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 14
```kotlin
import androidx.compose.material.icons.filled.ArrowBack
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 15
```kotlin
import androidx.compose.material.icons.filled.Delete
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 16
```kotlin
import androidx.compose.material.icons.filled.Edit
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 17
```kotlin
import androidx.compose.material3.AlertDialog
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 18
```kotlin
import androidx.compose.material3.Button
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 19
```kotlin
import androidx.compose.material3.Icon
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 20
```kotlin
import androidx.compose.material3.IconButton
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 21
```kotlin
import androidx.compose.material3.OutlinedButton
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 22
```kotlin
import androidx.compose.material3.OutlinedTextField
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 23
```kotlin
import androidx.compose.material3.Text
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 24
```kotlin
import androidx.compose.runtime.Composable
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 25
```kotlin
import androidx.compose.runtime.getValue
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 26
```kotlin
import androidx.compose.runtime.mutableStateOf
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 27
```kotlin
import androidx.compose.runtime.remember
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 28
```kotlin
import androidx.compose.runtime.setValue
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 29
```kotlin
import androidx.compose.ui.Alignment
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 30
```kotlin
import androidx.compose.ui.Modifier
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 31
```kotlin
import androidx.compose.ui.graphics.Color
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 32
```kotlin
import androidx.compose.ui.text.font.FontWeight
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 33
```kotlin
import androidx.compose.ui.unit.dp
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 34
```kotlin
import androidx.compose.ui.unit.sp
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 35
```kotlin
import com.example.delivery.navigation.DeliveryZone
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 36
```kotlin
import com.example.delivery.navigation.GeoPoint
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 37
```kotlin
import java.util.UUID
```
**Giải thích:** Import lớp/hàm bên ngoài để file sử dụng được.

### Dòng 38
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 39
```kotlin
enum class RouteCreationMode { NEW_ROUTE, UPDATE_ROUTE }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 40
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 41
```kotlin
@Composable
```
**Giải thích:** Đánh dấu hàm là Jetpack Compose UI; Compose có thể gọi và tái dựng hàm này.

### Dòng 42
```kotlin
internal fun DeliveryRouteScreen(
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 43
```kotlin
    zones: List<DeliveryZone>,
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 44
```kotlin
    onZonesChanged: (List<DeliveryZone>) -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 45
```kotlin
    onCreateRoute: (RouteCreationMode) -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 46
```kotlin
    onDeleteRoute: () -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 47
```kotlin
    onClose: () -> Unit,
```
**Giải thích:** Gọi hàm/khởi tạo; kiểm tra tham số và callback nếu hành vi không đúng.

### Dòng 48
```kotlin
) {
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 49
```kotlin
    var editorOpen by remember { mutableStateOf(false) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 50
```kotlin
    var editingIndex by remember { mutableStateOf<Int?>(null) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 51
```kotlin
    var confirmAction by remember { mutableStateOf<String?>(null) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 52
```kotlin
    var createChoiceOpen by remember { mutableStateOf(false) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 53
```kotlin
    Column(Modifier.fillMaxSize().background(AppBackground)) {
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 54
```kotlin
        Row(Modifier.fillMaxWidth().padding(start = 12.dp, top = 8.dp, end = 12.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 55
```kotlin
            IconButton(onClick = onClose) { Icon(Icons.Filled.ArrowBack, "Quay lại", tint = Color(0xFF12385F)) }
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 56
```kotlin
            Text("TUYẾN GIAO HÀNG", color = Color(0xFF12385F), fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 57
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 58
```kotlin
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 59
```kotlin
            Button(onClick = { createChoiceOpen = true }, modifier = Modifier.weight(1f)) { Text("Tạo tuyến") }
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 60
```kotlin
            OutlinedButton(onClick = { confirmAction = "Xóa" }, modifier = Modifier.weight(1f)) { Text("Xóa tuyến") }
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 61
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 62
```kotlin
        Text("Danh sách Zone (${zones.size}) — chạm tên Zone để đổi ưu tiên bằng nút lên/xuống.", color = Color(0xFF59636D), fontSize = 11.sp, modifier = Modifier.padding(14.dp, 10.dp, 14.dp, 5.dp))
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 63
```kotlin
        Button(onClick = { editingIndex = null; editorOpen = true }, modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 5.dp)) { Text("Tạo zone") }
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 64
```kotlin
        LazyColumn(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp)) {
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 65
```kotlin
            itemsIndexed(zones, key = { _, zone -> zone.id }) { index, zone ->
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 66
```kotlin
                Row(Modifier.fillMaxWidth().background(AppSurface, androidx.compose.foundation.shape.RoundedCornerShape(12.dp)).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 67
```kotlin
                    Column(Modifier.weight(1f).clickable { editingIndex = index; editorOpen = true }) {
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 68
```kotlin
                        Text("${index + 1}. ${zone.name}", color = Color(0xFF12385F), fontWeight = FontWeight.Bold)
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 69
```kotlin
                        Text(zone.points.joinToString("  •  ") { "%.5f, %.5f".format(it.latitude, it.longitude) }, color = Color(0xFF59636D), fontSize = 10.sp)
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 70
```kotlin
                    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 71
```kotlin
                    IconButton(enabled = index > 0, onClick = { val copy = zones.toMutableList(); copy[index] = copy[index - 1].also { copy[index - 1] = copy[index] }; onZonesChanged(copy) }) { Text("↑") }
```
**Giải thích:** Điều kiện UI: quyết định nút/điều khiển có được phép thao tác hay không.

### Dòng 72
```kotlin
                    IconButton(enabled = index < zones.lastIndex, onClick = { val copy = zones.toMutableList(); copy[index] = copy[index + 1].also { copy[index + 1] = copy[index] }; onZonesChanged(copy) }) { Text("↓") }
```
**Giải thích:** Điều kiện UI: quyết định nút/điều khiển có được phép thao tác hay không.

### Dòng 73
```kotlin
                    IconButton(onClick = { editingIndex = index; editorOpen = true }) { Icon(Icons.Filled.Edit, "Sửa", tint = Color(0xFF1E73BE)) }
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 74
```kotlin
                    IconButton(onClick = { onZonesChanged(zones.filterIndexed { i, _ -> i != index }) }) { Icon(Icons.Filled.Delete, "Xóa", tint = Color(0xFFC23D35)) }
```
**Giải thích:** Lọc dữ liệu theo điều kiện; chỉ giữ phần tử thỏa điều kiện.

### Dòng 75
```kotlin
                }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 76
```kotlin
            }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 77
```kotlin
        }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 78
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 79
```kotlin
    if (createChoiceOpen) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 80
```kotlin
        AlertDialog(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 81
```kotlin
            onDismissRequest = { createChoiceOpen = false },
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 82
```kotlin
            title = { Text("Chọn cách tạo tuyến") },
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 83
```kotlin
            text = { Text("Tuyến mới — ưu tiên cao nhất: đánh STT toàn bộ MVĐ đủ điều kiện.\n\nCập nhật tuyến — ưu tiên thứ hai: đánh lại STT các MVĐ thuộc SĐT mới được nạp tọa độ.") },
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 84
```kotlin
            confirmButton = {
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 85
```kotlin
                Button(onClick = { onCreateRoute(RouteCreationMode.NEW_ROUTE); createChoiceOpen = false }) { Text("Tuyến mới") }
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 86
```kotlin
            },
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 87
```kotlin
            dismissButton = {
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 88
```kotlin
                OutlinedButton(onClick = { onCreateRoute(RouteCreationMode.UPDATE_ROUTE); createChoiceOpen = false }) { Text("Cập nhật tuyến") }
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 89
```kotlin
            },
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 90
```kotlin
        )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 91
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 92
```kotlin
    confirmAction?.let { action ->
```
**Giải thích:** Xử lý giá trị nullable an toàn; khối chỉ chạy khi giá trị tồn tại.

### Dòng 93
```kotlin
        AlertDialog(onDismissRequest = { confirmAction = null }, title = { Text("Xác nhận") }, text = { Text("Bạn có chắc chắn muốn xóa Tuyến giao không?") }, confirmButton = { Button(onClick = { onDeleteRoute(); confirmAction = null }) { Text("Có") } }, dismissButton = { OutlinedButton(onClick = { confirmAction = null }) { Text("Không") } })
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 94
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 95
```kotlin
    if (editorOpen) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 96
```kotlin
        ZoneEditorDialog(initial = editingIndex?.let { zones[it] }, onDismiss = { editorOpen = false }, onSave = { zone ->
```
**Giải thích:** Xử lý giá trị nullable an toàn; khối chỉ chạy khi giá trị tồn tại.

### Dòng 97
```kotlin
            val copy = zones.toMutableList(); val index = editingIndex
```
**Giải thích:** Khai báo biến; val không gán lại, var có thể thay đổi trong phạm vi cho phép.

### Dòng 98
```kotlin
            if (index == null) copy += zone else copy[index] = zone
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 99
```kotlin
            onZonesChanged(copy); editorOpen = false
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 100
```kotlin
        })
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 101
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 102
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 103
```kotlin

```
**Giải thích:** Dòng trống, dùng để tách khối mã cho dễ đọc.

### Dòng 104
```kotlin
@Composable
```
**Giải thích:** Đánh dấu hàm là Jetpack Compose UI; Compose có thể gọi và tái dựng hàm này.

### Dòng 105
```kotlin
private fun ZoneEditorDialog(initial: DeliveryZone?, onDismiss: () -> Unit, onSave: (DeliveryZone) -> Unit) {
```
**Giải thích:** Khai báo hàm; nhận dữ liệu đầu vào và thực hiện một nhiệm vụ cụ thể.

### Dòng 106
```kotlin
    var name by remember(initial?.id) { mutableStateOf(initial?.name.orEmpty()) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 107
```kotlin
    var points by remember(initial?.id) { mutableStateOf(initial?.points ?: emptyList()) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 108
```kotlin
    var pointPickerOpen by remember { mutableStateOf(false) }
```
**Giải thích:** State Compose; lưu trạng thái UI để khi thay đổi Compose tái dựng phần liên quan.

### Dòng 109
```kotlin
    if (pointPickerOpen) {
```
**Giải thích:** Điều kiện: chỉ chạy khối kế tiếp khi biểu thức đúng.

### Dòng 110
```kotlin
        ZoneMultiVertexPickerDialog(
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 111
```kotlin
            initialPoints = points.map { CustomerPickerPosition(it.latitude, it.longitude) },
```
**Giải thích:** Biến đổi từng phần tử của danh sách sang giá trị mới.

### Dòng 112
```kotlin
            onDismiss = { pointPickerOpen = false },
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 113
```kotlin
            onConfirm = { selected ->
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 114
```kotlin
                points = selected.map { point -> GeoPoint(point.latitude, point.longitude) }
```
**Giải thích:** Biến đổi từng phần tử của danh sách sang giá trị mới.

### Dòng 115
```kotlin
                pointPickerOpen = false
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 116
```kotlin
            },
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 117
```kotlin
        )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 118
```kotlin
    }
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 119
```kotlin
    AlertDialog(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 120
```kotlin
        onDismissRequest = onDismiss,
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 121
```kotlin
        title = { Text(if (initial == null) "Tạo Zone mới" else "Sửa Zone") },
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 122
```kotlin
        text = { Column {
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 123
```kotlin
            OutlinedTextField(
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 124
```kotlin
                value = name,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 125
```kotlin
                onValueChange = { name = it },
```
**Giải thích:** Callback sự kiện UI; chạy khi người dùng thao tác hoặc dialog thay đổi trạng thái.

### Dòng 126
```kotlin
                label = { Text("Tên Zone") },
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 127
```kotlin
                placeholder = { Text("Ví dụ: Khu trung tâm") },
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 128
```kotlin
                singleLine = true,
```
**Giải thích:** Gán/khởi tạo giá trị; kiểm tra biểu thức bên phải khi dữ liệu sai.

### Dòng 129
```kotlin
            )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 130
```kotlin
            Text("Đã chọn ${points.size} đỉnh; cần ít nhất 3 đỉnh để lưu Zone.", color = Color(0xFF59636D), modifier = Modifier.padding(top = 8.dp))
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 131
```kotlin
            Button(onClick = { pointPickerOpen = true }) { Text(if (points.isEmpty()) "Mở bản đồ chọn đỉnh" else "Sửa các đỉnh trên bản đồ") }
```
**Giải thích:** Điều kiện UI/logic; quyết định có hiển thị hoặc thực hiện một nhánh hay không.

### Dòng 132
```kotlin
            points.forEachIndexed { i, p -> Text("Đỉnh ${i + 1}: %.6f, %.6f".format(p.latitude, p.longitude), modifier = Modifier.padding(vertical = 3.dp), fontSize = 11.sp) }
```
**Giải thích:** Cấu hình bố cục/ngoại hình/tương tác của thành phần Compose.

### Dòng 133
```kotlin
        }},
```
**Giải thích:** Câu lệnh/biểu thức Kotlin; kiểm tra dữ liệu đầu vào, đầu ra và phạm vi khi cần sửa lỗi.

### Dòng 134
```kotlin
        confirmButton = { Button(enabled = points.size >= 3 && name.isNotBlank(), onClick = { onSave(DeliveryZone(initial?.id ?: UUID.randomUUID().toString(), name.trim(), points)) }) { Text("Xác nhận") } },
```
**Giải thích:** Điều kiện UI: quyết định nút/điều khiển có được phép thao tác hay không.

### Dòng 135
```kotlin
        dismissButton = { OutlinedButton(onClick = onDismiss) { Text("Hủy") } },
```
**Giải thích:** Lệnh tạo/cấu hình UI Compose; đây là điểm nên kiểm tra khi sửa giao diện.

### Dòng 136
```kotlin
    )
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

### Dòng 137
```kotlin
}
```
**Giải thích:** Dấu cấu trúc, mở/đóng khối mã của hàm, điều kiện hoặc UI.

