# Giao Hàng Goong Alpha — cập nhật luồng Đã giao MVD

## Thay đổi

Khi xác nhận **Đã giao MVD**, đơn hàng được cập nhật sang trạng thái đã giao, xóa `sequence` và `sequenceLabel`, sau đó chuyển xuống cuối danh sách dữ liệu. Vì bản đồ chỉ nhận các đơn `isMapVisible`, đơn vừa giao không còn STT hoặc marker trên tab Bản đồ.

Sau khi xác nhận, ô tìm kiếm của tab Chi tiết được làm rỗng và focus chuyển tới đơn đang giao có STT kế tiếp; nếu không còn đơn có STT lớn hơn thì focus về đơn đang giao đầu tiên còn lại.

## Artifact

- APK release: `app/build/outputs/apk/release/app-release.apk`
- APK debug: `app/build/outputs/apk/debug/app-debug.apk`
- Bản source bàn giao bao gồm cấu hình signing, keystore xuất bản và `local.properties` chứa các key Goong theo source được người dùng tải lên.

## Kiểm tra

- `assembleDebug`: thành công.
- `assembleRelease`: thành công.
- Bộ unit test có sẵn của source: 88 test, 6 test fail ở các kiểm thử route/import có sẵn và không liên quan trực tiếp tới thay đổi MVD. Không dùng lỗi test này để đánh dấu APK build thất bại.
