# Tách UI / Logic / Chú thích source

## File UI
- `ui/DeliveryV2Screen.kt`: màn hình điều phối, state, chuyển tab/màn hình.
- `ui/MapDeliveryComponents.kt`: UI bản đồ + sheet đơn.
- `ui/CustomerComponents.kt`: UI khách hàng.
- `ui/DeliveryCompletionDialog.kt`: dialog xác nhận giao.

## File điều kiện
- `ui/logic/DeliveryConditions.kt`: tìm origin, tính STT, chọn đơn kế tiếp, validate STT.

## Goong
- `navigation/GoongApiConfig.kt`: khu vực cấu hình 2 API Goong.
- `map/GoongMapStyleLoader.kt`: nạp Map Tiles key vào style.
- `navigation/GoongDirectionsRepository.kt`: gọi Directions API.

## Cách sửa nhanh
1. Muốn đổi giao diện bản đồ/list đơn → `MapDeliveryComponents.kt`.
2. Muốn đổi giao diện khách hàng → `CustomerComponents.kt`.
3. Muốn đổi điều kiện tuyến/STT → `ui/logic/DeliveryConditions.kt`.
4. Muốn đổi chuyển màn hình/state → `DeliveryV2Screen.kt`.
5. Muốn kiểm tra Goong → mở `GoongApiConfig.kt` trước.

Các callback `on...` là cầu nối: UI con phát sự kiện, màn hình cha/store xử lý dữ liệu. Không nên đưa thao tác lưu dữ liệu vào composable nếu không cần.
