# Chú thích từng dòng — DeliveryV2 đã tách nhóm

Mỗi dòng code bên dưới có số thứ tự và giải thích chức năng để dễ đối chiếu khi sửa lỗi.

## `DeliveryV2Screen.kt`

1. `package com.example.delivery.ui` — Khai báo package.
2. `` — Dòng trống — phân cách các nhóm.
3. `import android.content.Context` — Nạp class/API cần dùng.
4. `import androidx.compose.foundation.background` — Nạp class/API cần dùng.
5. `import androidx.compose.foundation.layout.*` — Nạp class/API cần dùng.
6. `import androidx.compose.material.icons.Icons` — Nạp class/API cần dùng.
7. `import androidx.compose.material.icons.filled.*` — Nạp class/API cần dùng.
8. `import androidx.compose.material3.Icon` — Nạp class/API cần dùng.
9. `import androidx.compose.material3.IconButton` — Nạp class/API cần dùng.
10. `import androidx.compose.material3.Text` — Nạp class/API cần dùng.
11. `import androidx.compose.runtime.*` — Nạp class/API cần dùng.
12. `import androidx.compose.ui.Alignment` — Nạp class/API cần dùng.
13. `import androidx.compose.ui.Modifier` — Nạp class/API cần dùng.
14. `import androidx.compose.ui.draw.alpha` — Nạp class/API cần dùng.
15. `import androidx.compose.ui.platform.LocalContext` — Nạp class/API cần dùng.
16. `import androidx.compose.ui.text.font.FontWeight` — Nạp class/API cần dùng.
17. `import androidx.compose.ui.unit.dp` — Nạp class/API cần dùng.
18. `import androidx.compose.ui.unit.sp` — Nạp class/API cần dùng.
19. `import com.example.delivery.history.*` — Nạp class/API cần dùng.
20. `import com.example.delivery.model.*` — Nạp class/API cần dùng.
21. `import com.example.delivery.orderio.CoordinateUpdateRequest` — Nạp class/API cần dùng.
22. `import com.example.delivery.ui.logic.*` — Nạp class/API cần dùng.
23. `` — Dòng trống — phân cách các nhóm.
24. `@Composable` — Đánh dấu hàm là Compose UI.
25. `fun DeliveryV2Screen(` — Khai báo hàm/composable của nhóm.
26. `    orders: List<DeliveryOrder>,` — Lệnh Kotlin hỗ trợ xử lý của nhóm hiện tại.
27. `    transferPhotos: Map<String, TransferPhotoState>,` — Lệnh Kotlin hỗ trợ xử lý của nhóm hiện tại.
28. `    transferEvidence: List<TransferEvidence>,` — Lệnh Kotlin hỗ trợ xử lý của nhóm hiện tại.
29. `    customerProfiles: List<CustomerProfile>,` — Lệnh Kotlin hỗ trợ xử lý của nhóm hiện tại.
30. `    onDirectDelivered: (DeliveryOrder) -> Unit,` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
31. `    onSaveTransfer: (DeliveryOrder, PaymentChannel, String, String?, String?) -> Unit,` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
32. `    onCaptureTransferPhoto: (DeliveryOrder, ProofPhotoType) -> Unit,` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
33. `    onCall: (DeliveryOrder) -> Unit,` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
34. `    onZalo: (DeliveryOrder, String) -> Unit,` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
35. `    onSms: (DeliveryOrder, String) -> Unit,` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
36. `    onConfirmTransferPayment: (String) -> Unit,` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
37. `    transferMessage: (DeliveryOrder) -> String,` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
38. `    onRouteSequenceLocked: (Map<String, String>) -> Unit,` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
39. `    onCreateRoute: (RouteCreationMode) -> Unit,` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
40. `    onDeleteRoute: () -> Unit,` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
41. `    onSaveCustomer: (CustomerProfile) -> Unit,` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
42. `    onDeleteCustomer: (CustomerProfile) -> Unit,` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
43. `    onGetCustomerCoordinates: () -> Pair<Double, Double>?,` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
44. `    onExportBackup: () -> Unit,` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
45. `    onImportBackup: () -> Unit,` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
46. `    onImportOrders: () -> Unit,` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
47. `    onExportOrders: () -> Unit,` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
48. `    onExportStt: () -> Unit,` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
49. `    onImportStt: () -> Unit,` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
50. `    onAddManualOrder: (DeliveryOrder) -> Unit,` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
51. `    onDeleteOrder: (String) -> Unit,` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
52. `    onDeleteAllOrders: () -> Unit,` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
53. `    onUpdateCoordinates: (CoordinateUpdateRequest) -> Unit,` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
54. `    onSyncOrdersFromCustomerCoordinates: () -> Unit,` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
55. `    onOpenVtmanExport: () -> Unit,` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
56. `    backupStatus: String?,` — Lệnh Kotlin hỗ trợ xử lý của nhóm hiện tại.
57. `) {` — Mở block Kotlin; các dòng sau thuộc block này.
58. `    // GROUP: STATE — tạo và giữ toàn bộ trạng thái của màn hình.` — Chú thích — mô tả mục đích của code.
59. `    val state = rememberDeliveryV2State(orders)` — Gán giá trị/tạo biến hoặc state trung gian.
60. `    val context = LocalContext.current` — Gán giá trị/tạo biến hoặc state trung gian.
61. `` — Dòng trống — phân cách các nhóm.
62. `    // GROUP: NAVIGATION — nếu đang ở màn hình con thì không vẽ màn hình chính.` — Chú thích — mô tả mục đích của code.
63. `    val childScreenShown = DeliveryV2Navigation(` — Gán giá trị/tạo biến hoặc state trung gian.
64. `        state = state,` — Gán giá trị/tạo biến hoặc state trung gian.
65. `        orders = orders,` — Gán giá trị/tạo biến hoặc state trung gian.
66. `        transferEvidence = transferEvidence,` — Gán giá trị/tạo biến hoặc state trung gian.
67. `        backupStatus = backupStatus,` — Gán giá trị/tạo biến hoặc state trung gian.
68. `        onConfirmTransferPayment = onConfirmTransferPayment,` — Gán giá trị/tạo biến hoặc state trung gian.
69. `        onOpenVtmanExport = onOpenVtmanExport,` — Gán giá trị/tạo biến hoặc state trung gian.
70. `        onCreateRoute = onCreateRoute,` — Gán giá trị/tạo biến hoặc state trung gian.
71. `        onDeleteRoute = onDeleteRoute,` — Gán giá trị/tạo biến hoặc state trung gian.
72. `        onAddManualOrder = onAddManualOrder,` — Gán giá trị/tạo biến hoặc state trung gian.
73. `        onDeleteOrder = onDeleteOrder,` — Gán giá trị/tạo biến hoặc state trung gian.
74. `        onDeleteAllOrders = onDeleteAllOrders,` — Gán giá trị/tạo biến hoặc state trung gian.
75. `        onUpdateCoordinates = onUpdateCoordinates,` — Gán giá trị/tạo biến hoặc state trung gian.
76. `        onSyncOrdersFromCustomerCoordinates = onSyncOrdersFromCustomerCoordinates,` — Gán giá trị/tạo biến hoặc state trung gian.
77. `        onExportBackup = onExportBackup,` — Gán giá trị/tạo biến hoặc state trung gian.
78. `        onImportBackup = onImportBackup,` — Gán giá trị/tạo biến hoặc state trung gian.
79. `        onImportOrders = onImportOrders,` — Gán giá trị/tạo biến hoặc state trung gian.
80. `        onExportOrders = onExportOrders,` — Gán giá trị/tạo biến hoặc state trung gian.
81. `        onExportStt = onExportStt,` — Gán giá trị/tạo biến hoặc state trung gian.
82. `        onImportStt = onImportStt,` — Gán giá trị/tạo biến hoặc state trung gian.
83. `        onRouteSequenceLocked = { updated ->` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
84. `            state.stableRouteSequence = updated` — Gán giá trị/tạo biến hoặc state trung gian.
85. `            onRouteSequenceLocked(updated)` — Gọi hàm/composable hoặc truyền tham số.
86. `        },` — Đóng block Kotlin trước đó.
87. `    )` — Lệnh Kotlin hỗ trợ xử lý của nhóm hiện tại.
88. `    if (childScreenShown) return` — Điều kiện — quyết định nhánh xử lý.
89. `` — Dòng trống — phân cách các nhóm.
90. `    // GROUP: LOGIC — chuẩn hóa thứ tự hiển thị; thuật toán nằm trong DeliveryConditions.kt.` — Chú thích — mô tả mục đích của code.
91. `    LaunchedEffect(state.currentGps, orders, state.stableRouteSequence) {` — Side-effect Compose chạy khi key thay đổi; phù hợp cho đồng bộ dữ liệu hoặc quyền.
92. `        if (state.stableRouteSequence.isEmpty()) {` — Điều kiện — quyết định nhánh xử lý.
93. `            val origin = findRouteOrigin(orders, state.currentGps)` — Gán giá trị/tạo biến hoặc state trung gian.
94. `            if (origin != null) {` — Điều kiện — quyết định nhánh xử lý.
95. `                val initial = buildRouteSequence(orders, origin)` — Gán giá trị/tạo biến hoặc state trung gian.
96. `                state.stableRouteSequence = initial` — Gán giá trị/tạo biến hoặc state trung gian.
97. `                onRouteSequenceLocked(initial)` — Gọi hàm/composable hoặc truyền tham số.
98. `            }` — Đóng block Kotlin trước đó.
99. `        }` — Đóng block Kotlin trước đó.
100. `    }` — Đóng block Kotlin trước đó.
101. `    val displayOrders = orders.withStableRouteLabels(state.previewRouteSequence ?: state.stableRouteSequence)` — Gán giá trị/tạo biến hoặc state trung gian.
102. `` — Dòng trống — phân cách các nhóm.
103. `    // GROUP: MAIN UI — Header + Map + Detail + Customer + Bottom tabs.` — Chú thích — mô tả mục đích của code.
104. `    Column(Modifier.fillMaxSize().background(AppBackground).statusBarsPadding().navigationBarsPadding()) {` — Mở block Kotlin; các dòng sau thuộc block này.
105. `        Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {` — Mở block Kotlin; các dòng sau thuộc block này.
106. `            IconButton(onClick = { state.settingsOpen = true }) {` — Mở block Kotlin; các dòng sau thuộc block này.
107. `                Icon(Icons.Filled.Settings, "Cài đặt", tint = androidx.compose.ui.graphics.Color(0xFF12385F))` — Gán giá trị/tạo biến hoặc state trung gian.
108. `            }` — Đóng block Kotlin trước đó.
109. `            Text("GIAO HÀNG THEO CÁCH CỦA BẠN", modifier = Modifier.weight(1f), color = androidx.compose.ui.graphics.Color(0xFFE57B22), fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)` — Gán giá trị/tạo biến hoặc state trung gian.
110. `        }` — Đóng block Kotlin trước đó.
111. `        Box(Modifier.weight(1f)) {` — Mở block Kotlin; các dòng sau thuộc block này.
112. `            DeliveryV2Map(state, displayOrders, onRouteSequenceLocked)` — Gọi hàm/composable hoặc truyền tham số.
113. `            when (state.tab) {` — Phân nhánh theo trạng thái.
114. `                DeliveryTab.MAP -> Unit` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
115. `                DeliveryTab.DETAIL -> DeliveryV2Detail(` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
116. `                    state = state,` — Gán giá trị/tạo biến hoặc state trung gian.
117. `                    orders = displayOrders,` — Gán giá trị/tạo biến hoặc state trung gian.
118. `                    onCall = onCall,` — Gán giá trị/tạo biến hoặc state trung gian.
119. `                    onZalo = onZalo,` — Gán giá trị/tạo biến hoặc state trung gian.
120. `                    onSms = onSms,` — Gán giá trị/tạo biến hoặc state trung gian.
121. `                    transferMessage = transferMessage,` — Gán giá trị/tạo biến hoặc state trung gian.
122. `                    onDelivered = { state.completingOrder = it },` — Gán giá trị/tạo biến hoặc state trung gian.
123. `                )` — Lệnh Kotlin hỗ trợ xử lý của nhóm hiện tại.
124. `                DeliveryTab.CUSTOMERS -> DeliveryV2Customer(` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
125. `                    state = state,` — Gán giá trị/tạo biến hoặc state trung gian.
126. `                    context = context,` — Gán giá trị/tạo biến hoặc state trung gian.
127. `                    customerProfiles = customerProfiles,` — Gán giá trị/tạo biến hoặc state trung gian.
128. `                    onSaveCustomer = onSaveCustomer,` — Gán giá trị/tạo biến hoặc state trung gian.
129. `                    onDeleteCustomer = onDeleteCustomer,` — Gán giá trị/tạo biến hoặc state trung gian.
130. `                    onGetCustomerCoordinates = onGetCustomerCoordinates,` — Gán giá trị/tạo biến hoặc state trung gian.
131. `                )` — Lệnh Kotlin hỗ trợ xử lý của nhóm hiện tại.
132. `            }` — Đóng block Kotlin trước đó.
133. `            if (state.tab == DeliveryTab.DETAIL) {` — Điều kiện — quyết định nhánh xử lý.
134. `                IconButton(` — Gọi hàm/composable hoặc truyền tham số.
135. `                    onClick = { state.detailScrollTopRequest += 1 },` — Gán giá trị/tạo biến hoặc state trung gian.
136. `                    modifier = Modifier.align(Alignment.BottomStart).padding(start = 22.dp, bottom = 18.dp).size(62.dp)` — Gán giá trị/tạo biến hoặc state trung gian.
137. `                        .background(androidx.compose.ui.graphics.Color(0xFF12385F), androidx.compose.foundation.shape.CircleShape),` — Gọi hàm/composable hoặc truyền tham số.
138. `                ) {` — Mở block Kotlin; các dòng sau thuộc block này.
139. `                    Icon(Icons.Filled.ArrowUpward, contentDescription = "Về đầu danh sách", tint = androidx.compose.ui.graphics.Color.White, modifier = Modifier.size(31.dp))` — Gán giá trị/tạo biến hoặc state trung gian.
140. `                }` — Đóng block Kotlin trước đó.
141. `            }` — Đóng block Kotlin trước đó.
142. `        }` — Đóng block Kotlin trước đó.
143. `        Row(` — Gọi hàm/composable hoặc truyền tham số.
144. `            Modifier.fillMaxWidth().background(AppSurface).padding(horizontal = 10.dp, vertical = 8.dp),` — Gán giá trị/tạo biến hoặc state trung gian.
145. `            horizontalArrangement = Arrangement.spacedBy(7.dp),` — Gán giá trị/tạo biến hoặc state trung gian.
146. `        ) {` — Mở block Kotlin; các dòng sau thuộc block này.
147. `            TabButton("Bản đồ", Icons.Filled.Map, state.tab == DeliveryTab.MAP, Modifier.weight(1f)) { state.tab = DeliveryTab.MAP }` — Gọi hàm/composable hoặc truyền tham số.
148. `            TabButton("Chi tiết", Icons.Filled.ReceiptLong, state.tab == DeliveryTab.DETAIL, Modifier.weight(1f)) { state.tab = DeliveryTab.DETAIL }` — Gọi hàm/composable hoặc truyền tham số.
149. `            TabButton("Khách hàng", Icons.Filled.People, state.tab == DeliveryTab.CUSTOMERS, Modifier.weight(1f)) { state.tab = DeliveryTab.CUSTOMERS }` — Gọi hàm/composable hoặc truyền tham số.
150. `        }` — Đóng block Kotlin trước đó.
151. `    }` — Đóng block Kotlin trước đó.
152. `` — Dòng trống — phân cách các nhóm.
153. `    // GROUP: DIALOG — dialog được tách riêng để không lẫn vào UI chính.` — Chú thích — mô tả mục đích của code.
154. `    DeliveryV2Dialog(state, orders, onDirectDelivered)` — Gọi hàm/composable hoặc truyền tham số.
155. `}` — Đóng block Kotlin trước đó.

## `DeliveryV2State.kt`

1. `package com.example.delivery.ui` — Khai báo package.
2. `` — Dòng trống — phân cách các nhóm.
3. `import androidx.compose.runtime.Composable` — Nạp class/API cần dùng.
4. `import androidx.compose.runtime.getValue` — Nạp class/API cần dùng.
5. `import androidx.compose.runtime.LaunchedEffect` — Nạp class/API cần dùng.
6. `import androidx.compose.runtime.mutableStateOf` — Nạp class/API cần dùng.
7. `import androidx.compose.runtime.remember` — Nạp class/API cần dùng.
8. `import androidx.compose.runtime.saveable.rememberSaveable` — Nạp class/API cần dùng.
9. `import androidx.compose.runtime.setValue` — Nạp class/API cần dùng.
10. `import com.example.delivery.model.DeliveryOrder` — Nạp class/API cần dùng.
11. `import com.example.delivery.navigation.persistedRouteLabels` — Nạp class/API cần dùng.
12. `import com.example.delivery.navigation.DeliveryZone` — Nạp class/API cần dùng.
13. `import com.example.delivery.navigation.GeoPoint` — Nạp class/API cần dùng.
14. `` — Dòng trống — phân cách các nhóm.
15. `/**` — Chú thích — mô tả mục đích của code.
16. ` * GROUP: STATE` — Chú thích — mô tả mục đích của code.
17. ` * Chứa toàn bộ trạng thái màn hình DeliveryV2.` — Chú thích — mô tả mục đích của code.
18. ` * UI chỉ đọc/ghi state này; không đặt thuật toán nghiệp vụ ở đây.` — Chú thích — mô tả mục đích của code.
19. ` */` — Chú thích — mô tả mục đích của code.
20. `internal enum class DeliveryTab { MAP, DETAIL, CUSTOMERS }` — Khai báo kiểu dữ liệu/trạng thái.
21. `` — Dòng trống — phân cách các nhóm.
22. `data class TransferPhotoState(val billPath: String? = null, val dropOffPath: String? = null)` — Gán giá trị/tạo biến hoặc state trung gian.
23. `` — Dòng trống — phân cách các nhóm.
24. `internal class DeliveryV2State {` — Khai báo kiểu dữ liệu/trạng thái.
25. `    var tab by mutableStateOf(DeliveryTab.MAP)` — State Compose; thay đổi sẽ làm UI liên quan cập nhật.
26. `    var selectedNavigationOrder by mutableStateOf<DeliveryOrder?>(null)` — State Compose; thay đổi sẽ làm UI liên quan cập nhật.
27. `    var selectedWaybill by mutableStateOf<String?>(null)` — State Compose; thay đổi sẽ làm UI liên quan cập nhật.
28. `    var detailScrollTopRequest by mutableStateOf(0)` — State Compose; thay đổi sẽ làm UI liên quan cập nhật.
29. `    var detailSearchQuery by mutableStateOf("")` — State Compose; thay đổi sẽ làm UI liên quan cập nhật.
30. `    var scannerOpen by mutableStateOf(false)` — State Compose; thay đổi sẽ làm UI liên quan cập nhật.
31. `    var settingsOpen by mutableStateOf(false)` — State Compose; thay đổi sẽ làm UI liên quan cập nhật.
32. `    var backupOpen by mutableStateOf(false)` — State Compose; thay đổi sẽ làm UI liên quan cập nhật.
33. `    var cashAuditOpen by mutableStateOf(false)` — State Compose; thay đổi sẽ làm UI liên quan cập nhật.
34. `    var transferCheckOpen by mutableStateOf(false)` — State Compose; thay đổi sẽ làm UI liên quan cập nhật.
35. `    var orderManagementOpen by mutableStateOf(false)` — State Compose; thay đổi sẽ làm UI liên quan cập nhật.
36. `    var coordinateUpdateOpen by mutableStateOf(false)` — State Compose; thay đổi sẽ làm UI liên quan cập nhật.
37. `    var routeScreenOpen by mutableStateOf(false)` — State Compose; thay đổi sẽ làm UI liên quan cập nhật.
38. `    var completingOrder by mutableStateOf<DeliveryOrder?>(null)` — State Compose; thay đổi sẽ làm UI liên quan cập nhật.
39. `    var focusPhone by mutableStateOf<String?>(null)` — State Compose; thay đổi sẽ làm UI liên quan cập nhật.
40. `    var currentGps by mutableStateOf<GeoPoint?>(null)` — State Compose; thay đổi sẽ làm UI liên quan cập nhật.
41. `    var currentGpsUpdatedAt by mutableStateOf(0L)` — State Compose; thay đổi sẽ làm UI liên quan cập nhật.
42. `    var stableRouteSequence by mutableStateOf<Map<String, String>>(emptyMap())` — State Compose; thay đổi sẽ làm UI liên quan cập nhật.
43. `    var previewRouteSequence by mutableStateOf<Map<String, String>?>(null)` — State Compose; thay đổi sẽ làm UI liên quan cập nhật.
44. `    var zones by mutableStateOf<List<DeliveryZone>>(emptyList())` — State Compose; thay đổi sẽ làm UI liên quan cập nhật.
45. `    var zonesLoaded by mutableStateOf(false)` — State Compose; thay đổi sẽ làm UI liên quan cập nhật.
46. `    var locationGranted by mutableStateOf(false)` — State Compose; thay đổi sẽ làm UI liên quan cập nhật.
47. `    var lastBackPressedAt by mutableStateOf(0L)` — State Compose; thay đổi sẽ làm UI liên quan cập nhật.
48. `    var routeStateInitialized by mutableStateOf(false)` — State Compose; thay đổi sẽ làm UI liên quan cập nhật.
49. `}` — Đóng block Kotlin trước đó.
50. `` — Dòng trống — phân cách các nhóm.
51. `@Composable` — Đánh dấu hàm là Compose UI.
52. `internal fun rememberDeliveryV2State(orders: List<DeliveryOrder>): DeliveryV2State {` — Khai báo hàm/composable của nhóm.
53. `    val state = remember { DeliveryV2State() }` — Gán giá trị/tạo biến hoặc state trung gian.
54. `` — Dòng trống — phân cách các nhóm.
55. `    // Khôi phục STT đã commit từ dữ liệu đơn hàng; GPS mới không tự đánh lại STT.` — Chú thích — mô tả mục đích của code.
56. `    LaunchedEffect(orders) {` — Side-effect Compose chạy khi key thay đổi; phù hợp cho đồng bộ dữ liệu hoặc quyền.
57. `        if (orders.isEmpty()) {` — Điều kiện — quyết định nhánh xử lý.
58. `            state.stableRouteSequence = emptyMap()` — Gán giá trị/tạo biến hoặc state trung gian.
59. `            state.previewRouteSequence = null` — Gán giá trị/tạo biến hoặc state trung gian.
60. `            state.routeStateInitialized = false` — Gán giá trị/tạo biến hoặc state trung gian.
61. `        } else if (!state.routeStateInitialized) {` — Mở block Kotlin; các dòng sau thuộc block này.
62. `            state.stableRouteSequence = orders.persistedRouteLabels()` — Gán giá trị/tạo biến hoặc state trung gian.
63. `            state.routeStateInitialized = true` — Gán giá trị/tạo biến hoặc state trung gian.
64. `        }` — Đóng block Kotlin trước đó.
65. `    }` — Đóng block Kotlin trước đó.
66. `    return state` — Trả kết quả hoặc kết thúc hàm.
67. `}` — Đóng block Kotlin trước đó.

## `DeliveryV2Navigation.kt`

1. `package com.example.delivery.ui` — Khai báo package.
2. `` — Dòng trống — phân cách các nhóm.
3. `import android.Manifest` — Nạp class/API cần dùng.
4. `import android.app.Activity` — Nạp class/API cần dùng.
5. `import android.content.Context` — Nạp class/API cần dùng.
6. `import android.content.pm.PackageManager` — Nạp class/API cần dùng.
7. `import android.widget.Toast` — Nạp class/API cần dùng.
8. `import androidx.activity.compose.BackHandler` — Nạp class/API cần dùng.
9. `import androidx.activity.compose.rememberLauncherForActivityResult` — Nạp class/API cần dùng.
10. `import androidx.activity.result.contract.ActivityResultContracts` — Nạp class/API cần dùng.
11. `import androidx.compose.runtime.Composable` — Nạp class/API cần dùng.
12. `import androidx.compose.runtime.LaunchedEffect` — Nạp class/API cần dùng.
13. `import androidx.compose.ui.platform.LocalContext` — Nạp class/API cần dùng.
14. `import androidx.core.content.ContextCompat` — Nạp class/API cần dùng.
15. `import com.example.delivery.history.TransferEvidence` — Nạp class/API cần dùng.
16. `import com.example.delivery.model.DeliveryOrder` — Nạp class/API cần dùng.
17. `import com.example.delivery.navigation.DeliveryRouteStore` — Nạp class/API cần dùng.
18. `import com.example.delivery.navigation.GeoPoint` — Nạp class/API cần dùng.
19. `import com.example.delivery.ui.logic.buildRouteSequence` — Nạp class/API cần dùng.
20. `import com.example.delivery.ui.logic.findRouteOrigin` — Nạp class/API cần dùng.
21. `` — Dòng trống — phân cách các nhóm.
22. `/** GROUP: NAVIGATION - Back, màn hình con, quyền vị trí và chuyển modal. */` — Chú thích — mô tả mục đích của code.
23. `@Composable` — Đánh dấu hàm là Compose UI.
24. `internal fun DeliveryV2Navigation(` — Khai báo hàm/composable của nhóm.
25. `    state: DeliveryV2State,` — Lệnh Kotlin hỗ trợ xử lý của nhóm hiện tại.
26. `    orders: List<DeliveryOrder>,` — Lệnh Kotlin hỗ trợ xử lý của nhóm hiện tại.
27. `    transferEvidence: List<TransferEvidence>,` — Lệnh Kotlin hỗ trợ xử lý của nhóm hiện tại.
28. `    backupStatus: String?,` — Lệnh Kotlin hỗ trợ xử lý của nhóm hiện tại.
29. `    onConfirmTransferPayment: (String) -> Unit,` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
30. `    onOpenVtmanExport: () -> Unit,` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
31. `    onCreateRoute: (RouteCreationMode) -> Unit,` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
32. `    onDeleteRoute: () -> Unit,` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
33. `    onAddManualOrder: (DeliveryOrder) -> Unit,` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
34. `    onDeleteOrder: (String) -> Unit,` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
35. `    onDeleteAllOrders: () -> Unit,` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
36. `    onUpdateCoordinates: (com.example.delivery.orderio.CoordinateUpdateRequest) -> Unit,` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
37. `    onSyncOrdersFromCustomerCoordinates: () -> Unit,` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
38. `    onExportBackup: () -> Unit,` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
39. `    onImportBackup: () -> Unit,` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
40. `    onImportOrders: () -> Unit,` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
41. `    onExportOrders: () -> Unit,` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
42. `    onExportStt: () -> Unit,` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
43. `    onImportStt: () -> Unit,` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
44. `    onRouteSequenceLocked: (Map<String, String>) -> Unit,` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
45. `): Boolean {` — Mở block Kotlin; các dòng sau thuộc block này.
46. `    val context = LocalContext.current` — Gán giá trị/tạo biến hoặc state trung gian.
47. `    LaunchedEffect(context) {` — Side-effect Compose chạy khi key thay đổi; phù hợp cho đồng bộ dữ liệu hoặc quyền.
48. `        state.zones = DeliveryRouteStore.loadZones(context)` — Gán giá trị/tạo biến hoặc state trung gian.
49. `        state.zonesLoaded = true` — Gán giá trị/tạo biến hoặc state trung gian.
50. `    }` — Đóng block Kotlin trước đó.
51. `` — Dòng trống — phân cách các nhóm.
52. `    val locationPreferences = androidx.compose.runtime.remember(context) {` — Mở block Kotlin; các dòng sau thuộc block này.
53. `        context.getSharedPreferences("location_permission", Context.MODE_PRIVATE)` — Gọi hàm/composable hoặc truyền tham số.
54. `    }` — Đóng block Kotlin trước đó.
55. `    val locationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { permissions ->` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
56. `        state.locationGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true ||` — Lệnh Kotlin hỗ trợ xử lý của nhóm hiện tại.
57. `            permissions[Manifest.permission.ACCESS_COARSE_LOCATION] == true` — Lệnh Kotlin hỗ trợ xử lý của nhóm hiện tại.
58. `    }` — Đóng block Kotlin trước đó.
59. `` — Dòng trống — phân cách các nhóm.
60. `    LaunchedEffect(Unit) {` — Side-effect Compose chạy khi key thay đổi; phù hợp cho đồng bộ dữ liệu hoặc quyền.
61. `        state.locationGranted = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||` — Gọi hàm/composable hoặc truyền tham số.
62. `            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED` — Gọi hàm/composable hoặc truyền tham số.
63. `        if (!state.locationGranted && !locationPreferences.getBoolean("asked_once", false)) {` — Điều kiện — quyết định nhánh xử lý.
64. `            locationPreferences.edit().putBoolean("asked_once", true).apply()` — Gọi hàm/composable hoặc truyền tham số.
65. `            locationPermission.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))` — Gọi hàm/composable hoặc truyền tham số.
66. `        }` — Đóng block Kotlin trước đó.
67. `    }` — Đóng block Kotlin trước đó.
68. `` — Dòng trống — phân cách các nhóm.
69. `    BackHandler {` — Mở block Kotlin; các dòng sau thuộc block này.
70. `        when {` — Phân nhánh theo trạng thái.
71. `            state.scannerOpen -> state.scannerOpen = false` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
72. `            state.routeScreenOpen -> { state.routeScreenOpen = false; state.settingsOpen = true }` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
73. `            state.coordinateUpdateOpen -> { state.coordinateUpdateOpen = false; state.orderManagementOpen = true }` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
74. `            state.orderManagementOpen -> { state.orderManagementOpen = false; state.settingsOpen = true }` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
75. `            state.backupOpen -> { state.backupOpen = false; state.settingsOpen = true }` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
76. `            state.cashAuditOpen -> { state.cashAuditOpen = false; state.settingsOpen = true }` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
77. `            state.transferCheckOpen -> { state.transferCheckOpen = false; state.settingsOpen = true }` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
78. `            state.settingsOpen -> state.settingsOpen = false` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
79. `            else -> {` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
80. `                val now = System.currentTimeMillis()` — Gán giá trị/tạo biến hoặc state trung gian.
81. `                if (now - state.lastBackPressedAt <= 1_800L) {` — Điều kiện — quyết định nhánh xử lý.
82. `                    (context as? Activity)?.finish()` — Gọi hàm/composable hoặc truyền tham số.
83. `                } else {` — Mở block Kotlin; các dòng sau thuộc block này.
84. `                    state.lastBackPressedAt = now` — Gán giá trị/tạo biến hoặc state trung gian.
85. `                    Toast.makeText(context, "Nhấn Back lần nữa để thoát ứng dụng", Toast.LENGTH_SHORT).show()` — Gọi hàm/composable hoặc truyền tham số.
86. `                }` — Đóng block Kotlin trước đó.
87. `            }` — Đóng block Kotlin trước đó.
88. `        }` — Đóng block Kotlin trước đó.
89. `    }` — Đóng block Kotlin trước đó.
90. `` — Dòng trống — phân cách các nhóm.
91. `    if (state.scannerOpen) {` — Điều kiện — quyết định nhánh xử lý.
92. `        BarcodeScannerScreen(onCodeScanned = { code -> state.detailSearchQuery = code; state.scannerOpen = false; state.tab = DeliveryTab.DETAIL }, onDismiss = { state.scannerOpen = false })` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
93. `        return true` — Trả kết quả hoặc kết thúc hàm.
94. `    }` — Đóng block Kotlin trước đó.
95. `    if (state.settingsOpen) {` — Điều kiện — quyết định nhánh xử lý.
96. `        SettingsScreen(` — Gọi hàm/composable hoặc truyền tham số.
97. `            evidence = transferEvidence,` — Gán giá trị/tạo biến hoặc state trung gian.
98. `            onConfirmPayment = onConfirmTransferPayment,` — Gán giá trị/tạo biến hoặc state trung gian.
99. `            onOpenCashAudit = { state.settingsOpen = false; state.cashAuditOpen = true },` — Gán giá trị/tạo biến hoặc state trung gian.
100. `            onOpenBackup = { state.settingsOpen = false; state.backupOpen = true },` — Gán giá trị/tạo biến hoặc state trung gian.
101. `            onOpenVtmanExport = onOpenVtmanExport,` — Gán giá trị/tạo biến hoặc state trung gian.
102. `            onOpenTransferCheck = { state.settingsOpen = false; state.transferCheckOpen = true },` — Gán giá trị/tạo biến hoặc state trung gian.
103. `            onOpenOrderManagement = { state.settingsOpen = false; state.orderManagementOpen = true },` — Gán giá trị/tạo biến hoặc state trung gian.
104. `            onOpenAnchorPoint = { state.settingsOpen = false; state.routeScreenOpen = true },` — Gán giá trị/tạo biến hoặc state trung gian.
105. `            onClose = { state.settingsOpen = false },` — Gán giá trị/tạo biến hoặc state trung gian.
106. `        )` — Lệnh Kotlin hỗ trợ xử lý của nhóm hiện tại.
107. `        return true` — Trả kết quả hoặc kết thúc hàm.
108. `    }` — Đóng block Kotlin trước đó.
109. `    if (state.routeScreenOpen) {` — Điều kiện — quyết định nhánh xử lý.
110. `        DeliveryRouteScreen(` — Gọi hàm/composable hoặc truyền tham số.
111. `            zones = state.zones,` — Gán giá trị/tạo biến hoặc state trung gian.
112. `            onZonesChanged = { updated -> state.zones = updated; DeliveryRouteStore.saveZones(context, updated) },` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
113. `            onCreateRoute = onCreateRoute,` — Gán giá trị/tạo biến hoặc state trung gian.
114. `            onDeleteRoute = onDeleteRoute,` — Gán giá trị/tạo biến hoặc state trung gian.
115. `            onClose = { state.routeScreenOpen = false; state.settingsOpen = true },` — Gán giá trị/tạo biến hoặc state trung gian.
116. `        )` — Lệnh Kotlin hỗ trợ xử lý của nhóm hiện tại.
117. `        return true` — Trả kết quả hoặc kết thúc hàm.
118. `    }` — Đóng block Kotlin trước đó.
119. `    if (state.orderManagementOpen) {` — Điều kiện — quyết định nhánh xử lý.
120. `        OrderManagementScreen(` — Gọi hàm/composable hoặc truyền tham số.
121. `            status = backupStatus,` — Gán giá trị/tạo biến hoặc state trung gian.
122. `            onAddManualOrder = onAddManualOrder,` — Gán giá trị/tạo biến hoặc state trung gian.
123. `            onDeleteOrder = onDeleteOrder,` — Gán giá trị/tạo biến hoặc state trung gian.
124. `            onDeleteAllOrders = onDeleteAllOrders,` — Gán giá trị/tạo biến hoặc state trung gian.
125. `            onOpenCoordinateUpdate = { state.orderManagementOpen = false; state.coordinateUpdateOpen = true },` — Gán giá trị/tạo biến hoặc state trung gian.
126. `            onConfirmRouteChange = {` — Mở block Kotlin; các dòng sau thuộc block này.
127. `                val origin = findRouteOrigin(orders, state.currentGps)` — Gán giá trị/tạo biến hoặc state trung gian.
128. `                if (origin != null) {` — Điều kiện — quyết định nhánh xử lý.
129. `                    val confirmed = buildRouteSequence(orders, origin)` — Gán giá trị/tạo biến hoặc state trung gian.
130. `                    state.stableRouteSequence = confirmed` — Gán giá trị/tạo biến hoặc state trung gian.
131. `                    onRouteSequenceLocked(confirmed)` — Gọi hàm/composable hoặc truyền tham số.
132. `                    state.selectedNavigationOrder = null` — Gán giá trị/tạo biến hoặc state trung gian.
133. `                    state.coordinateUpdateOpen = false` — Gán giá trị/tạo biến hoặc state trung gian.
134. `                    state.orderManagementOpen = false` — Gán giá trị/tạo biến hoặc state trung gian.
135. `                }` — Đóng block Kotlin trước đó.
136. `            },` — Đóng block Kotlin trước đó.
137. `            onClose = { state.orderManagementOpen = false; state.settingsOpen = true },` — Gán giá trị/tạo biến hoặc state trung gian.
138. `        )` — Lệnh Kotlin hỗ trợ xử lý của nhóm hiện tại.
139. `        return true` — Trả kết quả hoặc kết thúc hàm.
140. `    }` — Đóng block Kotlin trước đó.
141. `    if (state.backupOpen) {` — Điều kiện — quyết định nhánh xử lý.
142. `        BackupDataScreen(onExportBackup, onImportBackup, onImportOrders, onExportOrders, onExportStt, onImportStt, backupStatus) { state.backupOpen = false; state.settingsOpen = true }` — Gán giá trị/tạo biến hoặc state trung gian.
143. `        return true` — Trả kết quả hoặc kết thúc hàm.
144. `    }` — Đóng block Kotlin trước đó.
145. `    if (state.cashAuditOpen) {` — Điều kiện — quyết định nhánh xử lý.
146. `        CashAuditScreen(onClose = { state.cashAuditOpen = false; state.settingsOpen = true })` — Gán giá trị/tạo biến hoặc state trung gian.
147. `        return true` — Trả kết quả hoặc kết thúc hàm.
148. `    }` — Đóng block Kotlin trước đó.
149. `    if (state.transferCheckOpen) {` — Điều kiện — quyết định nhánh xử lý.
150. `        TransferCheckScreen(onClose = { state.transferCheckOpen = false; state.settingsOpen = true })` — Gán giá trị/tạo biến hoặc state trung gian.
151. `        return true` — Trả kết quả hoặc kết thúc hàm.
152. `    }` — Đóng block Kotlin trước đó.
153. `    if (state.coordinateUpdateOpen) {` — Điều kiện — quyết định nhánh xử lý.
154. `        CoordinateUpdateScreen(` — Gọi hàm/composable hoặc truyền tham số.
155. `            status = backupStatus,` — Gán giá trị/tạo biến hoặc state trung gian.
156. `            onSave = onUpdateCoordinates,` — Gán giá trị/tạo biến hoặc state trung gian.
157. `            onConfirmRouteChange = {` — Mở block Kotlin; các dòng sau thuộc block này.
158. `                onSyncOrdersFromCustomerCoordinates()` — Gọi hàm/composable hoặc truyền tham số.
159. `                val origin = findRouteOrigin(orders, state.currentGps)` — Gán giá trị/tạo biến hoặc state trung gian.
160. `                if (origin != null) {` — Điều kiện — quyết định nhánh xử lý.
161. `                    val confirmed = buildRouteSequence(orders, origin)` — Gán giá trị/tạo biến hoặc state trung gian.
162. `                    state.stableRouteSequence = confirmed` — Gán giá trị/tạo biến hoặc state trung gian.
163. `                    onRouteSequenceLocked(confirmed)` — Gọi hàm/composable hoặc truyền tham số.
164. `                    state.selectedNavigationOrder = null` — Gán giá trị/tạo biến hoặc state trung gian.
165. `                    state.coordinateUpdateOpen = false` — Gán giá trị/tạo biến hoặc state trung gian.
166. `                    state.orderManagementOpen = false` — Gán giá trị/tạo biến hoặc state trung gian.
167. `                }` — Đóng block Kotlin trước đó.
168. `            },` — Đóng block Kotlin trước đó.
169. `            onClose = { state.coordinateUpdateOpen = false; state.orderManagementOpen = true },` — Gán giá trị/tạo biến hoặc state trung gian.
170. `        )` — Lệnh Kotlin hỗ trợ xử lý của nhóm hiện tại.
171. `        return true` — Trả kết quả hoặc kết thúc hàm.
172. `    }` — Đóng block Kotlin trước đó.
173. `    return false` — Trả kết quả hoặc kết thúc hàm.
174. `}` — Đóng block Kotlin trước đó.

## `DeliveryV2Map.kt`

1. `package com.example.delivery.ui` — Khai báo package.
2. `` — Dòng trống — phân cách các nhóm.
3. `import androidx.compose.runtime.Composable` — Nạp class/API cần dùng.
4. `import androidx.compose.ui.Modifier` — Nạp class/API cần dùng.
5. `import androidx.compose.ui.draw.alpha` — Nạp class/API cần dùng.
6. `import com.example.delivery.model.DeliveryOrder` — Nạp class/API cần dùng.
7. `import com.example.delivery.navigation.GeoPoint` — Nạp class/API cần dùng.
8. `` — Dòng trống — phân cách các nhóm.
9. `/** GROUP: MAP - Chỉ chịu trách nhiệm hiển thị và tương tác bản đồ. */` — Chú thích — mô tả mục đích của code.
10. `@Composable` — Đánh dấu hàm là Compose UI.
11. `internal fun DeliveryV2Map(` — Khai báo hàm/composable của nhóm.
12. `    state: DeliveryV2State,` — Lệnh Kotlin hỗ trợ xử lý của nhóm hiện tại.
13. `    displayOrders: List<DeliveryOrder>,` — Lệnh Kotlin hỗ trợ xử lý của nhóm hiện tại.
14. `    onRouteSequenceLocked: (Map<String, String>) -> Unit,` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
15. `) {` — Mở block Kotlin; các dòng sau thuộc block này.
16. `    MapDeliveryScreen(` — Gọi hàm/composable hoặc truyền tham số.
17. `        orders = displayOrders,` — Gán giá trị/tạo biến hoặc state trung gian.
18. `        selectedNavigationOrder = state.selectedNavigationOrder,` — Gán giá trị/tạo biến hoặc state trung gian.
19. `        selectedWaybill = state.selectedWaybill,` — Gán giá trị/tạo biến hoặc state trung gian.
20. `        onRouteSequencePreview = { state.previewRouteSequence = it },` — Gán giá trị/tạo biến hoặc state trung gian.
21. `        onRouteSequenceLocked = { updated ->` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
22. `            state.previewRouteSequence = null` — Gán giá trị/tạo biến hoặc state trung gian.
23. `            state.stableRouteSequence = updated` — Gán giá trị/tạo biến hoặc state trung gian.
24. `            onRouteSequenceLocked(updated)` — Gọi hàm/composable hoặc truyền tham số.
25. `        },` — Đóng block Kotlin trước đó.
26. `        onSelectNavigation = { order -> state.selectedNavigationOrder = order; state.selectedWaybill = order.waybill },` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
27. `        onSelectOrder = { order -> state.selectedWaybill = order.waybill; state.selectedNavigationOrder = order },` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
28. `        onReturnToNearest = { state.selectedNavigationOrder = null },` — Gán giá trị/tạo biến hoặc state trung gian.
29. `        onOpenDetail = { order ->` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
30. `            state.selectedWaybill = order.waybill` — Gán giá trị/tạo biến hoặc state trung gian.
31. `            state.selectedNavigationOrder = order` — Gán giá trị/tạo biến hoặc state trung gian.
32. `            state.detailSearchQuery = order.waybill` — Gán giá trị/tạo biến hoặc state trung gian.
33. `            state.tab = DeliveryTab.DETAIL` — Gán giá trị/tạo biến hoặc state trung gian.
34. `        },` — Đóng block Kotlin trước đó.
35. `        locationGranted = state.locationGranted,` — Gán giá trị/tạo biến hoặc state trung gian.
36. `        onLocationChanged = { latitude, longitude ->` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
37. `            state.currentGps = GeoPoint(latitude, longitude)` — Gán giá trị/tạo biến hoặc state trung gian.
38. `            state.currentGpsUpdatedAt = System.currentTimeMillis()` — Gán giá trị/tạo biến hoặc state trung gian.
39. `        },` — Đóng block Kotlin trước đó.
40. `        modifier = Modifier.alpha(if (state.tab == DeliveryTab.MAP) 1f else 0f),` — Gọi hàm/composable hoặc truyền tham số.
41. `    )` — Lệnh Kotlin hỗ trợ xử lý của nhóm hiện tại.
42. `}` — Đóng block Kotlin trước đó.

## `DeliveryV2Detail.kt`

1. `package com.example.delivery.ui` — Khai báo package.
2. `` — Dòng trống — phân cách các nhóm.
3. `import androidx.compose.runtime.Composable` — Nạp class/API cần dùng.
4. `import com.example.delivery.model.DeliveryOrder` — Nạp class/API cần dùng.
5. `` — Dòng trống — phân cách các nhóm.
6. `/** GROUP: DETAIL - Màn hình chi tiết đơn và các callback nghiệp vụ liên quan. */` — Chú thích — mô tả mục đích của code.
7. `@Composable` — Đánh dấu hàm là Compose UI.
8. `internal fun DeliveryV2Detail(` — Khai báo hàm/composable của nhóm.
9. `    state: DeliveryV2State,` — Lệnh Kotlin hỗ trợ xử lý của nhóm hiện tại.
10. `    orders: List<DeliveryOrder>,` — Lệnh Kotlin hỗ trợ xử lý của nhóm hiện tại.
11. `    onCall: (DeliveryOrder) -> Unit,` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
12. `    onZalo: (DeliveryOrder, String) -> Unit,` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
13. `    onSms: (DeliveryOrder, String) -> Unit,` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
14. `    transferMessage: (DeliveryOrder) -> String,` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
15. `    onDelivered: (DeliveryOrder) -> Unit,` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
16. `) {` — Mở block Kotlin; các dòng sau thuộc block này.
17. `    OrderDetailScreen(` — Gọi hàm/composable hoặc truyền tham số.
18. `        orders = orders,` — Gán giá trị/tạo biến hoặc state trung gian.
19. `        searchQuery = state.detailSearchQuery,` — Gán giá trị/tạo biến hoặc state trung gian.
20. `        onSearchChange = { state.detailSearchQuery = it },` — Gán giá trị/tạo biến hoặc state trung gian.
21. `        selectedWaybill = state.selectedWaybill,` — Gán giá trị/tạo biến hoặc state trung gian.
22. `        scrollToTopRequest = state.detailScrollTopRequest,` — Gán giá trị/tạo biến hoặc state trung gian.
23. `        onSelectOrder = { order -> state.selectedWaybill = order.waybill; state.selectedNavigationOrder = order },` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
24. `        onOpenScanner = { state.scannerOpen = true },` — Gán giá trị/tạo biến hoặc state trung gian.
25. `        onDelivered = onDelivered,` — Gán giá trị/tạo biến hoặc state trung gian.
26. `        onCall = onCall,` — Gán giá trị/tạo biến hoặc state trung gian.
27. `        onZalo = { onZalo(it, transferMessage(it)) },` — Gán giá trị/tạo biến hoặc state trung gian.
28. `        onSms = { onSms(it, transferMessage(it)) },` — Gán giá trị/tạo biến hoặc state trung gian.
29. `        onOpenCustomer = { order -> state.selectedWaybill = order.waybill; state.focusPhone = order.phone; state.tab = DeliveryTab.CUSTOMERS },` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
30. `        onNavigateOrder = { order -> state.selectedWaybill = order.waybill; state.selectedNavigationOrder = order; state.tab = DeliveryTab.MAP },` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
31. `    )` — Lệnh Kotlin hỗ trợ xử lý của nhóm hiện tại.
32. `}` — Đóng block Kotlin trước đó.

## `DeliveryV2Customer.kt`

1. `package com.example.delivery.ui` — Khai báo package.
2. `` — Dòng trống — phân cách các nhóm.
3. `import android.content.Context` — Nạp class/API cần dùng.
4. `import androidx.compose.runtime.Composable` — Nạp class/API cần dùng.
5. `import com.example.delivery.customer.CustomerProfile` — Nạp class/API cần dùng.
6. `import com.example.delivery.customer.CustomerProfileStore` — Nạp class/API cần dùng.
7. `import com.example.delivery.customer.matchesSearch` — Nạp class/API cần dùng.
8. `import com.example.delivery.location.RealtimeLocationPolicy` — Nạp class/API cần dùng.
9. `` — Dòng trống — phân cách các nhóm.
10. `/** GROUP: CUSTOMER - Danh sách khách hàng và vị trí GPS dùng khi lấy tọa độ. */` — Chú thích — mô tả mục đích của code.
11. `@Composable` — Đánh dấu hàm là Compose UI.
12. `internal fun DeliveryV2Customer(` — Khai báo hàm/composable của nhóm.
13. `    state: DeliveryV2State,` — Lệnh Kotlin hỗ trợ xử lý của nhóm hiện tại.
14. `    context: Context,` — Lệnh Kotlin hỗ trợ xử lý của nhóm hiện tại.
15. `    customerProfiles: List<CustomerProfile>,` — Lệnh Kotlin hỗ trợ xử lý của nhóm hiện tại.
16. `    onSaveCustomer: (CustomerProfile) -> Unit,` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
17. `    onDeleteCustomer: (CustomerProfile) -> Unit,` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
18. `    onGetCustomerCoordinates: () -> Pair<Double, Double>?,` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
19. `) {` — Mở block Kotlin; các dòng sau thuộc block này.
20. `    CustomerList(` — Gọi hàm/composable hoặc truyền tham số.
21. `        customerProfiles.filterNot { CustomerProfileStore.isDeleted(context, it.id) },` — Gọi hàm/composable hoặc truyền tham số.
22. `        state.focusPhone,` — Lệnh Kotlin hỗ trợ xử lý của nhóm hiện tại.
23. `        onSaveCustomer,` — Lệnh Kotlin hỗ trợ xử lý của nhóm hiện tại.
24. `        onDeleteCustomer,` — Lệnh Kotlin hỗ trợ xử lý của nhóm hiện tại.
25. `    ) {` — Mở block Kotlin; các dòng sau thuộc block này.
26. `        state.currentGps` — Lệnh Kotlin hỗ trợ xử lý của nhóm hiện tại.
27. `            ?.takeIf { RealtimeLocationPolicy.isFreshLastKnown(state.currentGpsUpdatedAt, System.currentTimeMillis()) }` — Gọi hàm/composable hoặc truyền tham số.
28. `            ?.let { gps -> gps.latitude to gps.longitude }` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
29. `            ?: onGetCustomerCoordinates()` — Gọi hàm/composable hoặc truyền tham số.
30. `    }` — Đóng block Kotlin trước đó.
31. `}` — Đóng block Kotlin trước đó.

## `DeliveryV2Dialog.kt`

1. `package com.example.delivery.ui` — Khai báo package.
2. `` — Dòng trống — phân cách các nhóm.
3. `import androidx.compose.runtime.Composable` — Nạp class/API cần dùng.
4. `import com.example.delivery.model.DeliveryOrder` — Nạp class/API cần dùng.
5. `import com.example.delivery.ui.logic.nextOrderAfterCompletion` — Nạp class/API cần dùng.
6. `` — Dòng trống — phân cách các nhóm.
7. `/** GROUP: DIALOG - Chỉ chứa dialog xác nhận hoàn tất đơn. */` — Chú thích — mô tả mục đích của code.
8. `@Composable` — Đánh dấu hàm là Compose UI.
9. `internal fun DeliveryV2Dialog(` — Khai báo hàm/composable của nhóm.
10. `    state: DeliveryV2State,` — Lệnh Kotlin hỗ trợ xử lý của nhóm hiện tại.
11. `    orders: List<DeliveryOrder>,` — Lệnh Kotlin hỗ trợ xử lý của nhóm hiện tại.
12. `    onDirectDelivered: (DeliveryOrder) -> Unit,` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
13. `) {` — Mở block Kotlin; các dòng sau thuộc block này.
14. `    state.completingOrder?.let { order ->` — Lambda/callback — code được gọi khi sự kiện tương ứng xảy ra.
15. `        DeliveryCompletionDialog(` — Gọi hàm/composable hoặc truyền tham số.
16. `            order = order,` — Gán giá trị/tạo biến hoặc state trung gian.
17. `            onDismiss = { state.completingOrder = null },` — Gán giá trị/tạo biến hoặc state trung gian.
18. `            onConfirm = {` — Mở block Kotlin; các dòng sau thuộc block này.
19. `                val nextOrder = nextOrderAfterCompletion(orders, order)` — Gán giá trị/tạo biến hoặc state trung gian.
20. `                onDirectDelivered(order)` — Gọi hàm/composable hoặc truyền tham số.
21. `                state.completingOrder = null` — Gán giá trị/tạo biến hoặc state trung gian.
22. `                state.detailSearchQuery = ""` — Gán giá trị/tạo biến hoặc state trung gian.
23. `                state.selectedWaybill = nextOrder?.waybill` — Gán giá trị/tạo biến hoặc state trung gian.
24. `                state.selectedNavigationOrder = nextOrder` — Gán giá trị/tạo biến hoặc state trung gian.
25. `            },` — Đóng block Kotlin trước đó.
26. `        )` — Lệnh Kotlin hỗ trợ xử lý của nhóm hiện tại.
27. `    }` — Đóng block Kotlin trước đó.
28. `}` — Đóng block Kotlin trước đó.
