# Tra nhanh DeliveryV2

- `DeliveryV2Screen.kt`: file điều phối, khoảng 155 dòng thay vì 428 dòng.
- `DeliveryV2State.kt`: tất cả biến state Compose tập trung.
- `DeliveryV2Navigation.kt`: BackHandler + các `if` chuyển màn hình + xin quyền vị trí.
- `DeliveryV2Map.kt`: MapDeliveryScreen và callback bản đồ.
- `DeliveryV2Detail.kt`: OrderDetailScreen và callback gọi/Zalo/SMS/giao hàng.
- `DeliveryV2Customer.kt`: CustomerList và lấy tọa độ từ GPS hiện tại hoặc fallback.
- `DeliveryV2Dialog.kt`: DeliveryCompletionDialog và chọn đơn kế tiếp.

## Cách sửa nhanh

- Muốn đổi kích thước/nút bản đồ → `MapDeliveryComponents.kt`.
- Muốn đổi điều kiện route/STT → `ui/logic/DeliveryConditions.kt`.
- Muốn đổi tab → `DeliveryV2Screen.kt` + `DeliveryV2State.kt`.
- Muốn đổi Back → `DeliveryV2Navigation.kt`.
- Muốn đổi chi tiết đơn → `OrderDetailScreen.kt`.
- Muốn đổi khách hàng → `CustomerComponents.kt`.
- Muốn đổi dialog hoàn tất → `DeliveryCompletionDialog.kt`.
