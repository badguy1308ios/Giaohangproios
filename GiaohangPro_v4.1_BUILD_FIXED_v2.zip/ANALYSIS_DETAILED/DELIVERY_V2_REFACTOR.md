# DeliveryV2Screen — cấu trúc mới

`DeliveryV2Screen.kt` hiện chỉ làm nhiệm vụ **điều phối**. Code được chia thành 6 nhóm để sửa nhanh:

| Nhóm | File | Chức năng | Khi cần sửa |
|---|---|---|---|
| State | `ui/DeliveryV2State.kt` | State của tab, đơn đang chọn, GPS, route, modal | Sửa dữ liệu trạng thái màn hình |
| Navigation | `ui/DeliveryV2Navigation.kt` | BackHandler, quyền GPS, Settings và màn hình con | Sửa luồng mở/đóng màn hình |
| Map | `ui/DeliveryV2Map.kt` | Cầu nối UI bản đồ, chọn đơn, mở chi tiết | Sửa hành vi liên quan bản đồ |
| Detail | `ui/DeliveryV2Detail.kt` | Cầu nối màn hình chi tiết đơn | Sửa callback từ Detail |
| Customer | `ui/DeliveryV2Customer.kt` | Cầu nối danh sách khách hàng và GPS | Sửa luồng khách hàng |
| Dialog | `ui/DeliveryV2Dialog.kt` | Dialog giao thành công và chọn đơn tiếp theo | Sửa xác nhận hoàn tất đơn |

## Quy tắc sửa code

1. **UI giao diện**: sửa component tương ứng (`MapDeliveryComponents.kt`, `OrderDetailScreen.kt`, `CustomerComponents.kt`, `DeliveryCompletionDialog.kt`).
2. **Điều kiện/tính toán route**: sửa `ui/logic/DeliveryConditions.kt`, không nhúng thuật toán vào UI.
3. **State**: thêm state vào `DeliveryV2State.kt`.
4. **Chuyển màn hình**: sửa `DeliveryV2Navigation.kt`.
5. **Không đưa logic nghiệp vụ dài trở lại `DeliveryV2Screen.kt`**.

## Chú thích dòng lệnh

Mỗi file mới có comment `GROUP:` ngay đầu khu vực chính. Các câu lệnh quan trọng đều có comment giải thích mục đích ngay tại chỗ. File `ANALYSIS_DETAILED/LINE_BY_LINE.md` tiếp tục chứa phần phân tích dòng-by-dòng của source trước khi tách.

## Luồng tổng quát

`DeliveryV2Screen` → `State` → `Navigation` → `Map/Detail/Customer` → `Dialog`.

Logic route: `DeliveryV2Screen/Navigation` → `DeliveryConditions` → cập nhật `State` → callback về `DeliveryOrderStore`.
