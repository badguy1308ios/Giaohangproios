# CONDITION INDEX

- `findRouteOrigin`: GPS hiện tại → fallback đơn tuyến.
- `buildRouteSequence`: tính map waybill → STT.
- `nextOrderAfterCompletion`: tìm đơn tiếp theo sau khi giao.
- `isValidRouteSequenceText`: kiểm tra STT như `1`, `2`, `3.n`.
- `DeliveryV2Screen.BackHandler`: điều hướng Back giữa các màn hình.
- `DeliveryV2Screen` các `if (... ) return`: chọn màn hình nào đang chiếm toàn bộ composition.
- `CustomerComponents`: lọc/tìm khách và trạng thái dialog.
- `MapDeliveryComponents`: trạng thái edit/preview STT và selection.
