# CHÚ THÍCH TỪNG DÒNG CODE

Bản hướng dẫn đọc source. Mỗi dòng Kotlin có giải thích và code gốc ngay bên dưới.

## `app/src/main/java/com/example/delivery/DeliveryApplication.kt`

**Dòng 1:** Khai báo package/namespace.

```kotlin
package com.example.delivery
```

**Dòng 2:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 3:** Import dependency.

```kotlin
import android.app.Application
```

**Dòng 4:** Import dependency.

```kotlin
import com.example.delivery.debug.CrashDiagnostic
```

**Dòng 5:** Import dependency.

```kotlin
import com.example.delivery.map.configureMapTileCache
```

**Dòng 6:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 7:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
class DeliveryApplication : Application() {
```

**Dòng 8:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    override fun onCreate() {
```

**Dòng 9:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        super.onCreate()
```

**Dòng 10:** Biến chỉ đọc.

```kotlin
        val systemHandler = Thread.getDefaultUncaughtExceptionHandler()
```

**Dòng 11:** Phép so sánh/điều kiện.

```kotlin
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
```

**Dòng 12:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            CrashDiagnostic.record(this, thread, error)
```

**Dòng 13:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            systemHandler?.uncaughtException(thread, error)
```

**Dòng 14:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 15:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        configureMapTileCache(this)
```

**Dòng 16:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 17:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

## `app/src/main/java/com/example/delivery/MainActivity.kt`

**Dòng 1:** Khai báo package/namespace.

```kotlin
package com.example.delivery
```

**Dòng 2:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 3:** Import dependency.

```kotlin
import android.content.ClipData
```

**Dòng 4:** Import dependency.

```kotlin
import android.content.ClipboardManager
```

**Dòng 5:** Import dependency.

```kotlin
import android.content.Context
```

**Dòng 6:** Import dependency.

```kotlin
import android.content.Intent
```

**Dòng 7:** Import dependency.

```kotlin
import android.location.Location
```

**Dòng 8:** Import dependency.

```kotlin
import android.location.LocationManager
```

**Dòng 9:** Import dependency.

```kotlin
import android.net.Uri
```

**Dòng 10:** Import dependency.

```kotlin
import android.os.Bundle
```

**Dòng 11:** Import dependency.

```kotlin
import android.provider.OpenableColumns
```

**Dòng 12:** Import dependency.

```kotlin
import android.widget.Toast
```

**Dòng 13:** Import dependency.

```kotlin
import androidx.activity.ComponentActivity
```

**Dòng 14:** Import dependency.

```kotlin
import androidx.activity.compose.setContent
```

**Dòng 15:** Import dependency.

```kotlin
import androidx.activity.result.contract.ActivityResultContracts
```

**Dòng 16:** Import dependency.

```kotlin
import androidx.compose.foundation.Image
```

**Dòng 17:** Import dependency.

```kotlin
import androidx.compose.foundation.background
```

**Dòng 18:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.Arrangement
```

**Dòng 19:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.Row
```

**Dòng 20:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.fillMaxSize
```

**Dòng 21:** Import dependency.

```kotlin
import androidx.compose.foundation.text.selection.SelectionContainer
```

**Dòng 22:** Import dependency.

```kotlin
import androidx.compose.material3.AlertDialog
```

**Dòng 23:** Import dependency.

```kotlin
import androidx.compose.material3.Button
```

**Dòng 24:** Import dependency.

```kotlin
import androidx.compose.material3.OutlinedButton
```

**Dòng 25:** Import dependency.

```kotlin
import androidx.compose.material3.Text
```

**Dòng 26:** Import dependency.

```kotlin
import androidx.compose.runtime.Composable
```

**Dòng 27:** Import dependency.

```kotlin
import androidx.compose.runtime.LaunchedEffect
```

**Dòng 28:** Import dependency.

```kotlin
import androidx.compose.runtime.getValue
```

**Dòng 29:** Import dependency.

```kotlin
import androidx.compose.runtime.mutableStateListOf
```

**Dòng 30:** Import dependency.

```kotlin
import androidx.compose.runtime.mutableStateMapOf
```

**Dòng 31:** Import dependency.

```kotlin
import androidx.compose.runtime.mutableStateOf
```

**Dòng 32:** Import dependency.

```kotlin
import androidx.compose.runtime.remember
```

**Dòng 33:** Import dependency.

```kotlin
import androidx.compose.runtime.setValue
```

**Dòng 34:** Import dependency.

```kotlin
import androidx.compose.ui.Modifier
```

**Dòng 35:** Import dependency.

```kotlin
import androidx.compose.ui.graphics.Color
```

**Dòng 36:** Import dependency.

```kotlin
import androidx.compose.ui.layout.ContentScale
```

**Dòng 37:** Import dependency.

```kotlin
import androidx.compose.ui.res.painterResource
```

**Dòng 38:** Import dependency.

```kotlin
import androidx.compose.ui.unit.dp
```

**Dòng 39:** Import dependency.

```kotlin
import androidx.core.content.ContextCompat
```

**Dòng 40:** Import dependency.

```kotlin
import androidx.core.view.WindowCompat
```

**Dòng 41:** Import dependency.

```kotlin
import androidx.core.view.WindowInsetsCompat
```

**Dòng 42:** Import dependency.

```kotlin
import androidx.core.view.WindowInsetsControllerCompat
```

**Dòng 43:** Import dependency.

```kotlin
import androidx.lifecycle.lifecycleScope
```

**Dòng 44:** Import dependency.

```kotlin
import com.example.delivery.backup.CustomerBackupArchive
```

**Dòng 45:** Import dependency.

```kotlin
import com.example.delivery.backup.CustomerBackupResult
```

**Dòng 46:** Import dependency.

```kotlin
import com.example.delivery.history.DeliveryPhotoHistory
```

**Dòng 47:** Import dependency.

```kotlin
import com.example.delivery.history.PaymentChannel
```

**Dòng 48:** Import dependency.

```kotlin
import com.example.delivery.history.ProofPhotoType
```

**Dòng 49:** Import dependency.

```kotlin
import com.example.delivery.history.TransferEvidence
```

**Dòng 50:** Import dependency.

```kotlin
import com.example.delivery.integration.VtmanExportContract
```

**Dòng 51:** Import dependency.

```kotlin
import com.example.delivery.location.RealtimeLocationPolicy
```

**Dòng 52:** Import dependency.

```kotlin
import com.example.delivery.navigation.DeliveryRouteStore
```

**Dòng 53:** Import dependency.

```kotlin
import com.example.delivery.navigation.DeliveryZone
```

**Dòng 54:** Import dependency.

```kotlin
import com.example.delivery.navigation.GeoPoint
```

**Dòng 55:** Import dependency.

```kotlin
import com.example.delivery.navigation.routeOrdersFrom
```

**Dòng 56:** Import dependency.

```kotlin
import com.example.delivery.navigation.distanceMeters
```

**Dòng 57:** Import dependency.

```kotlin
import com.example.delivery.navigation.routeOrdersFromZones
```

**Dòng 58:** Import dependency.

```kotlin
import com.example.delivery.navigation.orderRouteGroupsByZoneAndGeo
```

**Dòng 59:** Import dependency.

```kotlin
import com.example.delivery.customer.CustomerProfile
```

**Dòng 60:** Import dependency.

```kotlin
import com.example.delivery.customer.CustomerProfileStore
```

**Dòng 61:** Import dependency.

```kotlin
import com.example.delivery.customer.mergeOrderCustomers
```

**Dòng 62:** Import dependency.

```kotlin
import com.example.delivery.debug.CrashDiagnostic
```

**Dòng 63:** Import dependency.

```kotlin
import com.example.delivery.model.DeliveryOrder
```

**Dòng 64:** Import dependency.

```kotlin
import com.example.delivery.model.DeliveryStatus
```

**Dòng 65:** Import dependency.

```kotlin
import com.example.delivery.model.formatVnd
```

**Dòng 66:** Import dependency.

```kotlin
import com.example.delivery.model.isRouteActive
```

**Dòng 67:** Import dependency.

```kotlin
import com.example.delivery.model.canReceiveRouteSequence
```

**Dòng 68:** Import dependency.

```kotlin
import com.example.delivery.model.hasStoredCoordinates
```

**Dòng 69:** Import dependency.

```kotlin
import com.example.delivery.model.withSequenceLabel
```

**Dòng 70:** Import dependency.

```kotlin
import com.example.delivery.model.withSharedPhoneSequence
```

**Dòng 71:** Import dependency.

```kotlin
import com.example.delivery.model.phoneGroupKey
```

**Dòng 72:** Import dependency.

```kotlin
import com.example.delivery.model.deliveryOutcome
```

**Dòng 73:** Import dependency.

```kotlin
import com.example.delivery.model.csvStatus
```

**Dòng 74:** Import dependency.

```kotlin
import com.example.delivery.model.normalizedCoordinates
```

**Dòng 75:** Import dependency.

```kotlin
import com.example.delivery.model.nextActiveSequence
```

**Dòng 76:** Import dependency.

```kotlin
import com.example.delivery.model.sampleOrders
```

**Dòng 77:** Import dependency.

```kotlin
import com.example.delivery.orderio.DeliveryOrderStore
```

**Dòng 78:** Import dependency.

```kotlin
import com.example.delivery.orderio.CoordinateUpdateCoordinator
```

**Dòng 79:** Import dependency.

```kotlin
import com.example.delivery.orderio.CoordinateUpdateRequest
```

**Dòng 80:** Import dependency.

```kotlin
import com.example.delivery.orderio.CustomerCoordinateSyncCoordinator
```

**Dòng 81:** Import dependency.

```kotlin
import com.example.delivery.orderio.ManualOrderCoordinator
```

**Dòng 82:** Import dependency.

```kotlin
import com.example.delivery.orderio.OrderDeletionCoordinator
```

**Dòng 83:** Import dependency.

```kotlin
import com.example.delivery.orderio.OrderFileCodec
```

**Dòng 84:** Import dependency.

```kotlin
import com.example.delivery.orderio.OrderImportCoordinator
```

**Dòng 85:** Import dependency.

```kotlin
import com.example.delivery.orderio.OrderImportResult
```

**Dòng 86:** Import dependency.

```kotlin
import com.example.delivery.orderio.SttSequenceFileCodec
```

**Dòng 87:** Import dependency.

```kotlin
import com.example.delivery.ui.DeliveryV2Screen
```

**Dòng 88:** Import dependency.

```kotlin
import com.example.delivery.ui.RouteCreationMode
```

**Dòng 89:** Import dependency.

```kotlin
import com.example.delivery.ui.TransferPhotoState
```

**Dòng 90:** Import dependency.

```kotlin
import kotlinx.coroutines.delay
```

**Dòng 91:** Import dependency.

```kotlin
import java.io.File
```

**Dòng 92:** Import dependency.

```kotlin
import java.nio.charset.StandardCharsets
```

**Dòng 93:** Import dependency.

```kotlin
import java.text.SimpleDateFormat
```

**Dòng 94:** Import dependency.

```kotlin
import java.util.Date
```

**Dòng 95:** Import dependency.

```kotlin
import java.util.Locale
```

**Dòng 96:** Import dependency.

```kotlin
import kotlinx.coroutines.Dispatchers
```

**Dòng 97:** Import dependency.

```kotlin
import kotlinx.coroutines.launch
```

**Dòng 98:** Import dependency.

```kotlin
import kotlinx.coroutines.withContext
```

**Dòng 99:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 100:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
private data class CaptureTarget(val order: DeliveryOrder, val type: ProofPhotoType, val file: File)
```

**Dòng 101:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 102:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
class MainActivity : ComponentActivity() {
```

**Dòng 103:** Phép so sánh/điều kiện.

```kotlin
    private val orders = mutableStateListOf<DeliveryOrder>()
```

**Dòng 104:** Phép so sánh/điều kiện.

```kotlin
    private val transferPhotos = mutableStateMapOf<String, TransferPhotoState>()
```

**Dòng 105:** State Compose; thay đổi kích hoạt recomposition nơi state được đọc.

```kotlin
    private var evidence by mutableStateOf<List<TransferEvidence>>(emptyList())
```

**Dòng 106:** State Compose; thay đổi kích hoạt recomposition nơi state được đọc.

```kotlin
    private var customerProfiles by mutableStateOf<List<CustomerProfile>>(emptyList())
```

**Dòng 107:** State Compose; thay đổi kích hoạt recomposition nơi state được đọc.

```kotlin
    private var backupStatus by mutableStateOf<String?>(null)
```

**Dòng 108:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    private var captureTarget: CaptureTarget? = null
```

**Dòng 109:** Phép so sánh/điều kiện.

```kotlin
    private val backupExport = registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
```

**Dòng 110:** Safe-call: chỉ chạy khi khác null.

```kotlin
        uri?.let(::exportBackupTo)
```

**Dòng 111:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 112:** Phép so sánh/điều kiện.

```kotlin
    private val backupImport = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
```

**Dòng 113:** Safe-call: chỉ chạy khi khác null.

```kotlin
        uri?.let(::importBackupFrom)
```

**Dòng 114:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 115:** Phép so sánh/điều kiện.

```kotlin
    private val orderImport = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
```

**Dòng 116:** Safe-call: chỉ chạy khi khác null.

```kotlin
        uri?.let(::importOrdersFrom)
```

**Dòng 117:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 118:** Phép so sánh/điều kiện.

```kotlin
    private val orderExport = registerForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
```

**Dòng 119:** Safe-call: chỉ chạy khi khác null.

```kotlin
        uri?.let(::exportOrdersTo)
```

**Dòng 120:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 121:** Phép so sánh/điều kiện.

```kotlin
    private val sttExport = registerForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
```

**Dòng 122:** Safe-call: chỉ chạy khi khác null.

```kotlin
        uri?.let(::exportSttTo)
```

**Dòng 123:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 124:** Phép so sánh/điều kiện.

```kotlin
    private val sttImport = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
```

**Dòng 125:** Safe-call: chỉ chạy khi khác null.

```kotlin
        uri?.let(::importSttFrom)
```

**Dòng 126:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 127:** Phép so sánh/điều kiện.

```kotlin
    private val camera = registerForActivityResult(ActivityResultContracts.TakePicture()) { saved ->
```

**Dòng 128:** Biến chỉ đọc.

```kotlin
        val target = captureTarget ?: return@registerForActivityResult
```

**Dòng 129:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        captureTarget = null
```

**Dòng 130:** Điều kiện if.

```kotlin
        if (!saved) { target.file.delete(); return@registerForActivityResult }
```

**Dòng 131:** Biến chỉ đọc.

```kotlin
        val path = if (target.type == ProofPhotoType.DROP_OFF_WATERMARK) {
```

**Dòng 132:** Biến chỉ đọc.

```kotlin
            val location = lastLocation()
```

**Dòng 133:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            DeliveryPhotoHistory.addDropOffWatermark(target.file, target.order, location?.latitude, location?.longitude)
```

**Dòng 134:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        } else target.file.path
```

**Dòng 135:** Rẽ nhánh nhiều trường hợp.

```kotlin
        when (target.type) {
```

**Dòng 136:** Elvis: dùng giá trị dự phòng khi null.

```kotlin
            ProofPhotoType.BILL_CLOSEUP -> transferPhotos[target.order.waybill] = (transferPhotos[target.order.waybill] ?: TransferPhotoState()).copy(billPath = path)
```

**Dòng 137:** Elvis: dùng giá trị dự phòng khi null.

```kotlin
            ProofPhotoType.DROP_OFF_WATERMARK -> transferPhotos[target.order.waybill] = (transferPhotos[target.order.waybill] ?: TransferPhotoState()).copy(dropOffPath = path)
```

**Dòng 138:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 139:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 140:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 141:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    override fun onCreate(savedInstanceState: Bundle?) {
```

**Dòng 142:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        super.onCreate(savedInstanceState)
```

**Dòng 143:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        WindowCompat.setDecorFitsSystemWindows(window, false)
```

**Dòng 144:** Biến chỉ đọc.

```kotlin
        val storedOrders = DeliveryOrderStore.load(this)
```

**Dòng 145:** Chú thích, không thực thi.

```kotlin
        // Chỉ nạp dữ liệu mẫu ở lần chạy đầu; danh sách rỗng sau khi người dùng xóa tất cả phải được giữ nguyên.
```

**Dòng 146:** Biến chỉ đọc.

```kotlin
        val initialOrders = if (storedOrders.isEmpty() && !DeliveryOrderStore.hasBeenInitialized(this)) {
```

**Dòng 147:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            sampleOrders().also { DeliveryOrderStore.replace(this, it) }
```

**Dòng 148:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        } else {
```

**Dòng 149:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            storedOrders
```

**Dòng 150:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 151:** Biến chỉ đọc.

```kotlin
        val normalizedOrders = initialOrders.map(DeliveryOrder::normalizedCoordinates).withSharedPhoneSequence()
```

**Dòng 152:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        orders.addAll(normalizedOrders)
```

**Dòng 153:** Điều kiện if.

```kotlin
        if (normalizedOrders != initialOrders) persistOrders()
```

**Dòng 154:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        evidence = DeliveryPhotoHistory.getEvidence(this)
```

**Dòng 155:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        customerProfiles = CustomerProfileStore.load(this)
```

**Dòng 156:** Biến chỉ đọc.

```kotlin
        val systemBars = WindowCompat.getInsetsController(window, window.decorView)
```

**Dòng 157:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        systemBars.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
```

**Dòng 158:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        systemBars.hide(WindowInsetsCompat.Type.systemBars())
```

**Dòng 159:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        setContent {
```

**Dòng 160:** Biến có thể thay đổi.

```kotlin
            var showSplash by remember { mutableStateOf(true) }
```

**Dòng 161:** Biến có thể thay đổi.

```kotlin
            var crashDebug by remember { mutableStateOf(CrashDiagnostic.consume(this@MainActivity)) }
```

**Dòng 162:** Chạy coroutine theo key.

```kotlin
            LaunchedEffect(Unit) {
```

**Dòng 163:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                delay(1_500)
```

**Dòng 164:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                showSplash = false
```

**Dòng 165:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                systemBars.show(WindowInsetsCompat.Type.systemBars())
```

**Dòng 166:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 167:** Điều kiện if.

```kotlin
            if (showSplash) {
```

**Dòng 168:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                DeliveryLaunchScreen()
```

**Dòng 169:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            } else DeliveryV2Screen(
```

**Dòng 170:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                orders = orders,
```

**Dòng 171:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                transferPhotos = transferPhotos,
```

**Dòng 172:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                transferEvidence = evidence,
```

**Dòng 173:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                customerProfiles = customerProfiles.mergeOrderCustomers(orders),
```

**Dòng 174:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                onDirectDelivered = ::markDelivered,
```

**Dòng 175:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                onSaveTransfer = ::saveTransfer,
```

**Dòng 176:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                onCaptureTransferPhoto = ::captureProof,
```

**Dòng 177:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                onCall = ::openDial,
```

**Dòng 178:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                onZalo = ::openZalo,
```

**Dòng 179:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                onSms = ::openSms,
```

**Dòng 180:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                onConfirmTransferPayment = ::confirmTransferPayment,
```

**Dòng 181:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                transferMessage = ::transferMessage,
```

**Dòng 182:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                onRouteSequenceLocked = ::lockRouteSequence,
```

**Dòng 183:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                onCreateRoute = ::createRoute,
```

**Dòng 184:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                onDeleteRoute = ::deleteRoute,
```

**Dòng 185:** Phép so sánh/điều kiện.

```kotlin
                onSaveCustomer = { profile -> customerProfiles = CustomerProfileStore.upsert(this, profile) },
```

**Dòng 186:** Phép so sánh/điều kiện.

```kotlin
                onDeleteCustomer = { profile -> customerProfiles = CustomerProfileStore.delete(this, profile.id) },
```

**Dòng 187:** Safe-call: chỉ chạy khi khác null.

```kotlin
                onGetCustomerCoordinates = { lastLocation()?.let { it.latitude to it.longitude } },
```

**Dòng 188:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                onExportBackup = ::startBackupExport,
```

**Dòng 189:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                onImportBackup = ::startBackupImport,
```

**Dòng 190:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                onImportOrders = ::startOrderImport,
```

**Dòng 191:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                onExportOrders = ::startOrderExport,
```

**Dòng 192:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                onExportStt = ::startSttExport,
```

**Dòng 193:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                onImportStt = ::startSttImport,
```

**Dòng 194:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                onAddManualOrder = ::addManualOrder,
```

**Dòng 195:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                onDeleteOrder = ::deleteOrder,
```

**Dòng 196:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                onDeleteAllOrders = ::deleteAllOrders,
```

**Dòng 197:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                onUpdateCoordinates = ::updateCoordinates,
```

**Dòng 198:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                onSyncOrdersFromCustomerCoordinates = ::syncOrdersFromCustomerCoordinates,
```

**Dòng 199:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                onOpenVtmanExport = ::openVtmanExport,
```

**Dòng 200:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                backupStatus = backupStatus,
```

**Dòng 201:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            )
```

**Dòng 202:** Safe-call: chỉ chạy khi khác null.

```kotlin
            crashDebug?.let { detail ->
```

**Dòng 203:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                AlertDialog(
```

**Dòng 204:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    onDismissRequest = { crashDebug = null },
```

**Dòng 205:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    title = { Text("DEBUG LỖI CRASH") },
```

**Dòng 206:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    text = { SelectionContainer { Text(detail) } },
```

**Dòng 207:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    confirmButton = {
```

**Dòng 208:** Nút tương tác; onClick xử lý nhấn.

```kotlin
                        Button(onClick = {
```

**Dòng 209:** Biến chỉ đọc.

```kotlin
                            val clipboard = getSystemService(ClipboardManager::class.java)
```

**Dòng 210:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                            clipboard.setPrimaryClip(ClipData.newPlainText("Giao Hàng Goong Alpha crash debug", detail))
```

**Dòng 211:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        }) { Text("Sao chép lỗi") }
```

**Dòng 212:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    },
```

**Dòng 213:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    dismissButton = {
```

**Dòng 214:** Container ngang.

```kotlin
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
```

**Dòng 215:** Nút tương tác; onClick xử lý nhấn.

```kotlin
                            OutlinedButton(onClick = { crashDebug = null }) { Text("Đóng") }
```

**Dòng 216:** Nút tương tác; onClick xử lý nhấn.

```kotlin
                            OutlinedButton(onClick = { crashDebug = null; recreate() }) { Text("Khởi động lại") }
```

**Dòng 217:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        }
```

**Dòng 218:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    },
```

**Dòng 219:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                )
```

**Dòng 220:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 221:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 222:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 223:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 224:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun markDelivered(order: DeliveryOrder) {
```

**Dòng 225:** Biến chỉ đọc.

```kotlin
        val index = orders.indexOfFirst { it.waybill == order.waybill }
```

**Dòng 226:** Điều kiện if.

```kotlin
        if (index < 0) return
```

**Dòng 227:** Biến chỉ đọc.

```kotlin
        val updated = orders[index].copy(
```

**Dòng 228:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            status = DeliveryStatus.TT500,
```

**Dòng 229:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            requiresRedelivery = false,
```

**Dòng 230:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            failureReason = null,
```

**Dòng 231:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            delivered = true,
```

**Dòng 232:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            sequence = 0,
```

**Dòng 233:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            sequenceLabel = null,
```

**Dòng 234:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        )
```

**Dòng 235:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        orders.removeAt(index)
```

**Dòng 236:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        orders.add(updated)
```

**Dòng 237:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        persistOrders()
```

**Dòng 238:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 239:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun resetRetryableOrdersForRouting() {
```

**Dòng 240:** Biến có thể thay đổi.

```kotlin
        var changed = false
```

**Dòng 241:** Phép so sánh/điều kiện.

```kotlin
        orders.indices.forEach { index ->
```

**Dòng 242:** Biến chỉ đọc.

```kotlin
            val order = orders[index]
```

**Dòng 243:** Điều kiện if.

```kotlin
            if (order.csvStatus() == DeliveryStatus.TT506 || order.csvStatus() == DeliveryStatus.TT507 || order.csvStatus() == DeliveryStatus.TT508) {
```

**Dòng 244:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                orders[index] = order.copy(
```

**Dòng 245:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    status = DeliveryStatus.TT500,
```

**Dòng 246:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    requiresRedelivery = false,
```

**Dòng 247:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    wasRedelivered = false,
```

**Dòng 248:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    failureReason = null,
```

**Dòng 249:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    delivered = false,
```

**Dòng 250:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                )
```

**Dòng 251:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                changed = true
```

**Dòng 252:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 253:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 254:** Điều kiện if.

```kotlin
        if (changed) persistOrders()
```

**Dòng 255:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 256:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 257:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun createRoute(mode: RouteCreationMode) {
```

**Dòng 258:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        resetRetryableOrdersForRouting()
```

**Dòng 259:** Biến chỉ đọc.

```kotlin
        val zones = DeliveryRouteStore.loadZones(this)
```

**Dòng 260:** Biến chỉ đọc.

```kotlin
        val groupKey: (DeliveryOrder) -> String = { order -> order.phone.filter(Char::isDigit).ifBlank { order.waybill } }
```

**Dòng 261:** Biến chỉ đọc.

```kotlin
        val eligibleForNew = orders.filter { order ->
```

**Dòng 262:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            order.hasStoredCoordinates() && order.canReceiveRouteSequence()
```

**Dòng 263:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 264:** Biến chỉ đọc.

```kotlin
        val eligibleForUpdate = run {
```

**Dòng 265:** Biến chỉ đọc.

```kotlin
            val newlyLocatedKeys = orders.filter { it.hasStoredCoordinates() && it.sequence == 0 && it.canReceiveRouteSequence() }
```

**Dòng 266:** Biến đổi collection.

```kotlin
                .map(groupKey).toSet()
```

**Dòng 267:** Lọc collection.

```kotlin
            orders.filter { order ->
```

**Dòng 268:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                groupKey(order) in newlyLocatedKeys && order.hasStoredCoordinates() && order.canReceiveRouteSequence()
```

**Dòng 269:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 270:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 271:** Biến chỉ đọc.

```kotlin
        val candidates = if (mode == RouteCreationMode.NEW_ROUTE) eligibleForNew else eligibleForUpdate
```

**Dòng 272:** Biến chỉ đọc.

```kotlin
        val groups = candidates.groupBy(groupKey).values
```

**Dòng 273:** Chú thích, không thực thi.

```kotlin
        // Ưu tiên thứ tự Zone trong cùng khu vực gần nhau; tổng thể đi trái-phải,
```

**Dòng 274:** Chú thích, không thực thi.

```kotlin
        // dưới-lên để các MVĐ gần nhau, kể cả khác Zone, nhận STT gần nhau.
```

**Dòng 275:** Biến chỉ đọc.

```kotlin
        val ordered = orderRouteGroupsByZoneAndGeo(groups, zones)
```

**Dòng 276:** Biến có thể thay đổi.

```kotlin
        var next = if (mode == RouteCreationMode.NEW_ROUTE) 1 else orders.filter { it.isRouteActive() }.maxOfOrNull { it.sequence }?.plus(1) ?: 1
```

**Dòng 277:** Biến chỉ đọc.

```kotlin
        val sequenceByWaybill = mutableMapOf<String, Int>()
```

**Dòng 278:** Phép so sánh/điều kiện.

```kotlin
        ordered.forEach { group -> group.forEach { order -> sequenceByWaybill[order.waybill] = next }; next++ }
```

**Dòng 279:** Safe-call: chỉ chạy khi khác null.

```kotlin
        orders.indices.forEach { index -> sequenceByWaybill[orders[index].waybill]?.let { sequence -> orders[index] = orders[index].copy(sequence = sequence, sequenceLabel = null) } }
```

**Dòng 280:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        persistOrders()
```

**Dòng 281:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        DeliveryRouteStore.setRouteActive(this, true)
```

**Dòng 282:** Biến chỉ đọc.

```kotlin
        val label = if (mode == RouteCreationMode.NEW_ROUTE) "Tuyến mới" else "Cập nhật tuyến"
```

**Dòng 283:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        backupStatus = "Đã $label: ${ordered.size} nhóm SĐT, ${candidates.size} MVĐ được đánh STT."
```

**Dòng 284:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 285:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 286:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun deleteRoute() {
```

**Dòng 287:** Phép so sánh/điều kiện.

```kotlin
        orders.indices.forEach { index -> orders[index] = orders[index].copy(sequence = 0, sequenceLabel = null) }
```

**Dòng 288:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        persistOrders()
```

**Dòng 289:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        DeliveryRouteStore.clearRoute(this)
```

**Dòng 290:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        backupStatus = "Đã xóa tuyến và toàn bộ STT."
```

**Dòng 291:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 292:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 293:** Phép so sánh/điều kiện.

```kotlin
    private fun lockRouteSequence(sequenceByWaybill: Map<String, String>) {
```

**Dòng 294:** Biến có thể thay đổi.

```kotlin
        var changed = false
```

**Dòng 295:** Biến chỉ đọc.

```kotlin
        val labelsByPhone = orders.mapNotNull { order ->
```

**Dòng 296:** Safe-call: chỉ chạy khi khác null.

```kotlin
            sequenceByWaybill[order.waybill]?.trim()?.takeIf { it.isValidSequenceLabel() }?.let { order.phoneGroupKey() to it }
```

**Dòng 297:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }.toMap()
```

**Dòng 298:** Phép so sánh/điều kiện.

```kotlin
        orders.indices.forEach { index ->
```

**Dòng 299:** Biến chỉ đọc.

```kotlin
            val current = orders[index]
```

**Dòng 300:** Biến chỉ đọc.

```kotlin
            val label = labelsByPhone[current.phoneGroupKey()] ?: sequenceByWaybill[current.waybill]?.trim()
```

**Dòng 301:** Điều kiện if.

```kotlin
            if (label != null && current.hasStoredCoordinates() && !current.delivered && label.isValidSequenceLabel()) {
```

**Dòng 302:** Biến chỉ đọc.

```kotlin
                val updated = current.withSequenceLabel(label)
```

**Dòng 303:** Điều kiện if.

```kotlin
                if (updated.sequence != current.sequence || updated.sequenceLabel != current.sequenceLabel) {
```

**Dòng 304:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    orders[index] = updated
```

**Dòng 305:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    changed = true
```

**Dòng 306:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                }
```

**Dòng 307:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 308:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 309:** Điều kiện if.

```kotlin
        if (changed) persistOrders()
```

**Dòng 310:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 311:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 312:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun String.isValidSequenceLabel(): Boolean {
```

**Dòng 313:** Biến chỉ đọc.

```kotlin
        val parts = trim().split('.', limit = 2)
```

**Dòng 314:** Kết thúc hàm và trả kết quả.

```kotlin
        return parts[0].toIntOrNull()?.let { it > 0 } == true &&
```

**Dòng 315:** Safe-call: chỉ chạy khi khác null.

```kotlin
            (parts.size == 1 || parts[1].equals("n", true) || parts[1].toIntOrNull()?.let { it > 0 } == true)
```

**Dòng 316:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 317:** Phép so sánh/điều kiện.

```kotlin
    private fun replace(order: DeliveryOrder, update: (DeliveryOrder) -> DeliveryOrder) {
```

**Dòng 318:** Safe-call: chỉ chạy khi khác null.

```kotlin
        orders.indexOfFirst { it.waybill == order.waybill }.takeIf { it >= 0 }?.let { index ->
```

**Dòng 319:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            orders[index] = update(orders[index])
```

**Dòng 320:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            persistOrders()
```

**Dòng 321:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 322:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 323:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun captureProof(order: DeliveryOrder, type: ProofPhotoType) {
```

**Dòng 324:** Biến chỉ đọc.

```kotlin
        val file = DeliveryPhotoHistory.createOutputFile(this, order.waybill, type)
```

**Dòng 325:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        captureTarget = CaptureTarget(order, type, file)
```

**Dòng 326:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        camera.launch(DeliveryPhotoHistory.providerUri(this, file))
```

**Dòng 327:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 328:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun saveTransfer(order: DeliveryOrder, channel: PaymentChannel, message: String, bill: String?, drop: String?) {
```

**Dòng 329:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        DeliveryPhotoHistory.upsertEvidence(this, TransferEvidence(order.waybill, order.customer, order.phone, order.cod, channel, message, bill, drop, sentConfirmed = true))
```

**Dòng 330:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        evidence = DeliveryPhotoHistory.getEvidence(this)
```

**Dòng 331:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 332:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun confirmTransferPayment(waybill: String) {
```

**Dòng 333:** Biến chỉ đọc.

```kotlin
        val item = DeliveryPhotoHistory.confirmPaid(this, waybill) ?: return
```

**Dòng 334:** Safe-call: chỉ chạy khi khác null.

```kotlin
        orders.indexOfFirst { it.waybill == waybill }.takeIf { it >= 0 }?.let { index ->
```

**Dòng 335:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            orders[index] = orders[index].copy(status = DeliveryStatus.TT500, requiresRedelivery = false, failureReason = null, delivered = true)
```

**Dòng 336:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            persistOrders()
```

**Dòng 337:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 338:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        evidence = DeliveryPhotoHistory.getEvidence(this)
```

**Dòng 339:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 340:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun transferMessage(order: DeliveryOrder) = "Chào anh/chị ${order.customer}, em giao đơn hàng ${order.waybill}. Tiền COD: ${order.cod.formatVnd()}. Anh/Chị chuyển tiền vào STK: 0123456789 - Ngân hàng mặc định - Giao Hàng. Nội dung chuyển khoản: ${order.waybill}. Em cảm ơn ạ!"
```

**Dòng 341:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun startBackupExport() {
```

**Dòng 342:** Biến chỉ đọc.

```kotlin
        val stamp = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
```

**Dòng 343:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        backupExport.launch("giaohang_backup_$stamp.zip")
```

**Dòng 344:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 345:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 346:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun startBackupImport() = backupImport.launch(arrayOf("application/zip", "application/x-zip-compressed"))
```

**Dòng 347:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 348:** Chú thích, không thực thi.

```kotlin
    /** Một số trình quản lý tệp gán MIME không chuẩn cho CSV, nên mở tất cả rồi kiểm tra đuôi tệp trong OrderFileCodec. */
```

**Dòng 349:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun startOrderImport() = orderImport.launch(arrayOf("*/*"))
```

**Dòng 350:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 351:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun startOrderExport() {
```

**Dòng 352:** Biến chỉ đọc.

```kotlin
        val stamp = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
```

**Dòng 353:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        orderExport.launch("don_hang_$stamp.csv")
```

**Dòng 354:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 355:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 356:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun startSttExport() {
```

**Dòng 357:** Biến chỉ đọc.

```kotlin
        val stamp = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
```

**Dòng 358:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        sttExport.launch("stt_tuyen_giao_$stamp.csv")
```

**Dòng 359:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 360:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 361:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun startSttImport() = sttImport.launch(arrayOf("text/csv", "text/plain", "*/*"))
```

**Dòng 362:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 363:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun importOrdersFrom(uri: Uri) {
```

**Dòng 364:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        lifecycleScope.launch {
```

**Dòng 365:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            backupStatus = "Đang nhập đơn hàng…"
```

**Dòng 366:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            runCatching {
```

**Dòng 367:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                withContext(Dispatchers.IO) {
```

**Dòng 368:** Phép so sánh/điều kiện.

```kotlin
                    contentResolver.openInputStream(uri)?.use { input ->
```

**Dòng 369:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        OrderFileCodec.import(orderDocumentName(uri), input)
```

**Dòng 370:** Elvis: dùng giá trị dự phòng khi null.

```kotlin
                    } ?: error("Không thể mở tệp đơn hàng.")
```

**Dòng 371:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                }
```

**Dòng 372:** Phép so sánh/điều kiện.

```kotlin
            }.onSuccess { result: OrderImportResult ->
```

**Dòng 373:** Biến chỉ đọc.

```kotlin
                val knownCustomers = customerProfiles.mergeOrderCustomers(orders)
```

**Dòng 374:** Biến chỉ đọc.

```kotlin
                val merge = OrderImportCoordinator.replaceWithImportedBatch(orders.toList(), result.orders, knownCustomers)
```

**Dòng 375:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                orders.clear()
```

**Dòng 376:** Chú thích, không thực thi.

```kotlin
                // replaceWithImportedBatch đã khôi phục đúng các đơn không liên lạc được,
```

**Dòng 377:** Chú thích, không thực thi.

```kotlin
                // hẹn giao lại và tới kho nhận. Không reset trạng thái của các đơn khác tại đây.
```

**Dòng 378:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                orders.addAll(merge.orders.withSharedPhoneSequence())
```

**Dòng 379:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                persistOrders()
```

**Dòng 380:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                customerProfiles = CustomerProfileStore.upsertMissingFromOrders(this@MainActivity, merge.addedOrders)
```

**Dòng 381:** Biến chỉ đọc.

```kotlin
                val messages = mutableListOf("Đã nạp ${merge.orders.size} MVĐ cho danh sách hiện tại")
```

**Dòng 382:** Điều kiện if.

```kotlin
                if (merge.addedOrders.isNotEmpty()) messages += "thêm ${merge.addedOrders.size} MVĐ mới"
```

**Dòng 383:** Điều kiện if.

```kotlin
                if (merge.restoredProductCount > 0) messages += "bổ sung Hàng hóa cho ${merge.restoredProductCount} MVĐ đã có"
```

**Dòng 384:** Điều kiện if.

```kotlin
                if (merge.ignoredDuplicateCount > 0) messages += "giữ nguyên ${merge.ignoredDuplicateCount} MVĐ đã tồn tại"
```

**Dòng 385:** Điều kiện if.

```kotlin
                if (merge.reactivatedCount > 0) messages += "đưa lại ${merge.reactivatedCount} MVĐ không liên lạc được/hẹn giao lại/tới kho nhận về Đang giao"
```

**Dòng 386:** Điều kiện if.

```kotlin
                if (merge.removedNotInLatestImportCount > 0) messages += "ẩn ${merge.removedNotInLatestImportCount} MVĐ không có trong file khỏi Chi tiết và Bản đồ"
```

**Dòng 387:** Điều kiện if.

```kotlin
                if (result.skippedRows > 0) messages += "bỏ qua ${result.skippedRows} dòng không hợp lệ"
```

**Dòng 388:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                backupStatus = messages.joinToString("; ") + "."
```

**Dòng 389:** Phép so sánh/điều kiện.

```kotlin
            }.onFailure { error ->
```

**Dòng 390:** Elvis: dùng giá trị dự phòng khi null.

```kotlin
                backupStatus = "Nhập đơn hàng thất bại: ${error.message ?: "file không hợp lệ"}"
```

**Dòng 391:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 392:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 393:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 394:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 395:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun exportSttTo(uri: Uri) {
```

**Dòng 396:** Biến chỉ đọc.

```kotlin
        val snapshot = orders.toList()
```

**Dòng 397:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        lifecycleScope.launch {
```

**Dòng 398:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            backupStatus = "Đang lưu STT…"
```

**Dòng 399:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            runCatching {
```

**Dòng 400:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                withContext(Dispatchers.IO) {
```

**Dòng 401:** Phép so sánh/điều kiện.

```kotlin
                    contentResolver.openOutputStream(uri)?.use { output ->
```

**Dòng 402:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        output.write(SttSequenceFileCodec.exportCsv(snapshot).toByteArray(StandardCharsets.UTF_8))
```

**Dòng 403:** Elvis: dùng giá trị dự phòng khi null.

```kotlin
                    } ?: error("Không thể tạo tệp CSV STT.")
```

**Dòng 404:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                }
```

**Dòng 405:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }.onSuccess {
```

**Dòng 406:** Phép so sánh/điều kiện.

```kotlin
                backupStatus = "Đã lưu STT của ${snapshot.count { it.sequence > 0 }} mã vận đơn."
```

**Dòng 407:** Phép so sánh/điều kiện.

```kotlin
            }.onFailure { error ->
```

**Dòng 408:** Elvis: dùng giá trị dự phòng khi null.

```kotlin
                backupStatus = "Lưu STT thất bại: ${error.message ?: "lỗi không xác định"}"
```

**Dòng 409:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 410:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 411:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 412:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 413:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun importSttFrom(uri: Uri) {
```

**Dòng 414:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        lifecycleScope.launch {
```

**Dòng 415:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            backupStatus = "Đang khôi phục STT…"
```

**Dòng 416:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            runCatching {
```

**Dòng 417:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                withContext(Dispatchers.IO) {
```

**Dòng 418:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    contentResolver.openInputStream(uri)?.use { SttSequenceFileCodec.import(it) }
```

**Dòng 419:** Elvis: dùng giá trị dự phòng khi null.

```kotlin
                        ?: error("Không thể mở tệp STT.")
```

**Dòng 420:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                }
```

**Dòng 421:** Biến đổi collection.

```kotlin
            }.map { entries -> SttSequenceFileCodec.restore(orders.toList(), entries) }
```

**Dòng 422:** Phép so sánh/điều kiện.

```kotlin
                .onSuccess { result ->
```

**Dòng 423:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    orders.clear()
```

**Dòng 424:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    orders.addAll(result.orders.withSharedPhoneSequence())
```

**Dòng 425:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    persistOrders()
```

**Dòng 426:** Điều kiện if.

```kotlin
                    if (result.restoredCount > 0) DeliveryRouteStore.setRouteActive(this@MainActivity, true)
```

**Dòng 427:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    backupStatus = "Đã khôi phục ${result.restoredCount} STT; bỏ qua ${result.skippedMissingCount} MVĐ không còn trong danh sách và ${result.skippedStatusCount} MVĐ không đủ điều kiện."
```

**Dòng 428:** Phép so sánh/điều kiện.

```kotlin
                }.onFailure { error ->
```

**Dòng 429:** Elvis: dùng giá trị dự phòng khi null.

```kotlin
                    backupStatus = "Khôi phục STT thất bại: ${error.message ?: "tệp không hợp lệ"}"
```

**Dòng 430:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                }
```

**Dòng 431:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 432:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 433:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 434:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun exportOrdersTo(uri: Uri) {
```

**Dòng 435:** Biến chỉ đọc.

```kotlin
        val snapshot = orders.toList()
```

**Dòng 436:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        lifecycleScope.launch {
```

**Dòng 437:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            backupStatus = "Đang xuất đơn hàng…"
```

**Dòng 438:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            runCatching {
```

**Dòng 439:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                withContext(Dispatchers.IO) {
```

**Dòng 440:** Phép so sánh/điều kiện.

```kotlin
                    contentResolver.openOutputStream(uri)?.use { output ->
```

**Dòng 441:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        output.write(OrderFileCodec.exportCsv(snapshot).toByteArray(StandardCharsets.UTF_8))
```

**Dòng 442:** Elvis: dùng giá trị dự phòng khi null.

```kotlin
                    } ?: error("Không thể tạo tệp CSV.")
```

**Dòng 443:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                }
```

**Dòng 444:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }.onSuccess {
```

**Dòng 445:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                backupStatus = "Đã xuất ${snapshot.size} đơn hàng ra CSV."
```

**Dòng 446:** Phép so sánh/điều kiện.

```kotlin
            }.onFailure { error ->
```

**Dòng 447:** Elvis: dùng giá trị dự phòng khi null.

```kotlin
                backupStatus = "Xuất đơn hàng thất bại: ${error.message ?: "lỗi không xác định"}"
```

**Dòng 448:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 449:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 450:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 451:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 452:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun addManualOrder(draft: DeliveryOrder) {
```

**Dòng 453:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        runCatching {
```

**Dòng 454:** Biến chỉ đọc.

```kotlin
            val placed = ManualOrderCoordinator.place(draft, customerProfiles.mergeOrderCustomers(orders), orders, DeliveryRouteStore.isRouteActive(this))
```

**Dòng 455:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            orders.add(placed)
```

**Dòng 456:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            persistOrders()
```

**Dòng 457:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            customerProfiles = CustomerProfileStore.upsertMissingFromOrders(this, listOf(placed))
```

**Dòng 458:** Phép so sánh/điều kiện.

```kotlin
            backupStatus = if (placed.sequence > 0) {
```

**Dòng 459:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                "Đã thêm ${placed.waybill} với số thứ tự ${placed.sequence}."
```

**Dòng 460:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            } else {
```

**Dòng 461:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                "Đã thêm ${placed.waybill} ở đầu danh sách; hãy bổ sung tọa độ khách hàng để xếp tuyến."
```

**Dòng 462:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 463:** Phép so sánh/điều kiện.

```kotlin
        }.onFailure { error ->
```

**Dòng 464:** Elvis: dùng giá trị dự phòng khi null.

```kotlin
            backupStatus = "Không thể thêm mã vận đơn: ${error.message ?: "dữ liệu không hợp lệ"}"
```

**Dòng 465:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 466:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 467:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 468:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun deleteAllOrders() {
```

**Dòng 469:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        runCatching {
```

**Dòng 470:** Biến chỉ đọc.

```kotlin
            val count = orders.size
```

**Dòng 471:** Chú thích, không thực thi.

```kotlin
            // Không ghi outcome vào lịch sử: yêu cầu là xóa sạch, không để lại dấu vết MVD.
```

**Dòng 472:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            orders.clear()
```

**Dòng 473:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            transferPhotos.clear()
```

**Dòng 474:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            DeliveryOrderStore.replace(this, emptyList())
```

**Dòng 475:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            DeliveryPhotoHistory.clearAll(this)
```

**Dòng 476:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            DeliveryRouteStore.clearRoute(this)
```

**Dòng 477:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            evidence = emptyList()
```

**Dòng 478:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            backupStatus = "Đã xóa vĩnh viễn toàn bộ $count đơn hàng, trạng thái và lịch sử hình ảnh."
```

**Dòng 479:** Phép so sánh/điều kiện.

```kotlin
        }.onFailure { error ->
```

**Dòng 480:** Elvis: dùng giá trị dự phòng khi null.

```kotlin
            backupStatus = "Xóa toàn bộ đơn hàng thất bại: ${error.message ?: "không xác định"}"
```

**Dòng 481:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 482:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 483:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 484:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun deleteOrder(waybill: String) {
```

**Dòng 485:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        runCatching {
```

**Dòng 486:** Biến chỉ đọc.

```kotlin
            val deleted = orders.firstOrNull { it.waybill.equals(waybill.trim(), ignoreCase = true) }
```

**Dòng 487:** Elvis: dùng giá trị dự phòng khi null.

```kotlin
                ?: error("Không tìm thấy mã vận đơn cần xóa.")
```

**Dòng 488:** Chú thích, không thực thi.

```kotlin
            // Lưu hẳn khách trước khi bỏ đơn, để khách không bị mất khi đây là đơn duy nhất của họ.
```

**Dòng 489:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            customerProfiles = CustomerProfileStore.upsertMissingFromOrders(this, listOf(deleted))
```

**Dòng 490:** Biến chỉ đọc.

```kotlin
            val remaining = OrderDeletionCoordinator.delete(waybill, orders)
```

**Dòng 491:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            orders.clear()
```

**Dòng 492:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            orders.addAll(remaining)
```

**Dòng 493:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            persistOrders()
```

**Dòng 494:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            backupStatus = "Đã xóa đơn ${deleted.waybill}. Thông tin khách hàng vẫn được giữ lại."
```

**Dòng 495:** Phép so sánh/điều kiện.

```kotlin
        }.onFailure { error ->
```

**Dòng 496:** Elvis: dùng giá trị dự phòng khi null.

```kotlin
            backupStatus = "Không thể xóa đơn: ${error.message ?: "dữ liệu không hợp lệ"}"
```

**Dòng 497:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 498:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 499:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 500:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun updateCoordinates(request: CoordinateUpdateRequest) {
```

**Dòng 501:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        runCatching {
```

**Dòng 502:** Biến chỉ đọc.

```kotlin
            val result = CoordinateUpdateCoordinator.update(request, customerProfiles.mergeOrderCustomers(orders), orders)
```

**Dòng 503:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            orders.clear()
```

**Dòng 504:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            orders.addAll(result.orders)
```

**Dòng 505:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            persistOrders()
```

**Dòng 506:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            customerProfiles = CustomerProfileStore.replace(this, result.profiles)
```

**Dòng 507:** Biến chỉ đọc.

```kotlin
            val ordersText = result.updatedWaybills.size.takeIf { it > 0 }?.let { "$it đơn" }
```

**Dòng 508:** Biến chỉ đọc.

```kotlin
            val customersText = result.updatedProfileIds.size.takeIf { it > 0 }?.let { "$it khách hàng" }
```

**Dòng 509:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            backupStatus = "Đã cập nhật tọa độ cho ${listOfNotNull(ordersText, customersText).joinToString(" và ")}."
```

**Dòng 510:** Phép so sánh/điều kiện.

```kotlin
        }.onFailure { error ->
```

**Dòng 511:** Elvis: dùng giá trị dự phòng khi null.

```kotlin
            backupStatus = "Cập nhật tọa độ thất bại: ${error.message ?: "dữ liệu không hợp lệ"}"
```

**Dòng 512:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 513:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 514:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 515:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun syncOrdersFromCustomerCoordinates() {
```

**Dòng 516:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        runCatching {
```

**Dòng 517:** Biến chỉ đọc.

```kotlin
            val profiles = customerProfiles.mergeOrderCustomers(orders)
```

**Dòng 518:** Biến chỉ đọc.

```kotlin
            val result = CustomerCoordinateSyncCoordinator.sync(profiles, orders)
```

**Dòng 519:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            orders.clear()
```

**Dòng 520:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            orders.addAll(result.orders)
```

**Dòng 521:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            persistOrders()
```

**Dòng 522:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            customerProfiles = CustomerProfileStore.replace(this, profiles)
```

**Dòng 523:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            backupStatus = when {
```

**Dòng 524:** Phép so sánh/điều kiện.

```kotlin
                result.phoneMatchedWaybills.isEmpty() -> "Không có đơn nào khớp SĐT khách hàng đã lưu tọa độ."
```

**Dòng 525:** Nhánh thay thế.

```kotlin
                else -> "Đã rà ${result.phoneMatchedWaybills.size} đơn theo SĐT; cập nhật ${result.coordinateUpdatedWaybills.size} tọa độ và xếp lại ${result.resequencedWaybills.size} đơn."
```

**Dòng 526:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 527:** Phép so sánh/điều kiện.

```kotlin
        }.onFailure { error ->
```

**Dòng 528:** Elvis: dùng giá trị dự phòng khi null.

```kotlin
            backupStatus = "Rà soát SĐT thất bại: ${error.message ?: "dữ liệu không hợp lệ"}"
```

**Dòng 529:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 530:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 531:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 532:** Phép so sánh/điều kiện.

```kotlin
    private fun orderDocumentName(uri: Uri): String = contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
```

**Dòng 533:** Điều kiện if.

```kotlin
        if (cursor.moveToFirst()) cursor.getString(0) else null
```

**Dòng 534:** Elvis: dùng giá trị dự phòng khi null.

```kotlin
    } ?: uri.lastPathSegment.orEmpty()
```

**Dòng 535:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 536:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun persistOrders() = DeliveryOrderStore.replace(this, orders.toList())
```

**Dòng 537:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 538:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun openVtmanExport() {
```

**Dòng 539:** Biến chỉ đọc.

```kotlin
        val launchIntent = packageManager.getLaunchIntentForPackage(VtmanExportContract.packageName)
```

**Dòng 540:** Điều kiện if.

```kotlin
        if (launchIntent == null) {
```

**Dòng 541:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            Toast.makeText(this, VtmanExportContract.unavailableMessage, Toast.LENGTH_LONG).show()
```

**Dòng 542:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        } else {
```

**Dòng 543:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            startActivity(launchIntent)
```

**Dòng 544:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 545:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 546:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 547:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun exportBackupTo(uri: Uri) {
```

**Dòng 548:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        lifecycleScope.launch {
```

**Dòng 549:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            backupStatus = "Đang xuất file ZIP…"
```

**Dòng 550:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            runCatching {
```

**Dòng 551:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                withContext(Dispatchers.IO) {
```

**Dòng 552:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    contentResolver.openOutputStream(uri)?.use { CustomerBackupArchive.export(this@MainActivity, it) }
```

**Dòng 553:** Elvis: dùng giá trị dự phòng khi null.

```kotlin
                        ?: error("Không thể tạo file ZIP.")
```

**Dòng 554:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                }
```

**Dòng 555:** Phép so sánh/điều kiện.

```kotlin
            }.onSuccess { result -> backupStatus = result.exportMessage() }
```

**Dòng 556:** Elvis: dùng giá trị dự phòng khi null.

```kotlin
                .onFailure { backupStatus = "Xuất ZIP thất bại: ${it.message ?: "lỗi không xác định"}" }
```

**Dòng 557:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 558:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 559:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 560:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun importBackupFrom(uri: Uri) {
```

**Dòng 561:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        lifecycleScope.launch {
```

**Dòng 562:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            backupStatus = "Đang kiểm tra và nhập file ZIP…"
```

**Dòng 563:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            runCatching {
```

**Dòng 564:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                withContext(Dispatchers.IO) {
```

**Dòng 565:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    contentResolver.openInputStream(uri)?.use { CustomerBackupArchive.import(this@MainActivity, it) }
```

**Dòng 566:** Elvis: dùng giá trị dự phòng khi null.

```kotlin
                        ?: error("Không thể mở file ZIP.")
```

**Dòng 567:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                }
```

**Dòng 568:** Phép so sánh/điều kiện.

```kotlin
            }.onSuccess { result ->
```

**Dòng 569:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                refreshBackupData()
```

**Dòng 570:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                backupStatus = result.importMessage()
```

**Dòng 571:** Elvis: dùng giá trị dự phòng khi null.

```kotlin
            }.onFailure { backupStatus = "Nhập ZIP thất bại: ${it.message ?: "file không hợp lệ"}" }
```

**Dòng 572:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 573:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 574:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 575:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun refreshBackupData() {
```

**Dòng 576:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        evidence = DeliveryPhotoHistory.getEvidence(this)
```

**Dòng 577:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        customerProfiles = CustomerProfileStore.load(this)
```

**Dòng 578:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 579:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 580:** Phép so sánh/điều kiện.

```kotlin
    private fun CustomerBackupResult.exportMessage() = "Đã xuất ZIP: $customerCount khách, $imageCount ảnh WebP" + if (missingImageCount > 0) "; thiếu $missingImageCount ảnh không còn trên máy." else "."
```

**Dòng 581:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun CustomerBackupResult.importMessage() = "Đã nhập ZIP: $customerCount khách, $imageCount ảnh."
```

**Dòng 582:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun openDial(order: DeliveryOrder) = startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${order.phone}")))
```

**Dòng 583:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun openSms(order: DeliveryOrder, message: String) = startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${order.phone}")).putExtra("sms_body", message))
```

**Dòng 584:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun openZalo(order: DeliveryOrder, ignoredMessage: String) {
```

**Dòng 585:** Biến chỉ đọc.

```kotlin
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("zalo://conversation?phone=${order.phone}"))
```

**Dòng 586:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        runCatching { startActivity(intent) }.getOrElse {
```

**Dòng 587:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://zalo.me/${order.phone}")))
```

**Dòng 588:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 589:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 590:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun lastLocation() = runCatching {
```

**Dòng 591:** Biến chỉ đọc.

```kotlin
        val manager = getSystemService(LocationManager::class.java)
```

**Dòng 592:** Biến chỉ đọc.

```kotlin
        val now = System.currentTimeMillis()
```

**Dòng 593:** Biến chỉ đọc.

```kotlin
        val candidates: List<Location> = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)
```

**Dòng 594:** Biến đổi collection.

```kotlin
            .mapNotNull { provider -> runCatching { manager.getLastKnownLocation(provider) }.getOrNull() }
```

**Dòng 595:** Lọc collection.

```kotlin
            .filter { location -> RealtimeLocationPolicy.isUsableForCustomer(location.time, location.accuracy, now) }
```

**Dòng 596:** Phép so sánh/điều kiện.

```kotlin
        candidates.minWithOrNull(compareBy<Location> { it.accuracy }.thenByDescending { it.time })
```

**Dòng 597:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }.getOrNull()
```

**Dòng 598:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 599:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 600:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 601:** Đánh dấu hàm UI Compose.

```kotlin
@Composable
```

**Dòng 602:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
private fun DeliveryLaunchScreen() {
```

**Dòng 603:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    Image(
```

**Dòng 604:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        painter = painterResource(com.example.delivery.R.drawable.delivery_splash),
```

**Dòng 605:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        contentDescription = "Đang tải ứng dụng giao hàng",
```

**Dòng 606:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        modifier = Modifier.fillMaxSize().background(Color.White),
```

**Dòng 607:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        contentScale = ContentScale.Fit,
```

**Dòng 608:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    )
```

**Dòng 609:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

## `app/src/main/java/com/example/delivery/backup/CustomerBackupArchive.kt`

**Dòng 1:** Khai báo package/namespace.

```kotlin
package com.example.delivery.backup
```

**Dòng 2:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 3:** Import dependency.

```kotlin
import android.content.Context
```

**Dòng 4:** Import dependency.

```kotlin
import android.graphics.Bitmap
```

**Dòng 5:** Import dependency.

```kotlin
import android.graphics.BitmapFactory
```

**Dòng 6:** Import dependency.

```kotlin
import android.os.Build
```

**Dòng 7:** Import dependency.

```kotlin
import com.example.delivery.customer.CustomerProfileStore
```

**Dòng 8:** Import dependency.

```kotlin
import com.example.delivery.history.DeliveryPhotoHistory
```

**Dòng 9:** Import dependency.

```kotlin
import org.json.JSONArray
```

**Dòng 10:** Import dependency.

```kotlin
import org.json.JSONObject
```

**Dòng 11:** Import dependency.

```kotlin
import java.io.BufferedInputStream
```

**Dòng 12:** Import dependency.

```kotlin
import java.io.BufferedOutputStream
```

**Dòng 13:** Import dependency.

```kotlin
import java.io.File
```

**Dòng 14:** Import dependency.

```kotlin
import java.io.FileInputStream
```

**Dòng 15:** Import dependency.

```kotlin
import java.io.FileOutputStream
```

**Dòng 16:** Import dependency.

```kotlin
import java.io.InputStream
```

**Dòng 17:** Import dependency.

```kotlin
import java.io.OutputStream
```

**Dòng 18:** Import dependency.

```kotlin
import java.security.MessageDigest
```

**Dòng 19:** Import dependency.

```kotlin
import java.util.zip.ZipEntry
```

**Dòng 20:** Import dependency.

```kotlin
import java.util.zip.ZipInputStream
```

**Dòng 21:** Import dependency.

```kotlin
import java.util.zip.ZipOutputStream
```

**Dòng 22:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 23:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
internal object BackupArchiveRules {
```

**Dòng 24:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    const val FORMAT = "giaohang-customer-backup"
```

**Dòng 25:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    const val SCHEMA_VERSION = 1
```

**Dòng 26:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    const val MANIFEST = "manifest.json"
```

**Dòng 27:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    const val CUSTOMERS = "customers.json"
```

**Dòng 28:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    const val EVIDENCE = "transfer_evidence.json"
```

**Dòng 29:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    const val MAX_ENTRY_COUNT = 5_000
```

**Dòng 30:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    const val MAX_UNCOMPRESSED_BYTES = 350L * 1024L * 1024L
```

**Dòng 31:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    const val MAX_JSON_BYTES = 5L * 1024L * 1024L
```

**Dòng 32:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 33:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    fun isSafeArchivePath(path: String): Boolean {
```

**Dòng 34:** Điều kiện if.

```kotlin
        if (path.isBlank() || path.startsWith('/') || path.startsWith('\\')) return false
```

**Dòng 35:** Điều kiện if.

```kotlin
        if (':' in path) return false
```

**Dòng 36:** Kết thúc hàm và trả kết quả.

```kotlin
        return path.split('/').none { it.isBlank() || it == "." || it == ".." }
```

**Dòng 37:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 38:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 39:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    fun photoFolderForEntry(path: String): String? = when {
```

**Dòng 40:** Phép so sánh/điều kiện.

```kotlin
        path.startsWith("photos/customer_gate/") -> "customer_gate"
```

**Dòng 41:** Phép so sánh/điều kiện.

```kotlin
        path.startsWith("photos/bill/") -> "delivery_confirmation"
```

**Dòng 42:** Phép so sánh/điều kiện.

```kotlin
        path.startsWith("photos/drop_off/") -> "delivery_confirmation"
```

**Dòng 43:** Nhánh thay thế.

```kotlin
        else -> null
```

**Dòng 44:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 45:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 46:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 47:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
data class CustomerBackupResult(
```

**Dòng 48:** Biến chỉ đọc.

```kotlin
    val customerCount: Int,
```

**Dòng 49:** Biến chỉ đọc.

```kotlin
    val evidenceCount: Int,
```

**Dòng 50:** Biến chỉ đọc.

```kotlin
    val imageCount: Int,
```

**Dòng 51:** Biến chỉ đọc.

```kotlin
    val missingImageCount: Int = 0,
```

**Dòng 52:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
)
```

**Dòng 53:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 54:** Chú thích, không thực thi.

```kotlin
/**
```

**Dòng 55:** Chú thích, không thực thi.

```kotlin
 * Xuất và nhập snapshot dữ liệu Khách hàng và evidence chuyển khoản. Ảnh luôn được chuyển sang WebP
```

**Dòng 56:** Chú thích, không thực thi.

```kotlin
 * trong gói ZIP; dữ liệu đang chạy của ứng dụng tiếp tục dùng file ảnh riêng.
```

**Dòng 57:** Chú thích, không thực thi.

```kotlin
 */
```

**Dòng 58:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
object CustomerBackupArchive {
```

**Dòng 59:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    private const val WEBP_QUALITY = 84
```

**Dòng 60:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    private const val MAX_EXPORT_DIMENSION = 1920
```

**Dòng 61:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    private const val BUFFER_SIZE = 32 * 1024
```

**Dòng 62:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 63:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    fun export(context: Context, output: OutputStream): CustomerBackupResult {
```

**Dòng 64:** Biến chỉ đọc.

```kotlin
        val catalog = ExportPhotoCatalog()
```

**Dòng 65:** Biến chỉ đọc.

```kotlin
        val customersJson = rewriteCustomersForExport(CustomerProfileStore.snapshotJson(context), catalog)
```

**Dòng 66:** Biến chỉ đọc.

```kotlin
        val evidenceJson = rewriteEvidenceForExport(DeliveryPhotoHistory.snapshotEvidenceJson(context), catalog)
```

**Dòng 67:** Biến chỉ đọc.

```kotlin
        val entries = mutableListOf<ArchiveEntryInfo>()
```

**Dòng 68:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 69:** Phép so sánh/điều kiện.

```kotlin
        ZipOutputStream(BufferedOutputStream(output, BUFFER_SIZE)).use { zip ->
```

**Dòng 70:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            entries += zip.writeJson(BackupArchiveRules.CUSTOMERS, customersJson)
```

**Dòng 71:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            entries += zip.writeJson(BackupArchiveRules.EVIDENCE, evidenceJson)
```

**Dòng 72:** Phép so sánh/điều kiện.

```kotlin
            catalog.plans.values.forEach { plan -> entries += zip.writeWebp(plan) }
```

**Dòng 73:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 74:** Biến chỉ đọc.

```kotlin
            val manifest = JSONObject()
```

**Dòng 75:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                .put("format", BackupArchiveRules.FORMAT)
```

**Dòng 76:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                .put("schemaVersion", BackupArchiveRules.SCHEMA_VERSION)
```

**Dòng 77:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                .put("createdAt", System.currentTimeMillis())
```

**Dòng 78:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                .put("customers", JSONArray(customersJson).length())
```

**Dòng 79:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                .put("transferEvidence", JSONArray(evidenceJson).length())
```

**Dòng 80:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                .put("images", catalog.plans.size)
```

**Dòng 81:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                .put("missingImages", catalog.missingImageCount)
```

**Dòng 82:** Biến đổi collection.

```kotlin
                .put("entries", JSONArray(entries.map { it.toJson() }))
```

**Dòng 83:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            zip.writeJson(BackupArchiveRules.MANIFEST, manifest.toString())
```

**Dòng 84:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 85:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 86:** Kết thúc hàm và trả kết quả.

```kotlin
        return CustomerBackupResult(
```

**Dòng 87:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            customerCount = JSONArray(customersJson).length(),
```

**Dòng 88:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            evidenceCount = JSONArray(evidenceJson).length(),
```

**Dòng 89:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            imageCount = catalog.plans.size,
```

**Dòng 90:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            missingImageCount = catalog.missingImageCount,
```

**Dòng 91:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        )
```

**Dòng 92:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 93:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 94:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    fun import(context: Context, input: InputStream): CustomerBackupResult {
```

**Dòng 95:** Biến chỉ đọc.

```kotlin
        val temporaryRoot = File(context.cacheDir, "customer_backup_import_${System.nanoTime()}")
```

**Dòng 96:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        try {
```

**Dòng 97:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            temporaryRoot.mkdirs()
```

**Dòng 98:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            extractZip(input, temporaryRoot)
```

**Dòng 99:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 100:** Biến chỉ đọc.

```kotlin
            val manifestFile = File(temporaryRoot, BackupArchiveRules.MANIFEST)
```

**Dòng 101:** Biến chỉ đọc.

```kotlin
            val customerFile = File(temporaryRoot, BackupArchiveRules.CUSTOMERS)
```

**Dòng 102:** Biến chỉ đọc.

```kotlin
            val evidenceFile = File(temporaryRoot, BackupArchiveRules.EVIDENCE)
```

**Dòng 103:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            require(manifestFile.isFile && customerFile.isFile && evidenceFile.isFile) {
```

**Dòng 104:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                "ZIP thiếu file dữ liệu bắt buộc."
```

**Dòng 105:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 106:** Phép so sánh/điều kiện.

```kotlin
            require(manifestFile.length() <= BackupArchiveRules.MAX_JSON_BYTES && customerFile.length() <= BackupArchiveRules.MAX_JSON_BYTES && evidenceFile.length() <= BackupArchiveRules.MAX_JSON_BYTES) {
```

**Dòng 107:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                "Dữ liệu JSON trong ZIP vượt giới hạn cho phép."
```

**Dòng 108:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 109:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 110:** Biến chỉ đọc.

```kotlin
            val manifest = JSONObject(manifestFile.readText(Charsets.UTF_8))
```

**Dòng 111:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            validateManifest(manifest, temporaryRoot)
```

**Dòng 112:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 113:** Biến chỉ đọc.

```kotlin
            val customerRaw = customerFile.readText(Charsets.UTF_8)
```

**Dòng 114:** Biến chỉ đọc.

```kotlin
            val evidenceRaw = evidenceFile.readText(Charsets.UTF_8)
```

**Dòng 115:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            CustomerProfileStore.validateBackupJson(customerRaw)
```

**Dòng 116:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            DeliveryPhotoHistory.validateBackupJson(evidenceRaw)
```

**Dòng 117:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 118:** Biến chỉ đọc.

```kotlin
            val photoPaths = copyPhotosToApplicationStorage(context, manifest, temporaryRoot)
```

**Dòng 119:** Biến chỉ đọc.

```kotlin
            val customerJson = rewriteCustomersForImport(customerRaw, photoPaths)
```

**Dòng 120:** Biến chỉ đọc.

```kotlin
            val evidenceJson = rewriteEvidenceForImport(evidenceRaw, photoPaths)
```

**Dòng 121:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 122:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            CustomerProfileStore.validateBackupJson(customerJson)
```

**Dòng 123:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            DeliveryPhotoHistory.validateBackupJson(evidenceJson)
```

**Dòng 124:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            CustomerProfileStore.replaceFromBackupJson(context, customerJson)
```

**Dòng 125:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            DeliveryPhotoHistory.replaceFromBackupJson(context, evidenceJson)
```

**Dòng 126:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 127:** Kết thúc hàm và trả kết quả.

```kotlin
            return CustomerBackupResult(
```

**Dòng 128:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                customerCount = JSONArray(customerJson).length(),
```

**Dòng 129:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                evidenceCount = JSONArray(evidenceJson).length(),
```

**Dòng 130:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    imageCount = photoPaths.size,
```

**Dòng 131:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            )
```

**Dòng 132:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        } finally {
```

**Dòng 133:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            temporaryRoot.deleteRecursively()
```

**Dòng 134:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 135:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 136:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 137:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun rewriteCustomersForExport(raw: String, catalog: ExportPhotoCatalog): String {
```

**Dòng 138:** Biến chỉ đọc.

```kotlin
        val customers = JSONArray(raw)
```

**Dòng 139:** Phép so sánh/điều kiện.

```kotlin
        repeat(customers.length()) { customerIndex ->
```

**Dòng 140:** Biến chỉ đọc.

```kotlin
            val addresses = customers.getJSONObject(customerIndex).optJSONArray("addresses") ?: JSONArray()
```

**Dòng 141:** Phép so sánh/điều kiện.

```kotlin
            repeat(addresses.length()) { addressIndex ->
```

**Dòng 142:** Biến chỉ đọc.

```kotlin
                val address = addresses.getJSONObject(addressIndex)
```

**Dòng 143:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                address.put("housePhoto", catalog.reference(address.optString("housePhoto"), "customer_gate"))
```

**Dòng 144:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 145:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 146:** Kết thúc hàm và trả kết quả.

```kotlin
        return customers.toString()
```

**Dòng 147:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 148:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 149:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun rewriteEvidenceForExport(raw: String, catalog: ExportPhotoCatalog): String {
```

**Dòng 150:** Biến chỉ đọc.

```kotlin
        val evidence = JSONArray(raw)
```

**Dòng 151:** Phép so sánh/điều kiện.

```kotlin
        repeat(evidence.length()) { index ->
```

**Dòng 152:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            evidence.getJSONObject(index).apply {
```

**Dòng 153:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                put("bill", catalog.reference(optString("bill"), "bill"))
```

**Dòng 154:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                put("drop", catalog.reference(optString("drop"), "drop_off"))
```

**Dòng 155:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 156:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 157:** Kết thúc hàm và trả kết quả.

```kotlin
        return evidence.toString()
```

**Dòng 158:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 159:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 160:** Phép so sánh/điều kiện.

```kotlin
    private fun rewriteCustomersForImport(raw: String, photoPaths: Map<String, String>): String {
```

**Dòng 161:** Biến chỉ đọc.

```kotlin
        val customers = JSONArray(raw)
```

**Dòng 162:** Phép so sánh/điều kiện.

```kotlin
        repeat(customers.length()) { customerIndex ->
```

**Dòng 163:** Biến chỉ đọc.

```kotlin
            val addresses = customers.getJSONObject(customerIndex).optJSONArray("addresses") ?: JSONArray()
```

**Dòng 164:** Phép so sánh/điều kiện.

```kotlin
            repeat(addresses.length()) { addressIndex ->
```

**Dòng 165:** Biến chỉ đọc.

```kotlin
                val address = addresses.getJSONObject(addressIndex)
```

**Dòng 166:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                address.put("housePhoto", resolvePhotoPath(address.optString("housePhoto"), photoPaths))
```

**Dòng 167:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 168:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 169:** Kết thúc hàm và trả kết quả.

```kotlin
        return customers.toString()
```

**Dòng 170:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 171:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 172:** Phép so sánh/điều kiện.

```kotlin
    private fun rewriteEvidenceForImport(raw: String, photoPaths: Map<String, String>): String {
```

**Dòng 173:** Biến chỉ đọc.

```kotlin
        val evidence = JSONArray(raw)
```

**Dòng 174:** Phép so sánh/điều kiện.

```kotlin
        repeat(evidence.length()) { index ->
```

**Dòng 175:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            evidence.getJSONObject(index).apply {
```

**Dòng 176:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                put("bill", resolvePhotoPath(optString("bill"), photoPaths))
```

**Dòng 177:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                put("drop", resolvePhotoPath(optString("drop"), photoPaths))
```

**Dòng 178:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 179:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 180:** Kết thúc hàm và trả kết quả.

```kotlin
        return evidence.toString()
```

**Dòng 181:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 182:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 183:** Phép so sánh/điều kiện.

```kotlin
    private fun resolvePhotoPath(reference: String, photoPaths: Map<String, String>): String? {
```

**Dòng 184:** Điều kiện if.

```kotlin
        if (reference.isBlank() || reference == "null") return null
```

**Dòng 185:** Kết thúc hàm và trả kết quả.

```kotlin
        return photoPaths[reference] ?: throw IllegalArgumentException("ZIP tham chiếu ảnh không tồn tại: $reference")
```

**Dòng 186:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 187:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 188:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun extractZip(input: InputStream, root: File) {
```

**Dòng 189:** Biến chỉ đọc.

```kotlin
        val rootPath = root.canonicalPath + File.separator
```

**Dòng 190:** Biến có thể thay đổi.

```kotlin
        var entryCount = 0
```

**Dòng 191:** Biến có thể thay đổi.

```kotlin
        var totalBytes = 0L
```

**Dòng 192:** Biến chỉ đọc.

```kotlin
        val names = mutableSetOf<String>()
```

**Dòng 193:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 194:** Phép so sánh/điều kiện.

```kotlin
        ZipInputStream(BufferedInputStream(input, BUFFER_SIZE)).use { zip ->
```

**Dòng 195:** Biến có thể thay đổi.

```kotlin
            var entry = zip.nextEntry
```

**Dòng 196:** Phép so sánh/điều kiện.

```kotlin
            while (entry != null) {
```

**Dòng 197:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                entryCount += 1
```

**Dòng 198:** Phép so sánh/điều kiện.

```kotlin
                require(entryCount <= BackupArchiveRules.MAX_ENTRY_COUNT) { "ZIP có quá nhiều file." }
```

**Dòng 199:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                require(BackupArchiveRules.isSafeArchivePath(entry.name) && names.add(entry.name)) { "ZIP có đường dẫn không an toàn." }
```

**Dòng 200:** Biến chỉ đọc.

```kotlin
                val destination = File(root, entry.name)
```

**Dòng 201:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                require(destination.canonicalPath.startsWith(rootPath)) { "ZIP có đường dẫn không an toàn." }
```

**Dòng 202:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 203:** Điều kiện if.

```kotlin
                if (entry.isDirectory) {
```

**Dòng 204:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    destination.mkdirs()
```

**Dòng 205:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                } else {
```

**Dòng 206:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    destination.parentFile?.mkdirs()
```

**Dòng 207:** Phép so sánh/điều kiện.

```kotlin
                    FileOutputStream(destination).use { target ->
```

**Dòng 208:** Biến chỉ đọc.

```kotlin
                        val buffer = ByteArray(BUFFER_SIZE)
```

**Dòng 209:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        while (true) {
```

**Dòng 210:** Biến chỉ đọc.

```kotlin
                            val read = zip.read(buffer)
```

**Dòng 211:** Điều kiện if.

```kotlin
                            if (read <= 0) break
```

**Dòng 212:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                            totalBytes += read
```

**Dòng 213:** Phép so sánh/điều kiện.

```kotlin
                            require(totalBytes <= BackupArchiveRules.MAX_UNCOMPRESSED_BYTES) { "ZIP vượt giới hạn dung lượng giải nén." }
```

**Dòng 214:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                            target.write(buffer, 0, read)
```

**Dòng 215:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        }
```

**Dòng 216:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    }
```

**Dòng 217:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                }
```

**Dòng 218:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                zip.closeEntry()
```

**Dòng 219:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                entry = zip.nextEntry
```

**Dòng 220:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 221:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 222:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 223:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 224:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun validateManifest(manifest: JSONObject, root: File) {
```

**Dòng 225:** Phép so sánh/điều kiện.

```kotlin
        require(manifest.optString("format") == BackupArchiveRules.FORMAT) { "Không phải file sao lưu Giao Hàng hợp lệ." }
```

**Dòng 226:** Phép so sánh/điều kiện.

```kotlin
        require(manifest.optInt("schemaVersion") == BackupArchiveRules.SCHEMA_VERSION) { "Phiên bản file sao lưu chưa được hỗ trợ." }
```

**Dòng 227:** Biến chỉ đọc.

```kotlin
        val entries = manifest.optJSONArray("entries") ?: throw IllegalArgumentException("ZIP thiếu danh sách kiểm tra.")
```

**Dòng 228:** Biến chỉ đọc.

```kotlin
        val declared = mutableSetOf<String>()
```

**Dòng 229:** Phép so sánh/điều kiện.

```kotlin
        repeat(entries.length()) { index ->
```

**Dòng 230:** Biến chỉ đọc.

```kotlin
            val item = entries.getJSONObject(index)
```

**Dòng 231:** Biến chỉ đọc.

```kotlin
            val path = item.getString("path")
```

**Dòng 232:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            require(BackupArchiveRules.isSafeArchivePath(path) && declared.add(path)) { "Danh sách file trong ZIP không hợp lệ." }
```

**Dòng 233:** Biến chỉ đọc.

```kotlin
            val file = File(root, path)
```

**Dòng 234:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            require(file.isFile) { "ZIP thiếu file: $path" }
```

**Dòng 235:** Phép so sánh/điều kiện.

```kotlin
            require(file.length() == item.getLong("bytes")) { "Kích thước file không khớp: $path" }
```

**Dòng 236:** Phép so sánh/điều kiện.

```kotlin
            require(sha256(file) == item.getString("sha256")) { "Checksum không khớp: $path" }
```

**Dòng 237:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 238:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        require(BackupArchiveRules.CUSTOMERS in declared && BackupArchiveRules.EVIDENCE in declared) {
```

**Dòng 239:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            "ZIP thiếu dữ liệu chính."
```

**Dòng 240:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 241:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 242:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 243:** Phép so sánh/điều kiện.

```kotlin
    private fun copyPhotosToApplicationStorage(context: Context, manifest: JSONObject, root: File): Map<String, String> {
```

**Dòng 244:** Biến chỉ đọc.

```kotlin
        val entries = manifest.getJSONArray("entries")
```

**Dòng 245:** Biến chỉ đọc.

```kotlin
        val paths = linkedMapOf<String, String>()
```

**Dòng 246:** Phép so sánh/điều kiện.

```kotlin
        repeat(entries.length()) { index ->
```

**Dòng 247:** Biến chỉ đọc.

```kotlin
            val path = entries.getJSONObject(index).getString("path")
```

**Dòng 248:** Biến chỉ đọc.

```kotlin
            val targetFolder = BackupArchiveRules.photoFolderForEntry(path) ?: return@repeat
```

**Dòng 249:** Biến chỉ đọc.

```kotlin
            val source = File(root, path)
```

**Dòng 250:** Biến chỉ đọc.

```kotlin
            val targetDir = File(context.filesDir, targetFolder).apply { mkdirs() }
```

**Dòng 251:** Biến chỉ đọc.

```kotlin
            val target = File(targetDir, File(path).name)
```

**Dòng 252:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            source.copyTo(target, overwrite = true)
```

**Dòng 253:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            paths[path] = target.absolutePath
```

**Dòng 254:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 255:** Kết thúc hàm và trả kết quả.

```kotlin
        return paths
```

**Dòng 256:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 257:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 258:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun ZipOutputStream.writeJson(path: String, json: String): ArchiveEntryInfo {
```

**Dòng 259:** Biến chỉ đọc.

```kotlin
        val bytes = json.toByteArray(Charsets.UTF_8)
```

**Dòng 260:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        putNextEntry(ZipEntry(path))
```

**Dòng 261:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        write(bytes)
```

**Dòng 262:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        closeEntry()
```

**Dòng 263:** Kết thúc hàm và trả kết quả.

```kotlin
        return ArchiveEntryInfo(path, bytes.size.toLong(), sha256(bytes))
```

**Dòng 264:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 265:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 266:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun ZipOutputStream.writeWebp(plan: PhotoPlan): ArchiveEntryInfo {
```

**Dòng 267:** Biến chỉ đọc.

```kotlin
        val bitmap = decodeForBackup(plan.source) ?: throw IllegalStateException("Không đọc được ảnh: ${plan.source.name}")
```

**Dòng 268:** Biến chỉ đọc.

```kotlin
        val digest = MessageDigest.getInstance("SHA-256")
```

**Dòng 269:** Biến có thể thay đổi.

```kotlin
        var byteCount = 0L
```

**Dòng 270:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        try {
```

**Dòng 271:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            putNextEntry(ZipEntry(plan.archivePath))
```

**Dòng 272:** Biến chỉ đọc.

```kotlin
            val output = object : OutputStream() {
```

**Dòng 273:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
                override fun write(value: Int) {
```

**Dòng 274:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    digest.update(value.toByte())
```

**Dòng 275:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    this@writeWebp.write(value)
```

**Dòng 276:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    byteCount += 1
```

**Dòng 277:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                }
```

**Dòng 278:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 279:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
                override fun write(buffer: ByteArray, offset: Int, length: Int) {
```

**Dòng 280:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    digest.update(buffer, offset, length)
```

**Dòng 281:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    this@writeWebp.write(buffer, offset, length)
```

**Dòng 282:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    byteCount += length
```

**Dòng 283:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                }
```

**Dòng 284:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 285:** Biến chỉ đọc.

```kotlin
            val format = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) Bitmap.CompressFormat.WEBP_LOSSY else Bitmap.CompressFormat.WEBP
```

**Dòng 286:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            check(bitmap.compress(format, WEBP_QUALITY, output)) { "Không thể nén ảnh WebP: ${plan.source.name}" }
```

**Dòng 287:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            closeEntry()
```

**Dòng 288:** Kết thúc hàm và trả kết quả.

```kotlin
            return ArchiveEntryInfo(plan.archivePath, byteCount, digest.digest().toHex())
```

**Dòng 289:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        } finally {
```

**Dòng 290:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            bitmap.recycle()
```

**Dòng 291:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 292:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 293:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 294:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun decodeForBackup(file: File): Bitmap? {
```

**Dòng 295:** Biến chỉ đọc.

```kotlin
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
```

**Dòng 296:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        BitmapFactory.decodeFile(file.path, bounds)
```

**Dòng 297:** Điều kiện if.

```kotlin
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
```

**Dòng 298:** Biến chỉ đọc.

```kotlin
        val options = BitmapFactory.Options().apply {
```

**Dòng 299:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            inSampleSize = sampleSize(bounds.outWidth, bounds.outHeight)
```

**Dòng 300:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            inPreferredConfig = Bitmap.Config.ARGB_8888
```

**Dòng 301:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 302:** Kết thúc hàm và trả kết quả.

```kotlin
        return BitmapFactory.decodeFile(file.path, options)
```

**Dòng 303:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 304:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 305:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun sampleSize(width: Int, height: Int): Int {
```

**Dòng 306:** Biến có thể thay đổi.

```kotlin
        var sample = 1
```

**Dòng 307:** Phép so sánh/điều kiện.

```kotlin
        while (width / sample > MAX_EXPORT_DIMENSION || height / sample > MAX_EXPORT_DIMENSION) sample *= 2
```

**Dòng 308:** Kết thúc hàm và trả kết quả.

```kotlin
        return sample
```

**Dòng 309:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 310:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 311:** Phép so sánh/điều kiện.

```kotlin
    private fun sha256(file: File): String = FileInputStream(file).use { input ->
```

**Dòng 312:** Biến chỉ đọc.

```kotlin
        val digest = MessageDigest.getInstance("SHA-256")
```

**Dòng 313:** Biến chỉ đọc.

```kotlin
        val buffer = ByteArray(BUFFER_SIZE)
```

**Dòng 314:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        while (true) {
```

**Dòng 315:** Biến chỉ đọc.

```kotlin
            val read = input.read(buffer)
```

**Dòng 316:** Điều kiện if.

```kotlin
            if (read <= 0) break
```

**Dòng 317:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            digest.update(buffer, 0, read)
```

**Dòng 318:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 319:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        digest.digest().toHex()
```

**Dòng 320:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 321:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 322:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun sha256(bytes: ByteArray): String = MessageDigest.getInstance("SHA-256").digest(bytes).toHex()
```

**Dòng 323:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 324:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun ByteArray.toHex(): String = joinToString("") { "%02x".format(it.toInt() and 0xff) }
```

**Dòng 325:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 326:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    private data class ArchiveEntryInfo(val path: String, val bytes: Long, val sha256: String) {
```

**Dòng 327:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
        fun toJson() = JSONObject().put("path", path).put("bytes", bytes).put("sha256", sha256)
```

**Dòng 328:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 329:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 330:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    private data class PhotoPlan(val source: File, val archivePath: String)
```

**Dòng 331:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 332:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    private class ExportPhotoCatalog {
```

**Dòng 333:** Biến chỉ đọc.

```kotlin
        val plans = linkedMapOf<String, PhotoPlan>()
```

**Dòng 334:** Biến có thể thay đổi.

```kotlin
        var missingImageCount = 0
```

**Dòng 335:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            private set
```

**Dòng 336:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        private var nextIndex = 1
```

**Dòng 337:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 338:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
        fun reference(originalPath: String, category: String): String? {
```

**Dòng 339:** Điều kiện if.

```kotlin
            if (originalPath.isBlank() || originalPath == "null") return null
```

**Dòng 340:** Biến chỉ đọc.

```kotlin
            val source = File(originalPath)
```

**Dòng 341:** Điều kiện if.

```kotlin
            if (!source.isFile) {
```

**Dòng 342:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                missingImageCount += 1
```

**Dòng 343:** Kết thúc hàm và trả kết quả.

```kotlin
                return null
```

**Dòng 344:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 345:** Kết thúc hàm và trả kết quả.

```kotlin
            return plans.getOrPut(source.canonicalPath) {
```

**Dòng 346:** Biến chỉ đọc.

```kotlin
                val archivePath = "photos/$category/${category}_${nextIndex++}.webp"
```

**Dòng 347:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                PhotoPlan(source, archivePath)
```

**Dòng 348:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }.archivePath
```

**Dòng 349:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 350:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 351:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

## `app/src/main/java/com/example/delivery/cash/CashAuditCalculator.kt`

**Dòng 1:** Khai báo package/namespace.

```kotlin
package com.example.delivery.cash
```

**Dòng 2:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 3:** Import dependency.

```kotlin
import java.text.NumberFormat
```

**Dòng 4:** Import dependency.

```kotlin
import java.util.Locale
```

**Dòng 5:** Import dependency.

```kotlin
import kotlin.math.abs
```

**Dòng 6:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 7:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
enum class CashAuditStatus { SURPLUS, DEFICIT, BALANCED }
```

**Dòng 8:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 9:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
data class CashAuditResult(
```

**Dòng 10:** Biến chỉ đọc.

```kotlin
    val cashTotal: Long,
```

**Dòng 11:** Biến chỉ đọc.

```kotlin
    val difference: Long,
```

**Dòng 12:** Biến chỉ đọc.

```kotlin
    val status: CashAuditStatus,
```

**Dòng 13:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
)
```

**Dòng 14:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 15:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
object CashAuditCalculator {
```

**Dòng 16:** Biến chỉ đọc.

```kotlin
    val denominations = listOf(500_000L, 200_000L, 100_000L, 50_000L)
```

**Dòng 17:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 18:** Phép so sánh/điều kiện.

```kotlin
    fun cashTotal(counts: Map<Long, Int>): Long = denominations.sumOf { denomination ->
```

**Dòng 19:** Elvis: dùng giá trị dự phòng khi null.

```kotlin
        denomination * (counts[denomination] ?: 0).coerceAtLeast(0).toLong()
```

**Dòng 20:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 21:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 22:** Chú thích, không thực thi.

```kotlin
    /** (Tổng tiền mặt + Bank) - (Cước + COD). */
```

**Dòng 23:** Phép so sánh/điều kiện.

```kotlin
    fun calculate(counts: Map<Long, Int>, cod: Long, fee: Long, bank: Long): CashAuditResult {
```

**Dòng 24:** Biến chỉ đọc.

```kotlin
        val cash = cashTotal(counts)
```

**Dòng 25:** Biến chỉ đọc.

```kotlin
        val difference = (cash + bank.coerceAtLeast(0)) - (fee.coerceAtLeast(0) + cod.coerceAtLeast(0))
```

**Dòng 26:** Biến chỉ đọc.

```kotlin
        val status = when {
```

**Dòng 27:** Phép so sánh/điều kiện.

```kotlin
            difference > 0 -> CashAuditStatus.SURPLUS
```

**Dòng 28:** Phép so sánh/điều kiện.

```kotlin
            difference < 0 -> CashAuditStatus.DEFICIT
```

**Dòng 29:** Nhánh thay thế.

```kotlin
            else -> CashAuditStatus.BALANCED
```

**Dòng 30:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 31:** Kết thúc hàm và trả kết quả.

```kotlin
        return CashAuditResult(cashTotal = cash, difference = difference, status = status)
```

**Dòng 32:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 33:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 34:** Lọc collection.

```kotlin
    fun parseAmount(raw: String): Long = raw.filter(Char::isDigit).toLongOrNull() ?: 0L
```

**Dòng 35:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 36:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    fun formatAmount(amount: Long): String = NumberFormat.getIntegerInstance(Locale.US).format(abs(amount))
```

**Dòng 37:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

## `app/src/main/java/com/example/delivery/cash/CashAuditStore.kt`

**Dòng 1:** Khai báo package/namespace.

```kotlin
package com.example.delivery.cash
```

**Dòng 2:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 3:** Import dependency.

```kotlin
import android.content.Context
```

**Dòng 4:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 5:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
data class CashAuditState(
```

**Dòng 6:** Biến chỉ đọc.

```kotlin
    val counts: Map<Long, Int> = CashAuditCalculator.denominations.associateWith { 0 },
```

**Dòng 7:** Biến chỉ đọc.

```kotlin
    val bankInput: String = "",
```

**Dòng 8:** Biến chỉ đọc.

```kotlin
    val feeInput: String = "",
```

**Dòng 9:** Biến chỉ đọc.

```kotlin
    val codInput: String = "",
```

**Dòng 10:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
) {
```

**Dòng 11:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    fun normalized(): CashAuditState = copy(
```

**Dòng 12:** Tạo Map key/value.

```kotlin
        counts = CashAuditCalculator.denominations.associateWith { denomination ->
```

**Dòng 13:** Elvis: dùng giá trị dự phòng khi null.

```kotlin
            (counts[denomination] ?: 0).coerceIn(0, 999)
```

**Dòng 14:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        },
```

**Dòng 15:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    )
```

**Dòng 16:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 17:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 18:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
object CashAuditStore {
```

**Dòng 19:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    private const val PREFERENCES = "cash_audit_state_v1"
```

**Dòng 20:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    private const val BANK = "bank"
```

**Dòng 21:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    private const val FEE = "fee"
```

**Dòng 22:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    private const val COD = "cod"
```

**Dòng 23:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 24:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    fun load(context: Context): CashAuditState {
```

**Dòng 25:** Biến chỉ đọc.

```kotlin
        val preferences = context.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE)
```

**Dòng 26:** Kết thúc hàm và trả kết quả.

```kotlin
        return CashAuditState(
```

**Dòng 27:** Tạo Map key/value.

```kotlin
            counts = CashAuditCalculator.denominations.associateWith { denomination ->
```

**Dòng 28:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                preferences.getInt(countKey(denomination), 0).coerceIn(0, 999)
```

**Dòng 29:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            },
```

**Dòng 30:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            bankInput = preferences.getString(BANK, "").orEmpty(),
```

**Dòng 31:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            feeInput = preferences.getString(FEE, "").orEmpty(),
```

**Dòng 32:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            codInput = preferences.getString(COD, "").orEmpty(),
```

**Dòng 33:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        )
```

**Dòng 34:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 35:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 36:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    fun save(context: Context, state: CashAuditState) {
```

**Dòng 37:** Biến chỉ đọc.

```kotlin
        val normalized = state.normalized()
```

**Dòng 38:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        context.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE).edit().apply {
```

**Dòng 39:** Phép so sánh/điều kiện.

```kotlin
            normalized.counts.forEach { (denomination, count) -> putInt(countKey(denomination), count) }
```

**Dòng 40:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            putString(BANK, normalized.bankInput)
```

**Dòng 41:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            putString(FEE, normalized.feeInput)
```

**Dòng 42:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            putString(COD, normalized.codInput)
```

**Dòng 43:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            apply()
```

**Dòng 44:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 45:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 46:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 47:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    fun reset(context: Context) {
```

**Dòng 48:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        context.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE).edit().clear().apply()
```

**Dòng 49:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 50:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 51:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun countKey(denomination: Long): String = "count_$denomination"
```

**Dòng 52:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

## `app/src/main/java/com/example/delivery/contact/ZaloPhone.kt`

**Dòng 1:** Khai báo package/namespace.

```kotlin
package com.example.delivery.contact
```

**Dòng 2:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 3:** Chú thích, không thực thi.

```kotlin
/** Chuẩn hóa số Việt Nam để Zalo nhận diện liên hệ theo đầu số quốc tế 84. */
```

**Dòng 4:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
fun zaloPhoneNumber(rawPhone: String): String? {
```

**Dòng 5:** Biến chỉ đọc.

```kotlin
    val digits = rawPhone.filter(Char::isDigit)
```

**Dòng 6:** Biến chỉ đọc.

```kotlin
    val international = when {
```

**Dòng 7:** Phép so sánh/điều kiện.

```kotlin
        digits.startsWith("0084") -> digits.removePrefix("00")
```

**Dòng 8:** Phép so sánh/điều kiện.

```kotlin
        digits.startsWith("84") -> digits
```

**Dòng 9:** Phép so sánh/điều kiện.

```kotlin
        digits.startsWith("0") -> "84${digits.drop(1)}"
```

**Dòng 10:** Nhánh thay thế.

```kotlin
        else -> digits
```

**Dòng 11:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 12:** Kết thúc hàm và trả kết quả.

```kotlin
    return international.takeIf { it.startsWith("84") && it.length in 11..12 }
```

**Dòng 13:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 14:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 15:** Chú thích, không thực thi.

```kotlin
/** Số dạng E.164 mà Android Danh bạ truyền cho các ứng dụng nhắn tin. */
```

**Dòng 16:** Safe-call: chỉ chạy khi khác null.

```kotlin
fun zaloContactPhone(rawPhone: String): String? = zaloPhoneNumber(rawPhone)?.let { "+$it" }
```

## `app/src/main/java/com/example/delivery/customer/CustomerProfile.kt`

**Dòng 1:** Khai báo package/namespace.

```kotlin
package com.example.delivery.customer
```

**Dòng 2:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 3:** Import dependency.

```kotlin
import android.content.Context
```

**Dòng 4:** Import dependency.

```kotlin
import com.example.delivery.model.DeliveryOrder
```

**Dòng 5:** Import dependency.

```kotlin
import com.example.delivery.model.hasStoredCoordinates
```

**Dòng 6:** Import dependency.

```kotlin
import com.example.delivery.model.isMapCoordinatePair
```

**Dòng 7:** Import dependency.

```kotlin
import org.json.JSONArray
```

**Dòng 8:** Import dependency.

```kotlin
import org.json.JSONObject
```

**Dòng 9:** Import dependency.

```kotlin
import java.text.Normalizer
```

**Dòng 10:** Import dependency.

```kotlin
import java.util.Locale
```

**Dòng 11:** Import dependency.

```kotlin
import java.util.UUID
```

**Dòng 12:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 13:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
enum class CustomerContactMethod(val label: String) {
```

**Dòng 14:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    CALL("Gọi"),
```

**Dòng 15:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    SMS("SMS"),
```

**Dòng 16:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    ZALO("Zalo"),
```

**Dòng 17:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 18:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 19:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
data class CustomerPhone(
```

**Dòng 20:** Biến chỉ đọc.

```kotlin
    val number: String,
```

**Dòng 21:** Biến chỉ đọc.

```kotlin
    val isPrimary: Boolean = false,
```

**Dòng 22:** Biến chỉ đọc.

```kotlin
    val methods: Set<CustomerContactMethod> = setOf(CustomerContactMethod.CALL, CustomerContactMethod.SMS, CustomerContactMethod.ZALO),
```

**Dòng 23:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
)
```

**Dòng 24:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 25:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
data class CustomerAddress(
```

**Dòng 26:** Biến chỉ đọc.

```kotlin
    val address: String,
```

**Dòng 27:** Biến chỉ đọc.

```kotlin
    val latitude: Double? = null,
```

**Dòng 28:** Biến chỉ đọc.

```kotlin
    val longitude: Double? = null,
```

**Dòng 29:** Biến chỉ đọc.

```kotlin
    val isPrimary: Boolean = false,
```

**Dòng 30:** Biến chỉ đọc.

```kotlin
    val housePhotoPath: String? = null,
```

**Dòng 31:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
)
```

**Dòng 32:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 33:** Chú thích, không thực thi.

```kotlin
/** Chuẩn hóa tọa độ khách đã lưu nhầm theo thứ tự Kinh độ, Vĩ độ. */
```

**Dòng 34:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
fun CustomerAddress.normalizedCoordinates(): CustomerAddress = when {
```

**Dòng 35:** Phép so sánh/điều kiện.

```kotlin
    latitude == null || longitude == null -> this
```

**Dòng 36:** Phép so sánh/điều kiện.

```kotlin
    isMapCoordinatePair(latitude, longitude) -> this
```

**Dòng 37:** Phép so sánh/điều kiện.

```kotlin
    isMapCoordinatePair(longitude, latitude) -> copy(latitude = longitude, longitude = latitude)
```

**Dòng 38:** Nhánh thay thế.

```kotlin
    else -> copy(latitude = null, longitude = null)
```

**Dòng 39:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 40:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 41:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
data class CustomerProfile(
```

**Dòng 42:** Biến chỉ đọc.

```kotlin
    val id: String = UUID.randomUUID().toString(),
```

**Dòng 43:** Biến chỉ đọc.

```kotlin
    val name: String = "",
```

**Dòng 44:** Biến chỉ đọc.

```kotlin
    val names: List<String> = emptyList(),
```

**Dòng 45:** Biến chỉ đọc.

```kotlin
    val phones: List<CustomerPhone> = listOf(CustomerPhone("", isPrimary = true)),
```

**Dòng 46:** Biến chỉ đọc.

```kotlin
    val addresses: List<CustomerAddress> = listOf(CustomerAddress("", isPrimary = true)),
```

**Dòng 47:** Biến chỉ đọc.

```kotlin
    val note: String = "",
```

**Dòng 48:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
) {
```

**Dòng 49:** Biến chỉ đọc.

```kotlin
    val displayName: String get() = names.firstOrNull { it.isNotBlank() } ?: name
```

**Dòng 50:** Biến chỉ đọc.

```kotlin
    val primaryPhone: CustomerPhone
```

**Dòng 51:** Lấy phần tử đầu hoặc null.

```kotlin
        get() = phones.firstOrNull { it.isPrimary }
```

**Dòng 52:** Lấy phần tử đầu hoặc null.

```kotlin
            ?: phones.firstOrNull()
```

**Dòng 53:** Elvis: dùng giá trị dự phòng khi null.

```kotlin
            ?: CustomerPhone(number = "", isPrimary = true)
```

**Dòng 54:** Biến chỉ đọc.

```kotlin
    val primaryAddress: CustomerAddress
```

**Dòng 55:** Lấy phần tử đầu hoặc null.

```kotlin
        get() = addresses.firstOrNull { it.isPrimary }
```

**Dòng 56:** Lấy phần tử đầu hoặc null.

```kotlin
            ?: addresses.firstOrNull()
```

**Dòng 57:** Elvis: dùng giá trị dự phòng khi null.

```kotlin
            ?: CustomerAddress(address = "", isPrimary = true)
```

**Dòng 58:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 59:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    fun normalized(): CustomerProfile {
```

**Dòng 60:** Biến chỉ đọc.

```kotlin
        val cleanNames = (names + name).map(String::trim).filter(String::isNotBlank).distinct()
```

**Dòng 61:** Biến chỉ đọc.

```kotlin
        val cleanPhones = phones.map { it.copy(number = it.number.trim()) }.filter { it.number.isNotBlank() }
```

**Dòng 62:** Biến chỉ đọc.

```kotlin
        val normalizedPhones = cleanPhones.map { phone ->
```

**Dòng 63:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            phone.copy(methods = phone.methods.ifEmpty {
```

**Dòng 64:** Điều kiện if.

```kotlin
                if (cleanPhones.size == 1) CustomerContactMethod.entries.toSet()
```

**Dòng 65:** Nhánh thay thế.

```kotlin
                else setOf(CustomerContactMethod.CALL)
```

**Dòng 66:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            })
```

**Dòng 67:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 68:** Biến chỉ đọc.

```kotlin
        val cleanAddresses = addresses.map { it.normalizedCoordinates().copy(address = it.address.trim()) }.filter { it.address.isNotBlank() }
```

**Dòng 69:** Biến chỉ đọc.

```kotlin
        val primaryPhoneIndex = cleanPhones.indexOfFirst { it.isPrimary }.takeIf { it >= 0 } ?: 0
```

**Dòng 70:** Biến chỉ đọc.

```kotlin
        val primaryAddressIndex = cleanAddresses.indexOfFirst { it.isPrimary }.takeIf { it >= 0 } ?: 0
```

**Dòng 71:** Kết thúc hàm và trả kết quả.

```kotlin
        return copy(
```

**Dòng 72:** Lấy phần tử đầu hoặc null.

```kotlin
            name = cleanNames.firstOrNull().orEmpty(),
```

**Dòng 73:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            names = cleanNames,
```

**Dòng 74:** Biến đổi collection.

```kotlin
            phones = normalizedPhones.mapIndexed { index, phone -> phone.copy(isPrimary = index == primaryPhoneIndex) },
```

**Dòng 75:** Biến đổi collection.

```kotlin
            addresses = cleanAddresses.mapIndexed { index, address -> address.copy(isPrimary = index == primaryAddressIndex) },
```

**Dòng 76:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            note = note.trim(),
```

**Dòng 77:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        )
```

**Dòng 78:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 79:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 80:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    fun isValid(): Boolean = (names.any { it.isNotBlank() } || name.isNotBlank()) && phones.any { it.number.isNotBlank() } && addresses.any { it.address.isNotBlank() }
```

**Dòng 81:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 82:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    companion object {
```

**Dòng 83:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
        fun empty() = CustomerProfile()
```

**Dòng 84:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
        fun fromOrder(order: DeliveryOrder) = CustomerProfile(
```

**Dòng 85:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            id = "order-${order.phone.customerPhoneKey()}",
```

**Dòng 86:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            name = order.customer,
```

**Dòng 87:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            names = listOf(order.customer),
```

**Dòng 88:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            phones = listOf(CustomerPhone(order.phone, isPrimary = true)),
```

**Dòng 89:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            addresses = listOf(
```

**Dòng 90:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                CustomerAddress(
```

**Dòng 91:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    address = order.address,
```

**Dòng 92:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    latitude = order.latitude.takeIf { order.hasStoredCoordinates() },
```

**Dòng 93:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    longitude = order.longitude.takeIf { order.hasStoredCoordinates() },
```

**Dòng 94:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    isPrimary = true,
```

**Dòng 95:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                ),
```

**Dòng 96:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            ),
```

**Dòng 97:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        )
```

**Dòng 98:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 99:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 100:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 101:** Chú thích, không thực thi.

```kotlin
/** Chỉ tạo hồ sơ mới khi dòng đơn có đủ tên, SĐT và địa chỉ để người dùng bổ sung sau. */
```

**Dòng 102:** Phép so sánh/điều kiện.

```kotlin
fun List<CustomerProfile>.missingProfilesFromOrders(orders: List<DeliveryOrder>): List<CustomerProfile> {
```

**Dòng 103:** Biến chỉ đọc.

```kotlin
    val savedPhones = flatMap { profile -> profile.phones.map { it.number.customerPhoneKey() } }.filter(String::isNotBlank).toSet()
```

**Dòng 104:** Kết thúc hàm và trả kết quả.

```kotlin
    return orders
```

**Dòng 105:** Lọc collection.

```kotlin
        .filter { order -> order.phone.customerPhoneKey().isNotBlank() && order.customer.isNotBlank() && order.address.isNotBlank() }
```

**Dòng 106:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        .distinctBy { it.phone.customerPhoneKey() }
```

**Dòng 107:** Lọc collection.

```kotlin
        .filter { order -> order.phone.customerPhoneKey() !in savedPhones }
```

**Dòng 108:** Biến đổi collection.

```kotlin
        .map(CustomerProfile::fromOrder)
```

**Dòng 109:** Biến đổi collection.

```kotlin
        .map(CustomerProfile::normalized)
```

**Dòng 110:** Lọc collection.

```kotlin
        .filter(CustomerProfile::isValid)
```

**Dòng 111:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 112:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 113:** Chú thích, không thực thi.

```kotlin
/** Chuẩn hóa 0xxx, 84xxx, +84xxx và 0084xxx về cùng định danh khách hàng. */
```

**Dòng 114:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
internal fun String.customerPhoneKey(): String {
```

**Dòng 115:** Biến chỉ đọc.

```kotlin
    val digits = filter(Char::isDigit)
```

**Dòng 116:** Kết thúc hàm và trả kết quả.

```kotlin
    return when {
```

**Dòng 117:** Phép so sánh/điều kiện.

```kotlin
        digits.startsWith("0084") && digits.length > 4 -> "0${digits.drop(4)}"
```

**Dòng 118:** Phép so sánh/điều kiện.

```kotlin
        digits.startsWith("84") && digits.length > 2 -> "0${digits.drop(2)}"
```

**Dòng 119:** Nhánh thay thế.

```kotlin
        else -> digits
```

**Dòng 120:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 121:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 122:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 123:** Phép so sánh/điều kiện.

```kotlin
fun List<CustomerProfile>.mergeOrderCustomers(orders: List<DeliveryOrder>): List<CustomerProfile> {
```

**Dòng 124:** Biến chỉ đọc.

```kotlin
    val savedByPhone = flatMap { profile ->
```

**Dòng 125:** Biến đổi collection.

```kotlin
        profile.phones.mapNotNull { phone -> phone.number.customerPhoneKey().takeIf(String::isNotBlank)?.let { it to profile } }
```

**Dòng 126:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }.toMap()
```

**Dòng 127:** Biến chỉ đọc.

```kotlin
    val orderPhoneKeys = orders.map { it.phone.customerPhoneKey() }.filter(String::isNotBlank).toSet()
```

**Dòng 128:** Biến chỉ đọc.

```kotlin
    val derived = orders
```

**Dòng 129:** Lọc collection.

```kotlin
        .filter { it.phone.customerPhoneKey().isNotBlank() }
```

**Dòng 130:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        .distinctBy { it.phone.customerPhoneKey() }
```

**Dòng 131:** Biến đổi collection.

```kotlin
        .map { order -> savedByPhone[order.phone.customerPhoneKey()] ?: CustomerProfile.fromOrder(order) }
```

**Dòng 132:** Biến chỉ đọc.

```kotlin
    val manual = filter { profile -> profile.phones.none { it.number.customerPhoneKey() in orderPhoneKeys } }
```

**Dòng 133:** Kết thúc hàm và trả kết quả.

```kotlin
    return (derived + manual)
```

**Dòng 134:** Lấy phần tử đầu hoặc null.

```kotlin
        .distinctBy { profile -> profile.phones.firstOrNull()?.number?.customerPhoneKey().orEmpty().ifBlank { profile.id } }
```

**Dòng 135:** Sắp xếp collection.

```kotlin
        .sortedBy { it.displayName.lowercase() }
```

**Dòng 136:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 137:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 138:** Phép so sánh/điều kiện.

```kotlin
fun List<CustomerProfile>.withoutCustomer(customerId: String): List<CustomerProfile> = filterNot { it.id == customerId }
```

**Dòng 139:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 140:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
fun CustomerProfile.matchesSearch(query: String): Boolean {
```

**Dòng 141:** Biến chỉ đọc.

```kotlin
    val textQuery = query.searchKey()
```

**Dòng 142:** Điều kiện if.

```kotlin
    if (textQuery.isBlank()) return true
```

**Dòng 143:** Biến chỉ đọc.

```kotlin
    val digitsQuery = query.filter(Char::isDigit)
```

**Dòng 144:** Biến chỉ đọc.

```kotlin
    val textMatches = (names + name + addresses.map { it.address }).any { value -> value.searchKey().contains(textQuery) }
```

**Dòng 145:** Biến chỉ đọc.

```kotlin
    val phoneMatches = phones.any { phone ->
```

**Dòng 146:** Lọc collection.

```kotlin
        phone.number.searchKey().contains(textQuery) || (digitsQuery.isNotBlank() && phone.number.filter(Char::isDigit).contains(digitsQuery))
```

**Dòng 147:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 148:** Kết thúc hàm và trả kết quả.

```kotlin
    return textMatches || phoneMatches
```

**Dòng 149:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 150:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 151:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
private fun String.searchKey(): String = Normalizer.normalize(trim(), Normalizer.Form.NFD)
```

**Dòng 152:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    .replace("\\p{Mn}+".toRegex(), "")
```

**Dòng 153:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    .lowercase(Locale.ROOT)
```

**Dòng 154:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 155:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
object CustomerProfileStore {
```

**Dòng 156:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    private const val PREF = "customer_profiles_v2"
```

**Dòng 157:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    private const val KEY = "items"
```

**Dòng 158:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    private const val DELETED_PREFIX = "deleted_"
```

**Dòng 159:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 160:** Phép so sánh/điều kiện.

```kotlin
    fun load(context: Context): List<CustomerProfile> = runCatching {
```

**Dòng 161:** Biến chỉ đọc.

```kotlin
        val array = JSONArray(context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, "[]"))
```

**Dòng 162:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        List(array.length()) { array.getJSONObject(it).toProfile() }
```

**Dòng 163:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }.getOrDefault(emptyList())
```

**Dòng 164:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 165:** Phép so sánh/điều kiện.

```kotlin
    fun upsert(context: Context, profile: CustomerProfile): List<CustomerProfile> {
```

**Dòng 166:** Biến chỉ đọc.

```kotlin
        val normalized = profile.normalized()
```

**Dòng 167:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        require(normalized.isValid()) { "Hồ sơ khách hàng chưa đủ thông tin" }
```

**Dòng 168:** Biến chỉ đọc.

```kotlin
        val updated = load(context).filterNot { it.id == normalized.id } + normalized
```

**Dòng 169:** Kết thúc hàm và trả kết quả.

```kotlin
        return persist(context, updated)
```

**Dòng 170:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 171:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 172:** Chú thích, không thực thi.

```kotlin
    /** Lưu hẳn các khách mới phát hiện từ dữ liệu đơn, không chỉ hiển thị tạm theo danh sách đơn. */
```

**Dòng 173:** Phép so sánh/điều kiện.

```kotlin
    fun upsertMissingFromOrders(context: Context, orders: List<DeliveryOrder>): List<CustomerProfile> {
```

**Dòng 174:** Biến chỉ đọc.

```kotlin
        val current = load(context)
```

**Dòng 175:** Biến chỉ đọc.

```kotlin
        val missing = current.missingProfilesFromOrders(orders)
```

**Dòng 176:** Kết thúc hàm và trả kết quả.

```kotlin
        return if (missing.isEmpty()) current else persist(context, current + missing)
```

**Dòng 177:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 178:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 179:** Chú thích, không thực thi.

```kotlin
    /** Lưu toàn bộ hồ sơ sau khi một thao tác hệ thống đã cập nhật tọa độ liên quan. */
```

**Dòng 180:** Phép so sánh/điều kiện.

```kotlin
    fun replace(context: Context, profiles: List<CustomerProfile>): List<CustomerProfile> = persist(context, profiles)
```

**Dòng 181:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 182:** Phép so sánh/điều kiện.

```kotlin
    private fun persist(context: Context, profiles: List<CustomerProfile>): List<CustomerProfile> {
```

**Dòng 183:** Biến chỉ đọc.

```kotlin
        val normalized = profiles.map(CustomerProfile::normalized).distinctBy(CustomerProfile::id)
```

**Dòng 184:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
```

**Dòng 185:** Biến đổi collection.

```kotlin
            .putString(KEY, JSONArray(normalized.map { it.toJson() }).toString())
```

**Dòng 186:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            .apply()
```

**Dòng 187:** Kết thúc hàm và trả kết quả.

```kotlin
        return normalized
```

**Dòng 188:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 189:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 190:** Chú thích, không thực thi.

```kotlin
    /** Xóa hồ sơ đã lưu và đánh dấu ẩn để hồ sơ suy ra từ đơn hàng cũng không hiện lại. */
```

**Dòng 191:** Phép so sánh/điều kiện.

```kotlin
    fun delete(context: Context, customerId: String): List<CustomerProfile> {
```

**Dòng 192:** Biến chỉ đọc.

```kotlin
        val updated = load(context).withoutCustomer(customerId)
```

**Dòng 193:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
```

**Dòng 194:** Biến đổi collection.

```kotlin
            .putString(KEY, JSONArray(updated.map { it.toJson() }).toString())
```

**Dòng 195:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            .putBoolean("$DELETED_PREFIX$customerId", true)
```

**Dòng 196:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            .apply()
```

**Dòng 197:** Kết thúc hàm và trả kết quả.

```kotlin
        return updated
```

**Dòng 198:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 199:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 200:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    fun isDeleted(context: Context, customerId: String): Boolean = context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getBoolean("$DELETED_PREFIX$customerId", false)
```

**Dòng 201:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 202:** Chú thích, không thực thi.

```kotlin
    /** JSON nguyên bản dùng cho archive; đường dẫn ảnh sẽ được module backup thay bằng path tương đối. */
```

**Dòng 203:** Elvis: dùng giá trị dự phòng khi null.

```kotlin
    fun snapshotJson(context: Context): String = context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
```

**Dòng 204:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 205:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    fun validateBackupJson(raw: String) {
```

**Dòng 206:** Biến chỉ đọc.

```kotlin
        val values = JSONArray(raw)
```

**Dòng 207:** Phép so sánh/điều kiện.

```kotlin
        List(values.length()) { values.getJSONObject(it).toProfile() }.forEach { profile ->
```

**Dòng 208:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            require(profile.isValid()) { "Một hồ sơ khách hàng trong ZIP chưa đủ thông tin." }
```

**Dòng 209:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 210:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 211:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 212:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    fun replaceFromBackupJson(context: Context, raw: String) {
```

**Dòng 213:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        validateBackupJson(raw)
```

**Dòng 214:** Biến chỉ đọc.

```kotlin
        val preferences = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
```

**Dòng 215:** Biến chỉ đọc.

```kotlin
        val editor = preferences.edit().putString(KEY, JSONArray(raw).toString())
```

**Dòng 216:** Lọc collection.

```kotlin
        preferences.all.keys.filter { it.startsWith(DELETED_PREFIX) }.forEach(editor::remove)
```

**Dòng 217:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        check(editor.commit()) {
```

**Dòng 218:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            "Không thể lưu dữ liệu khách hàng sau khi nhập ZIP."
```

**Dòng 219:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 220:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 221:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 222:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun CustomerProfile.toJson() = JSONObject()
```

**Dòng 223:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        .put("id", id)
```

**Dòng 224:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        .put("name", name)
```

**Dòng 225:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        .put("names", JSONArray(names))
```

**Dòng 226:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        .put("note", note)
```

**Dòng 227:** Biến đổi collection.

```kotlin
        .put("phones", JSONArray(phones.map { phone -> JSONObject().put("number", phone.number).put("primary", phone.isPrimary).put("methods", JSONArray(phone.methods.map { it.name })) }))
```

**Dòng 228:** Biến đổi collection.

```kotlin
        .put("addresses", JSONArray(addresses.map { address -> JSONObject().put("address", address.address).put("lat", address.latitude).put("lng", address.longitude).put("primary", address.isPrimary).put("housePhoto", address.housePhotoPath) }))
```

**Dòng 229:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 230:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun JSONObject.toProfile(): CustomerProfile {
```

**Dòng 231:** Biến chỉ đọc.

```kotlin
        val phoneArray = getJSONArray("phones")
```

**Dòng 232:** Biến chỉ đọc.

```kotlin
        val addressArray = getJSONArray("addresses")
```

**Dòng 233:** Kết thúc hàm và trả kết quả.

```kotlin
        return CustomerProfile(
```

**Dòng 234:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            id = getString("id"),
```

**Dòng 235:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            name = optString("name"),
```

**Dòng 236:** Safe-call: chỉ chạy khi khác null.

```kotlin
            names = optJSONArray("names")?.let { array -> List(array.length()) { array.optString(it) } }.orEmpty(),
```

**Dòng 237:** Phép so sánh/điều kiện.

```kotlin
            phones = List(phoneArray.length()) { index ->
```

**Dòng 238:** Biến chỉ đọc.

```kotlin
                val item = phoneArray.getJSONObject(index)
```

**Dòng 239:** Safe-call: chỉ chạy khi khác null.

```kotlin
                CustomerPhone(item.getString("number"), item.optBoolean("primary"), item.optJSONArray("methods")?.let { methods -> List(methods.length()) { CustomerContactMethod.valueOf(methods.getString(it)) }.toSet() } ?: setOf(CustomerContactMethod.CALL))
```

**Dòng 240:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            },
```

**Dòng 241:** Phép so sánh/điều kiện.

```kotlin
            addresses = List(addressArray.length()) { index ->
```

**Dòng 242:** Biến chỉ đọc.

```kotlin
                val item = addressArray.getJSONObject(index)
```

**Dòng 243:** Phép so sánh/điều kiện.

```kotlin
                CustomerAddress(item.getString("address"), item.optDouble("lat").takeIf { !it.isNaN() }, item.optDouble("lng").takeIf { !it.isNaN() }, item.optBoolean("primary"), item.optString("housePhoto").takeIf { it.isNotBlank() && it != "null" })
```

**Dòng 244:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            },
```

**Dòng 245:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            note = optString("note"),
```

**Dòng 246:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        ).normalized()
```

**Dòng 247:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 248:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

## `app/src/main/java/com/example/delivery/debug/CrashDiagnostic.kt`

**Dòng 1:** Khai báo package/namespace.

```kotlin
package com.example.delivery.debug
```

**Dòng 2:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 3:** Import dependency.

```kotlin
import android.content.Context
```

**Dòng 4:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 5:** Chú thích, không thực thi.

```kotlin
/** Lưu lỗi crash gần nhất để hiển thị một lần khi người dùng mở lại ứng dụng. */
```

**Dòng 6:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
object CrashDiagnostic {
```

**Dòng 7:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    private const val preferencesName = "delivery_crash_diagnostic"
```

**Dòng 8:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    private const val crashDetailKey = "last_crash_detail"
```

**Dòng 9:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 10:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    fun record(context: Context, thread: Thread, error: Throwable) {
```

**Dòng 11:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        runCatching {
```

**Dòng 12:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            context.getSharedPreferences(preferencesName, Context.MODE_PRIVATE)
```

**Dòng 13:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                .edit()
```

**Dòng 14:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                .putString(crashDetailKey, CrashDiagnosticFormatter.format(thread.name, error))
```

**Dòng 15:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                .commit()
```

**Dòng 16:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 17:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 18:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 19:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    fun consume(context: Context): String? {
```

**Dòng 20:** Biến chỉ đọc.

```kotlin
        val preferences = context.getSharedPreferences(preferencesName, Context.MODE_PRIVATE)
```

**Dòng 21:** Biến chỉ đọc.

```kotlin
        val detail = preferences.getString(crashDetailKey, null) ?: return null
```

**Dòng 22:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        preferences.edit().remove(crashDetailKey).apply()
```

**Dòng 23:** Kết thúc hàm và trả kết quả.

```kotlin
        return detail
```

**Dòng 24:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 25:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 26:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 27:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
internal object CrashDiagnosticFormatter {
```

**Dòng 28:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    fun format(threadName: String, error: Throwable): String {
```

**Dòng 29:** Biến chỉ đọc.

```kotlin
        val type = error.javaClass.simpleName.ifBlank { "không xác định" }
```

**Dòng 30:** Biến chỉ đọc.

```kotlin
        val message = error.message?.take(240) ?: "không có"
```

**Dòng 31:** Biến chỉ đọc.

```kotlin
        val trace = error.stackTraceToString().lineSequence().take(8).joinToString("\n").take(900)
```

**Dòng 32:** Kết thúc hàm và trả kết quả.

```kotlin
        return "Bước lỗi: ứng dụng bị dừng đột ngột.\nLuồng: $threadName\nLoại lỗi: $type\nChi tiết: $message\n\nDấu vết:\n$trace\n\nChọn Sao chép lỗi và gửi lại nội dung này để kiểm tra tiếp."
```

**Dòng 33:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 34:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

## `app/src/main/java/com/example/delivery/history/DeliveryPhotoHistory.kt`

**Dòng 1:** Khai báo package/namespace.

```kotlin
package com.example.delivery.history
```

**Dòng 2:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 3:** Import dependency.

```kotlin
import android.content.Context
```

**Dòng 4:** Import dependency.

```kotlin
import android.graphics.Bitmap
```

**Dòng 5:** Import dependency.

```kotlin
import android.graphics.BitmapFactory
```

**Dòng 6:** Import dependency.

```kotlin
import android.graphics.Canvas
```

**Dòng 7:** Import dependency.

```kotlin
import android.graphics.Color
```

**Dòng 8:** Import dependency.

```kotlin
import android.graphics.Paint
```

**Dòng 9:** Import dependency.

```kotlin
import androidx.core.content.FileProvider
```

**Dòng 10:** Import dependency.

```kotlin
import com.example.delivery.model.DeliveryOrder
```

**Dòng 11:** Import dependency.

```kotlin
import org.json.JSONArray
```

**Dòng 12:** Import dependency.

```kotlin
import org.json.JSONObject
```

**Dòng 13:** Import dependency.

```kotlin
import java.io.File
```

**Dòng 14:** Import dependency.

```kotlin
import java.io.FileOutputStream
```

**Dòng 15:** Import dependency.

```kotlin
import java.text.SimpleDateFormat
```

**Dòng 16:** Import dependency.

```kotlin
import java.util.Date
```

**Dòng 17:** Import dependency.

```kotlin
import java.util.Locale
```

**Dòng 18:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 19:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
enum class ProofPhotoType { BILL_CLOSEUP, DROP_OFF_WATERMARK }
```

**Dòng 20:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
enum class PaymentChannel { ZALO, SMS }
```

**Dòng 21:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 22:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
data class TransferEvidence(
```

**Dòng 23:** Biến chỉ đọc.

```kotlin
    val waybill: String,
```

**Dòng 24:** Biến chỉ đọc.

```kotlin
    val customer: String,
```

**Dòng 25:** Biến chỉ đọc.

```kotlin
    val phone: String,
```

**Dòng 26:** Biến chỉ đọc.

```kotlin
    val cod: Long,
```

**Dòng 27:** Biến chỉ đọc.

```kotlin
    val channel: PaymentChannel,
```

**Dòng 28:** Biến chỉ đọc.

```kotlin
    val message: String,
```

**Dòng 29:** Biến chỉ đọc.

```kotlin
    val billPhotoPath: String? = null,
```

**Dòng 30:** Biến chỉ đọc.

```kotlin
    val dropOffPhotoPath: String? = null,
```

**Dòng 31:** Biến chỉ đọc.

```kotlin
    val sentConfirmed: Boolean = false,
```

**Dòng 32:** Biến chỉ đọc.

```kotlin
    val paidConfirmed: Boolean = false,
```

**Dòng 33:** Biến chỉ đọc.

```kotlin
    val createdAt: Long = System.currentTimeMillis(),
```

**Dòng 34:** Biến chỉ đọc.

```kotlin
    val confirmedAt: Long? = null,
```

**Dòng 35:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
)
```

**Dòng 36:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 37:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
object DeliveryPhotoHistory {
```

**Dòng 38:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    private const val EVIDENCE_PREF = "transfer_evidence_v1"
```

**Dòng 39:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    private val dateFormat = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US)
```

**Dòng 40:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 41:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    fun createOutputFile(context: Context, waybill: String, type: ProofPhotoType): File {
```

**Dòng 42:** Biến chỉ đọc.

```kotlin
        val dir = File(context.filesDir, "delivery_confirmation").apply { mkdirs() }
```

**Dòng 43:** Kết thúc hàm và trả kết quả.

```kotlin
        return File(dir, "${waybill}_${type.name.lowercase()}_${dateFormat.format(Date())}.jpg")
```

**Dòng 44:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 45:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 46:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    fun createCustomerGateFile(context: Context, customerId: String): File {
```

**Dòng 47:** Biến chỉ đọc.

```kotlin
        val dir = File(context.filesDir, "customer_gate").apply { mkdirs() }
```

**Dòng 48:** Kết thúc hàm và trả kết quả.

```kotlin
        return File(dir, "${customerId}_${dateFormat.format(Date())}.jpg")
```

**Dòng 49:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 50:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 51:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    fun providerUri(context: Context, file: File) = FileProvider.getUriForFile(context, "${context.packageName}.deliveryphotos", file)
```

**Dòng 52:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 53:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    fun addDropOffWatermark(file: File, order: DeliveryOrder, latitude: Double?, longitude: Double?): String {
```

**Dòng 54:** Biến chỉ đọc.

```kotlin
        val original = BitmapFactory.decodeFile(file.path) ?: return file.path
```

**Dòng 55:** Biến chỉ đọc.

```kotlin
        val bitmap = original.copy(Bitmap.Config.ARGB_8888, true)
```

**Dòng 56:** Biến chỉ đọc.

```kotlin
        val canvas = Canvas(bitmap)
```

**Dòng 57:** Biến chỉ đọc.

```kotlin
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
```

**Dòng 58:** Biến chỉ đọc.

```kotlin
        val stamp = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("vi", "VN")).format(Date())
```

**Dòng 59:** Biến chỉ đọc.

```kotlin
        val coordinates = if (latitude != null && longitude != null) String.format(Locale.US, "%.5f, %.5f", latitude, longitude) else "Chưa có GPS"
```

**Dòng 60:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        paint.color = Color.argb(185, 0, 0, 0)
```

**Dòng 61:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        canvas.drawRect(0f, (bitmap.height - 106).coerceAtLeast(0).toFloat(), bitmap.width.toFloat(), bitmap.height.toFloat(), paint)
```

**Dòng 62:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        paint.color = Color.WHITE
```

**Dòng 63:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        paint.textSize = (bitmap.width / 29f).coerceAtLeast(18f)
```

**Dòng 64:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        canvas.drawText(order.waybill, 18f, bitmap.height - 70f, paint)
```

**Dòng 65:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        paint.textSize = (bitmap.width / 36f).coerceAtLeast(15f)
```

**Dòng 66:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        canvas.drawText("$stamp • $coordinates", 18f, bitmap.height - 32f, paint)
```

**Dòng 67:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.JPEG, 92, it) }
```

**Dòng 68:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        original.recycle(); bitmap.recycle()
```

**Dòng 69:** Kết thúc hàm và trả kết quả.

```kotlin
        return file.path
```

**Dòng 70:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 71:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 72:** Sắp xếp collection.

```kotlin
    fun getEvidence(context: Context): List<TransferEvidence> = readEvidence(context).sortedByDescending { it.createdAt }
```

**Dòng 73:** Lọc collection.

```kotlin
    fun upsertEvidence(context: Context, evidence: TransferEvidence) { writeEvidence(context, readEvidence(context).filterNot { it.waybill == evidence.waybill } + evidence) }
```

**Dòng 74:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    fun confirmPaid(context: Context, waybill: String): TransferEvidence? {
```

**Dòng 75:** Biến chỉ đọc.

```kotlin
        val current = readEvidence(context).firstOrNull { it.waybill == waybill } ?: return null
```

**Dòng 76:** Biến chỉ đọc.

```kotlin
        val confirmed = current.copy(paidConfirmed = true, confirmedAt = System.currentTimeMillis())
```

**Dòng 77:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        upsertEvidence(context, confirmed)
```

**Dòng 78:** Kết thúc hàm và trả kết quả.

```kotlin
        return confirmed
```

**Dòng 79:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 80:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 81:** Elvis: dùng giá trị dự phòng khi null.

```kotlin
    fun snapshotEvidenceJson(context: Context): String = context.getSharedPreferences(EVIDENCE_PREF, Context.MODE_PRIVATE).getString("items", "[]") ?: "[]"
```

**Dòng 82:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    fun validateBackupJson(evidenceRaw: String) {
```

**Dòng 83:** Biến chỉ đọc.

```kotlin
        val evidence = JSONArray(evidenceRaw)
```

**Dòng 84:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        List(evidence.length()) { evidence.getJSONObject(it).toEvidence() }
```

**Dòng 85:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 86:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 87:** Chú thích, không thực thi.

```kotlin
    /** Xóa vĩnh viễn dữ liệu bằng chứng/lịch sử và ảnh giao nhận; không tạo lại bản ghi outcome. */
```

**Dòng 88:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    fun clearAll(context: Context) {
```

**Dòng 89:** Biến chỉ đọc.

```kotlin
        val evidence = readEvidence(context)
```

**Dòng 90:** Biến chỉ đọc.

```kotlin
        val paths = evidence.flatMap { listOfNotNull(it.billPhotoPath, it.dropOffPhotoPath) }.distinct()
```

**Dòng 91:** Biến đổi collection.

```kotlin
        paths.map(::File).forEach { it.delete() }
```

**Dòng 92:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        File(context.filesDir, "delivery_confirmation").deleteRecursively()
```

**Dòng 93:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        check(context.getSharedPreferences(EVIDENCE_PREF, Context.MODE_PRIVATE).edit().clear().commit()) {
```

**Dòng 94:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            "Không thể xóa bằng chứng giao hàng."
```

**Dòng 95:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 96:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 97:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 98:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    fun replaceFromBackupJson(context: Context, evidenceRaw: String) {
```

**Dòng 99:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        validateBackupJson(evidenceRaw)
```

**Dòng 100:** Biến chỉ đọc.

```kotlin
        val evidenceSaved = context.getSharedPreferences(EVIDENCE_PREF, Context.MODE_PRIVATE).edit().putString("items", JSONArray(evidenceRaw).toString()).commit()
```

**Dòng 101:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        check(evidenceSaved) { "Không thể lưu bằng chứng chuyển khoản sau khi nhập ZIP." }
```

**Dòng 102:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 103:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 104:** Phép so sánh/điều kiện.

```kotlin
    private fun readEvidence(context: Context): List<TransferEvidence> = runCatching {
```

**Dòng 105:** Biến chỉ đọc.

```kotlin
        val arr = JSONArray(context.getSharedPreferences(EVIDENCE_PREF, Context.MODE_PRIVATE).getString("items", "[]"))
```

**Dòng 106:** Phép so sánh/điều kiện.

```kotlin
        List(arr.length()) { index -> arr.getJSONObject(index).toEvidence() }
```

**Dòng 107:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }.getOrDefault(emptyList())
```

**Dòng 108:** Biến đổi collection.

```kotlin
    private fun writeEvidence(context: Context, values: List<TransferEvidence>) { context.getSharedPreferences(EVIDENCE_PREF, Context.MODE_PRIVATE).edit().putString("items", JSONArray(values.map { it.toJson() }).toString()).apply() }
```

**Dòng 109:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun TransferEvidence.toJson() = JSONObject().put("waybill", waybill).put("customer", customer).put("phone", phone).put("cod", cod).put("channel", channel.name).put("message", message).put("bill", billPhotoPath).put("drop", dropOffPhotoPath).put("sent", sentConfirmed).put("paid", paidConfirmed).put("created", createdAt).put("confirmed", confirmedAt)
```

**Dòng 110:** Phép so sánh/điều kiện.

```kotlin
    private fun JSONObject.toEvidence() = TransferEvidence(getString("waybill"), getString("customer"), getString("phone"), getLong("cod"), PaymentChannel.valueOf(getString("channel")), getString("message"), optString("bill").takeIf { it.isNotBlank() && it != "null" }, optString("drop").takeIf { it.isNotBlank() && it != "null" }, optBoolean("sent"), optBoolean("paid"), getLong("created"), optLong("confirmed").takeIf { it > 0 })
```

**Dòng 111:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 112:** Dòng trống — phân tách nhóm.

```kotlin

```

## `app/src/main/java/com/example/delivery/integration/VtmanExportContract.kt`

**Dòng 1:** Khai báo package/namespace.

```kotlin
package com.example.delivery.integration
```

**Dòng 2:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 3:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
object VtmanExportContract {
```

**Dòng 4:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    const val packageName = "com.vtman.waybillscanner"
```

**Dòng 5:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    const val unavailableMessage = "Chưa cài VTMan Export. Hãy cài công cụ trước rồi mở lại mục này."
```

**Dòng 6:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

## `app/src/main/java/com/example/delivery/location/RealtimeLocationPolicy.kt`

**Dòng 1:** Khai báo package/namespace.

```kotlin
package com.example.delivery.location
```

**Dòng 2:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 3:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
object RealtimeLocationPolicy {
```

**Dòng 4:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    const val MAX_LAST_KNOWN_AGE_MS = 2 * 60 * 1000L
```

**Dòng 5:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    const val MAX_CUSTOMER_LOCATION_ACCURACY_METERS = 75f
```

**Dòng 6:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 7:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    fun isFreshLastKnown(locationTimeMillis: Long, nowMillis: Long): Boolean =
```

**Dòng 8:** Phép so sánh/điều kiện.

```kotlin
        locationTimeMillis > 0 && nowMillis >= locationTimeMillis && nowMillis - locationTimeMillis <= MAX_LAST_KNOWN_AGE_MS
```

**Dòng 9:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 10:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    fun shouldAccept(currentTimeMillis: Long?, candidateTimeMillis: Long): Boolean =
```

**Dòng 11:** Phép so sánh/điều kiện.

```kotlin
        currentTimeMillis == null || candidateTimeMillis >= currentTimeMillis
```

**Dòng 12:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 13:** Chú thích, không thực thi.

```kotlin
    /** Không lưu điểm GPS cũ hoặc có bán kính sai số lớn cho địa chỉ khách. */
```

**Dòng 14:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    fun isUsableForCustomer(locationTimeMillis: Long, accuracyMeters: Float, nowMillis: Long): Boolean =
```

**Dòng 15:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        isFreshLastKnown(locationTimeMillis, nowMillis) && accuracyMeters.isFinite() && accuracyMeters in 0f..MAX_CUSTOMER_LOCATION_ACCURACY_METERS
```

**Dòng 16:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

## `app/src/main/java/com/example/delivery/map/GoongMapStyleLoader.kt`

**Dòng 1:** Khai báo package/namespace.

```kotlin
package com.example.delivery.map
```

**Dòng 2:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 3:** Import dependency.

```kotlin
import android.content.Context
```

**Dòng 4:** Import dependency.

```kotlin
import com.example.delivery.R
```

**Dòng 5:** Import dependency.

```kotlin
import com.example.delivery.navigation.GoongApiConfig
```

**Dòng 6:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 7:** Chú thích, không thực thi.

```kotlin
/**
```

**Dòng 8:** Chú thích, không thực thi.

```kotlin
 * Nạp style GOONG cho MapLibre và thay API key trong style bằng BuildConfig.
```

**Dòng 9:** Chú thích, không thực thi.

```kotlin
 *
```

**Dòng 10:** Chú thích, không thực thi.

```kotlin
 * Lý do tách riêng:
```

**Dòng 11:** Chú thích, không thực thi.

```kotlin
 * - Tập trung toàn bộ logic Map Tiles API vào một chỗ.
```

**Dòng 12:** Chú thích, không thực thi.

```kotlin
 * - Không để API key hard-code trong goong_map_style.json.
```

**Dòng 13:** Chú thích, không thực thi.

```kotlin
 * - Các màn hình bản đồ chỉ cần gọi load(context).
```

**Dòng 14:** Chú thích, không thực thi.

```kotlin
 */
```

**Dòng 15:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
internal object GoongMapStyleLoader {
```

**Dòng 16:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    fun load(context: Context): String {
```

**Dòng 17:** Biến chỉ đọc.

```kotlin
        val key = GoongApiConfig.mapTilesKey
```

**Dòng 18:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        check(key.isNotBlank()) { "Thiếu GOONG_MAP_TILES_KEY" }
```

**Dòng 19:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 20:** Kết thúc hàm và trả kết quả.

```kotlin
        return context.resources
```

**Dòng 21:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            .openRawResource(R.raw.goong_map_style)
```

**Dòng 22:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            .bufferedReader()
```

**Dòng 23:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            .use { it.readText() }
```

**Dòng 24:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            .replace("__GOONG_MAP_TILES_KEY__", key)
```

**Dòng 25:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 26:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

## `app/src/main/java/com/example/delivery/map/MapTileCache.kt`

**Dòng 1:** Khai báo package/namespace.

```kotlin
package com.example.delivery.map
```

**Dòng 2:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 3:** Import dependency.

```kotlin
import android.content.Context
```

**Dòng 4:** Import dependency.

```kotlin
import android.util.Log
```

**Dòng 5:** Import dependency.

```kotlin
import org.maplibre.android.MapLibre
```

**Dòng 6:** Import dependency.

```kotlin
import org.maplibre.android.offline.OfflineManager
```

**Dòng 7:** Import dependency.

```kotlin
import java.util.concurrent.atomic.AtomicBoolean
```

**Dòng 8:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 9:** Chú thích, không thực thi.

```kotlin
/** Ambient cache is retained by MapLibre after a MapView is disposed between tabs. */
```

**Dòng 10:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
const val MAP_TILE_CACHE_BYTES = 96L * 1024L * 1024L
```

**Dòng 11:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 12:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
private val cacheConfigured = AtomicBoolean(false)
```

**Dòng 13:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 14:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
fun configureMapTileCache(context: Context) {
```

**Dòng 15:** Điều kiện if.

```kotlin
    if (!cacheConfigured.compareAndSet(false, true)) return
```

**Dòng 16:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 17:** Biến chỉ đọc.

```kotlin
    val appContext = context.applicationContext
```

**Dòng 18:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    MapLibre.getInstance(appContext)
```

**Dòng 19:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    OfflineManager.getInstance(appContext).setMaximumAmbientCacheSize(
```

**Dòng 20:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        MAP_TILE_CACHE_BYTES,
```

**Dòng 21:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        object : OfflineManager.FileSourceCallback {
```

**Dòng 22:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
            override fun onSuccess() = Unit
```

**Dòng 23:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 24:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
            override fun onError(error: String) {
```

**Dòng 25:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                Log.w("MapTileCache", "Không thể cập nhật giới hạn cache tile: $error")
```

**Dòng 26:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 27:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        },
```

**Dòng 28:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    )
```

**Dòng 29:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

## `app/src/main/java/com/example/delivery/model/DeliveryOrder.kt`

**Dòng 1:** Khai báo package/namespace.

```kotlin
package com.example.delivery.model
```

**Dòng 2:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 3:** Import dependency.

```kotlin
import java.text.NumberFormat
```

**Dòng 4:** Import dependency.

```kotlin
import java.util.Locale
```

**Dòng 5:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 6:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
enum class DeliveryStatus {
```

**Dòng 7:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    TT500, TT505, TT506, TT507, TT508, TT515;
```

**Dòng 8:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    companion object { fun label(status: DeliveryStatus) = status.name }
```

**Dòng 9:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 10:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 11:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
enum class DeliveryOutcome {
```

**Dòng 12:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    ACTIVE,
```

**Dòng 13:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    DELIVERED,
```

**Dòng 14:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    TEMPORARY_FAILURE,
```

**Dòng 15:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    TERMINAL_FAILURE,
```

**Dòng 16:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    PICKUP_AT_WAREHOUSE,
```

**Dòng 17:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 18:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 19:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
enum class DeliveryFailureReason(val label: String, val outcome: DeliveryOutcome) {
```

**Dòng 20:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    NO_CONTACT("Không liên lạc được", DeliveryOutcome.TEMPORARY_FAILURE),
```

**Dòng 21:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    RESCHEDULED("Hẹn giao lại", DeliveryOutcome.TEMPORARY_FAILURE),
```

**Dòng 22:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    REFUSED("Từ chối nhận", DeliveryOutcome.TERMINAL_FAILURE),
```

**Dòng 23:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    THREE_ATTEMPTS("Giao thất bại 3 ca", DeliveryOutcome.TERMINAL_FAILURE),
```

**Dòng 24:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    PICKUP_AT_WAREHOUSE("Tới kho lấy", DeliveryOutcome.PICKUP_AT_WAREHOUSE),
```

**Dòng 25:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 26:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 27:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
data class DeliveryOrder(
```

**Dòng 28:** Biến chỉ đọc.

```kotlin
    val waybill: String,
```

**Dòng 29:** Biến chỉ đọc.

```kotlin
    val customer: String,
```

**Dòng 30:** Biến chỉ đọc.

```kotlin
    val phone: String,
```

**Dòng 31:** Biến chỉ đọc.

```kotlin
    val address: String,
```

**Dòng 32:** Biến chỉ đọc.

```kotlin
    val product: String,
```

**Dòng 33:** Biến chỉ đọc.

```kotlin
    val cod: Long,
```

**Dòng 34:** Biến chỉ đọc.

```kotlin
    val service: String,
```

**Dòng 35:** Biến chỉ đọc.

```kotlin
    val status: DeliveryStatus = DeliveryStatus.TT500,
```

**Dòng 36:** Biến chỉ đọc.

```kotlin
    val sequence: Int = 0,
```

**Dòng 37:** Biến chỉ đọc.

```kotlin
    val latitude: Double = 10.7769,
```

**Dòng 38:** Biến chỉ đọc.

```kotlin
    val longitude: Double = 106.7009,
```

**Dòng 39:** Biến chỉ đọc.

```kotlin
    val requiresRedelivery: Boolean = false,
```

**Dòng 40:** Biến chỉ đọc.

```kotlin
    val wasRedelivered: Boolean = false,
```

**Dòng 41:** Biến chỉ đọc.

```kotlin
    val failureReason: DeliveryFailureReason? = null,
```

**Dòng 42:** Biến chỉ đọc.

```kotlin
    val failureCount: Int = 0,
```

**Dòng 43:** Biến chỉ đọc.

```kotlin
    val delivered: Boolean = false,
```

**Dòng 44:** Chú thích, không thực thi.

```kotlin
    /** Nhãn STT đầy đủ; null nghĩa là dùng sequence nguyên để tương thích dữ liệu cũ. */
```

**Dòng 45:** Biến chỉ đọc.

```kotlin
    val sequenceLabel: String? = null,
```

**Dòng 46:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
)
```

**Dòng 47:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 48:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
fun Long.formatVnd(): String = NumberFormat.getNumberInstance(Locale("vi", "VN")).format(this) + " đ"
```

**Dòng 49:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 50:** Chú thích, không thực thi.

```kotlin
/** Mã trạng thái trong CSV là nguồn hiển thị chính; dữ liệu cũ được suy ra từ các cờ đã lưu. */
```

**Dòng 51:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
fun DeliveryOrder.csvStatus(): DeliveryStatus = when {
```

**Dòng 52:** Phép so sánh/điều kiện.

```kotlin
    status == DeliveryStatus.TT515 -> DeliveryStatus.TT500
```

**Dòng 53:** Phép so sánh/điều kiện.

```kotlin
    status != DeliveryStatus.TT500 -> status
```

**Dòng 54:** Phép so sánh/điều kiện.

```kotlin
    failureReason?.outcome == DeliveryOutcome.TEMPORARY_FAILURE || requiresRedelivery -> DeliveryStatus.TT506
```

**Dòng 55:** Phép so sánh/điều kiện.

```kotlin
    failureReason?.outcome == DeliveryOutcome.PICKUP_AT_WAREHOUSE -> DeliveryStatus.TT507
```

**Dòng 56:** Phép so sánh/điều kiện.

```kotlin
    failureReason?.outcome == DeliveryOutcome.TERMINAL_FAILURE -> DeliveryStatus.TT505
```

**Dòng 57:** Phép so sánh/điều kiện.

```kotlin
    wasRedelivered -> DeliveryStatus.TT508
```

**Dòng 58:** Nhánh thay thế.

```kotlin
    else -> DeliveryStatus.TT500
```

**Dòng 59:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 60:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 61:** Chú thích, không thực thi.

```kotlin
/** Tương thích dữ liệu cũ: trạng thái nghiệp vụ được suy ra từ mã CSV và các cờ đã lưu. */
```

**Dòng 62:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
fun DeliveryOrder.deliveryOutcome(): DeliveryOutcome = when {
```

**Dòng 63:** Phép so sánh/điều kiện.

```kotlin
    delivered || status == DeliveryStatus.TT515 -> DeliveryOutcome.DELIVERED
```

**Dòng 64:** Nhánh thay thế.

```kotlin
    else -> when (csvStatus()) {
```

**Dòng 65:** Phép so sánh/điều kiện.

```kotlin
    DeliveryStatus.TT506 -> DeliveryOutcome.TEMPORARY_FAILURE
```

**Dòng 66:** Phép so sánh/điều kiện.

```kotlin
    DeliveryStatus.TT507 -> DeliveryOutcome.PICKUP_AT_WAREHOUSE
```

**Dòng 67:** Phép so sánh/điều kiện.

```kotlin
    DeliveryStatus.TT505 -> DeliveryOutcome.TERMINAL_FAILURE
```

**Dòng 68:** Nhánh thay thế.

```kotlin
    else -> DeliveryOutcome.ACTIVE
```

**Dòng 69:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 70:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 71:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
fun DeliveryOrder.statusLabel(): String = when (deliveryOutcome()) {
```

**Dòng 72:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 73:** Phép so sánh/điều kiện.

```kotlin
    DeliveryOutcome.ACTIVE -> if (wasRedelivered) "Đang giao lại" else "Đang giao"
```

**Dòng 74:** Phép so sánh/điều kiện.

```kotlin
    DeliveryOutcome.DELIVERED -> "Đã giao"
```

**Dòng 75:** Phép so sánh/điều kiện.

```kotlin
    DeliveryOutcome.TEMPORARY_FAILURE -> "Thất bại tạm thời"
```

**Dòng 76:** Phép so sánh/điều kiện.

```kotlin
    DeliveryOutcome.TERMINAL_FAILURE -> "Giao thất bại"
```

**Dòng 77:** Phép so sánh/điều kiện.

```kotlin
    DeliveryOutcome.PICKUP_AT_WAREHOUSE -> "Tới kho lấy"
```

**Dòng 78:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 79:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 80:** Chú thích, không thực thi.

```kotlin
/** TT500, TT506, TT507, TT508 vẫn được xếp tuyến; chỉ TT505 bị loại khỏi STT. */
```

**Dòng 81:** Phép so sánh/điều kiện.

```kotlin
fun DeliveryOrder.canReceiveRouteSequence(): Boolean = !delivered && status != DeliveryStatus.TT515 && csvStatus() != DeliveryStatus.TT505
```

**Dòng 82:** Elvis: dùng giá trị dự phòng khi null.

```kotlin
fun DeliveryOrder.sequenceText(): String = sequenceLabel?.trim()?.takeIf { it.isNotBlank() } ?: sequence.takeIf { it > 0 }?.toString().orEmpty()
```

**Dòng 83:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 84:** Chú thích, không thực thi.

```kotlin
/** Khóa nhóm ổn định: bỏ ký tự định dạng của SĐT, dùng MVĐ nếu SĐT trống. */
```

**Dòng 85:** Lọc collection.

```kotlin
fun DeliveryOrder.phoneGroupKey(): String = phone.filter(Char::isDigit).ifBlank { waybill.trim().lowercase(Locale.ROOT) }
```

**Dòng 86:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 87:** Chú thích, không thực thi.

```kotlin
/** Sửa dữ liệu cũ để mọi MVĐ cùng SĐT có đúng một STT hiển thị/lưu trữ. */
```

**Dòng 88:** Phép so sánh/điều kiện.

```kotlin
fun List<DeliveryOrder>.withSharedPhoneSequence(): List<DeliveryOrder> {
```

**Dòng 89:** Biến chỉ đọc.

```kotlin
    val canonical = filter { it.sequenceText().isNotBlank() }
```

**Dòng 90:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        .groupBy { it.phoneGroupKey() }
```

**Dòng 91:** Biến đổi collection.

```kotlin
        .mapValues { (_, group) -> group.minWith(compareBy<DeliveryOrder> { it.sequenceSortValue() }.thenBy { it.waybill }).sequenceText() }
```

**Dòng 92:** Kết thúc hàm và trả kết quả.

```kotlin
    return map { order -> canonical[order.phoneGroupKey()]?.let(order::withSequenceLabel) ?: order }
```

**Dòng 93:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 94:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 95:** Chú thích, không thực thi.

```kotlin
/** Khóa sắp xếp: STT nguyên đứng trước nhánh, `5.n` đứng sau các nhánh cụ thể của 5. */
```

**Dòng 96:** Phép so sánh/điều kiện.

```kotlin
fun DeliveryOrder.sequenceSortValue(): Long = sequenceText().let { text ->
```

**Dòng 97:** Điều kiện if.

```kotlin
    if (text.isBlank()) Long.MAX_VALUE
```

**Dòng 98:** Nhánh thay thế.

```kotlin
    else {
```

**Dòng 99:** Biến chỉ đọc.

```kotlin
        val parts = text.split('.', limit = 2)
```

**Dòng 100:** Biến chỉ đọc.

```kotlin
        val major = parts[0].toIntOrNull() ?: Int.MAX_VALUE
```

**Dòng 101:** Biến chỉ đọc.

```kotlin
        val minor = parts.getOrNull(1)?.let { if (it.equals("n", true)) 999_999 else it.toIntOrNull() ?: 999_998 } ?: 0
```

**Dòng 102:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        major.toLong() * 1_000_000L + minor
```

**Dòng 103:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 104:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 105:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 106:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
fun DeliveryOrder.isRouteActive(): Boolean = canReceiveRouteSequence() && sequenceText().isNotBlank()
```

**Dòng 107:** Phép so sánh/điều kiện.

```kotlin
fun DeliveryOrder.isPickupAtWarehouse(): Boolean = deliveryOutcome() == DeliveryOutcome.PICKUP_AT_WAREHOUSE
```

**Dòng 108:** Chú thích, không thực thi.

```kotlin
/** Chỉ hiển thị năm mã trạng thái nghiệp vụ đã thống nhất. */
```

**Dòng 109:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
fun DeliveryOrder.detailStatusLabel(): String = when (csvStatus()) {
```

**Dòng 110:** Phép so sánh/điều kiện.

```kotlin
    DeliveryStatus.TT500 -> "TT500"
```

**Dòng 111:** Phép so sánh/điều kiện.

```kotlin
    DeliveryStatus.TT506 -> "TT506 · Hẹn lại / Không liên lạc được"
```

**Dòng 112:** Phép so sánh/điều kiện.

```kotlin
    DeliveryStatus.TT507 -> "TT507 · Tới kho nhận"
```

**Dòng 113:** Phép so sánh/điều kiện.

```kotlin
    DeliveryStatus.TT508 -> "TT508 · Giao lại"
```

**Dòng 114:** Phép so sánh/điều kiện.

```kotlin
    DeliveryStatus.TT505 -> "TT505 · Từ chối nhận / Giao thất bại 3 ca"
```

**Dòng 115:** Phép so sánh/điều kiện.

```kotlin
    DeliveryStatus.TT515 -> "TT500"
```

**Dòng 116:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 117:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
fun DeliveryOrder.isMapVisible(): Boolean = hasStoredCoordinates() && isRouteActive()
```

**Dòng 118:** Phép so sánh/điều kiện.

```kotlin
fun DeliveryOrder.isTemporaryFailure(): Boolean = deliveryOutcome() == DeliveryOutcome.TEMPORARY_FAILURE
```

**Dòng 119:** Phép so sánh/điều kiện.

```kotlin
fun DeliveryOrder.isTerminalFailure(): Boolean = deliveryOutcome() == DeliveryOutcome.TERMINAL_FAILURE
```

**Dòng 120:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 121:** Chú thích, không thực thi.

```kotlin
/** Một cặp tọa độ an toàn để truyền cho MapLibre và dịch vụ chỉ đường. */
```

**Dòng 122:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
fun isMapCoordinatePair(latitude: Double, longitude: Double): Boolean =
```

**Dòng 123:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    latitude.isFinite() && longitude.isFinite() && latitude in -90.0..90.0 && longitude in -180.0..180.0
```

**Dòng 124:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 125:** Chú thích, không thực thi.

```kotlin
/** Tọa độ 0,0 biểu thị đơn chưa được người dùng lưu vị trí khách hàng. */
```

**Dòng 126:** Phép so sánh/điều kiện.

```kotlin
fun DeliveryOrder.hasStoredCoordinates(): Boolean = isMapCoordinatePair(latitude, longitude) && (latitude != 0.0 || longitude != 0.0)
```

**Dòng 127:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 128:** Chú thích, không thực thi.

```kotlin
/**
```

**Dòng 129:** Chú thích, không thực thi.

```kotlin
 * Khôi phục dữ liệu cũ từng dán ngược Kinh độ, Vĩ độ. Cặp không thể sửa an toàn
```

**Dòng 130:** Chú thích, không thực thi.

```kotlin
 * được đổi thành 0,0 để không thể làm MapLibre crash.
```

**Dòng 131:** Chú thích, không thực thi.

```kotlin
 */
```

**Dòng 132:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
fun DeliveryOrder.normalizedCoordinates(): DeliveryOrder = when {
```

**Dòng 133:** Phép so sánh/điều kiện.

```kotlin
    isMapCoordinatePair(latitude, longitude) -> this
```

**Dòng 134:** Phép so sánh/điều kiện.

```kotlin
    isMapCoordinatePair(longitude, latitude) -> copy(latitude = longitude, longitude = latitude)
```

**Dòng 135:** Nhánh thay thế.

```kotlin
    else -> copy(latitude = 0.0, longitude = 0.0)
```

**Dòng 136:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 137:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 138:** Phép so sánh/điều kiện.

```kotlin
fun List<DeliveryOrder>.nextActiveSequence(): Int = filter { it.isRouteActive() }
```

**Dòng 139:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    .maxOfOrNull { it.sequence }
```

**Dòng 140:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    ?.plus(1)
```

**Dòng 141:** Elvis: dùng giá trị dự phòng khi null.

```kotlin
    ?: 1
```

**Dòng 142:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 143:** Chú thích, không thực thi.

```kotlin
/** Thứ tự nghiệp vụ chung: chưa tọa độ, đang giao, giao lại, kho lấy, tạm thời, hoàn toàn, đã giao. */
```

**Dòng 144:** Phép so sánh/điều kiện.

```kotlin
fun List<DeliveryOrder>.dispatchDisplayOrder(): List<DeliveryOrder> = sortedWith(
```

**Dòng 145:** Phép so sánh/điều kiện.

```kotlin
    compareBy<DeliveryOrder> {
```

**Dòng 146:** Rẽ nhánh nhiều trường hợp.

```kotlin
        when {
```

**Dòng 147:** Phép so sánh/điều kiện.

```kotlin
            it.deliveryOutcome() == DeliveryOutcome.ACTIVE && !it.hasStoredCoordinates() -> 0
```

**Dòng 148:** Phép so sánh/điều kiện.

```kotlin
            it.isRouteActive() -> 1
```

**Dòng 149:** Phép so sánh/điều kiện.

```kotlin
            it.isPickupAtWarehouse() -> 2
```

**Dòng 150:** Phép so sánh/điều kiện.

```kotlin
            it.isTemporaryFailure() -> 3
```

**Dòng 151:** Phép so sánh/điều kiện.

```kotlin
            it.isTerminalFailure() -> 4
```

**Dòng 152:** Phép so sánh/điều kiện.

```kotlin
            it.deliveryOutcome() == DeliveryOutcome.DELIVERED -> 5
```

**Dòng 153:** Nhánh thay thế.

```kotlin
            else -> 5
```

**Dòng 154:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 155:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }.thenBy { it.sequenceSortValue() }.thenBy { it.waybill },
```

**Dòng 156:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
)
```

**Dòng 157:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 158:** Chú thích, không thực thi.

```kotlin
/** Áp dụng số route đã chốt; đơn đã xử lý không còn số, các đơn còn lại không bị tái đánh số. */
```

**Dòng 159:** Phép so sánh/điều kiện.

```kotlin
fun List<DeliveryOrder>.withStableRouteSequence(sequenceByWaybill: Map<String, Int>): List<DeliveryOrder> =
```

**Dòng 160:** Phép so sánh/điều kiện.

```kotlin
    map { order ->
```

**Dòng 161:** Biến chỉ đọc.

```kotlin
        val sequence = sequenceByWaybill[order.waybill]
```

**Dòng 162:** Điều kiện if.

```kotlin
        if (sequence != null) order.copy(sequence = sequence, sequenceLabel = null) else order
```

**Dòng 163:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }.dispatchDisplayOrder()
```

**Dòng 164:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 165:** Phép so sánh/điều kiện.

```kotlin
fun List<DeliveryOrder>.withStableRouteLabels(sequenceByWaybill: Map<String, String>): List<DeliveryOrder> =
```

**Dòng 166:** Phép so sánh/điều kiện.

```kotlin
    map { order ->
```

**Dòng 167:** Biến chỉ đọc.

```kotlin
        val label = sequenceByWaybill[order.waybill]
```

**Dòng 168:** Điều kiện if.

```kotlin
        if (label != null) order.withSequenceLabel(label) else order
```

**Dòng 169:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }.dispatchDisplayOrder()
```

**Dòng 170:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 171:** Chú thích, không thực thi.

```kotlin
/**
```

**Dòng 172:** Chú thích, không thực thi.

```kotlin
 * Chèn STT mới vào tuyến và dồn các đơn phía sau sang STT kế tiếp.
```

**Dòng 173:** Chú thích, không thực thi.

```kotlin
 * Đơn vừa sửa được ưu tiên trước khi gặp STT trùng; các nhánh hợp lệ được giữ
```

**Dòng 174:** Chú thích, không thực thi.

```kotlin
 * nguyên nếu không xung đột, còn nhánh bị đẩy sẽ nhận số kế tiếp để không trùng.
```

**Dòng 175:** Chú thích, không thực thi.

```kotlin
 */
```

**Dòng 176:** Phép so sánh/điều kiện.

```kotlin
fun List<DeliveryOrder>.resequenceDraftLabels(
```

**Dòng 177:** Phép so sánh/điều kiện.

```kotlin
    drafts: Map<String, String>,
```

**Dòng 178:** Phép so sánh/điều kiện.

```kotlin
    original: Map<String, String>,
```

**Dòng 179:** Phép so sánh/điều kiện.

```kotlin
): Map<String, String> {
```

**Dòng 180:** Biến chỉ đọc.

```kotlin
    val routable = filter { it.canReceiveRouteSequence() && it.hasStoredCoordinates() }
```

**Dòng 181:** Biến chỉ đọc.

```kotlin
    val ranked = routable.groupBy { it.phoneGroupKey() }.values.mapIndexed { index, group ->
```

**Dòng 182:** Biến chỉ đọc.

```kotlin
        val order = group.first()
```

**Dòng 183:** Biến chỉ đọc.

```kotlin
        val label = group.map { drafts[it.waybill]?.trim().orEmpty().ifBlank { original[it.waybill].orEmpty().ifBlank { it.sequenceText() } } }
```

**Dòng 184:** Lấy phần tử đầu hoặc null.

```kotlin
            .firstOrNull { it.isNotBlank() } ?: ""
```

**Dòng 185:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        Triple(group, label, index)
```

**Dòng 186:** Lọc collection.

```kotlin
    }.filter { it.second.isNotBlank() && it.second.toSequenceSortValue() != null }
```

**Dòng 187:** Sắp xếp collection.

```kotlin
        .sortedWith(compareBy<Triple<List<DeliveryOrder>, String, Int>> { it.second.toSequenceSortValue() }
```

**Dòng 188:** Phép so sánh/điều kiện.

```kotlin
            .thenBy { if (it.first.any { order -> original[order.waybill] != it.second }) 0 else 1 }
```

**Dòng 189:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            .thenBy { it.third })
```

**Dòng 190:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 191:** Biến chỉ đọc.

```kotlin
    val result = linkedMapOf<String, String>()
```

**Dòng 192:** Biến có thể thay đổi.

```kotlin
    var previousSort = Long.MIN_VALUE
```

**Dòng 193:** Biến có thể thay đổi.

```kotlin
    var nextMajor = 0
```

**Dòng 194:** Phép so sánh/điều kiện.

```kotlin
    ranked.forEach { (group, preferred, _) ->
```

**Dòng 195:** Biến chỉ đọc.

```kotlin
        val preferredSort = preferred.toSequenceSortValue() ?: return@forEach
```

**Dòng 196:** Biến chỉ đọc.

```kotlin
        val assigned = if (preferredSort > previousSort) {
```

**Dòng 197:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            preferred
```

**Dòng 198:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        } else {
```

**Dòng 199:** Biến có thể thay đổi.

```kotlin
            var candidate = maxOf(nextMajor + 1, (previousSort / 1_000_000L).toInt() + 1)
```

**Dòng 200:** Phép so sánh/điều kiện.

```kotlin
            while (result.values.any { it.toSequenceSortValue() == candidate.toLong() * 1_000_000L }) candidate += 1
```

**Dòng 201:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            candidate.toString()
```

**Dòng 202:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 203:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        group.forEach { result[it.waybill] = assigned }
```

**Dòng 204:** Elvis: dùng giá trị dự phòng khi null.

```kotlin
        previousSort = assigned.toSequenceSortValue() ?: previousSort
```

**Dòng 205:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        nextMajor = maxOf(nextMajor, (previousSort / 1_000_000L).toInt())
```

**Dòng 206:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 207:** Kết thúc hàm và trả kết quả.

```kotlin
    return drafts + result
```

**Dòng 208:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 209:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 210:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
private fun String.toSequenceSortValue(): Long? {
```

**Dòng 211:** Biến chỉ đọc.

```kotlin
    val parts = trim().split('.', limit = 2)
```

**Dòng 212:** Biến chỉ đọc.

```kotlin
    val major = parts.firstOrNull()?.toIntOrNull() ?: return null
```

**Dòng 213:** Điều kiện if.

```kotlin
    if (major <= 0) return null
```

**Dòng 214:** Biến chỉ đọc.

```kotlin
    val minor = parts.getOrNull(1)?.let { if (it.equals("n", true)) 999_999 else it.toIntOrNull() ?: return null } ?: 0
```

**Dòng 215:** Điều kiện if.

```kotlin
    if (minor <= 0 && parts.size > 1) return null
```

**Dòng 216:** Kết thúc hàm và trả kết quả.

```kotlin
    return major.toLong() * 1_000_000L + minor
```

**Dòng 217:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 218:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 219:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
fun DeliveryOrder.withSequenceLabel(label: String): DeliveryOrder {
```

**Dòng 220:** Biến chỉ đọc.

```kotlin
    val normalized = label.trim()
```

**Dòng 221:** Biến chỉ đọc.

```kotlin
    val major = normalized.substringBefore('.').toIntOrNull() ?: 0
```

**Dòng 222:** Kết thúc hàm và trả kết quả.

```kotlin
    return copy(sequence = major, sequenceLabel = normalized.takeIf { it.contains('.') })
```

**Dòng 223:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 224:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 225:** Lọc collection.

```kotlin
fun List<DeliveryOrder>.filterForDetail(query: String, showDelivered: Boolean, showUnsuccessful: Boolean): List<DeliveryOrder> {
```

**Dòng 226:** Biến chỉ đọc.

```kotlin
    val normalized = query.trim().lowercase()
```

**Dòng 227:** Biến chỉ đọc.

```kotlin
    val matched = filter { order ->
```

**Dòng 228:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        normalized.isBlank() || listOf(order.waybill, order.customer, order.phone, order.cod.toString(), order.cod.formatVnd())
```

**Dòng 229:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            .any { it.lowercase().contains(normalized) }
```

**Dòng 230:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 231:** Biến chỉ đọc.

```kotlin
    val filtered = when {
```

**Dòng 232:** Lọc collection.

```kotlin
        showDelivered -> matched.filter { it.deliveryOutcome() == DeliveryOutcome.DELIVERED }
```

**Dòng 233:** Lọc collection.

```kotlin
        showUnsuccessful -> matched.filter { it.isTemporaryFailure() || it.isTerminalFailure() }
```

**Dòng 234:** Nhánh thay thế.

```kotlin
        else -> matched
```

**Dòng 235:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 236:** Kết thúc hàm và trả kết quả.

```kotlin
    return filtered.dispatchDisplayOrder()
```

**Dòng 237:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 238:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 239:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
fun sampleOrders() = listOf(
```

**Dòng 240:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    DeliveryOrder("LT250001", "Nguyễn Minh An", "0900001001", "12 Lê Duẩn, thị trấn Long Thành, Đồng Nai", "Thùng nước giặt 3.5L", 28000, "GBP", DeliveryStatus.TT500, 1, 10.7803, 106.9501),
```

**Dòng 241:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    DeliveryOrder("LT250002", "Trần Thu Hà", "0900001002", "45 Lê Duẩn, thị trấn Long Thành, Đồng Nai", "Sữa tắm chăm sóc da", 135000, "PTTX", DeliveryStatus.TT506, 2, 10.7821, 106.9518),
```

**Dòng 242:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    DeliveryOrder("LT250003", "Lê Quốc Bảo", "0900001003", "28 Nguyễn Văn Cừ, thị trấn Long Thành, Đồng Nai", "Phụ kiện điện thoại", 78000, "GH1P", DeliveryStatus.TT507, 3, 10.7758, 106.9529),
```

**Dòng 243:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    DeliveryOrder("LT250004", "Phạm Ngọc Lan", "0900001004", "67 Nguyễn Văn Cừ, thị trấn Long Thành, Đồng Nai", "Bình giữ nhiệt 1L", 92000, "GBP", DeliveryStatus.TT500, 4, 10.7735, 106.9486),
```

**Dòng 244:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    DeliveryOrder("LT250005", "Võ Thanh Tâm", "0900001005", "16 Trần Phú, thị trấn Long Thành, Đồng Nai", "Hộp cơm điện", 215000, "PTTX", DeliveryStatus.TT508, 5, 10.7774, 106.9447),
```

**Dòng 245:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    DeliveryOrder("LT250006", "Đặng Mỹ Duyên", "0900001006", "92 Trần Phú, thị trấn Long Thành, Đồng Nai", "Áo khoác chống nắng", 168000, "GH1P", DeliveryStatus.TT506, 6, 10.7843, 106.9434),
```

**Dòng 246:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    DeliveryOrder("LT250007", "Bùi Hoàng Nam", "0900001007", "08 Quốc lộ 51, xã An Phước, Long Thành, Đồng Nai", "Dầu nhớt xe máy", 125000, "GBP", DeliveryStatus.TT500, 7, 10.7990, 106.9404),
```

**Dòng 247:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    DeliveryOrder("LT250008", "Đỗ Thảo Vy", "0900001008", "120 Quốc lộ 51, xã An Phước, Long Thành, Đồng Nai", "Thực phẩm khô", 186000, "PTTX", DeliveryStatus.TT507, 8, 10.8068, 106.9370),
```

**Dòng 248:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    DeliveryOrder("LT250009", "Hồ Gia Huy", "0900001009", "35 ĐT 769, xã Lộc An, Long Thành, Đồng Nai", "Tai nghe Bluetooth", 359000, "GH1P", DeliveryStatus.TT506, 9, 10.7712, 106.9716),
```

**Dòng 249:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    DeliveryOrder("LT250010", "Ngô Khánh Linh", "0900001010", "88 ĐT 769, xã Lộc An, Long Thành, Đồng Nai", "Máy xay mini", 245000, "GBP", DeliveryStatus.TT500, 10, 10.7649, 106.9788),
```

**Dòng 250:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    DeliveryOrder("LT250011", "Dương Quốc Khánh", "0900001011", "14 Đường Cầu Mây, xã Long Đức, Long Thành, Đồng Nai", "Bộ dụng cụ sửa xe", 312000, "PTTX", DeliveryStatus.TT508, 11, 10.7586, 106.9252),
```

**Dòng 251:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    DeliveryOrder("LT250012", "Lý Bảo Trân", "0900001012", "56 Đường Cầu Mây, xã Long Đức, Long Thành, Đồng Nai", "Chăn hè 1.8m", 275000, "GH1P", DeliveryStatus.TT500, 12, 10.7541, 106.9185),
```

**Dòng 252:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    DeliveryOrder("LT250013", "Mai Tuấn Kiệt", "0900001013", "21 Đường Hùng Vương, thị trấn Long Thành, Đồng Nai", "Đèn bàn LED", 149000, "GBP", DeliveryStatus.TT506, 13, 10.7897, 106.9549),
```

**Dòng 253:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    DeliveryOrder("LT250014", "Tạ Hồng Phúc", "0900001014", "73 Đường Hùng Vương, thị trấn Long Thành, Đồng Nai", "Balo laptop", 420000, "PTTX", DeliveryStatus.TT507, 14, 10.7923, 106.9571),
```

**Dòng 254:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    DeliveryOrder("LT250015", "Cao Thu Trang", "0900001015", "18 Đường Nguyễn Huệ, thị trấn Long Thành, Đồng Nai", "Hộp đựng thực phẩm", 86000, "GH1P", DeliveryStatus.TT500, 15, 10.7865, 106.9460),
```

**Dòng 255:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    DeliveryOrder("LT250016", "Quách Nhật Minh", "0900001016", "90 Đường Nguyễn Huệ, thị trấn Long Thành, Đồng Nai", "Bàn phím không dây", 535000, "GBP", DeliveryStatus.TT508, 16, 10.7908, 106.9406),
```

**Dòng 256:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    DeliveryOrder("LT250017", "Châu Kim Ngân", "0900001017", "31 Đường Suối Trầu, xã Suối Trầu, Long Thành, Đồng Nai", "Mỹ phẩm chăm sóc tóc", 198000, "PTTX", DeliveryStatus.TT506, 17, 10.8031, 106.9316),
```

**Dòng 257:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    DeliveryOrder("LT250018", "Tống Anh Khoa", "0900001018", "76 Đường Suối Trầu, xã Suối Trầu, Long Thành, Đồng Nai", "Máy sấy tóc", 389000, "GH1P", DeliveryStatus.TT500, 18, 10.8097, 106.9364),
```

**Dòng 258:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    DeliveryOrder("LT250019", "La Mỹ Hạnh", "0900001019", "22 Đường Bàu Cạn, xã Bàu Cạn, Long Thành, Đồng Nai", "Thùng sữa hạt", 264000, "GBP", DeliveryStatus.TT507, 19, 10.7606, 106.9217),
```

**Dòng 259:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    DeliveryOrder("LT250020", "Triệu Đức Thành", "0900001020", "95 Đường Bàu Cạn, xã Bàu Cạn, Long Thành, Đồng Nai", "Quạt để bàn", 335000, "PTTX", DeliveryStatus.TT508, 20, 10.7554, 106.9248),
```

**Dòng 260:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
)
```

## `app/src/main/java/com/example/delivery/navigation/AnchorPointStore.kt`

**Dòng 1:** Khai báo package/namespace.

```kotlin
package com.example.delivery.navigation
```

**Dòng 2:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 3:** Import dependency.

```kotlin
import android.content.Context
```

**Dòng 4:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 5:** Chú thích, không thực thi.

```kotlin
/** Điểm Neo của tuyến giao, được giữ lại cho đến khi người dùng đặt điểm mới. */
```

**Dòng 6:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
object AnchorPointStore {
```

**Dòng 7:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    private const val PREFERENCES = "delivery_route_preferences"
```

**Dòng 8:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    private const val KEY_LATITUDE = "anchor_latitude"
```

**Dòng 9:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    private const val KEY_LONGITUDE = "anchor_longitude"
```

**Dòng 10:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 11:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    fun load(context: Context): GeoPoint? {
```

**Dòng 12:** Biến chỉ đọc.

```kotlin
        val preferences = context.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE)
```

**Dòng 13:** Biến chỉ đọc.

```kotlin
        val latitude = preferences.getString(KEY_LATITUDE, null)?.toDoubleOrNull()
```

**Dòng 14:** Biến chỉ đọc.

```kotlin
        val longitude = preferences.getString(KEY_LONGITUDE, null)?.toDoubleOrNull()
```

**Dòng 15:** Kết thúc hàm và trả kết quả.

```kotlin
        return if (latitude.isValidLatitude() && longitude.isValidLongitude()) {
```

**Dòng 16:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            GeoPoint(latitude!!, longitude!!)
```

**Dòng 17:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        } else {
```

**Dòng 18:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            null
```

**Dòng 19:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 20:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 21:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 22:** Chú thích, không thực thi.

```kotlin
    /** Ghi đồng bộ để điểm Neo không bị mất nếu app dừng đột ngột ngay sau khi chọn. */
```

**Dòng 23:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    fun save(context: Context, point: GeoPoint) {
```

**Dòng 24:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        require(point.latitude.isValidLatitude()) { "Vĩ độ điểm Neo không hợp lệ." }
```

**Dòng 25:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        require(point.longitude.isValidLongitude()) { "Kinh độ điểm Neo không hợp lệ." }
```

**Dòng 26:** Biến chỉ đọc.

```kotlin
        val saved = context.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE).edit()
```

**Dòng 27:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            .putString(KEY_LATITUDE, point.latitude.toString())
```

**Dòng 28:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            .putString(KEY_LONGITUDE, point.longitude.toString())
```

**Dòng 29:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            .commit()
```

**Dòng 30:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        check(saved) { "Không thể lưu điểm Neo." }
```

**Dòng 31:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 32:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 33:** Phép so sánh/điều kiện.

```kotlin
    private fun Double?.isValidLatitude(): Boolean = this != null && isFinite() && this in -90.0..90.0
```

**Dòng 34:** Phép so sánh/điều kiện.

```kotlin
    private fun Double?.isValidLongitude(): Boolean = this != null && isFinite() && this in -180.0..180.0
```

**Dòng 35:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

## `app/src/main/java/com/example/delivery/navigation/DeliveryRouteStore.kt`

**Dòng 1:** Khai báo package/namespace.

```kotlin
package com.example.delivery.navigation
```

**Dòng 2:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 3:** Import dependency.

```kotlin
import android.content.Context
```

**Dòng 4:** Import dependency.

```kotlin
import org.json.JSONArray
```

**Dòng 5:** Import dependency.

```kotlin
import org.json.JSONObject
```

**Dòng 6:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 7:** Chú thích, không thực thi.

```kotlin
/** Một Zone là đa giác có từ ba đỉnh trở lên, không giới hạn số đỉnh; thứ tự trong danh sách là ưu tiên tuyến. */
```

**Dòng 8:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
data class DeliveryZone(
```

**Dòng 9:** Biến chỉ đọc.

```kotlin
    val id: String,
```

**Dòng 10:** Biến chỉ đọc.

```kotlin
    val name: String,
```

**Dòng 11:** Biến chỉ đọc.

```kotlin
    val points: List<GeoPoint>,
```

**Dòng 12:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
)
```

**Dòng 13:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 14:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
object DeliveryRouteStore {
```

**Dòng 15:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    private const val PREFS = "delivery_route_preferences"
```

**Dòng 16:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    private const val ZONES = "delivery_zones_v1"
```

**Dòng 17:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    private const val ROUTE_ACTIVE = "route_active"
```

**Dòng 18:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 19:** Phép so sánh/điều kiện.

```kotlin
    fun loadZones(context: Context): List<DeliveryZone> = runCatching {
```

**Dòng 20:** Biến chỉ đọc.

```kotlin
        val array = JSONArray(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(ZONES, "[]"))
```

**Dòng 21:** Phép so sánh/điều kiện.

```kotlin
        List(array.length()) { index ->
```

**Dòng 22:** Biến chỉ đọc.

```kotlin
            val item = array.getJSONObject(index)
```

**Dòng 23:** Biến chỉ đọc.

```kotlin
            val points = item.getJSONArray("points").let { coords ->
```

**Dòng 24:** Phép so sánh/điều kiện.

```kotlin
                List(coords.length()) { point ->
```

**Dòng 25:** Biến chỉ đọc.

```kotlin
                    val p = coords.getJSONObject(point)
```

**Dòng 26:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    GeoPoint(p.getDouble("lat"), p.getDouble("lng"))
```

**Dòng 27:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                }
```

**Dòng 28:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 29:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            DeliveryZone(item.getString("id"), item.optString("name", "Zone ${index + 1}"), points)
```

**Dòng 30:** Lọc collection.

```kotlin
        }.filter { it.points.size >= 3 }
```

**Dòng 31:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }.getOrDefault(emptyList())
```

**Dòng 32:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 33:** Phép so sánh/điều kiện.

```kotlin
    fun saveZones(context: Context, zones: List<DeliveryZone>) {
```

**Dòng 34:** Phép so sánh/điều kiện.

```kotlin
        require(zones.all { it.points.size >= 3 }) { "Mỗi Zone phải có ít nhất 3 điểm." }
```

**Dòng 35:** Biến chỉ đọc.

```kotlin
        val array = JSONArray().apply {
```

**Dòng 36:** Phép so sánh/điều kiện.

```kotlin
            zones.forEach { zone ->
```

**Dòng 37:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                put(JSONObject().put("id", zone.id).put("name", zone.name).put("points", JSONArray().apply {
```

**Dòng 38:** Phép so sánh/điều kiện.

```kotlin
                    zone.points.forEach { point -> put(JSONObject().put("lat", point.latitude).put("lng", point.longitude)) }
```

**Dòng 39:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                }))
```

**Dòng 40:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 41:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 42:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        check(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(ZONES, array.toString()).commit())
```

**Dòng 43:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 44:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 45:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    fun isRouteActive(context: Context): Boolean = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(ROUTE_ACTIVE, false)
```

**Dòng 46:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    fun setRouteActive(context: Context, active: Boolean) {
```

**Dòng 47:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        check(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(ROUTE_ACTIVE, active).commit())
```

**Dòng 48:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 49:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    fun clearRoute(context: Context) {
```

**Dòng 50:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        setRouteActive(context, false)
```

**Dòng 51:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 52:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 53:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    fun contains(zone: DeliveryZone, latitude: Double, longitude: Double): Boolean {
```

**Dòng 54:** Điều kiện if.

```kotlin
        if (zone.points.size < 3) return false
```

**Dòng 55:** Biến chỉ đọc.

```kotlin
        val x = longitude; val y = latitude
```

**Dòng 56:** Biến có thể thay đổi.

```kotlin
        var inside = false
```

**Dòng 57:** Phép so sánh/điều kiện.

```kotlin
        zone.points.indices.forEach { i ->
```

**Dòng 58:** Biến chỉ đọc.

```kotlin
            val a = zone.points[i]; val b = zone.points[(i + 1) % zone.points.size]
```

**Dòng 59:** Biến chỉ đọc.

```kotlin
            val intersects = ((a.latitude > y) != (b.latitude > y)) && (x < (b.longitude - a.longitude) * (y - a.latitude) / (b.latitude - a.latitude) + a.longitude)
```

**Dòng 60:** Điều kiện if.

```kotlin
            if (intersects) inside = !inside
```

**Dòng 61:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 62:** Kết thúc hàm và trả kết quả.

```kotlin
        return inside
```

**Dòng 63:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 64:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

## `app/src/main/java/com/example/delivery/navigation/GoongApiConfig.kt`

**Dòng 1:** Khai báo package/namespace.

```kotlin
package com.example.delivery.navigation
```

**Dòng 2:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 3:** Import dependency.

```kotlin
import com.example.delivery.BuildConfig
```

**Dòng 4:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 5:** Chú thích, không thực thi.

```kotlin
/**
```

**Dòng 6:** Chú thích, không thực thi.

```kotlin
 * GOONG API CONFIGURATION — đặt ở đầu package navigation để dễ tìm và kiểm tra.
```

**Dòng 7:** Chú thích, không thực thi.

```kotlin
 *
```

**Dòng 8:** Chú thích, không thực thi.

```kotlin
 * API #1: Map Tiles/Style: tiles.goong.io (MapLibre dùng style JSON + các tile/font/sprite resource).
```

**Dòng 9:** Chú thích, không thực thi.

```kotlin
 * API #2: Directions REST: rsapi.goong.io/Direction (tính tuyến đường giữa hai điểm).
```

**Dòng 10:** Chú thích, không thực thi.

```kotlin
 *
```

**Dòng 11:** Chú thích, không thực thi.

```kotlin
 * API key thật không đặt trong source. Gradle lấy từ local.properties:
```

**Dòng 12:** Chú thích, không thực thi.

```kotlin
 * GOONG_MAP_TILES_KEY và GOONG_REST_API_KEY.
```

**Dòng 13:** Chú thích, không thực thi.

```kotlin
 */
```

**Dòng 14:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
internal object GoongApiConfig {
```

**Dòng 15:** Chú thích, không thực thi.

```kotlin
    /** GOONG Map Tiles key được Gradle đưa vào BuildConfig từ local.properties. */
```

**Dòng 16:** Biến chỉ đọc.

```kotlin
    val mapTilesKey: String
```

**Dòng 17:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        get() = BuildConfig.GOONG_MAP_TILES_KEY
```

**Dòng 18:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 19:** Chú thích, không thực thi.

```kotlin
    /** GOONG REST Directions key được Gradle đưa vào BuildConfig từ local.properties. */
```

**Dòng 20:** Biến chỉ đọc.

```kotlin
    val restApiKey: String
```

**Dòng 21:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        get() = BuildConfig.GOONG_REST_API_KEY
```

**Dòng 22:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 23:** Chú thích, không thực thi.

```kotlin
    /** Endpoint REST dùng để gọi API Directions. */
```

**Dòng 24:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    const val directionsEndpoint = "https://rsapi.goong.io/Direction"
```

**Dòng 25:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 26:** Chú thích, không thực thi.

```kotlin
    /** Base domain của hệ thống Map Tiles GOONG, dùng để kiểm tra/cấu hình style. */
```

**Dòng 27:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    const val mapTilesEndpoint = "https://tiles.goong.io/"
```

**Dòng 28:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

## `app/src/main/java/com/example/delivery/navigation/GoongDirectionsRepository.kt`

**Dòng 1:** Khai báo package/namespace.

```kotlin
package com.example.delivery.navigation
```

**Dòng 2:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 3:** Import dependency.

```kotlin
import android.net.Uri
```

**Dòng 4:** Import dependency.

```kotlin
import kotlinx.coroutines.delay
```

**Dòng 5:** Import dependency.

```kotlin
import kotlinx.coroutines.Dispatchers
```

**Dòng 6:** Import dependency.

```kotlin
import kotlinx.coroutines.withContext
```

**Dòng 7:** Import dependency.

```kotlin
import org.json.JSONObject
```

**Dòng 8:** Import dependency.

```kotlin
import java.io.IOException
```

**Dòng 9:** Import dependency.

```kotlin
import java.net.HttpURLConnection
```

**Dòng 10:** Import dependency.

```kotlin
import java.net.URL
```

**Dòng 11:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 12:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
data class GeoPoint(val latitude: Double, val longitude: Double)
```

**Dòng 13:** Phép so sánh/điều kiện.

```kotlin
data class GoongRoute(val points: List<GeoPoint>)
```

**Dòng 14:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 15:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
class GoongDirectionsRepository {
```

**Dòng 16:** Phép so sánh/điều kiện.

```kotlin
    suspend fun directions(origin: GeoPoint, destination: GeoPoint): Result<GoongRoute> = withContext(Dispatchers.IO) {
```

**Dòng 17:** Biến chỉ đọc.

```kotlin
        val key = GoongApiConfig.restApiKey
```

**Dòng 18:** Điều kiện if.

```kotlin
        if (key.isBlank()) return@withContext Result.failure(IllegalStateException("Thiếu GOONG_REST_API_KEY"))
```

**Dòng 19:** Biến có thể thay đổi.

```kotlin
        var lastError: Throwable? = null
```

**Dòng 20:** Phép so sánh/điều kiện.

```kotlin
        repeat(3) { attempt ->
```

**Dòng 21:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            try {
```

**Dòng 22:** Kết thúc hàm và trả kết quả.

```kotlin
                return@withContext Result.success(requestDirections(origin, destination, key))
```

**Dòng 23:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            } catch (error: Throwable) {
```

**Dòng 24:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                lastError = error
```

**Dòng 25:** Điều kiện if.

```kotlin
                if (attempt < 2) delay(450L * (attempt + 1))
```

**Dòng 26:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 27:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 28:** Elvis: dùng giá trị dự phòng khi null.

```kotlin
        Result.failure(lastError ?: IOException("Goong Directions không trả được tuyến đường"))
```

**Dòng 29:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 30:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 31:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun requestDirections(origin: GeoPoint, destination: GeoPoint, key: String): GoongRoute {
```

**Dòng 32:** Biến chỉ đọc.

```kotlin
        val url = Uri.parse(GoongApiConfig.directionsEndpoint).buildUpon()
```

**Dòng 33:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            .appendQueryParameter("origin", "${origin.latitude},${origin.longitude}")
```

**Dòng 34:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            .appendQueryParameter("destination", "${destination.latitude},${destination.longitude}")
```

**Dòng 35:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            .appendQueryParameter("vehicle", "car")
```

**Dòng 36:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            .appendQueryParameter("api_key", key)
```

**Dòng 37:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            .build().toString()
```

**Dòng 38:** Biến chỉ đọc.

```kotlin
        val connection = URL(url).openConnection() as HttpURLConnection
```

**Dòng 39:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        connection.connectTimeout = 10_000
```

**Dòng 40:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        connection.readTimeout = 12_000
```

**Dòng 41:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        connection.requestMethod = "GET"
```

**Dòng 42:** Kết thúc hàm và trả kết quả.

```kotlin
        return try {
```

**Dòng 43:** Điều kiện if.

```kotlin
            if (connection.responseCode !in 200..299) throw IOException("Goong Directions HTTP ${connection.responseCode}")
```

**Dòng 44:** Biến chỉ đọc.

```kotlin
            val body = connection.inputStream.bufferedReader().use { it.readText() }
```

**Dòng 45:** Biến chỉ đọc.

```kotlin
            val route = JSONObject(body).optJSONArray("routes")?.optJSONObject(0)
```

**Dòng 46:** Biến chỉ đọc.

```kotlin
            val encoded = route?.optJSONObject("overview_polyline")?.optString("points") ?: route?.optString("overview_polyline")
```

**Dòng 47:** Biến chỉ đọc.

```kotlin
            val points = encoded?.takeIf { it.isNotBlank() }?.let(::decodePolyline).orEmpty()
```

**Dòng 48:** Phép so sánh/điều kiện.

```kotlin
            require(points.size >= 2) { "Goong Directions không có overview_polyline" }
```

**Dòng 49:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            GoongRoute(points)
```

**Dòng 50:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        } finally {
```

**Dòng 51:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            connection.disconnect()
```

**Dòng 52:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 53:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 54:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 55:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    companion object {
```

**Dòng 56:** Phép so sánh/điều kiện.

```kotlin
        fun decodePolyline(encoded: String): List<GeoPoint> {
```

**Dòng 57:** Biến chỉ đọc.

```kotlin
            val points = mutableListOf<GeoPoint>()
```

**Dòng 58:** Biến có thể thay đổi.

```kotlin
            var index = 0
```

**Dòng 59:** Biến có thể thay đổi.

```kotlin
            var latitude = 0
```

**Dòng 60:** Biến có thể thay đổi.

```kotlin
            var longitude = 0
```

**Dòng 61:** Phép so sánh/điều kiện.

```kotlin
            while (index < encoded.length) {
```

**Dòng 62:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
                fun decodeValue(): Int {
```

**Dòng 63:** Biến có thể thay đổi.

```kotlin
                    var shift = 0
```

**Dòng 64:** Biến có thể thay đổi.

```kotlin
                    var result = 0
```

**Dòng 65:** Phép so sánh/điều kiện.

```kotlin
                    while (index < encoded.length) {
```

**Dòng 66:** Biến chỉ đọc.

```kotlin
                        val value = encoded[index++].code - 63
```

**Dòng 67:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        result = result or ((value and 0x1f) shl shift)
```

**Dòng 68:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        shift += 5
```

**Dòng 69:** Điều kiện if.

```kotlin
                        if (value < 0x20) break
```

**Dòng 70:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    }
```

**Dòng 71:** Kết thúc hàm và trả kết quả.

```kotlin
                    return if ((result and 1) != 0) (result shr 1).inv() else result shr 1
```

**Dòng 72:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                }
```

**Dòng 73:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                latitude += decodeValue()
```

**Dòng 74:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                longitude += decodeValue()
```

**Dòng 75:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                points += GeoPoint(latitude / 1e5, longitude / 1e5)
```

**Dòng 76:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 77:** Kết thúc hàm và trả kết quả.

```kotlin
            return points
```

**Dòng 78:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 79:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 80:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

## `app/src/main/java/com/example/delivery/navigation/RoutePlanner.kt`

**Dòng 1:** Khai báo package/namespace.

```kotlin
package com.example.delivery.navigation
```

**Dòng 2:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 3:** Import dependency.

```kotlin
import com.example.delivery.model.DeliveryOrder
```

**Dòng 4:** Import dependency.

```kotlin
import com.example.delivery.model.dispatchDisplayOrder
```

**Dòng 5:** Import dependency.

```kotlin
import com.example.delivery.model.hasStoredCoordinates
```

**Dòng 6:** Import dependency.

```kotlin
import com.example.delivery.model.isRouteActive
```

**Dòng 7:** Import dependency.

```kotlin
import com.example.delivery.model.sequenceText
```

**Dòng 8:** Import dependency.

```kotlin
import com.example.delivery.model.sequenceSortValue
```

**Dòng 9:** Import dependency.

```kotlin
import com.example.delivery.model.phoneGroupKey
```

**Dòng 10:** Import dependency.

```kotlin
import kotlin.math.atan2
```

**Dòng 11:** Import dependency.

```kotlin
import kotlin.math.cos
```

**Dòng 12:** Import dependency.

```kotlin
import kotlin.math.sin
```

**Dòng 13:** Import dependency.

```kotlin
import kotlin.math.sqrt
```

**Dòng 14:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 15:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
private const val EARTH_RADIUS_METERS = 6_371_000.0
```

**Dòng 16:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 17:** Chú thích, không thực thi.

```kotlin
/** Ưu tiên điểm Neo đã lưu; GPS chỉ là phương án thay thế khi chưa có điểm Neo. */
```

**Dòng 18:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
fun preferredRouteOrigin(anchorPoint: GeoPoint?, currentLocation: GeoPoint?, fallback: GeoPoint?): GeoPoint? =
```

**Dòng 19:** Elvis: dùng giá trị dự phòng khi null.

```kotlin
    anchorPoint ?: currentLocation ?: fallback
```

**Dòng 20:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 21:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
fun distanceMeters(from: GeoPoint, to: GeoPoint): Double {
```

**Dòng 22:** Biến chỉ đọc.

```kotlin
    val deltaLatitude = Math.toRadians(to.latitude - from.latitude)
```

**Dòng 23:** Biến chỉ đọc.

```kotlin
    val deltaLongitude = Math.toRadians(to.longitude - from.longitude)
```

**Dòng 24:** Biến chỉ đọc.

```kotlin
    val latitudeOne = Math.toRadians(from.latitude)
```

**Dòng 25:** Biến chỉ đọc.

```kotlin
    val latitudeTwo = Math.toRadians(to.latitude)
```

**Dòng 26:** Biến chỉ đọc.

```kotlin
    val haversine = sin(deltaLatitude / 2) * sin(deltaLatitude / 2) +
```

**Dòng 27:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        cos(latitudeOne) * cos(latitudeTwo) * sin(deltaLongitude / 2) * sin(deltaLongitude / 2)
```

**Dòng 28:** Kết thúc hàm và trả kết quả.

```kotlin
    return EARTH_RADIUS_METERS * 2 * atan2(sqrt(haversine), sqrt(1 - haversine))
```

**Dòng 29:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 30:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 31:** Chú thích, không thực thi.

```kotlin
/**
```

**Dòng 32:** Chú thích, không thực thi.

```kotlin
 * Lập tuyến hai bước: chọn điểm kế gần nhất từ GPS hiện tại, sau đó tối ưu toàn cục
```

**Dòng 33:** Chú thích, không thực thi.

```kotlin
 * bằng 2-opt và phép chuyển điểm. Phép chuyển điểm xử lý các trường hợp greedy
```

**Dòng 34:** Chú thích, không thực thi.

```kotlin
 * chen một điểm xa vào giữa một cụm giao gần nhau.
```

**Dòng 35:** Chú thích, không thực thi.

```kotlin
 */
```

**Dòng 36:** Phép so sánh/điều kiện.

```kotlin
fun routeOrdersFrom(origin: GeoPoint, orders: List<DeliveryOrder>): List<DeliveryOrder> = routeOrdersFromZones(origin, orders, emptyList())
```

**Dòng 37:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 38:** Chú thích, không thực thi.

```kotlin
/**
```

**Dòng 39:** Chú thích, không thực thi.

```kotlin
 * Sắp xếp các block SĐT theo kinh độ tăng dần (trái sang phải), sau đó vĩ độ
```

**Dòng 40:** Chú thích, không thực thi.

```kotlin
 * tăng dần (dưới lên trên). Trong cùng ô địa lý lân cận, Zone được ưu tiên
```

**Dòng 41:** Chú thích, không thực thi.

```kotlin
 * theo thứ tự trong danh sách Zone để không tách các MVĐ gần nhau quá xa.
```

**Dòng 42:** Chú thích, không thực thi.

```kotlin
 */
```

**Dòng 43:** Phép so sánh/điều kiện.

```kotlin
fun orderRouteGroupsByZoneAndGeo(groups: Collection<List<DeliveryOrder>>, zones: List<DeliveryZone>): List<List<DeliveryOrder>> {
```

**Dòng 44:** Điều kiện if.

```kotlin
    if (groups.size <= 1) return groups.toList()
```

**Dòng 45:** Biến đổi collection.

```kotlin
    fun center(group: List<DeliveryOrder>) = GeoPoint(group.map { it.latitude }.average(), group.map { it.longitude }.average())
```

**Dòng 46:** Phép so sánh/điều kiện.

```kotlin
    fun zoneRank(group: List<DeliveryOrder>): Int = zones.indexOfFirst { zone ->
```

**Dòng 47:** Phép so sánh/điều kiện.

```kotlin
        group.any { order -> DeliveryRouteStore.contains(zone, order.latitude, order.longitude) }
```

**Dòng 48:** Phép so sánh/điều kiện.

```kotlin
    }.let { if (it < 0) Int.MAX_VALUE else it }
```

**Dòng 49:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 50:** Biến chỉ đọc.

```kotlin
    val remaining = groups.toMutableList()
```

**Dòng 51:** Biến chỉ đọc.

```kotlin
    val ordered = mutableListOf<List<DeliveryOrder>>()
```

**Dòng 52:** Biến có thể thay đổi.

```kotlin
    var cursorGroup = remaining.minWithOrNull(compareBy<List<DeliveryOrder>>(
```

**Dòng 53:** Phép so sánh/điều kiện.

```kotlin
        { group -> center(group).longitude },
```

**Dòng 54:** Phép so sánh/điều kiện.

```kotlin
        { group -> center(group).latitude },
```

**Dòng 55:** Phép so sánh/điều kiện.

```kotlin
        { group -> zoneRank(group) },
```

**Dòng 56:** Phép so sánh/điều kiện.

```kotlin
        { group -> group.minOf { it.waybill } },
```

**Dòng 57:** Elvis: dùng giá trị dự phòng khi null.

```kotlin
    )) ?: return emptyList()
```

**Dòng 58:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    remaining.remove(cursorGroup)
```

**Dòng 59:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    ordered += cursorGroup
```

**Dòng 60:** Biến có thể thay đổi.

```kotlin
    var cursor = center(cursorGroup)
```

**Dòng 61:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 62:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    while (remaining.isNotEmpty()) {
```

**Dòng 63:** Biến chỉ đọc.

```kotlin
        val next = remaining.minWithOrNull(compareBy<List<DeliveryOrder>>(
```

**Dòng 64:** Phép so sánh/điều kiện.

```kotlin
            { group ->
```

**Dòng 65:** Biến chỉ đọc.

```kotlin
                val target = center(group)
```

**Dòng 66:** Biến chỉ đọc.

```kotlin
                val travel = distanceMeters(cursor, target)
```

**Dòng 67:** Chú thích, không thực thi.

```kotlin
                // Giữ chiều trái-phải: chỉ chấp nhận đi lùi khi quãng đường ngắn hơn rõ rệt.
```

**Dòng 68:** Biến chỉ đọc.

```kotlin
                val backward = ((cursor.longitude - target.longitude).coerceAtLeast(0.0)) * 111_000.0
```

**Dòng 69:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                travel + backward * 2.0
```

**Dòng 70:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            },
```

**Dòng 71:** Phép so sánh/điều kiện.

```kotlin
            { group -> zoneRank(group) },
```

**Dòng 72:** Phép so sánh/điều kiện.

```kotlin
            { group -> center(group).longitude },
```

**Dòng 73:** Phép so sánh/điều kiện.

```kotlin
            { group -> center(group).latitude },
```

**Dòng 74:** Phép so sánh/điều kiện.

```kotlin
            { group -> group.minOf { it.waybill } },
```

**Dòng 75:** Elvis: dùng giá trị dự phòng khi null.

```kotlin
        )) ?: break
```

**Dòng 76:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        ordered += next
```

**Dòng 77:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        cursor = center(next)
```

**Dòng 78:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        remaining.remove(next)
```

**Dòng 79:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 80:** Kết thúc hàm và trả kết quả.

```kotlin
    return ordered
```

**Dòng 81:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 82:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 83:** Chú thích, không thực thi.

```kotlin
/** Lập tuyến theo ưu tiên Zone; trong mỗi Zone sắp gần đến xa, ngoài Zone xếp sau. */
```

**Dòng 84:** Phép so sánh/điều kiện.

```kotlin
fun routeOrdersFromZones(origin: GeoPoint, orders: List<DeliveryOrder>, zones: List<DeliveryZone>): List<DeliveryOrder> {
```

**Dòng 85:** Biến chỉ đọc.

```kotlin
    val candidates = orders.filter { it.isRouteActive() && it.hasStoredCoordinates() }
```

**Dòng 86:** Biến chỉ đọc.

```kotlin
    val groups = candidates.groupBy { it.phoneGroupKey() }.values
```

**Dòng 87:** Biến chỉ đọc.

```kotlin
    val orderedGroups = if (zones.isEmpty()) nearestNeighborGroups(origin, groups) else orderRouteGroupsByZoneAndGeo(groups, zones)
```

**Dòng 88:** Kết thúc hàm và trả kết quả.

```kotlin
    return orderedGroups.flatMapIndexed { index, group ->
```

**Dòng 89:** Sắp xếp collection.

```kotlin
        group.sortedWith(compareBy<DeliveryOrder> { it.longitude }.thenBy { it.latitude }.thenBy { it.waybill })
```

**Dòng 90:** Biến đổi collection.

```kotlin
            .map { it.copy(sequence = index + 1) }
```

**Dòng 91:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 92:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 93:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 94:** Phép so sánh/điều kiện.

```kotlin
private fun nearestNeighborGroups(origin: GeoPoint, groups: Collection<List<DeliveryOrder>>): List<List<DeliveryOrder>> {
```

**Dòng 95:** Biến chỉ đọc.

```kotlin
    val remaining = groups.toMutableList()
```

**Dòng 96:** Biến chỉ đọc.

```kotlin
    val result = mutableListOf<List<DeliveryOrder>>()
```

**Dòng 97:** Biến có thể thay đổi.

```kotlin
    var cursor = origin
```

**Dòng 98:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    while (remaining.isNotEmpty()) {
```

**Dòng 99:** Biến chỉ đọc.

```kotlin
        val next = remaining.minByOrNull { group -> group.minOf { distanceMeters(cursor, GeoPoint(it.latitude, it.longitude)) } } ?: break
```

**Dòng 100:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        result += next
```

**Dòng 101:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        cursor = next.minBy { distanceMeters(cursor, GeoPoint(it.latitude, it.longitude)) }.let { GeoPoint(it.latitude, it.longitude) }
```

**Dòng 102:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        remaining.remove(next)
```

**Dòng 103:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 104:** Kết thúc hàm và trả kết quả.

```kotlin
    return result
```

**Dòng 105:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 106:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 107:** Phép so sánh/điều kiện.

```kotlin
private fun nearestNeighbor(origin: GeoPoint, orders: List<DeliveryOrder>): List<DeliveryOrder> {
```

**Dòng 108:** Biến chỉ đọc.

```kotlin
    val remaining = orders.toMutableList()
```

**Dòng 109:** Biến chỉ đọc.

```kotlin
    val result = mutableListOf<DeliveryOrder>()
```

**Dòng 110:** Biến có thể thay đổi.

```kotlin
    var cursor = origin
```

**Dòng 111:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    while (remaining.isNotEmpty()) {
```

**Dòng 112:** Biến chỉ đọc.

```kotlin
        val next = remaining.minByOrNull { distanceMeters(cursor, GeoPoint(it.latitude, it.longitude)) } ?: break
```

**Dòng 113:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        result += next
```

**Dòng 114:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        cursor = GeoPoint(next.latitude, next.longitude)
```

**Dòng 115:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        remaining.remove(next)
```

**Dòng 116:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 117:** Kết thúc hàm và trả kết quả.

```kotlin
    return result
```

**Dòng 118:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 119:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 120:** Chú thích, không thực thi.

```kotlin
/** Đảo các đoạn tuyến khi việc đảo làm giảm tổng quãng đường đi thực tế. */
```

**Dòng 121:** Phép so sánh/điều kiện.

```kotlin
private fun optimizeRoute(origin: GeoPoint, initial: List<DeliveryOrder>): List<DeliveryOrder> {
```

**Dòng 122:** Điều kiện if.

```kotlin
    if (initial.size < 3) return initial
```

**Dòng 123:** Biến có thể thay đổi.

```kotlin
    var route = initial
```

**Dòng 124:** Biến có thể thay đổi.

```kotlin
    var bestDistance = routeDistanceMeters(origin, route)
```

**Dòng 125:** Biến có thể thay đổi.

```kotlin
    var improved = true
```

**Dòng 126:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    while (improved) {
```

**Dòng 127:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        improved = false
```

**Dòng 128:** Biến có thể thay đổi.

```kotlin
        var bestCandidate = route
```

**Dòng 129:** Biến có thể thay đổi.

```kotlin
        var bestCandidateDistance = bestDistance
```

**Dòng 130:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 131:** Chú thích, không thực thi.

```kotlin
        // Thử toàn bộ phép đảo đoạn 2-opt, chọn ứng viên tốt nhất của lượt hiện tại.
```

**Dòng 132:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        for (start in 0 until route.lastIndex) {
```

**Dòng 133:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            for (end in start + 1..route.lastIndex) {
```

**Dòng 134:** Biến chỉ đọc.

```kotlin
                val candidate = route.toMutableList().apply { subList(start, end + 1).reverse() }
```

**Dòng 135:** Biến chỉ đọc.

```kotlin
                val candidateDistance = routeDistanceMeters(origin, candidate)
```

**Dòng 136:** Điều kiện if.

```kotlin
                if (candidateDistance + 0.5 < bestCandidateDistance) {
```

**Dòng 137:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    bestCandidate = candidate
```

**Dòng 138:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    bestCandidateDistance = candidateDistance
```

**Dòng 139:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                }
```

**Dòng 140:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 141:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 142:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 143:** Chú thích, không thực thi.

```kotlin
        // Thử đưa từng điểm ra khỏi vị trí cũ và chèn vào vị trí khác. Đây là bước
```

**Dòng 144:** Chú thích, không thực thi.

```kotlin
        // giữ các điểm sát nhau thành một cụm ngay cả khi nearest-neighbor ban đầu bị chen.
```

**Dòng 145:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        for (from in route.indices) {
```

**Dòng 146:** Biến chỉ đọc.

```kotlin
            val without = route.toMutableList().apply { removeAt(from) }
```

**Dòng 147:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            for (insertion in 0..without.size) {
```

**Dòng 148:** Biến chỉ đọc.

```kotlin
                val candidate = without.toMutableList().apply { add(insertion, route[from]) }
```

**Dòng 149:** Biến chỉ đọc.

```kotlin
                val candidateDistance = routeDistanceMeters(origin, candidate)
```

**Dòng 150:** Điều kiện if.

```kotlin
                if (candidateDistance + 0.5 < bestCandidateDistance) {
```

**Dòng 151:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    bestCandidate = candidate
```

**Dòng 152:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    bestCandidateDistance = candidateDistance
```

**Dòng 153:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                }
```

**Dòng 154:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 155:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 156:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 157:** Điều kiện if.

```kotlin
        if (bestCandidateDistance + 0.5 < bestDistance) {
```

**Dòng 158:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            route = bestCandidate
```

**Dòng 159:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            bestDistance = bestCandidateDistance
```

**Dòng 160:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            improved = true
```

**Dòng 161:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 162:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 163:** Kết thúc hàm và trả kết quả.

```kotlin
    return route
```

**Dòng 164:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 165:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 166:** Phép so sánh/điều kiện.

```kotlin
fun routeDistanceMeters(origin: GeoPoint, route: List<DeliveryOrder>): Double {
```

**Dòng 167:** Biến có thể thay đổi.

```kotlin
    var total = 0.0
```

**Dòng 168:** Biến có thể thay đổi.

```kotlin
    var cursor = origin
```

**Dòng 169:** Phép so sánh/điều kiện.

```kotlin
    route.forEach { order ->
```

**Dòng 170:** Biến chỉ đọc.

```kotlin
        val next = GeoPoint(order.latitude, order.longitude)
```

**Dòng 171:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        total += distanceMeters(cursor, next)
```

**Dòng 172:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        cursor = next
```

**Dòng 173:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 174:** Kết thúc hàm và trả kết quả.

```kotlin
    return total
```

**Dòng 175:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 176:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 177:** Chú thích, không thực thi.

```kotlin
/**
```

**Dòng 178:** Chú thích, không thực thi.

```kotlin
 * Trả về đúng một danh sách để mọi tab dùng chung: các điểm GPS đang giao được
```

**Dòng 179:** Chú thích, không thực thi.

```kotlin
 * đánh số nearest-neighbor, sau đó là đơn thất bại không số, rồi đơn đã giao không số.
```

**Dòng 180:** Chú thích, không thực thi.

```kotlin
 */
```

**Dòng 181:** Phép so sánh/điều kiện.

```kotlin
fun routeOrdersForDisplay(origin: GeoPoint, orders: List<DeliveryOrder>): List<DeliveryOrder> {
```

**Dòng 182:** Biến chỉ đọc.

```kotlin
    val active = routeOrdersFrom(origin, orders)
```

**Dòng 183:** Biến chỉ đọc.

```kotlin
    val inactive = orders.filterNot { it.isRouteActive() }.dispatchDisplayOrder()
```

**Dòng 184:** Kết thúc hàm và trả kết quả.

```kotlin
    return active + inactive
```

**Dòng 185:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 186:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 187:** Chú thích, không thực thi.

```kotlin
/**
```

**Dòng 188:** Chú thích, không thực thi.

```kotlin
 * Khôi phục bản đồ STT đã commit trong DeliveryOrderStore. Không dùng GPS để
```

**Dòng 189:** Chú thích, không thực thi.

```kotlin
 * tính lại khi bản đồ đã có STT; việc đổi tuyến phải đi qua thao tác xác nhận.
```

**Dòng 190:** Chú thích, không thực thi.

```kotlin
 */
```

**Dòng 191:** Phép so sánh/điều kiện.

```kotlin
fun List<DeliveryOrder>.persistedRouteSequence(): Map<String, Int> =
```

**Dòng 192:** Phép so sánh/điều kiện.

```kotlin
    filter { it.isRouteActive() && it.hasStoredCoordinates() && it.sequence > 0 && it.sequenceLabel == null }
```

**Dòng 193:** Sắp xếp collection.

```kotlin
        .sortedWith(compareBy<DeliveryOrder> { it.sequence }.thenBy { it.waybill })
```

**Dòng 194:** Tạo Map key/value.

```kotlin
        .associate { it.waybill to it.sequence }
```

**Dòng 195:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 196:** Phép so sánh/điều kiện.

```kotlin
fun List<DeliveryOrder>.persistedRouteLabels(): Map<String, String> =
```

**Dòng 197:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    filter { it.isRouteActive() && it.hasStoredCoordinates() }
```

**Dòng 198:** Sắp xếp collection.

```kotlin
        .sortedWith(compareBy<DeliveryOrder> { it.sequenceSortValue() }.thenBy { it.waybill })
```

**Dòng 199:** Tạo Map key/value.

```kotlin
        .associate { it.waybill to it.sequenceText() }
```

## `app/src/main/java/com/example/delivery/orderio/CoordinateTextParser.kt`

**Dòng 1:** Khai báo package/namespace.

```kotlin
package com.example.delivery.orderio
```

**Dòng 2:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 3:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
data class ParsedCoordinates(val latitude: Double, val longitude: Double)
```

**Dòng 4:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 5:** Chú thích, không thực thi.

```kotlin
/** Nhận hai số tọa độ theo thứ tự vĩ độ/kinh độ hoặc kinh độ/vĩ độ và tự xác định theo miền hợp lệ. */
```

**Dòng 6:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
object CoordinateTextParser {
```

**Dòng 7:** Elvis: dùng giá trị dự phòng khi null.

```kotlin
    private val coordinateNumber = Regex("[-+]?\\d+(?:[.,]\\d+)?")
```

**Dòng 8:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 9:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    fun parse(raw: String): ParsedCoordinates? {
```

**Dòng 10:** Biến chỉ đọc.

```kotlin
        val values = values(raw)
```

**Dòng 11:** Điều kiện if.

```kotlin
        if (values.size < 2) return null
```

**Dòng 12:** Biến chỉ đọc.

```kotlin
        val first = values[0]
```

**Dòng 13:** Biến chỉ đọc.

```kotlin
        val second = values[1]
```

**Dòng 14:** Kết thúc hàm và trả kết quả.

```kotlin
        return when {
```

**Dòng 15:** Phép so sánh/điều kiện.

```kotlin
            first in -90.0..90.0 && second in -180.0..180.0 -> ParsedCoordinates(first, second)
```

**Dòng 16:** Phép so sánh/điều kiện.

```kotlin
            first in -180.0..180.0 && second in -90.0..90.0 -> ParsedCoordinates(second, first)
```

**Dòng 17:** Nhánh thay thế.

```kotlin
            else -> null
```

**Dòng 18:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 19:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 20:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 21:** Chú thích, không thực thi.

```kotlin
    /** Dùng riêng cho ô Kinh độ: hiểu vị trí thứ nhất là Kinh độ, vị trí thứ hai là Vĩ độ. */
```

**Dòng 22:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    fun parseLongitudeThenLatitude(raw: String): ParsedCoordinates? {
```

**Dòng 23:** Biến chỉ đọc.

```kotlin
        val values = values(raw)
```

**Dòng 24:** Điều kiện if.

```kotlin
        if (values.size < 2) return null
```

**Dòng 25:** Biến chỉ đọc.

```kotlin
        val longitude = values[0]
```

**Dòng 26:** Biến chỉ đọc.

```kotlin
        val latitude = values[1]
```

**Dòng 27:** Kết thúc hàm và trả kết quả.

```kotlin
        return ParsedCoordinates(latitude, longitude).takeIf {
```

**Dòng 28:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            it.latitude in -90.0..90.0 && it.longitude in -180.0..180.0
```

**Dòng 29:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 30:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 31:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 32:** Phép so sánh/điều kiện.

```kotlin
    private fun values(raw: String): List<Double> = coordinateNumber.findAll(raw)
```

**Dòng 33:** Biến đổi collection.

```kotlin
        .mapNotNull { match -> match.value.replace(',', '.').toDoubleOrNull() }
```

**Dòng 34:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        .take(2)
```

**Dòng 35:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        .toList()
```

**Dòng 36:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

## `app/src/main/java/com/example/delivery/orderio/CoordinateUpdateCoordinator.kt`

**Dòng 1:** Khai báo package/namespace.

```kotlin
package com.example.delivery.orderio
```

**Dòng 2:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 3:** Import dependency.

```kotlin
import com.example.delivery.customer.CustomerProfile
```

**Dòng 4:** Import dependency.

```kotlin
import com.example.delivery.model.DeliveryOrder
```

**Dòng 5:** Import dependency.

```kotlin
import com.example.delivery.model.canReceiveRouteSequence
```

**Dòng 6:** Import dependency.

```kotlin
import com.example.delivery.model.nextActiveSequence
```

**Dòng 7:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 8:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
data class CoordinateUpdateRequest(
```

**Dòng 9:** Biến chỉ đọc.

```kotlin
    val reference: String,
```

**Dòng 10:** Biến chỉ đọc.

```kotlin
    val latitude: Double,
```

**Dòng 11:** Biến chỉ đọc.

```kotlin
    val longitude: Double,
```

**Dòng 12:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
)
```

**Dòng 13:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 14:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
data class CoordinateUpdateResult(
```

**Dòng 15:** Biến chỉ đọc.

```kotlin
    val profiles: List<CustomerProfile>,
```

**Dòng 16:** Biến chỉ đọc.

```kotlin
    val orders: List<DeliveryOrder>,
```

**Dòng 17:** Biến chỉ đọc.

```kotlin
    val updatedProfileIds: Set<String>,
```

**Dòng 18:** Biến chỉ đọc.

```kotlin
    val updatedWaybills: Set<String>,
```

**Dòng 19:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
)
```

**Dòng 20:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 21:** Chú thích, không thực thi.

```kotlin
/** Cập nhật theo MVĐ hoặc SĐT; đơn chưa có số thứ tự được đưa vào cuối tuyến sau khi có tọa độ. */
```

**Dòng 22:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
object CoordinateUpdateCoordinator {
```

**Dòng 23:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    fun update(
```

**Dòng 24:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        request: CoordinateUpdateRequest,
```

**Dòng 25:** Phép so sánh/điều kiện.

```kotlin
        profiles: List<CustomerProfile>,
```

**Dòng 26:** Phép so sánh/điều kiện.

```kotlin
        orders: List<DeliveryOrder>,
```

**Dòng 27:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    ): CoordinateUpdateResult {
```

**Dòng 28:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        require(request.reference.trim().isNotBlank()) { "Vui lòng nhập SĐT hoặc mã vận đơn." }
```

**Dòng 29:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        require(request.latitude in -90.0..90.0 && request.longitude in -180.0..180.0) { "Tọa độ không hợp lệ." }
```

**Dòng 30:** Biến chỉ đọc.

```kotlin
        val reference = request.reference.trim()
```

**Dòng 31:** Biến chỉ đọc.

```kotlin
        val phoneReference = normalizePhone(reference)
```

**Dòng 32:** Biến chỉ đọc.

```kotlin
        val matchedOrders = orders.filter { order ->
```

**Dòng 33:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            order.waybill.equals(reference, ignoreCase = true) ||
```

**Dòng 34:** Phép so sánh/điều kiện.

```kotlin
                (phoneReference.isNotBlank() && normalizePhone(order.phone) == phoneReference)
```

**Dòng 35:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 36:** Biến chỉ đọc.

```kotlin
        val relevantPhones = (matchedOrders.map { it.phone } + reference.takeIf { phoneReference.isNotBlank() }.orEmpty())
```

**Dòng 37:** Biến đổi collection.

```kotlin
            .map(::normalizePhone)
```

**Dòng 38:** Lọc collection.

```kotlin
            .filter(String::isNotBlank)
```

**Dòng 39:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            .toSet()
```

**Dòng 40:** Biến chỉ đọc.

```kotlin
        val updatedProfiles = profiles.map { profile ->
```

**Dòng 41:** Điều kiện if.

```kotlin
            if (profile.phones.any { normalizePhone(it.number) in relevantPhones }) {
```

**Dòng 42:** Biến chỉ đọc.

```kotlin
                val primaryIndex = profile.addresses.indexOfFirst { it.isPrimary }.takeIf { it >= 0 } ?: 0
```

**Dòng 43:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                profile.copy(
```

**Dòng 44:** Biến đổi collection.

```kotlin
                    addresses = profile.addresses.mapIndexed { index, address ->
```

**Dòng 45:** Điều kiện if.

```kotlin
                        if (index == primaryIndex) address.copy(latitude = request.latitude, longitude = request.longitude) else address
```

**Dòng 46:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    },
```

**Dòng 47:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                )
```

**Dòng 48:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            } else profile
```

**Dòng 49:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 50:** Biến chỉ đọc.

```kotlin
        val updatedProfileIds = profiles.zip(updatedProfiles)
```

**Dòng 51:** Lọc collection.

```kotlin
            .filter { (before, after) -> before != after }
```

**Dòng 52:** Biến đổi collection.

```kotlin
            .map { (_, after) -> after.id }
```

**Dòng 53:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            .toSet()
```

**Dòng 54:** Biến chỉ đọc.

```kotlin
        val matchedWaybills = matchedOrders.map { it.waybill }.toSet()
```

**Dòng 55:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        require(matchedWaybills.isNotEmpty() || updatedProfileIds.isNotEmpty()) { "Không tìm thấy khách hàng hoặc mã vận đơn tương ứng." }
```

**Dòng 56:** Biến có thể thay đổi.

```kotlin
        var nextSequence = orders.filter { it.waybill !in matchedWaybills }.nextActiveSequence()
```

**Dòng 57:** Biến chỉ đọc.

```kotlin
        val updatedOrders = orders.map { order ->
```

**Dòng 58:** Điều kiện if.

```kotlin
            if (order.waybill !in matchedWaybills) order else order.copy(
```

**Dòng 59:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                latitude = request.latitude,
```

**Dòng 60:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                longitude = request.longitude,
```

**Dòng 61:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                sequence = when {
```

**Dòng 62:** Phép so sánh/điều kiện.

```kotlin
                    !order.canReceiveRouteSequence() -> 0
```

**Dòng 63:** Phép so sánh/điều kiện.

```kotlin
                    order.sequence > 0 -> order.sequence
```

**Dòng 64:** Nhánh thay thế.

```kotlin
                    else -> nextSequence++
```

**Dòng 65:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                },
```

**Dòng 66:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            )
```

**Dòng 67:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 68:** Kết thúc hàm và trả kết quả.

```kotlin
        return CoordinateUpdateResult(updatedProfiles, updatedOrders, updatedProfileIds, matchedWaybills)
```

**Dòng 69:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 70:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 71:** Lọc collection.

```kotlin
    private fun normalizePhone(value: String): String = value.filter(Char::isDigit)
```

**Dòng 72:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

## `app/src/main/java/com/example/delivery/orderio/CustomerCoordinateSyncCoordinator.kt`

**Dòng 1:** Khai báo package/namespace.

```kotlin
package com.example.delivery.orderio
```

**Dòng 2:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 3:** Import dependency.

```kotlin
import com.example.delivery.customer.CustomerProfile
```

**Dòng 4:** Import dependency.

```kotlin
import com.example.delivery.model.DeliveryOrder
```

**Dòng 5:** Import dependency.

```kotlin
import com.example.delivery.model.canReceiveRouteSequence
```

**Dòng 6:** Import dependency.

```kotlin
import com.example.delivery.model.hasStoredCoordinates
```

**Dòng 7:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 8:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
data class CustomerCoordinateSyncResult(
```

**Dòng 9:** Biến chỉ đọc.

```kotlin
    val orders: List<DeliveryOrder>,
```

**Dòng 10:** Biến chỉ đọc.

```kotlin
    val phoneMatchedWaybills: Set<String>,
```

**Dòng 11:** Biến chỉ đọc.

```kotlin
    val coordinateUpdatedWaybills: Set<String>,
```

**Dòng 12:** Biến chỉ đọc.

```kotlin
    val resequencedWaybills: Set<String>,
```

**Dòng 13:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
)
```

**Dòng 14:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 15:** Chú thích, không thực thi.

```kotlin
/** Rà từng SĐT đơn với hồ sơ khách, sao chép tọa độ địa chỉ chính và đánh lại số tuyến đang giao. */
```

**Dòng 16:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
object CustomerCoordinateSyncCoordinator {
```

**Dòng 17:** Phép so sánh/điều kiện.

```kotlin
    fun sync(profiles: List<CustomerProfile>, orders: List<DeliveryOrder>): CustomerCoordinateSyncResult {
```

**Dòng 18:** Biến chỉ đọc.

```kotlin
        val coordinatesByPhone = linkedMapOf<String, ParsedCoordinates>()
```

**Dòng 19:** Phép so sánh/điều kiện.

```kotlin
        profiles.forEach { profile ->
```

**Dòng 20:** Biến chỉ đọc.

```kotlin
            val address = profile.primaryAddress
```

**Dòng 21:** Biến chỉ đọc.

```kotlin
            val latitude = address.latitude
```

**Dòng 22:** Biến chỉ đọc.

```kotlin
            val longitude = address.longitude
```

**Dòng 23:** Điều kiện if.

```kotlin
            if (latitude != null && longitude != null && latitude.isFinite() && longitude.isFinite() && (latitude != 0.0 || longitude != 0.0)) {
```

**Dòng 24:** Lọc collection.

```kotlin
                profile.phones.map { it.number.phoneKey() }.filter(String::isNotBlank).forEach { phone ->
```

**Dòng 25:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    coordinatesByPhone.putIfAbsent(phone, ParsedCoordinates(latitude, longitude))
```

**Dòng 26:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                }
```

**Dòng 27:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 28:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 29:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 30:** Biến chỉ đọc.

```kotlin
        val matchedWaybills = linkedSetOf<String>()
```

**Dòng 31:** Biến chỉ đọc.

```kotlin
        val changedCoordinates = linkedSetOf<String>()
```

**Dòng 32:** Biến chỉ đọc.

```kotlin
        val withProfileCoordinates = orders.map { order ->
```

**Dòng 33:** Biến chỉ đọc.

```kotlin
            val coordinates = coordinatesByPhone[order.phone.phoneKey()] ?: return@map order
```

**Dòng 34:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            matchedWaybills += order.waybill
```

**Dòng 35:** Điều kiện if.

```kotlin
            if (order.latitude != coordinates.latitude || order.longitude != coordinates.longitude) changedCoordinates += order.waybill
```

**Dòng 36:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            order.copy(latitude = coordinates.latitude, longitude = coordinates.longitude)
```

**Dòng 37:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 38:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 39:** Biến có thể thay đổi.

```kotlin
        var sequence = 1
```

**Dòng 40:** Biến chỉ đọc.

```kotlin
        val resequenced = linkedSetOf<String>()
```

**Dòng 41:** Biến chỉ đọc.

```kotlin
        val resequencedOrders = withProfileCoordinates.map { order ->
```

**Dòng 42:** Biến chỉ đọc.

```kotlin
            val shouldRoute = order.canReceiveRouteSequence() && order.hasStoredCoordinates()
```

**Dòng 43:** Biến chỉ đọc.

```kotlin
            val newSequence = if (shouldRoute) sequence++ else 0
```

**Dòng 44:** Điều kiện if.

```kotlin
            if (order.sequence != newSequence) resequenced += order.waybill
```

**Dòng 45:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            order.copy(sequence = newSequence)
```

**Dòng 46:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 47:** Kết thúc hàm và trả kết quả.

```kotlin
        return CustomerCoordinateSyncResult(resequencedOrders, matchedWaybills, changedCoordinates, resequenced)
```

**Dòng 48:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 49:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 50:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun String.phoneKey(): String = filter(Char::isDigit)
```

**Dòng 51:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

## `app/src/main/java/com/example/delivery/orderio/ManualOrderCoordinator.kt`

**Dòng 1:** Khai báo package/namespace.

```kotlin
package com.example.delivery.orderio
```

**Dòng 2:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 3:** Import dependency.

```kotlin
import com.example.delivery.customer.CustomerProfile
```

**Dòng 4:** Import dependency.

```kotlin
import com.example.delivery.model.DeliveryOrder
```

**Dòng 5:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 6:** Chú thích, không thực thi.

```kotlin
/** Áp dụng quy tắc thêm tay: chỉ đơn khớp SĐT có tọa độ đã lưu mới được gán số cuối tuyến. */
```

**Dòng 7:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
object ManualOrderCoordinator {
```

**Dòng 8:** Phép so sánh/điều kiện.

```kotlin
    fun place(draft: DeliveryOrder, profiles: List<CustomerProfile>, existingOrders: List<DeliveryOrder>, routeActive: Boolean = true): DeliveryOrder {
```

**Dòng 9:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        require(draft.waybill.trim().isNotBlank()) { "Vui lòng nhập mã vận đơn." }
```

**Dòng 10:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        require(existingOrders.none { it.waybill.equals(draft.waybill.trim(), ignoreCase = true) }) { "Mã vận đơn đã tồn tại." }
```

**Dòng 11:** Biến chỉ đọc.

```kotlin
        val phoneKey = draft.phone.phoneKey()
```

**Dòng 12:** Biến chỉ đọc.

```kotlin
        val profile = profiles.firstOrNull { candidate ->
```

**Dòng 13:** Phép so sánh/điều kiện.

```kotlin
            phoneKey.isNotBlank() && candidate.phones.any { it.number.phoneKey() == phoneKey }
```

**Dòng 14:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 15:** Biến chỉ đọc.

```kotlin
        val locatedAddress = profile?.addresses?.firstOrNull { address ->
```

**Dòng 16:** Phép so sánh/điều kiện.

```kotlin
            address.latitude?.isFinite() == true && address.longitude?.isFinite() == true
```

**Dòng 17:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 18:** Biến chỉ đọc.

```kotlin
        val hasCoordinates = locatedAddress != null
```

**Dòng 19:** Kết thúc hàm và trả kết quả.

```kotlin
        return draft.copy(
```

**Dòng 20:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            waybill = draft.waybill.trim(),
```

**Dòng 21:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            customer = draft.customer.trim().ifBlank { profile?.displayName.orEmpty() },
```

**Dòng 22:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            phone = draft.phone.trim(),
```

**Dòng 23:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            address = draft.address.trim().ifBlank { locatedAddress?.address.orEmpty() },
```

**Dòng 24:** Elvis: dùng giá trị dự phòng khi null.

```kotlin
            latitude = locatedAddress?.latitude ?: 0.0,
```

**Dòng 25:** Elvis: dùng giá trị dự phòng khi null.

```kotlin
            longitude = locatedAddress?.longitude ?: 0.0,
```

**Dòng 26:** Chú thích, không thực thi.

```kotlin
            // Đơn mới không tự nối vào tuyến; người dùng chủ động chèn STT bằng Sửa/Lưu.
```

**Dòng 27:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            sequence = 0,
```

**Dòng 28:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        )
```

**Dòng 29:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 30:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 31:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun String.phoneKey(): String = filter(Char::isDigit)
```

**Dòng 32:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

## `app/src/main/java/com/example/delivery/orderio/OrderDeletionCoordinator.kt`

**Dòng 1:** Khai báo package/namespace.

```kotlin
package com.example.delivery.orderio
```

**Dòng 2:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 3:** Import dependency.

```kotlin
import com.example.delivery.model.DeliveryOrder
```

**Dòng 4:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 5:** Chú thích, không thực thi.

```kotlin
/** Chỉ loại bỏ đơn theo MVĐ. Hồ sơ khách được lưu riêng bởi lớp gọi trước khi thực hiện xóa. */
```

**Dòng 6:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
object OrderDeletionCoordinator {
```

**Dòng 7:** Phép so sánh/điều kiện.

```kotlin
    fun delete(waybill: String, orders: List<DeliveryOrder>): List<DeliveryOrder> {
```

**Dòng 8:** Biến chỉ đọc.

```kotlin
        val key = waybill.trim()
```

**Dòng 9:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        require(key.isNotBlank()) { "Vui lòng nhập mã vận đơn cần xóa." }
```

**Dòng 10:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        require(orders.any { it.waybill.equals(key, ignoreCase = true) }) { "Không tìm thấy mã vận đơn cần xóa." }
```

**Dòng 11:** Kết thúc hàm và trả kết quả.

```kotlin
        return orders.filterNot { it.waybill.equals(key, ignoreCase = true) }
```

**Dòng 12:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 13:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

## `app/src/main/java/com/example/delivery/orderio/OrderFileCodec.kt`

**Dòng 1:** Khai báo package/namespace.

```kotlin
package com.example.delivery.orderio
```

**Dòng 2:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 3:** Import dependency.

```kotlin
import android.content.Context
```

**Dòng 4:** Import dependency.

```kotlin
import com.example.delivery.model.DeliveryFailureReason
```

**Dòng 5:** Import dependency.

```kotlin
import com.example.delivery.model.DeliveryOrder
```

**Dòng 6:** Import dependency.

```kotlin
import com.example.delivery.model.sequenceText
```

**Dòng 7:** Import dependency.

```kotlin
import com.example.delivery.model.DeliveryStatus
```

**Dòng 8:** Import dependency.

```kotlin
import org.json.JSONArray
```

**Dòng 9:** Import dependency.

```kotlin
import org.json.JSONObject
```

**Dòng 10:** Import dependency.

```kotlin
import org.w3c.dom.Element
```

**Dòng 11:** Import dependency.

```kotlin
import java.io.ByteArrayInputStream
```

**Dòng 12:** Import dependency.

```kotlin
import java.io.InputStream
```

**Dòng 13:** Import dependency.

```kotlin
import java.nio.charset.StandardCharsets
```

**Dòng 14:** Import dependency.

```kotlin
import java.text.Normalizer
```

**Dòng 15:** Import dependency.

```kotlin
import java.util.Locale
```

**Dòng 16:** Import dependency.

```kotlin
import java.util.zip.ZipInputStream
```

**Dòng 17:** Import dependency.

```kotlin
import javax.xml.parsers.DocumentBuilderFactory
```

**Dòng 18:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 19:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
private fun String.isValidSequenceLabel(): Boolean {
```

**Dòng 20:** Biến chỉ đọc.

```kotlin
    val parts = trim().split('.', limit = 2)
```

**Dòng 21:** Kết thúc hàm và trả kết quả.

```kotlin
    return parts.size == 2 && parts[0].toIntOrNull()?.let { it > 0 } == true &&
```

**Dòng 22:** Safe-call: chỉ chạy khi khác null.

```kotlin
        (parts[1].equals("n", true) || parts[1].toIntOrNull()?.let { it > 0 } == true)
```

**Dòng 23:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 24:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 25:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
data class OrderImportResult(
```

**Dòng 26:** Biến chỉ đọc.

```kotlin
    val orders: List<DeliveryOrder>,
```

**Dòng 27:** Biến chỉ đọc.

```kotlin
    val skippedRows: Int,
```

**Dòng 28:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
)
```

**Dòng 29:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 30:** Chú thích, không thực thi.

```kotlin
/** Đọc danh sách đơn từ CSV, TXT hoặc bảng tính XLSX đầu tiên trong tệp. */
```

**Dòng 31:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
object OrderFileCodec {
```

**Dòng 32:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    private val headerAliases = mapOf(
```

**Dòng 33:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        "waybill" to setOf("mavandon", "waybill", "tracking", "madon", "orderid"),
```

**Dòng 34:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        "customer" to setOf("tenkhachhang", "khachhang", "customer", "nguoinhan", "tennguoinhan"),
```

**Dòng 35:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        "phone" to setOf("sdt", "sodienthoai", "phone", "mobile", "dienthoai"),
```

**Dòng 36:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        "address" to setOf("diachi", "address", "diachinguoinhan"),
```

**Dòng 37:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        "product" to setOf("hanghoa", "sanpham", "product", "noidung", "tenhang", "mathang", "tenhanghoa", "tensanpham", "motahang", "motasanpham", "chitietsanpham", "thongtinhanghoa", "item"),
```

**Dòng 38:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        "cod" to setOf("cod", "sotien", "tiencod", "amount", "tienthu", "thanhtoan"),
```

**Dòng 39:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        "service" to setOf("dichvu", "service"),
```

**Dòng 40:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        "status" to setOf("trangthai", "status"),
```

**Dòng 41:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        "sequence" to setOf("stt", "sequence", "thutu"),
```

**Dòng 42:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        "latitude" to setOf("latitude", "lat", "vido"),
```

**Dòng 43:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        "longitude" to setOf("longitude", "lng", "lon", "kinhdo"),
```

**Dòng 44:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        "requiresRedelivery" to setOf("giaolai", "requiresredelivery"),
```

**Dòng 45:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        "wasRedelivered" to setOf("dagiaolai", "wasredelivered"),
```

**Dòng 46:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        "failureReason" to setOf("lydothatbai", "failurereason", "reason"),
```

**Dòng 47:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        "failureCount" to setOf("solanthatbai", "failurecount", "attempts"),
```

**Dòng 48:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        "delivered" to setOf("dagiao", "delivered"),
```

**Dòng 49:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    )
```

**Dòng 50:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    private val defaultColumnKeys = listOf("waybill", "customer", "phone", "address", "product", "cod", "service", "status", "sequence", "latitude", "longitude", "requiresRedelivery", "wasRedelivered", "failureReason", "failureCount", "delivered")
```

**Dòng 51:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 52:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    fun import(fileName: String, input: InputStream): OrderImportResult {
```

**Dòng 53:** Biến chỉ đọc.

```kotlin
        val extension = fileName.substringAfterLast('.', "").lowercase(Locale.ROOT)
```

**Dòng 54:** Biến chỉ đọc.

```kotlin
        val rows = when (extension) {
```

**Dòng 55:** Phép so sánh/điều kiện.

```kotlin
            "csv", "txt" -> parseDelimited(input.readBytes().toString(StandardCharsets.UTF_8))
```

**Dòng 56:** Phép so sánh/điều kiện.

```kotlin
            "xlsx" -> parseXlsx(input)
```

**Dòng 57:** Nhánh thay thế.

```kotlin
            else -> error("Chỉ hỗ trợ tệp CSV, XLSX hoặc TXT.")
```

**Dòng 58:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 59:** Kết thúc hàm và trả kết quả.

```kotlin
        return rows.toOrders()
```

**Dòng 60:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 61:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 62:** Phép so sánh/điều kiện.

```kotlin
    fun exportCsv(orders: List<DeliveryOrder>): String = buildString {
```

**Dòng 63:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        append('\uFEFF')
```

**Dòng 64:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        appendCsvRow(listOf("Mã vận đơn", "Tên khách hàng", "SĐT", "Địa chỉ", "Hàng hóa", "COD", "Dịch vụ", "Trạng thái", "STT", "Vĩ độ", "Kinh độ", "Giao lại", "Đã giao lại", "Lý do thất bại", "Số lần thất bại", "Đã giao"))
```

**Dòng 65:** Phép so sánh/điều kiện.

```kotlin
        orders.forEach { order ->
```

**Dòng 66:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            appendCsvRow(
```

**Dòng 67:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                listOf(
```

**Dòng 68:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    order.waybill,
```

**Dòng 69:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    order.customer,
```

**Dòng 70:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    order.phone,
```

**Dòng 71:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    order.address,
```

**Dòng 72:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    order.product,
```

**Dòng 73:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    order.cod.toString(),
```

**Dòng 74:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    order.service,
```

**Dòng 75:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    order.status.name,
```

**Dòng 76:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    order.sequenceText(),
```

**Dòng 77:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    order.latitude.toString(),
```

**Dòng 78:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    order.longitude.toString(),
```

**Dòng 79:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    order.requiresRedelivery.toString(),
```

**Dòng 80:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    order.wasRedelivered.toString(),
```

**Dòng 81:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    order.failureReason?.name.orEmpty(),
```

**Dòng 82:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    order.failureCount.toString(),
```

**Dòng 83:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    order.delivered.toString(),
```

**Dòng 84:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                ),
```

**Dòng 85:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            )
```

**Dòng 86:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 87:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 88:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 89:** Phép so sánh/điều kiện.

```kotlin
    internal fun parseDelimited(rawText: String): List<List<String>> {
```

**Dòng 90:** Biến chỉ đọc.

```kotlin
        val text = rawText.removePrefix("\uFEFF")
```

**Dòng 91:** Biến chỉ đọc.

```kotlin
        val firstLine = text.lineSequence().firstOrNull { it.isNotBlank() }.orEmpty()
```

**Dòng 92:** Biến chỉ đọc.

```kotlin
        val separator = listOf(',', ';', '\t', '|').maxByOrNull { candidate -> firstLine.count { it == candidate } } ?: ','
```

**Dòng 93:** Biến chỉ đọc.

```kotlin
        val rows = mutableListOf<List<String>>()
```

**Dòng 94:** Biến chỉ đọc.

```kotlin
        val cells = mutableListOf<String>()
```

**Dòng 95:** Biến chỉ đọc.

```kotlin
        val value = StringBuilder()
```

**Dòng 96:** Biến có thể thay đổi.

```kotlin
        var quoted = false
```

**Dòng 97:** Biến có thể thay đổi.

```kotlin
        var index = 0
```

**Dòng 98:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
        fun finishRow() {
```

**Dòng 99:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            cells += value.toString().trim()
```

**Dòng 100:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            value.clear()
```

**Dòng 101:** Điều kiện if.

```kotlin
            if (cells.any { it.isNotBlank() }) rows += cells.toList()
```

**Dòng 102:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            cells.clear()
```

**Dòng 103:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 104:** Phép so sánh/điều kiện.

```kotlin
        while (index < text.length) {
```

**Dòng 105:** Rẽ nhánh nhiều trường hợp.

```kotlin
            when (val character = text[index]) {
```

**Dòng 106:** Phép so sánh/điều kiện.

```kotlin
                '"' -> {
```

**Dòng 107:** Điều kiện if.

```kotlin
                    if (quoted && index + 1 < text.length && text[index + 1] == '"') {
```

**Dòng 108:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        value.append('"')
```

**Dòng 109:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        index++
```

**Dòng 110:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    } else if (quoted) {
```

**Dòng 111:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        quoted = false
```

**Dòng 112:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    } else if (value.isEmpty()) {
```

**Dòng 113:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        quoted = true
```

**Dòng 114:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    } else {
```

**Dòng 115:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        value.append(character)
```

**Dòng 116:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    }
```

**Dòng 117:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                }
```

**Dòng 118:** Phép so sánh/điều kiện.

```kotlin
                separator -> if (quoted) value.append(character) else {
```

**Dòng 119:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    cells += value.toString().trim()
```

**Dòng 120:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    value.clear()
```

**Dòng 121:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                }
```

**Dòng 122:** Phép so sánh/điều kiện.

```kotlin
                '\n' -> if (quoted) value.append(character) else finishRow()
```

**Dòng 123:** Phép so sánh/điều kiện.

```kotlin
                '\r' -> Unit
```

**Dòng 124:** Nhánh thay thế.

```kotlin
                else -> value.append(character)
```

**Dòng 125:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 126:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            index++
```

**Dòng 127:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 128:** Điều kiện if.

```kotlin
        if (value.isNotEmpty() || cells.isNotEmpty()) finishRow()
```

**Dòng 129:** Kết thúc hàm và trả kết quả.

```kotlin
        return rows
```

**Dòng 130:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 131:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 132:** Phép so sánh/điều kiện.

```kotlin
    private fun List<List<String>>.toOrders(): OrderImportResult {
```

**Dòng 133:** Biến chỉ đọc.

```kotlin
        val usableRows = filter { row -> row.any { it.isNotBlank() } }
```

**Dòng 134:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        require(usableRows.isNotEmpty()) { "Tệp đơn hàng đang trống." }
```

**Dòng 135:** Biến chỉ đọc.

```kotlin
        val firstRowKeys = usableRows.first().map(::normalizeHeader)
```

**Dòng 136:** Biến chỉ đọc.

```kotlin
        val hasHeader = firstRowKeys.any { key -> headerAliases.values.any { key in it } }
```

**Dòng 137:** Biến chỉ đọc.

```kotlin
        val mapping = if (hasHeader) {
```

**Dòng 138:** Biến đổi collection.

```kotlin
            headerAliases.mapNotNull { (canonical, aliases) ->
```

**Dòng 139:** Phép so sánh/điều kiện.

```kotlin
                firstRowKeys.indexOfFirst { header ->
```

**Dòng 140:** Phép so sánh/điều kiện.

```kotlin
                    header in aliases || aliases.any { alias -> alias.length >= 4 && header.contains(alias) }
```

**Dòng 141:** Safe-call: chỉ chạy khi khác null.

```kotlin
                }.takeIf { it >= 0 }?.let { canonical to it }
```

**Dòng 142:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }.toMap()
```

**Dòng 143:** Biến đổi collection.

```kotlin
        } else defaultColumnKeys.mapIndexed { index, key -> key to index }.toMap()
```

**Dòng 144:** Biến chỉ đọc.

```kotlin
        val sourceRows = if (hasHeader) usableRows.drop(1) else usableRows
```

**Dòng 145:** Biến có thể thay đổi.

```kotlin
        var skipped = 0
```

**Dòng 146:** Biến chỉ đọc.

```kotlin
        val parsed = sourceRows.mapNotNull { row ->
```

**Dòng 147:** Safe-call: chỉ chạy khi khác null.

```kotlin
            fun value(key: String): String = mapping[key]?.let { row.getOrNull(it).orEmpty().trim() }.orEmpty()
```

**Dòng 148:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
            fun productValue(): String = value("product").ifBlank {
```

**Dòng 149:** Biến chỉ đọc.

```kotlin
                val productColumn = firstRowKeys.indexOfFirst { header ->
```

**Dòng 150:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    header in headerAliases.getValue("product") || header.contains("mathang") || header.contains("hanghoa")
```

**Dòng 151:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                }
```

**Dòng 152:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                row.getOrNull(productColumn).orEmpty().trim()
```

**Dòng 153:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 154:** Biến chỉ đọc.

```kotlin
            val waybill = value("waybill")
```

**Dòng 155:** Điều kiện if.

```kotlin
            if (waybill.isBlank()) {
```

**Dòng 156:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                skipped++
```

**Dòng 157:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                null
```

**Dòng 158:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            } else {
```

**Dòng 159:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                DeliveryOrder(
```

**Dòng 160:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    waybill = waybill,
```

**Dòng 161:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    customer = value("customer"),
```

**Dòng 162:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    phone = value("phone"),
```

**Dòng 163:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    address = value("address"),
```

**Dòng 164:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    product = productValue(),
```

**Dòng 165:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    cod = value("cod").toMoney(),
```

**Dòng 166:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    service = value("service"),
```

**Dòng 167:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    status = value("status").toDeliveryStatus(),
```

**Dòng 168:** Elvis: dùng giá trị dự phòng khi null.

```kotlin
                    sequence = value("sequence").substringBefore('.').toIntOrNull() ?: 0,
```

**Dòng 169:** Elvis: dùng giá trị dự phòng khi null.

```kotlin
                    latitude = value("latitude").toCoordinate() ?: 0.0,
```

**Dòng 170:** Elvis: dùng giá trị dự phòng khi null.

```kotlin
                    longitude = value("longitude").toCoordinate() ?: 0.0,
```

**Dòng 171:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    requiresRedelivery = value("requiresRedelivery").toBooleanValue(),
```

**Dòng 172:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    wasRedelivered = value("wasRedelivered").toBooleanValue(),
```

**Dòng 173:** Lấy phần tử đầu hoặc null.

```kotlin
                    failureReason = DeliveryFailureReason.entries.firstOrNull { it.name.equals(value("failureReason"), ignoreCase = true) },
```

**Dòng 174:** Elvis: dùng giá trị dự phòng khi null.

```kotlin
                    failureCount = value("failureCount").toIntOrNull()?.coerceAtLeast(0) ?: 0,
```

**Dòng 175:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    delivered = value("delivered").toBooleanValue() || value("status").equals("TT515", ignoreCase = true),
```

**Dòng 176:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    sequenceLabel = value("sequence").takeIf { it.contains('.') && it.isValidSequenceLabel() },
```

**Dòng 177:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                )
```

**Dòng 178:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 179:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }.distinctBy { it.waybill }
```

**Dòng 180:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        require(parsed.isNotEmpty()) { "Không tìm thấy Mã vận đơn hợp lệ. Hãy dùng cột 'Mã vận đơn' hoặc để mã ở cột đầu tiên." }
```

**Dòng 181:** Kết thúc hàm và trả kết quả.

```kotlin
        return OrderImportResult(parsed, skipped + (sourceRows.size - parsed.size - skipped).coerceAtLeast(0))
```

**Dòng 182:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 183:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 184:** Phép so sánh/điều kiện.

```kotlin
    private fun parseXlsx(input: InputStream): List<List<String>> {
```

**Dòng 185:** Biến có thể thay đổi.

```kotlin
        var sharedStrings = emptyList<String>()
```

**Dòng 186:** Biến có thể thay đổi.

```kotlin
        var sheetBytes: ByteArray? = null
```

**Dòng 187:** Phép so sánh/điều kiện.

```kotlin
        ZipInputStream(input.buffered()).use { zip ->
```

**Dòng 188:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            while (true) {
```

**Dòng 189:** Biến chỉ đọc.

```kotlin
                val entry = zip.nextEntry ?: break
```

**Dòng 190:** Rẽ nhánh nhiều trường hợp.

```kotlin
                when {
```

**Dòng 191:** Phép so sánh/điều kiện.

```kotlin
                    entry.name == "xl/sharedStrings.xml" -> sharedStrings = parseSharedStrings(zip.readBytes())
```

**Dòng 192:** Phép so sánh/điều kiện.

```kotlin
                    entry.name.startsWith("xl/worksheets/") && entry.name.endsWith(".xml") && sheetBytes == null -> sheetBytes = zip.readBytes()
```

**Dòng 193:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                }
```

**Dòng 194:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                zip.closeEntry()
```

**Dòng 195:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 196:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 197:** Kết thúc hàm và trả kết quả.

```kotlin
        return parseWorksheet(sheetBytes ?: error("Không tìm thấy bảng tính trong tệp XLSX."), sharedStrings)
```

**Dòng 198:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 199:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 200:** Phép so sánh/điều kiện.

```kotlin
    private fun parseSharedStrings(bytes: ByteArray): List<String> {
```

**Dòng 201:** Biến chỉ đọc.

```kotlin
        val items = xmlDocument(bytes).getElementsByTagName("si")
```

**Dòng 202:** Kết thúc hàm và trả kết quả.

```kotlin
        return List(items.length) { index -> items.item(index).textContent.orEmpty() }
```

**Dòng 203:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 204:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 205:** Phép so sánh/điều kiện.

```kotlin
    private fun parseWorksheet(bytes: ByteArray, sharedStrings: List<String>): List<List<String>> {
```

**Dòng 206:** Biến chỉ đọc.

```kotlin
        val rowNodes = xmlDocument(bytes).getElementsByTagName("row")
```

**Dòng 207:** Biến chỉ đọc.

```kotlin
        val rows = mutableListOf<List<String>>()
```

**Dòng 208:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        for (rowIndex in 0 until rowNodes.length) {
```

**Dòng 209:** Biến chỉ đọc.

```kotlin
            val row = rowNodes.item(rowIndex) as? Element ?: continue
```

**Dòng 210:** Biến chỉ đọc.

```kotlin
            val rowValues = mutableMapOf<Int, String>()
```

**Dòng 211:** Biến chỉ đọc.

```kotlin
            val cells = row.getElementsByTagName("c")
```

**Dòng 212:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            for (cellIndex in 0 until cells.length) {
```

**Dòng 213:** Biến chỉ đọc.

```kotlin
                val cell = cells.item(cellIndex) as? Element ?: continue
```

**Dòng 214:** Biến chỉ đọc.

```kotlin
                val column = cell.getAttribute("r").toColumnIndex().takeIf { it >= 0 } ?: rowValues.size
```

**Dòng 215:** Biến chỉ đọc.

```kotlin
                val raw = cell.textContent.orEmpty()
```

**Dòng 216:** Biến chỉ đọc.

```kotlin
                val resolved = if (cell.getAttribute("t") == "s") raw.toIntOrNull()?.let { sharedStrings.getOrNull(it) }.orEmpty() else raw
```

**Dòng 217:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                rowValues[column] = resolved
```

**Dòng 218:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 219:** Điều kiện if.

```kotlin
            if (rowValues.isNotEmpty()) {
```

**Dòng 220:** Biến chỉ đọc.

```kotlin
                val lastColumn = rowValues.keys.maxOrNull() ?: -1
```

**Dòng 221:** Phép so sánh/điều kiện.

```kotlin
                rows += List(lastColumn + 1) { column -> rowValues[column].orEmpty() }
```

**Dòng 222:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 223:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 224:** Kết thúc hàm và trả kết quả.

```kotlin
        return rows
```

**Dòng 225:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 226:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 227:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun xmlDocument(bytes: ByteArray) = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(ByteArrayInputStream(bytes))
```

**Dòng 228:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 229:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun String.toColumnIndex(): Int {
```

**Dòng 230:** Biến chỉ đọc.

```kotlin
        val letters = takeWhile(Char::isLetter).uppercase(Locale.ROOT)
```

**Dòng 231:** Điều kiện if.

```kotlin
        if (letters.isBlank()) return -1
```

**Dòng 232:** Kết thúc hàm và trả kết quả.

```kotlin
        return letters.fold(0) { result, character -> result * 26 + (character - 'A' + 1) } - 1
```

**Dòng 233:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 234:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 235:** Elvis: dùng giá trị dự phòng khi null.

```kotlin
    private fun String.toMoney(): Long = filter { it.isDigit() || it == '-' }.toLongOrNull() ?: 0L
```

**Dòng 236:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun String.toCoordinate(): Double? = trim().replace(',', '.').toDoubleOrNull()
```

**Dòng 237:** Lấy phần tử đầu hoặc null.

```kotlin
    private fun String.toDeliveryStatus(): DeliveryStatus = DeliveryStatus.entries.firstOrNull { it.name.equals(trim(), ignoreCase = true) } ?: DeliveryStatus.TT500
```

**Dòng 238:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun String.toBooleanValue(): Boolean = trim().lowercase(Locale.ROOT) in setOf("true", "1", "yes", "co", "có")
```

**Dòng 239:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 240:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun normalizeHeader(value: String): String = Normalizer.normalize(value.trim(), Normalizer.Form.NFD)
```

**Dòng 241:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        .replace("\\p{Mn}+".toRegex(), "")
```

**Dòng 242:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        .lowercase(Locale.ROOT)
```

**Dòng 243:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        .replace('đ', 'd')
```

**Dòng 244:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        .replace("[^a-z0-9]".toRegex(), "")
```

**Dòng 245:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 246:** Phép so sánh/điều kiện.

```kotlin
    private fun StringBuilder.appendCsvRow(values: List<String>) {
```

**Dòng 247:** Phép so sánh/điều kiện.

```kotlin
        append(values.joinToString(",") { value -> "\"${value.replace("\"", "\"\"")}\"" })
```

**Dòng 248:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        append("\r\n")
```

**Dòng 249:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 250:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 251:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 252:** Chú thích, không thực thi.

```kotlin
/** Lưu danh sách đơn được nhập để vẫn còn sau khi đóng và mở lại ứng dụng. */
```

**Dòng 253:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
object DeliveryOrderStore {
```

**Dòng 254:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    private const val PREF = "delivery_orders_v1"
```

**Dòng 255:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    private const val KEY = "items"
```

**Dòng 256:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    private const val INITIALIZED_KEY = "initialized"
```

**Dòng 257:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 258:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    fun hasBeenInitialized(context: Context): Boolean =
```

**Dòng 259:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getBoolean(INITIALIZED_KEY, false)
```

**Dòng 260:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 261:** Phép so sánh/điều kiện.

```kotlin
    fun load(context: Context): List<DeliveryOrder> = runCatching {
```

**Dòng 262:** Biến chỉ đọc.

```kotlin
        val array = JSONArray(context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, "[]"))
```

**Dòng 263:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        List(array.length()) { array.getJSONObject(it).toOrder() }
```

**Dòng 264:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }.getOrDefault(emptyList())
```

**Dòng 265:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 266:** Phép so sánh/điều kiện.

```kotlin
    fun replace(context: Context, values: List<DeliveryOrder>) {
```

**Dòng 267:** Biến chỉ đọc.

```kotlin
        val uniqueOrders = values.filter { it.waybill.isNotBlank() }.distinctBy { it.waybill }
```

**Dòng 268:** Biến chỉ đọc.

```kotlin
        val saved = context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
```

**Dòng 269:** Biến đổi collection.

```kotlin
            .putString(KEY, JSONArray(uniqueOrders.map { it.toJson() }).toString())
```

**Dòng 270:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            .putBoolean(INITIALIZED_KEY, true)
```

**Dòng 271:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            .commit()
```

**Dòng 272:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        check(saved) { "Không thể lưu danh sách đơn hàng." }
```

**Dòng 273:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 274:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 275:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun String.isValidSequenceLabel(): Boolean {
```

**Dòng 276:** Biến chỉ đọc.

```kotlin
        val parts = trim().split('.', limit = 2)
```

**Dòng 277:** Kết thúc hàm và trả kết quả.

```kotlin
        return parts.size == 2 && parts[0].toIntOrNull()?.let { it > 0 } == true &&
```

**Dòng 278:** Safe-call: chỉ chạy khi khác null.

```kotlin
            (parts[1].equals("n", true) || parts[1].toIntOrNull()?.let { it > 0 } == true)
```

**Dòng 279:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 280:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 281:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun DeliveryOrder.toJson() = JSONObject()
```

**Dòng 282:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        .put("waybill", waybill)
```

**Dòng 283:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        .put("customer", customer)
```

**Dòng 284:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        .put("phone", phone)
```

**Dòng 285:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        .put("address", address)
```

**Dòng 286:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        .put("product", product)
```

**Dòng 287:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        .put("cod", cod)
```

**Dòng 288:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        .put("service", service)
```

**Dòng 289:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        .put("status", status.name)
```

**Dòng 290:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        .put("sequence", sequence)
```

**Dòng 291:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        .put("sequenceLabel", sequenceLabel)
```

**Dòng 292:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        .put("latitude", latitude)
```

**Dòng 293:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        .put("longitude", longitude)
```

**Dòng 294:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        .put("requiresRedelivery", requiresRedelivery)
```

**Dòng 295:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        .put("wasRedelivered", wasRedelivered)
```

**Dòng 296:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        .put("failureReason", failureReason?.name)
```

**Dòng 297:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        .put("failureCount", failureCount)
```

**Dòng 298:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        .put("delivered", delivered)
```

**Dòng 299:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 300:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun JSONObject.toOrder() = DeliveryOrder(
```

**Dòng 301:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        waybill = getString("waybill"),
```

**Dòng 302:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        customer = optString("customer"),
```

**Dòng 303:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        phone = optString("phone"),
```

**Dòng 304:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        address = optString("address"),
```

**Dòng 305:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        product = optString("product"),
```

**Dòng 306:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        cod = optLong("cod"),
```

**Dòng 307:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        service = optString("service"),
```

**Dòng 308:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        status = optString("status").toDeliveryStatus(),
```

**Dòng 309:** Elvis: dùng giá trị dự phòng khi null.

```kotlin
        sequence = optString("sequence").substringBefore('.').toIntOrNull() ?: optInt("sequence"),
```

**Dòng 310:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        latitude = optDouble("latitude", 10.7769),
```

**Dòng 311:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        longitude = optDouble("longitude", 106.7009),
```

**Dòng 312:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        requiresRedelivery = optBoolean("requiresRedelivery"),
```

**Dòng 313:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        wasRedelivered = optBoolean("wasRedelivered"),
```

**Dòng 314:** Lấy phần tử đầu hoặc null.

```kotlin
        failureReason = DeliveryFailureReason.entries.firstOrNull { it.name.equals(optString("failureReason"), ignoreCase = true) },
```

**Dòng 315:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        failureCount = optInt("failureCount").coerceAtLeast(0),
```

**Dòng 316:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        delivered = optBoolean("delivered", optString("status").equals("TT515", ignoreCase = true)),
```

**Dòng 317:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        sequenceLabel = optString("sequenceLabel").takeIf { it.isValidSequenceLabel() },
```

**Dòng 318:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    )
```

**Dòng 319:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 320:** Lấy phần tử đầu hoặc null.

```kotlin
    private fun String.toDeliveryStatus(): DeliveryStatus = DeliveryStatus.entries.firstOrNull { it.name.equals(trim(), ignoreCase = true) } ?: DeliveryStatus.TT500
```

**Dòng 321:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

## `app/src/main/java/com/example/delivery/orderio/OrderImportCoordinator.kt`

**Dòng 1:** Khai báo package/namespace.

```kotlin
package com.example.delivery.orderio
```

**Dòng 2:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 3:** Import dependency.

```kotlin
import com.example.delivery.customer.CustomerProfile
```

**Dòng 4:** Import dependency.

```kotlin
import com.example.delivery.customer.customerPhoneKey
```

**Dòng 5:** Import dependency.

```kotlin
import com.example.delivery.model.DeliveryStatus
```

**Dòng 6:** Import dependency.

```kotlin
import com.example.delivery.model.DeliveryOrder
```

**Dòng 7:** Import dependency.

```kotlin
import com.example.delivery.model.isPickupAtWarehouse
```

**Dòng 8:** Import dependency.

```kotlin
import com.example.delivery.model.isTemporaryFailure
```

**Dòng 9:** Import dependency.

```kotlin
import com.example.delivery.model.normalizedCoordinates
```

**Dòng 10:** Import dependency.

```kotlin
import java.util.Locale
```

**Dòng 11:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 12:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
data class OrderMergeResult(
```

**Dòng 13:** Biến chỉ đọc.

```kotlin
    val orders: List<DeliveryOrder>,
```

**Dòng 14:** Biến chỉ đọc.

```kotlin
    val addedOrders: List<DeliveryOrder>,
```

**Dòng 15:** Biến chỉ đọc.

```kotlin
    val ignoredDuplicateCount: Int,
```

**Dòng 16:** Biến chỉ đọc.

```kotlin
    val restoredProductCount: Int = 0,
```

**Dòng 17:** Biến chỉ đọc.

```kotlin
    val reactivatedCount: Int = 0,
```

**Dòng 18:** Biến chỉ đọc.

```kotlin
    val removedNotInLatestImportCount: Int = 0,
```

**Dòng 19:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
)
```

**Dòng 20:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 21:** Chú thích, không thực thi.

```kotlin
/** Ghép đơn từ file vào danh sách hiện có mà không bao giờ thay thế dữ liệu của MVĐ đã lưu. */
```

**Dòng 22:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
object OrderImportCoordinator {
```

**Dòng 23:** Chú thích, không thực thi.

```kotlin
    /**
```

**Dòng 24:** Chú thích, không thực thi.

```kotlin
     * Nạp một danh sách MVĐ mới cho ca hiện tại. Chỉ các MVĐ có trong file được giữ trên
```

**Dòng 25:** Chú thích, không thực thi.

```kotlin
     * Chi tiết/Bản đồ; khách hàng và lịch sử không thuộc danh sách orders nên không bị xóa.
```

**Dòng 26:** Chú thích, không thực thi.

```kotlin
     */
```

**Dòng 27:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    fun replaceWithImportedBatch(
```

**Dòng 28:** Phép so sánh/điều kiện.

```kotlin
        existingOrders: List<DeliveryOrder>,
```

**Dòng 29:** Phép so sánh/điều kiện.

```kotlin
        importedOrders: List<DeliveryOrder>,
```

**Dòng 30:** Phép so sánh/điều kiện.

```kotlin
        customerProfiles: List<CustomerProfile> = emptyList(),
```

**Dòng 31:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    ): OrderMergeResult {
```

**Dòng 32:** Biến chỉ đọc.

```kotlin
        val existingByWaybill = existingOrders.associateBy { it.waybillKey() }
```

**Dòng 33:** Biến chỉ đọc.

```kotlin
        val accepted = mutableListOf<DeliveryOrder>()
```

**Dòng 34:** Biến chỉ đọc.

```kotlin
        val added = mutableListOf<DeliveryOrder>()
```

**Dòng 35:** Biến chỉ đọc.

```kotlin
        val temporaryIndexes = mutableListOf<Int>()
```

**Dòng 36:** Biến chỉ đọc.

```kotlin
        val importedKeys = mutableSetOf<String>()
```

**Dòng 37:** Biến có thể thay đổi.

```kotlin
        var duplicates = 0
```

**Dòng 38:** Biến có thể thay đổi.

```kotlin
        var restoredProducts = 0
```

**Dòng 39:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 40:** Phép so sánh/điều kiện.

```kotlin
        importedOrders.forEach { imported ->
```

**Dòng 41:** Biến chỉ đọc.

```kotlin
            val waybillKey = imported.waybillKey()
```

**Dòng 42:** Điều kiện if.

```kotlin
            if (!importedKeys.add(waybillKey)) return@forEach
```

**Dòng 43:** Biến chỉ đọc.

```kotlin
            val saved = existingByWaybill[waybillKey]
```

**Dòng 44:** Điều kiện if.

```kotlin
            if (saved == null) {
```

**Dòng 45:** Biến chỉ đọc.

```kotlin
                val newOrder = imported.withCustomerAddress(customerProfiles).normalizedCoordinates()
```

**Dòng 46:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                accepted += newOrder
```

**Dòng 47:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                added += newOrder
```

**Dòng 48:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            } else {
```

**Dòng 49:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                duplicates++
```

**Dòng 50:** Biến chỉ đọc.

```kotlin
                val preserved = if (saved.product.isBlank() && imported.product.isNotBlank()) {
```

**Dòng 51:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    restoredProducts++
```

**Dòng 52:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    saved.copy(product = imported.product.trim())
```

**Dòng 53:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                } else {
```

**Dòng 54:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    saved
```

**Dòng 55:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                }
```

**Dòng 56:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                accepted += preserved
```

**Dòng 57:** Điều kiện if.

```kotlin
                if (preserved.isTemporaryFailure() || preserved.isPickupAtWarehouse()) temporaryIndexes += accepted.lastIndex
```

**Dòng 58:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 59:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 60:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 61:** Chú thích, không thực thi.

```kotlin
        // Nhập đơn không tự đánh STT. Kể cả đơn có tọa độ hoặc được kích hoạt lại,
```

**Dòng 62:** Chú thích, không thực thi.

```kotlin
        // người dùng phải chủ động tạo/cập nhật tuyến mới để app sinh STT.
```

**Dòng 63:** Phép so sánh/điều kiện.

```kotlin
        temporaryIndexes.forEach { index ->
```

**Dòng 64:** Biến chỉ đọc.

```kotlin
            val order = accepted[index]
```

**Dòng 65:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            accepted[index] = order.copy(
```

**Dòng 66:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                status = DeliveryStatus.TT500,
```

**Dòng 67:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                sequence = 0,
```

**Dòng 68:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                sequenceLabel = null,
```

**Dòng 69:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                requiresRedelivery = false,
```

**Dòng 70:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                wasRedelivered = false,
```

**Dòng 71:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                failureReason = null,
```

**Dòng 72:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            )
```

**Dòng 73:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 74:** Phép so sánh/điều kiện.

```kotlin
        accepted.indices.forEach { index ->
```

**Dòng 75:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            accepted[index] = accepted[index].copy(sequence = 0, sequenceLabel = null)
```

**Dòng 76:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 77:** Biến chỉ đọc.

```kotlin
        val removed = existingOrders.count { it.waybillKey() !in importedKeys }
```

**Dòng 78:** Kết thúc hàm và trả kết quả.

```kotlin
        return OrderMergeResult(
```

**Dòng 79:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            orders = accepted,
```

**Dòng 80:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            addedOrders = added,
```

**Dòng 81:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            ignoredDuplicateCount = duplicates,
```

**Dòng 82:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            restoredProductCount = restoredProducts,
```

**Dòng 83:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            reactivatedCount = temporaryIndexes.size,
```

**Dòng 84:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            removedNotInLatestImportCount = removed,
```

**Dòng 85:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        )
```

**Dòng 86:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 87:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 88:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    fun appendNew(
```

**Dòng 89:** Phép so sánh/điều kiện.

```kotlin
        existingOrders: List<DeliveryOrder>,
```

**Dòng 90:** Phép so sánh/điều kiện.

```kotlin
        importedOrders: List<DeliveryOrder>,
```

**Dòng 91:** Phép so sánh/điều kiện.

```kotlin
        customerProfiles: List<CustomerProfile> = emptyList(),
```

**Dòng 92:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    ): OrderMergeResult {
```

**Dòng 93:** Biến chỉ đọc.

```kotlin
        val mergedOrders = existingOrders.toMutableList()
```

**Dòng 94:** Biến chỉ đọc.

```kotlin
        val indexByWaybill = existingOrders.mapIndexed { index, order -> order.waybillKey() to index }.toMap().toMutableMap()
```

**Dòng 95:** Biến chỉ đọc.

```kotlin
        val added = mutableListOf<DeliveryOrder>()
```

**Dòng 96:** Biến có thể thay đổi.

```kotlin
        var duplicates = 0
```

**Dòng 97:** Biến có thể thay đổi.

```kotlin
        var restoredProducts = 0
```

**Dòng 98:** Phép so sánh/điều kiện.

```kotlin
        importedOrders.forEach { imported ->
```

**Dòng 99:** Biến chỉ đọc.

```kotlin
            val waybillKey = imported.waybillKey()
```

**Dòng 100:** Biến chỉ đọc.

```kotlin
            val existingIndex = indexByWaybill[waybillKey]
```

**Dòng 101:** Điều kiện if.

```kotlin
            if (existingIndex == null) {
```

**Dòng 102:** Biến chỉ đọc.

```kotlin
                val accepted = imported.withCustomerAddress(customerProfiles).normalizedCoordinates()
```

**Dòng 103:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                indexByWaybill[waybillKey] = mergedOrders.size
```

**Dòng 104:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                mergedOrders += accepted
```

**Dòng 105:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                added += accepted
```

**Dòng 106:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            } else {
```

**Dòng 107:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                duplicates++
```

**Dòng 108:** Biến chỉ đọc.

```kotlin
                val existing = mergedOrders[existingIndex]
```

**Dòng 109:** Điều kiện if.

```kotlin
                if (existing.product.isBlank() && imported.product.isNotBlank()) {
```

**Dòng 110:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    mergedOrders[existingIndex] = existing.copy(product = imported.product.trim())
```

**Dòng 111:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    restoredProducts++
```

**Dòng 112:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                }
```

**Dòng 113:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 114:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 115:** Kết thúc hàm và trả kết quả.

```kotlin
        return OrderMergeResult(mergedOrders, added, duplicates, restoredProducts)
```

**Dòng 116:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 117:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 118:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun DeliveryOrder.waybillKey(): String = waybill.trim().lowercase(Locale.ROOT)
```

**Dòng 119:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 120:** Phép so sánh/điều kiện.

```kotlin
    private fun DeliveryOrder.withCustomerAddress(profiles: List<CustomerProfile>): DeliveryOrder {
```

**Dòng 121:** Biến chỉ đọc.

```kotlin
        val targetPhone = phone.customerPhoneKey()
```

**Dòng 122:** Điều kiện if.

```kotlin
        if (targetPhone.isBlank()) return this
```

**Dòng 123:** Biến chỉ đọc.

```kotlin
        val matchedProfile = profiles.firstOrNull { profile ->
```

**Dòng 124:** Phép so sánh/điều kiện.

```kotlin
            profile.phones.any { savedPhone -> savedPhone.number.customerPhoneKey() == targetPhone }
```

**Dòng 125:** Elvis: dùng giá trị dự phòng khi null.

```kotlin
        } ?: return this
```

**Dòng 126:** Biến chỉ đọc.

```kotlin
        val savedAddress = matchedProfile.primaryAddress
```

**Dòng 127:** Điều kiện if.

```kotlin
        if (savedAddress.address.isBlank()) return this
```

**Dòng 128:** Kết thúc hàm và trả kết quả.

```kotlin
        return copy(
```

**Dòng 129:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            address = savedAddress.address,
```

**Dòng 130:** Elvis: dùng giá trị dự phòng khi null.

```kotlin
            latitude = savedAddress.latitude ?: latitude,
```

**Dòng 131:** Elvis: dùng giá trị dự phòng khi null.

```kotlin
            longitude = savedAddress.longitude ?: longitude,
```

**Dòng 132:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        )
```

**Dòng 133:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 134:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 135:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

## `app/src/main/java/com/example/delivery/orderio/SttSequenceFileCodec.kt`

**Dòng 1:** Khai báo package/namespace.

```kotlin
package com.example.delivery.orderio
```

**Dòng 2:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 3:** Import dependency.

```kotlin
import com.example.delivery.model.DeliveryOrder
```

**Dòng 4:** Import dependency.

```kotlin
import com.example.delivery.model.isPickupAtWarehouse
```

**Dòng 5:** Import dependency.

```kotlin
import com.example.delivery.model.isTerminalFailure
```

**Dòng 6:** Import dependency.

```kotlin
import com.example.delivery.model.isTemporaryFailure
```

**Dòng 7:** Import dependency.

```kotlin
import java.io.InputStream
```

**Dòng 8:** Import dependency.

```kotlin
import java.nio.charset.StandardCharsets
```

**Dòng 9:** Import dependency.

```kotlin
import java.text.Normalizer
```

**Dòng 10:** Import dependency.

```kotlin
import java.util.Locale
```

**Dòng 11:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 12:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
data class SttSequenceEntry(val waybill: String, val sequence: Int)
```

**Dòng 13:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 14:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
data class SttRestoreResult(
```

**Dòng 15:** Biến chỉ đọc.

```kotlin
    val orders: List<DeliveryOrder>,
```

**Dòng 16:** Biến chỉ đọc.

```kotlin
    val restoredCount: Int,
```

**Dòng 17:** Biến chỉ đọc.

```kotlin
    val skippedMissingCount: Int,
```

**Dòng 18:** Biến chỉ đọc.

```kotlin
    val skippedStatusCount: Int,
```

**Dòng 19:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
)
```

**Dòng 20:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 21:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
object SttSequenceFileCodec {
```

**Dòng 22:** Phép so sánh/điều kiện.

```kotlin
    fun exportCsv(orders: List<DeliveryOrder>): String = buildString {
```

**Dòng 23:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        append('\uFEFF')
```

**Dòng 24:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        append("\"Mã vận đơn\",\"STT\"\r\n")
```

**Dòng 25:** Lọc collection.

```kotlin
        orders.filter { it.sequence > 0 }.forEach { order ->
```

**Dòng 26:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            appendCsvRow(order.waybill, order.sequence.toString())
```

**Dòng 27:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 28:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 29:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 30:** Phép so sánh/điều kiện.

```kotlin
    fun import(input: InputStream): List<SttSequenceEntry> {
```

**Dòng 31:** Biến chỉ đọc.

```kotlin
        val rows = OrderFileCodec.parseDelimited(input.readBytes().toString(StandardCharsets.UTF_8))
```

**Dòng 32:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        require(rows.isNotEmpty()) { "Tệp STT đang trống." }
```

**Dòng 33:** Biến chỉ đọc.

```kotlin
        val first = rows.first().map { value -> value.normalizeHeader() }
```

**Dòng 34:** Biến chỉ đọc.

```kotlin
        val waybillIndex = first.indexOfFirst { it in setOf("mavandon", "waybill", "tracking", "madon", "orderid") }
```

**Dòng 35:** Biến chỉ đọc.

```kotlin
        val sequenceIndex = first.indexOfFirst { it in setOf("stt", "sequence", "thutu") }
```

**Dòng 36:** Biến chỉ đọc.

```kotlin
        val hasHeader = waybillIndex >= 0 || sequenceIndex >= 0
```

**Dòng 37:** Biến chỉ đọc.

```kotlin
        val wb = if (hasHeader) waybillIndex else 0
```

**Dòng 38:** Biến chỉ đọc.

```kotlin
        val seq = if (hasHeader) sequenceIndex else 1
```

**Dòng 39:** Phép so sánh/điều kiện.

```kotlin
        require(wb >= 0 && seq >= 0) { "Tệp STT phải có cột Mã vận đơn và STT." }
```

**Dòng 40:** Kết thúc hàm và trả kết quả.

```kotlin
        return rows.drop(if (hasHeader) 1 else 0).mapNotNull { row ->
```

**Dòng 41:** Biến chỉ đọc.

```kotlin
            val waybill = row.getOrNull(wb).orEmpty().trim()
```

**Dòng 42:** Biến chỉ đọc.

```kotlin
            val sequence = row.getOrNull(seq)?.trim()?.toIntOrNull()
```

**Dòng 43:** Điều kiện if.

```kotlin
            if (waybill.isBlank() || sequence == null || sequence <= 0) null else SttSequenceEntry(waybill, sequence)
```

**Dòng 44:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }.distinctBy { it.waybill.lowercase(Locale.ROOT) }.also {
```

**Dòng 45:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            require(it.isNotEmpty()) { "Không tìm thấy Mã vận đơn và STT hợp lệ." }
```

**Dòng 46:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 47:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 48:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 49:** Phép so sánh/điều kiện.

```kotlin
    fun restore(orders: List<DeliveryOrder>, entries: List<SttSequenceEntry>): SttRestoreResult {
```

**Dòng 50:** Biến chỉ đọc.

```kotlin
        val byWaybill = entries.associateBy { it.waybill.trim().lowercase(Locale.ROOT) }
```

**Dòng 51:** Biến có thể thay đổi.

```kotlin
        var restored = 0
```

**Dòng 52:** Biến có thể thay đổi.

```kotlin
        var missing = 0
```

**Dòng 53:** Biến có thể thay đổi.

```kotlin
        var skipped = 0
```

**Dòng 54:** Biến chỉ đọc.

```kotlin
        val result = orders.map { order ->
```

**Dòng 55:** Biến chỉ đọc.

```kotlin
            val entry = byWaybill[order.waybill.trim().lowercase(Locale.ROOT)]
```

**Dòng 56:** Rẽ nhánh nhiều trường hợp.

```kotlin
            when {
```

**Dòng 57:** Phép so sánh/điều kiện.

```kotlin
                entry == null -> order
```

**Dòng 58:** Phép so sánh/điều kiện.

```kotlin
                order.isTemporaryFailure() || order.isTerminalFailure() || order.isPickupAtWarehouse() -> {
```

**Dòng 59:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    skipped++
```

**Dòng 60:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    order
```

**Dòng 61:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                }
```

**Dòng 62:** Nhánh thay thế.

```kotlin
                else -> {
```

**Dòng 63:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    restored++
```

**Dòng 64:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    order.copy(sequence = entry.sequence)
```

**Dòng 65:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                }
```

**Dòng 66:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 67:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 68:** Phép so sánh/điều kiện.

```kotlin
        entries.forEach { entry ->
```

**Dòng 69:** Điều kiện if.

```kotlin
            if (orders.none { order -> order.waybill.equals(entry.waybill, ignoreCase = true) }) missing++
```

**Dòng 70:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 71:** Kết thúc hàm và trả kết quả.

```kotlin
        return SttRestoreResult(result, restored, missing, skipped)
```

**Dòng 72:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 73:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 74:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun String.normalizeHeader(): String = Normalizer.normalize(trim(), Normalizer.Form.NFD)
```

**Dòng 75:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        .replace("\\p{Mn}+".toRegex(), "")
```

**Dòng 76:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        .lowercase(Locale.ROOT)
```

**Dòng 77:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        .replace('đ', 'd')
```

**Dòng 78:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        .replace("[^a-z0-9]".toRegex(), "")
```

**Dòng 79:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 80:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    private fun StringBuilder.appendCsvRow(waybill: String, sequence: String) {
```

**Dòng 81:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        append("\"").append(waybill.replace("\"", "\"\""))
```

**Dòng 82:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            .append("\",\"").append(sequence).append("\"\r\n")
```

**Dòng 83:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 84:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

## `app/src/main/java/com/example/delivery/ui/AnchorPointScreen.kt`

**Dòng 1:** Khai báo package/namespace.

```kotlin
package com.example.delivery.ui
```

**Dòng 2:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 3:** Import dependency.

```kotlin
import androidx.compose.foundation.background
```

**Dòng 4:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.Column
```

**Dòng 5:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.Row
```

**Dòng 6:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.fillMaxSize
```

**Dòng 7:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.fillMaxWidth
```

**Dòng 8:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.padding
```

**Dòng 9:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.statusBarsPadding
```

**Dòng 10:** Import dependency.

```kotlin
import androidx.compose.material.icons.Icons
```

**Dòng 11:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.ArrowBack
```

**Dòng 12:** Import dependency.

```kotlin
import androidx.compose.material3.Button
```

**Dòng 13:** Import dependency.

```kotlin
import androidx.compose.material3.Icon
```

**Dòng 14:** Import dependency.

```kotlin
import androidx.compose.material3.IconButton
```

**Dòng 15:** Import dependency.

```kotlin
import androidx.compose.material3.Text
```

**Dòng 16:** Import dependency.

```kotlin
import androidx.compose.runtime.Composable
```

**Dòng 17:** Import dependency.

```kotlin
import androidx.compose.ui.Alignment
```

**Dòng 18:** Import dependency.

```kotlin
import androidx.compose.ui.Modifier
```

**Dòng 19:** Import dependency.

```kotlin
import androidx.compose.ui.graphics.Color
```

**Dòng 20:** Import dependency.

```kotlin
import androidx.compose.ui.text.font.FontWeight
```

**Dòng 21:** Import dependency.

```kotlin
import androidx.compose.ui.unit.dp
```

**Dòng 22:** Import dependency.

```kotlin
import androidx.compose.ui.unit.sp
```

**Dòng 23:** Import dependency.

```kotlin
import com.example.delivery.navigation.GeoPoint
```

**Dòng 24:** Import dependency.

```kotlin
import java.util.Locale
```

**Dòng 25:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 26:** Đánh dấu hàm UI Compose.

```kotlin
@Composable
```

**Dòng 27:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
internal fun AnchorPointScreen(
```

**Dòng 28:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    anchorPoint: GeoPoint?,
```

**Dòng 29:** Phép so sánh/điều kiện.

```kotlin
    onOpenPicker: () -> Unit,
```

**Dòng 30:** Phép so sánh/điều kiện.

```kotlin
    onClose: () -> Unit,
```

**Dòng 31:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
) {
```

**Dòng 32:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
    Column(Modifier.fillMaxSize().background(AppBackground)) {
```

**Dòng 33:** Container ngang.

```kotlin
        Row(
```

**Dòng 34:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            Modifier.fillMaxWidth().statusBarsPadding().padding(start = 12.dp, top = 8.dp, end = 12.dp, bottom = 10.dp),
```

**Dòng 35:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            verticalAlignment = Alignment.CenterVertically,
```

**Dòng 36:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        ) {
```

**Dòng 37:** Nút tương tác; onClick xử lý nhấn.

```kotlin
            IconButton(onClick = onClose) { Icon(Icons.Filled.ArrowBack, "Quay lại Cài đặt", tint = Color(0xFF12385F)) }
```

**Dòng 38:** Hiển thị văn bản.

```kotlin
            Text("ĐIỂM NEO VÀ VÙNG GIAO HÀNG", color = Color(0xFF12385F), fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
```

**Dòng 39:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 40:** Hiển thị văn bản.

```kotlin
        Text(
```

**Dòng 41:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            "Điểm Neo được lưu cố định và chỉ thay đổi khi bạn đặt lại điểm mới. Khi xác nhận thay đổi tuyến, STT sẽ được xếp từ gần đến xa theo điểm này.",
```

**Dòng 42:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            color = Color(0xFF59636D),
```

**Dòng 43:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            fontSize = 12.sp,
```

**Dòng 44:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
```

**Dòng 45:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        )
```

**Dòng 46:** Hiển thị văn bản.

```kotlin
        Text(
```

**Dòng 47:** Safe-call: chỉ chạy khi khác null.

```kotlin
            anchorPoint?.let { String.format(Locale.US, "Điểm Neo hiện tại: %.6f, %.6f", it.latitude, it.longitude) }
```

**Dòng 48:** Elvis: dùng giá trị dự phòng khi null.

```kotlin
                ?: "Chưa đặt Điểm Neo. Ứng dụng sẽ dùng GPS hoặc điểm dự phòng khi xếp tuyến.",
```

**Dòng 49:** Phép so sánh/điều kiện.

```kotlin
            color = if (anchorPoint == null) Color(0xFFC23D35) else Color(0xFF1E73BE),
```

**Dòng 50:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            fontSize = 12.sp,
```

**Dòng 51:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            fontWeight = FontWeight.Bold,
```

**Dòng 52:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
```

**Dòng 53:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        )
```

**Dòng 54:** Nút tương tác; onClick xử lý nhấn.

```kotlin
        Button(
```

**Dòng 55:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            onClick = onOpenPicker,
```

**Dòng 56:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
```

**Dòng 57:** Phép so sánh/điều kiện.

```kotlin
        ) { Text(if (anchorPoint == null) "Đặt điểm Neo" else "Đặt lại điểm Neo") }
```

**Dòng 58:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 59:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

## `app/src/main/java/com/example/delivery/ui/BarcodeScannerScreen.kt`

**Dòng 1:** Khai báo package/namespace.

```kotlin
package com.example.delivery.ui
```

**Dòng 2:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 3:** Import dependency.

```kotlin
import android.Manifest
```

**Dòng 4:** Import dependency.

```kotlin
import android.content.Context
```

**Dòng 5:** Import dependency.

```kotlin
import android.content.pm.PackageManager
```

**Dòng 6:** Import dependency.

```kotlin
import android.os.Build
```

**Dòng 7:** Import dependency.

```kotlin
import android.os.VibrationEffect
```

**Dòng 8:** Import dependency.

```kotlin
import android.os.Vibrator
```

**Dòng 9:** Import dependency.

```kotlin
import androidx.activity.compose.rememberLauncherForActivityResult
```

**Dòng 10:** Import dependency.

```kotlin
import androidx.activity.result.contract.ActivityResultContracts
```

**Dòng 11:** Import dependency.

```kotlin
import androidx.camera.core.Camera
```

**Dòng 12:** Import dependency.

```kotlin
import androidx.camera.core.CameraSelector
```

**Dòng 13:** Import dependency.

```kotlin
import androidx.camera.core.ImageAnalysis
```

**Dòng 14:** Import dependency.

```kotlin
import androidx.camera.core.Preview
```

**Dòng 15:** Import dependency.

```kotlin
import androidx.camera.lifecycle.ProcessCameraProvider
```

**Dòng 16:** Import dependency.

```kotlin
import androidx.camera.view.PreviewView
```

**Dòng 17:** Import dependency.

```kotlin
import androidx.compose.animation.core.LinearEasing
```

**Dòng 18:** Import dependency.

```kotlin
import androidx.compose.animation.core.RepeatMode
```

**Dòng 19:** Import dependency.

```kotlin
import androidx.compose.animation.core.animateFloat
```

**Dòng 20:** Import dependency.

```kotlin
import androidx.compose.animation.core.infiniteRepeatable
```

**Dòng 21:** Import dependency.

```kotlin
import androidx.compose.animation.core.rememberInfiniteTransition
```

**Dòng 22:** Import dependency.

```kotlin
import androidx.compose.animation.core.tween
```

**Dòng 23:** Import dependency.

```kotlin
import androidx.compose.foundation.background
```

**Dòng 24:** Import dependency.

```kotlin
import androidx.compose.foundation.border
```

**Dòng 25:** Import dependency.

```kotlin
import androidx.compose.foundation.Canvas
```

**Dòng 26:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.Box
```

**Dòng 27:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.fillMaxSize
```

**Dòng 28:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.fillMaxWidth
```

**Dòng 29:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.height
```

**Dòng 30:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.offset
```

**Dòng 31:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.padding
```

**Dòng 32:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.width
```

**Dòng 33:** Import dependency.

```kotlin
import androidx.compose.foundation.shape.RoundedCornerShape
```

**Dòng 34:** Import dependency.

```kotlin
import androidx.compose.material.icons.Icons
```

**Dòng 35:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.Close
```

**Dòng 36:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.FlashOn
```

**Dòng 37:** Import dependency.

```kotlin
import androidx.compose.material3.Icon
```

**Dòng 38:** Import dependency.

```kotlin
import androidx.compose.material3.IconButton
```

**Dòng 39:** Import dependency.

```kotlin
import androidx.compose.material3.Text
```

**Dòng 40:** Import dependency.

```kotlin
import androidx.compose.runtime.Composable
```

**Dòng 41:** Import dependency.

```kotlin
import androidx.compose.runtime.DisposableEffect
```

**Dòng 42:** Import dependency.

```kotlin
import androidx.compose.runtime.LaunchedEffect
```

**Dòng 43:** Import dependency.

```kotlin
import androidx.compose.runtime.getValue
```

**Dòng 44:** Import dependency.

```kotlin
import androidx.compose.runtime.mutableStateOf
```

**Dòng 45:** Import dependency.

```kotlin
import androidx.compose.runtime.remember
```

**Dòng 46:** Import dependency.

```kotlin
import androidx.compose.runtime.setValue
```

**Dòng 47:** Import dependency.

```kotlin
import androidx.compose.ui.Alignment
```

**Dòng 48:** Import dependency.

```kotlin
import androidx.compose.ui.Modifier
```

**Dòng 49:** Import dependency.

```kotlin
import androidx.compose.ui.geometry.Offset
```

**Dòng 50:** Import dependency.

```kotlin
import androidx.compose.ui.geometry.Size
```

**Dòng 51:** Import dependency.

```kotlin
import androidx.compose.ui.graphics.Brush
```

**Dòng 52:** Import dependency.

```kotlin
import androidx.compose.ui.graphics.Color
```

**Dòng 53:** Import dependency.

```kotlin
import androidx.compose.ui.platform.LocalContext
```

**Dòng 54:** Import dependency.

```kotlin
import androidx.compose.ui.platform.LocalLifecycleOwner
```

**Dòng 55:** Import dependency.

```kotlin
import androidx.compose.ui.unit.dp
```

**Dòng 56:** Import dependency.

```kotlin
import androidx.core.content.ContextCompat
```

**Dòng 57:** Import dependency.

```kotlin
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
```

**Dòng 58:** Import dependency.

```kotlin
import com.google.mlkit.vision.barcode.BarcodeScanning
```

**Dòng 59:** Import dependency.

```kotlin
import com.google.mlkit.vision.barcode.common.Barcode
```

**Dòng 60:** Import dependency.

```kotlin
import com.google.mlkit.vision.common.InputImage
```

**Dòng 61:** Import dependency.

```kotlin
import kotlinx.coroutines.delay
```

**Dòng 62:** Import dependency.

```kotlin
import java.util.concurrent.Executors
```

**Dòng 63:** Import dependency.

```kotlin
import java.util.concurrent.atomic.AtomicBoolean
```

**Dòng 64:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 65:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
internal const val QR_SCAN_HAPTIC_MILLIS = 45L
```

**Dòng 66:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 67:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
@Suppress("DEPRECATION")
```

**Dòng 68:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
internal fun triggerQrScanHaptic(context: Context) {
```

**Dòng 69:** Biến chỉ đọc.

```kotlin
    val vibrator = context.getSystemService(Vibrator::class.java) ?: return
```

**Dòng 70:** Điều kiện if.

```kotlin
    if (!vibrator.hasVibrator()) return
```

**Dòng 71:** Điều kiện if.

```kotlin
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
```

**Dòng 72:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        vibrator.vibrate(VibrationEffect.createOneShot(QR_SCAN_HAPTIC_MILLIS, VibrationEffect.DEFAULT_AMPLITUDE))
```

**Dòng 73:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    } else {
```

**Dòng 74:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        vibrator.vibrate(QR_SCAN_HAPTIC_MILLIS)
```

**Dòng 75:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 76:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 77:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 78:** Đánh dấu hàm UI Compose.

```kotlin
@Composable
```

**Dòng 79:** Phép so sánh/điều kiện.

```kotlin
fun BarcodeScannerScreen(onCodeScanned: (String) -> Unit, onDismiss: () -> Unit) {
```

**Dòng 80:** Biến chỉ đọc.

```kotlin
    val context = LocalContext.current
```

**Dòng 81:** Biến chỉ đọc.

```kotlin
    val lifecycleOwner = LocalLifecycleOwner.current
```

**Dòng 82:** Biến có thể thay đổi.

```kotlin
    var granted by remember { mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) }
```

**Dòng 83:** Biến chỉ đọc.

```kotlin
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
```

**Dòng 84:** Biến có thể thay đổi.

```kotlin
    var torchEnabled by remember { mutableStateOf(false) }
```

**Dòng 85:** Biến có thể thay đổi.

```kotlin
    var boundCamera by remember { mutableStateOf<Camera?>(null) }
```

**Dòng 86:** Biến có thể thay đổi.

```kotlin
    var scannedCode by remember { mutableStateOf<String?>(null) }
```

**Dòng 87:** Biến chỉ đọc.

```kotlin
    val accepted = remember { AtomicBoolean(false) }
```

**Dòng 88:** Biến chỉ đọc.

```kotlin
    val executor = remember { Executors.newSingleThreadExecutor() }
```

**Dòng 89:** Biến chỉ đọc.

```kotlin
    val green = Color(0xFF00E676)
```

**Dòng 90:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 91:** Chạy coroutine theo key.

```kotlin
    LaunchedEffect(Unit) { if (!granted) permission.launch(Manifest.permission.CAMERA) }
```

**Dòng 92:** Chạy coroutine theo key.

```kotlin
    LaunchedEffect(scannedCode) {
```

**Dòng 93:** Biến chỉ đọc.

```kotlin
        val code = scannedCode ?: return@LaunchedEffect
```

**Dòng 94:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        delay(180)
```

**Dòng 95:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        onCodeScanned(code)
```

**Dòng 96:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 97:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    DisposableEffect(Unit) { onDispose { executor.shutdown(); boundCamera?.cameraControl?.enableTorch(false) } }
```

**Dòng 98:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 99:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
    Box(Modifier.fillMaxSize().background(Color.Black)) {
```

**Dòng 100:** Điều kiện if.

```kotlin
        if (granted) {
```

**Dòng 101:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            androidx.compose.ui.viewinterop.AndroidView(
```

**Dòng 102:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
                modifier = Modifier.fillMaxSize(),
```

**Dòng 103:** Phép so sánh/điều kiện.

```kotlin
                factory = { viewContext ->
```

**Dòng 104:** Phép so sánh/điều kiện.

```kotlin
                    PreviewView(viewContext).also { previewView ->
```

**Dòng 105:** Biến chỉ đọc.

```kotlin
                        val providerFuture = ProcessCameraProvider.getInstance(context)
```

**Dòng 106:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        providerFuture.addListener({
```

**Dòng 107:** Biến chỉ đọc.

```kotlin
                            val provider = providerFuture.get()
```

**Dòng 108:** Biến chỉ đọc.

```kotlin
                            val preview = Preview.Builder().build().also { it.surfaceProvider = previewView.surfaceProvider }
```

**Dòng 109:** Biến chỉ đọc.

```kotlin
                            val analysis = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
```

**Dòng 110:** Biến chỉ đọc.

```kotlin
                            val scanner = BarcodeScanning.getClient(
```

**Dòng 111:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                                BarcodeScannerOptions.Builder().setBarcodeFormats(
```

**Dòng 112:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                                    Barcode.FORMAT_QR_CODE,
```

**Dòng 113:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                                    Barcode.FORMAT_CODE_128,
```

**Dòng 114:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                                    Barcode.FORMAT_CODE_39,
```

**Dòng 115:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                                    Barcode.FORMAT_EAN_13,
```

**Dòng 116:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                                    Barcode.FORMAT_EAN_8,
```

**Dòng 117:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                                ).build(),
```

**Dòng 118:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                            )
```

**Dòng 119:** Phép so sánh/điều kiện.

```kotlin
                            analysis.setAnalyzer(executor) { imageProxy ->
```

**Dòng 120:** Biến chỉ đọc.

```kotlin
                                val mediaImage = imageProxy.image
```

**Dòng 121:** Điều kiện if.

```kotlin
                                if (mediaImage == null) {
```

**Dòng 122:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                                    imageProxy.close()
```

**Dòng 123:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                                } else {
```

**Dòng 124:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                                    scanner.process(InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees))
```

**Dòng 125:** Phép so sánh/điều kiện.

```kotlin
                                        .addOnSuccessListener { values ->
```

**Dòng 126:** Biến chỉ đọc.

```kotlin
                                            val code = values.firstOrNull { !it.rawValue.isNullOrBlank() }?.rawValue
```

**Dòng 127:** Điều kiện if.

```kotlin
                                            if (code != null && accepted.compareAndSet(false, true)) {
```

**Dòng 128:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                                                ContextCompat.getMainExecutor(context).execute {
```

**Dòng 129:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                                                    triggerQrScanHaptic(context)
```

**Dòng 130:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                                                    scannedCode = code
```

**Dòng 131:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                                                }
```

**Dòng 132:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                                            }
```

**Dòng 133:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                                        }
```

**Dòng 134:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                                        .addOnCompleteListener { imageProxy.close() }
```

**Dòng 135:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                                }
```

**Dòng 136:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                            }
```

**Dòng 137:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                            provider.unbindAll()
```

**Dòng 138:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                            boundCamera = provider.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
```

**Dòng 139:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        }, ContextCompat.getMainExecutor(context))
```

**Dòng 140:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    }
```

**Dòng 141:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                },
```

**Dòng 142:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            )
```

**Dòng 143:** Phép so sánh/điều kiện.

```kotlin
            ScannerOverlay(green, scannedCode != null)
```

**Dòng 144:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            IconButton(modifier = Modifier.align(Alignment.TopStart).padding(16.dp), onClick = onDismiss) { Icon(Icons.Filled.Close, "Đóng quét mã", tint = Color.White) }
```

**Dòng 145:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            IconButton(modifier = Modifier.align(Alignment.TopEnd).padding(16.dp), onClick = { torchEnabled = !torchEnabled; boundCamera?.cameraControl?.enableTorch(torchEnabled) }) { Icon(Icons.Filled.FlashOn, "Đèn flash", tint = if (torchEnabled) green else Color.White) }
```

**Dòng 146:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            Text("QUÉT MÃ QR", color = Color.White, modifier = Modifier.align(Alignment.TopCenter).padding(top = 22.dp))
```

**Dòng 147:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            Text(if (scannedCode == null) "Đưa QR hoặc mã vạch vào khung để quét" else "Đã nhận diện mã", color = Color.White, modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 36.dp))
```

**Dòng 148:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        } else {
```

**Dòng 149:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            Text("Cần quyền Camera để quét mã", color = Color.White, modifier = Modifier.align(Alignment.Center))
```

**Dòng 150:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            IconButton(modifier = Modifier.align(Alignment.TopStart).padding(16.dp), onClick = onDismiss) { Icon(Icons.Filled.Close, "Đóng", tint = Color.White) }
```

**Dòng 151:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 152:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 153:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 154:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 155:** Đánh dấu hàm UI Compose.

```kotlin
@Composable
```

**Dòng 156:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
private fun ScannerOverlay(color: Color, isSuccess: Boolean) {
```

**Dòng 157:** Biến chỉ đọc.

```kotlin
    val transition = rememberInfiniteTransition(label = "scanner")
```

**Dòng 158:** Biến chỉ đọc.

```kotlin
    val vertical by transition.animateFloat(0f, 1f, infiniteRepeatable(tween(1750, easing = LinearEasing), RepeatMode.Reverse), label = "vertical")
```

**Dòng 159:** Biến chỉ đọc.

```kotlin
    val accent = if (isSuccess) Color(0xFF69F0AE) else color
```

**Dòng 160:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
```

**Dòng 161:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        Canvas(Modifier.fillMaxSize()) {
```

**Dòng 162:** Biến chỉ đọc.

```kotlin
            val frameWidth = 296.dp.toPx()
```

**Dòng 163:** Biến chỉ đọc.

```kotlin
            val frameHeight = 220.dp.toPx()
```

**Dòng 164:** Biến chỉ đọc.

```kotlin
            val left = (size.width - frameWidth) / 2f
```

**Dòng 165:** Biến chỉ đọc.

```kotlin
            val top = (size.height - frameHeight) / 2f
```

**Dòng 166:** Biến chỉ đọc.

```kotlin
            val shade = Color.Black.copy(alpha = 0.46f)
```

**Dòng 167:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            drawRect(shade, size = Size(size.width, top))
```

**Dòng 168:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            drawRect(shade, topLeft = Offset(0f, top + frameHeight), size = Size(size.width, size.height - top - frameHeight))
```

**Dòng 169:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            drawRect(shade, topLeft = Offset(0f, top), size = Size(left, frameHeight))
```

**Dòng 170:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            drawRect(shade, topLeft = Offset(left + frameWidth, top), size = Size(size.width - left - frameWidth, frameHeight))
```

**Dòng 171:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 172:** Container xếp/chồng UI.

```kotlin
        Box(
```

**Dòng 173:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            Modifier
```

**Dòng 174:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                .width(296.dp)
```

**Dòng 175:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                .height(220.dp)
```

**Dòng 176:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                .border(if (isSuccess) 2.dp else 1.dp, if (isSuccess) accent else Color.White.copy(alpha = 0.92f), RoundedCornerShape(16.dp)),
```

**Dòng 177:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        ) {
```

**Dòng 178:** Container xếp/chồng UI.

```kotlin
            Box(
```

**Dòng 179:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                Modifier
```

**Dòng 180:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    .fillMaxWidth()
```

**Dòng 181:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    .height(9.dp)
```

**Dòng 182:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    .offset(y = (202f * vertical).dp)
```

**Dòng 183:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    .background(
```

**Dòng 184:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        Brush.horizontalGradient(listOf(Color.Transparent, accent.copy(alpha = 0.2f), accent, accent.copy(alpha = 0.2f), Color.Transparent)),
```

**Dòng 185:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        RoundedCornerShape(12.dp),
```

**Dòng 186:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    ),
```

**Dòng 187:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            )
```

**Dòng 188:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 189:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 190:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

## `app/src/main/java/com/example/delivery/ui/CashAuditScreen.kt`

**Dòng 1:** Khai báo package/namespace.

```kotlin
package com.example.delivery.ui
```

**Dòng 2:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 3:** Import dependency.

```kotlin
import android.content.Context
```

**Dòng 4:** Import dependency.

```kotlin
import androidx.compose.foundation.ExperimentalFoundationApi
```

**Dòng 5:** Import dependency.

```kotlin
import androidx.compose.foundation.background
```

**Dòng 6:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.Arrangement
```

**Dòng 7:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.Column
```

**Dòng 8:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.Row
```

**Dòng 9:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.Spacer
```

**Dòng 10:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.fillMaxSize
```

**Dòng 11:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.fillMaxWidth
```

**Dòng 12:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.height
```

**Dòng 13:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.imePadding
```

**Dòng 14:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.padding
```

**Dòng 15:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.size
```

**Dòng 16:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.statusBarsPadding
```

**Dòng 17:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.width
```

**Dòng 18:** Import dependency.

```kotlin
import androidx.compose.foundation.rememberScrollState
```

**Dòng 19:** Import dependency.

```kotlin
import androidx.compose.foundation.relocation.BringIntoViewRequester
```

**Dòng 20:** Import dependency.

```kotlin
import androidx.compose.foundation.relocation.bringIntoViewRequester
```

**Dòng 21:** Import dependency.

```kotlin
import androidx.compose.foundation.shape.CircleShape
```

**Dòng 22:** Import dependency.

```kotlin
import androidx.compose.foundation.shape.RoundedCornerShape
```

**Dòng 23:** Import dependency.

```kotlin
import androidx.compose.foundation.verticalScroll
```

**Dòng 24:** Import dependency.

```kotlin
import androidx.compose.material.icons.Icons
```

**Dòng 25:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.Add
```

**Dòng 26:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.ArrowBack
```

**Dòng 27:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.Remove
```

**Dòng 28:** Import dependency.

```kotlin
import androidx.compose.material3.Button
```

**Dòng 29:** Import dependency.

```kotlin
import androidx.compose.material3.ButtonDefaults
```

**Dòng 30:** Import dependency.

```kotlin
import androidx.compose.material3.Icon
```

**Dòng 31:** Import dependency.

```kotlin
import androidx.compose.material3.IconButton
```

**Dòng 32:** Import dependency.

```kotlin
import androidx.compose.material3.OutlinedButton
```

**Dòng 33:** Import dependency.

```kotlin
import androidx.compose.material3.OutlinedTextField
```

**Dòng 34:** Import dependency.

```kotlin
import androidx.compose.material3.Text
```

**Dòng 35:** Import dependency.

```kotlin
import androidx.compose.runtime.Composable
```

**Dòng 36:** Import dependency.

```kotlin
import androidx.compose.runtime.LaunchedEffect
```

**Dòng 37:** Import dependency.

```kotlin
import androidx.compose.runtime.getValue
```

**Dòng 38:** Import dependency.

```kotlin
import androidx.compose.runtime.mutableStateOf
```

**Dòng 39:** Import dependency.

```kotlin
import androidx.compose.runtime.remember
```

**Dòng 40:** Import dependency.

```kotlin
import androidx.compose.runtime.setValue
```

**Dòng 41:** Import dependency.

```kotlin
import androidx.compose.ui.Alignment
```

**Dòng 42:** Import dependency.

```kotlin
import androidx.compose.ui.ExperimentalComposeUiApi
```

**Dòng 43:** Import dependency.

```kotlin
import androidx.compose.ui.Modifier
```

**Dòng 44:** Import dependency.

```kotlin
import androidx.compose.ui.focus.FocusManager
```

**Dòng 45:** Import dependency.

```kotlin
import androidx.compose.ui.focus.FocusRequester
```

**Dòng 46:** Import dependency.

```kotlin
import androidx.compose.ui.focus.focusProperties
```

**Dòng 47:** Import dependency.

```kotlin
import androidx.compose.ui.focus.onFocusChanged
```

**Dòng 48:** Import dependency.

```kotlin
import androidx.compose.ui.graphics.Color
```

**Dòng 49:** Import dependency.

```kotlin
import androidx.compose.ui.input.key.Key
```

**Dòng 50:** Import dependency.

```kotlin
import androidx.compose.ui.input.key.KeyEventType
```

**Dòng 51:** Import dependency.

```kotlin
import androidx.compose.ui.input.key.key
```

**Dòng 52:** Import dependency.

```kotlin
import androidx.compose.ui.input.key.onPreviewKeyEvent
```

**Dòng 53:** Import dependency.

```kotlin
import androidx.compose.ui.input.key.type
```

**Dòng 54:** Import dependency.

```kotlin
import androidx.compose.ui.platform.LocalFocusManager
```

**Dòng 55:** Import dependency.

```kotlin
import androidx.compose.ui.platform.LocalContext
```

**Dòng 56:** Import dependency.

```kotlin
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
```

**Dòng 57:** Import dependency.

```kotlin
import androidx.compose.ui.platform.SoftwareKeyboardController
```

**Dòng 58:** Import dependency.

```kotlin
import androidx.compose.ui.text.TextRange
```

**Dòng 59:** Import dependency.

```kotlin
import androidx.compose.ui.text.font.FontWeight
```

**Dòng 60:** Import dependency.

```kotlin
import androidx.compose.ui.text.input.ImeAction
```

**Dòng 61:** Import dependency.

```kotlin
import androidx.compose.ui.text.input.KeyboardType
```

**Dòng 62:** Import dependency.

```kotlin
import androidx.compose.ui.text.input.TextFieldValue
```

**Dòng 63:** Import dependency.

```kotlin
import androidx.compose.ui.unit.dp
```

**Dòng 64:** Import dependency.

```kotlin
import androidx.compose.ui.unit.sp
```

**Dòng 65:** Import dependency.

```kotlin
import androidx.compose.foundation.text.KeyboardActions
```

**Dòng 66:** Import dependency.

```kotlin
import androidx.compose.foundation.text.KeyboardOptions
```

**Dòng 67:** Import dependency.

```kotlin
import com.example.delivery.cash.CashAuditCalculator
```

**Dòng 68:** Import dependency.

```kotlin
import com.example.delivery.cash.CashAuditState
```

**Dòng 69:** Import dependency.

```kotlin
import com.example.delivery.cash.CashAuditStatus
```

**Dòng 70:** Import dependency.

```kotlin
import com.example.delivery.cash.CashAuditStore
```

**Dòng 71:** Import dependency.

```kotlin
import kotlin.math.abs
```

**Dòng 72:** Import dependency.

```kotlin
import kotlinx.coroutines.delay
```

**Dòng 73:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 74:** Đánh dấu hàm UI Compose.

```kotlin
@Composable
```

**Dòng 75:** Phép so sánh/điều kiện.

```kotlin
fun CashAuditScreen(onClose: () -> Unit) {
```

**Dòng 76:** Biến chỉ đọc.

```kotlin
    val context = LocalContext.current
```

**Dòng 77:** Biến chỉ đọc.

```kotlin
    val focusManager = LocalFocusManager.current
```

**Dòng 78:** Biến chỉ đọc.

```kotlin
    val keyboardController = LocalSoftwareKeyboardController.current
```

**Dòng 79:** Biến chỉ đọc.

```kotlin
    val restoredState = remember(context) { CashAuditStore.load(context) }
```

**Dòng 80:** Biến có thể thay đổi.

```kotlin
    var counts by remember(context) { mutableStateOf(restoredState.counts) }
```

**Dòng 81:** Biến có thể thay đổi.

```kotlin
    var bankInput by remember(context) { mutableStateOf(moneyTextFieldValue(restoredState.bankInput)) }
```

**Dòng 82:** Biến có thể thay đổi.

```kotlin
    var feeInput by remember(context) { mutableStateOf(moneyTextFieldValue(restoredState.feeInput)) }
```

**Dòng 83:** Biến có thể thay đổi.

```kotlin
    var codInput by remember(context) { mutableStateOf(moneyTextFieldValue(restoredState.codInput)) }
```

**Dòng 84:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    fun saveState(
```

**Dòng 85:** Phép so sánh/điều kiện.

```kotlin
        nextCounts: Map<Long, Int> = counts,
```

**Dòng 86:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        nextBank: String = bankInput.text,
```

**Dòng 87:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        nextFee: String = feeInput.text,
```

**Dòng 88:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        nextCod: String = codInput.text,
```

**Dòng 89:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    ) {
```

**Dòng 90:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        CashAuditStore.save(context, CashAuditState(nextCounts, nextBank, nextFee, nextCod))
```

**Dòng 91:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 92:** Biến chỉ đọc.

```kotlin
    val result = CashAuditCalculator.calculate(
```

**Dòng 93:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        counts = counts,
```

**Dòng 94:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        bank = CashAuditCalculator.parseAmount(bankInput.text),
```

**Dòng 95:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        fee = CashAuditCalculator.parseAmount(feeInput.text),
```

**Dòng 96:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        cod = CashAuditCalculator.parseAmount(codInput.text),
```

**Dòng 97:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    )
```

**Dòng 98:** Biến chỉ đọc.

```kotlin
    val resultStyle = when (result.status) {
```

**Dòng 99:** Phép so sánh/điều kiện.

```kotlin
        CashAuditStatus.SURPLUS -> ResultStyle(Color(0xFFE6F5EA), Color(0xFF167B38), "DƯ")
```

**Dòng 100:** Phép so sánh/điều kiện.

```kotlin
        CashAuditStatus.DEFICIT -> ResultStyle(Color(0xFFFFE9E7), Color(0xFFC23D35), "THIẾU")
```

**Dòng 101:** Phép so sánh/điều kiện.

```kotlin
        CashAuditStatus.BALANCED -> ResultStyle(Color(0xFFE8F2FF), Color(0xFF1E73BE), "ĐÃ KHỚP")
```

**Dòng 102:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 103:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 104:** Container dọc.

```kotlin
    Column(
```

**Dòng 105:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        Modifier
```

**Dòng 106:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            .fillMaxSize()
```

**Dòng 107:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            .background(AppBackground)
```

**Dòng 108:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            .statusBarsPadding()
```

**Dòng 109:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            .imePadding()
```

**Dòng 110:** Giữ giá trị qua recomposition.

```kotlin
            .verticalScroll(rememberScrollState())
```

**Dòng 111:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            .padding(bottom = 18.dp),
```

**Dòng 112:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    ) {
```

**Dòng 113:** Container ngang.

```kotlin
        Row(
```

**Dòng 114:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            Modifier.fillMaxWidth().padding(start = 10.dp, top = 8.dp, end = 14.dp, bottom = 8.dp),
```

**Dòng 115:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            verticalAlignment = Alignment.CenterVertically,
```

**Dòng 116:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        ) {
```

**Dòng 117:** Nút tương tác; onClick xử lý nhấn.

```kotlin
            IconButton(onClick = onClose) { Icon(Icons.Filled.ArrowBack, "Quay lại Cài đặt", tint = Color(0xFF12385F)) }
```

**Dòng 118:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            Text("BẢNG KÊ TIỀN", modifier = Modifier.weight(1f), color = Color(0xFF12385F), fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
```

**Dòng 119:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 120:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 121:** Container dọc.

```kotlin
        Column(
```

**Dòng 122:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            Modifier.fillMaxWidth().padding(horizontal = 12.dp).background(resultStyle.background, RoundedCornerShape(18.dp)).padding(16.dp),
```

**Dòng 123:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        ) {
```

**Dòng 124:** Hiển thị văn bản.

```kotlin
            Text("KẾT QUẢ BẢNG TÍNH", color = resultStyle.foreground, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
```

**Dòng 125:** Hiển thị văn bản.

```kotlin
            Text(
```

**Dòng 126:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                text = "${resultStyle.label} ${CashAuditCalculator.formatAmount(abs(result.difference))}đ",
```

**Dòng 127:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                color = resultStyle.foreground,
```

**Dòng 128:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                fontSize = 27.sp,
```

**Dòng 129:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                fontWeight = FontWeight.ExtraBold,
```

**Dòng 130:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
                modifier = Modifier.padding(top = 4.dp),
```

**Dòng 131:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            )
```

**Dòng 132:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            Text("(Tiền mặt + Bank) − (Cước + COD)", color = resultStyle.foreground.copy(alpha = 0.78f), fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
```

**Dòng 133:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 134:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 135:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
```

**Dòng 136:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            Text("ĐẾM TIỀN MẶT", modifier = Modifier.weight(1f), color = Color(0xFFE57B22), fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
```

**Dòng 137:** Nút tương tác; onClick xử lý nhấn.

```kotlin
            OutlinedButton(onClick = {
```

**Dòng 138:** Tạo Map key/value.

```kotlin
                counts = CashAuditCalculator.denominations.associateWith { 0 }
```

**Dòng 139:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                bankInput = moneyTextFieldValue("")
```

**Dòng 140:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                feeInput = moneyTextFieldValue("")
```

**Dòng 141:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                codInput = moneyTextFieldValue("")
```

**Dòng 142:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                CashAuditStore.reset(context)
```

**Dòng 143:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                focusManager.clearFocus()
```

**Dòng 144:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            }, modifier = Modifier.height(36.dp)) { Text("Reset 0", fontSize = 11.sp) }
```

**Dòng 145:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 146:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 147:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp).background(AppSurface, RoundedCornerShape(18.dp)).padding(12.dp)) {
```

**Dòng 148:** Phép so sánh/điều kiện.

```kotlin
            CashAuditCalculator.denominations.forEach { denomination ->
```

**Dòng 149:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                CashDenominationRow(
```

**Dòng 150:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    denomination = denomination,
```

**Dòng 151:** Elvis: dùng giá trị dự phòng khi null.

```kotlin
                    count = counts[denomination] ?: 0,
```

**Dòng 152:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    focusManager = focusManager,
```

**Dòng 153:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    keyboardController = keyboardController,
```

**Dòng 154:** Phép so sánh/điều kiện.

```kotlin
                    onCountChange = { count ->
```

**Dòng 155:** Biến chỉ đọc.

```kotlin
                        val nextCounts = counts + (denomination to count.coerceIn(0, 999))
```

**Dòng 156:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        counts = nextCounts
```

**Dòng 157:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        saveState(nextCounts = nextCounts)
```

**Dòng 158:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    },
```

**Dòng 159:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                )
```

**Dòng 160:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 161:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
```

**Dòng 162:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
                Text("TỔNG TIỀN MẶT", modifier = Modifier.weight(1f), color = Color(0xFF12385F), fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
```

**Dòng 163:** Hiển thị văn bản.

```kotlin
                Text("${CashAuditCalculator.formatAmount(result.cashTotal)}đ", color = Color(0xFF12385F), fontWeight = FontWeight.ExtraBold, fontSize = 21.sp)
```

**Dòng 164:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 165:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 166:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 167:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        Text("ĐỐI SOÁT", modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp), color = Color(0xFFE57B22), fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
```

**Dòng 168:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp).background(AppSurface, RoundedCornerShape(18.dp)).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
```

**Dòng 169:** Phép so sánh/điều kiện.

```kotlin
            MoneyInputRow("Bank", bankInput, { value -> bankInput = value; saveState(nextBank = value.text) }, focusManager, keyboardController)
```

**Dòng 170:** Phép so sánh/điều kiện.

```kotlin
            MoneyInputRow("Cước", feeInput, { value -> feeInput = value; saveState(nextFee = value.text) }, focusManager, keyboardController)
```

**Dòng 171:** Phép so sánh/điều kiện.

```kotlin
            MoneyInputRow("COD", codInput, { value -> codInput = value; saveState(nextCod = value.text) }, focusManager, keyboardController)
```

**Dòng 172:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 173:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 174:** Nút tương tác; onClick xử lý nhấn.

```kotlin
        Button(
```

**Dòng 175:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            onClick = onClose,
```

**Dòng 176:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 16.dp).height(50.dp),
```

**Dòng 177:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E73BE)),
```

**Dòng 178:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            shape = RoundedCornerShape(15.dp),
```

**Dòng 179:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        ) { Text("Đóng bảng kê", fontWeight = FontWeight.ExtraBold) }
```

**Dòng 180:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 181:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 182:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 183:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
private data class ResultStyle(val background: Color, val foreground: Color, val label: String)
```

**Dòng 184:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 185:** Đánh dấu hàm UI Compose.

```kotlin
@Composable
```

**Dòng 186:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
@OptIn(ExperimentalComposeUiApi::class)
```

**Dòng 187:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
private fun CashDenominationRow(
```

**Dòng 188:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    denomination: Long,
```

**Dòng 189:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    count: Int,
```

**Dòng 190:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    focusManager: FocusManager,
```

**Dòng 191:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    keyboardController: SoftwareKeyboardController?,
```

**Dòng 192:** Phép so sánh/điều kiện.

```kotlin
    onCountChange: (Int) -> Unit,
```

**Dòng 193:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
) {
```

**Dòng 194:** Container ngang.

```kotlin
    Row(
```

**Dòng 195:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        Modifier.fillMaxWidth().padding(vertical = 5.dp),
```

**Dòng 196:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        verticalAlignment = Alignment.CenterVertically,
```

**Dòng 197:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        horizontalArrangement = Arrangement.spacedBy(7.dp),
```

**Dòng 198:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    ) {
```

**Dòng 199:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        Text("${CashAuditCalculator.formatAmount(denomination)}đ", modifier = Modifier.weight(1.38f), color = Color(0xFF12385F), fontWeight = FontWeight.Bold, fontSize = 12.sp)
```

**Dòng 200:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        IconButton(onClick = { onCountChange((count - 1).coerceAtLeast(0)) }, modifier = Modifier.size(38.dp).background(Color(0xFFF2F6F9), CircleShape)) { Icon(Icons.Filled.Remove, "Giảm số lượng", tint = Color(0xFF1E73BE)) }
```

**Dòng 201:** Ô nhập liệu.

```kotlin
        OutlinedTextField(
```

**Dòng 202:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            value = count.toString(),
```

**Dòng 203:** Lọc collection.

```kotlin
            onValueChange = { onCountChange(it.filter(Char::isDigit).toIntOrNull() ?: 0) },
```

**Dòng 204:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            singleLine = true,
```

**Dòng 205:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            modifier = Modifier
```

**Dòng 206:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                .width(58.dp)
```

**Dòng 207:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                .height(52.dp)
```

**Dòng 208:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                .focusProperties {
```

**Dòng 209:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    next = FocusRequester.Cancel
```

**Dòng 210:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    previous = FocusRequester.Cancel
```

**Dòng 211:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                }
```

**Dòng 212:** Phép so sánh/điều kiện.

```kotlin
                .onPreviewKeyEvent { event ->
```

**Dòng 213:** Điều kiện if.

```kotlin
                    if (event.type == KeyEventType.KeyDown && event.key == Key.Enter) {
```

**Dòng 214:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        focusManager.clearFocus(force = true)
```

**Dòng 215:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        true
```

**Dòng 216:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    } else {
```

**Dòng 217:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        false
```

**Dòng 218:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    }
```

**Dòng 219:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                },
```

**Dòng 220:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF12385F), textAlign = androidx.compose.ui.text.style.TextAlign.Center),
```

**Dòng 221:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Done),
```

**Dòng 222:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            keyboardActions = KeyboardActions(
```

**Dòng 223:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                onDone = { finishCashAuditInput(focusManager, keyboardController) },
```

**Dòng 224:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                onNext = { finishCashAuditInput(focusManager, keyboardController) },
```

**Dòng 225:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            ),
```

**Dòng 226:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        )
```

**Dòng 227:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        IconButton(onClick = { onCountChange(count + 1) }, modifier = Modifier.size(38.dp).background(Color(0xFF1E73BE), CircleShape)) { Icon(Icons.Filled.Add, "Tăng số lượng", tint = Color.White) }
```

**Dòng 228:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        Text("${CashAuditCalculator.formatAmount(denomination * count)}đ", modifier = Modifier.weight(1.23f), color = Color(0xFF12385F), fontWeight = FontWeight.ExtraBold, fontSize = 12.sp, textAlign = androidx.compose.ui.text.style.TextAlign.End)
```

**Dòng 229:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 230:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 231:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 232:** Đánh dấu hàm UI Compose.

```kotlin
@Composable
```

**Dòng 233:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
@OptIn(ExperimentalFoundationApi::class, ExperimentalComposeUiApi::class)
```

**Dòng 234:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
private fun MoneyInputRow(
```

**Dòng 235:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    label: String,
```

**Dòng 236:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    value: TextFieldValue,
```

**Dòng 237:** Phép so sánh/điều kiện.

```kotlin
    onValueChange: (TextFieldValue) -> Unit,
```

**Dòng 238:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    focusManager: FocusManager,
```

**Dòng 239:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    keyboardController: SoftwareKeyboardController?,
```

**Dòng 240:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
) {
```

**Dòng 241:** Biến chỉ đọc.

```kotlin
    val requester = remember { BringIntoViewRequester() }
```

**Dòng 242:** Biến có thể thay đổi.

```kotlin
    var focused by remember { mutableStateOf(false) }
```

**Dòng 243:** Chạy coroutine theo key.

```kotlin
    LaunchedEffect(focused) {
```

**Dòng 244:** Điều kiện if.

```kotlin
        if (focused) {
```

**Dòng 245:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            delay(220)
```

**Dòng 246:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            requester.bringIntoView()
```

**Dòng 247:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 248:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 249:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
```

**Dòng 250:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        Text(label, modifier = Modifier.width(78.dp), color = Color(0xFF12385F), fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
```

**Dòng 251:** Ô nhập liệu.

```kotlin
        OutlinedTextField(
```

**Dòng 252:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            value = value,
```

**Dòng 253:** Phép so sánh/điều kiện.

```kotlin
            onValueChange = { incoming ->
```

**Dòng 254:** Biến chỉ đọc.

```kotlin
                val formatted = incoming.text.groupedMoneyInput()
```

**Dòng 255:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                onValueChange(
```

**Dòng 256:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    TextFieldValue(
```

**Dòng 257:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        text = formatted,
```

**Dòng 258:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        selection = TextRange(
```

**Dòng 259:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                            groupedMoneyCursorPosition(
```

**Dòng 260:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                                rawText = incoming.text,
```

**Dòng 261:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                                selectionEnd = incoming.selection.end,
```

**Dòng 262:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                                formattedText = formatted,
```

**Dòng 263:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                            ),
```

**Dòng 264:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        ),
```

**Dòng 265:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    ),
```

**Dòng 266:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                )
```

**Dòng 267:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            },
```

**Dòng 268:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            placeholder = { Text("0", fontSize = 13.sp) },
```

**Dòng 269:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            suffix = { Text("đ", fontSize = 12.sp) },
```

**Dòng 270:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            singleLine = true,
```

**Dòng 271:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            modifier = Modifier
```

**Dòng 272:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                .weight(1f)
```

**Dòng 273:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                .height(54.dp)
```

**Dòng 274:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                .bringIntoViewRequester(requester)
```

**Dòng 275:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                .onFocusChanged { focused = it.isFocused }
```

**Dòng 276:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                .focusProperties {
```

**Dòng 277:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    next = FocusRequester.Cancel
```

**Dòng 278:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    previous = FocusRequester.Cancel
```

**Dòng 279:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                }
```

**Dòng 280:** Phép so sánh/điều kiện.

```kotlin
                .onPreviewKeyEvent { event ->
```

**Dòng 281:** Điều kiện if.

```kotlin
                    if (event.type == KeyEventType.KeyDown && event.key == Key.Enter) {
```

**Dòng 282:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        focusManager.clearFocus(force = true)
```

**Dòng 283:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        true
```

**Dòng 284:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    } else {
```

**Dòng 285:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        false
```

**Dòng 286:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    }
```

**Dòng 287:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                },
```

**Dòng 288:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF12385F), textAlign = androidx.compose.ui.text.style.TextAlign.End),
```

**Dòng 289:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Done),
```

**Dòng 290:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            keyboardActions = KeyboardActions(
```

**Dòng 291:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                onDone = { finishCashAuditInput(focusManager, keyboardController) },
```

**Dòng 292:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                onNext = { finishCashAuditInput(focusManager, keyboardController) },
```

**Dòng 293:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            ),
```

**Dòng 294:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        )
```

**Dòng 295:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 296:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 297:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 298:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
private fun finishCashAuditInput(
```

**Dòng 299:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    focusManager: FocusManager,
```

**Dòng 300:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    keyboardController: SoftwareKeyboardController?,
```

**Dòng 301:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
) {
```

**Dòng 302:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    keyboardController?.hide()
```

**Dòng 303:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    focusManager.clearFocus(force = true)
```

**Dòng 304:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 305:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 306:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
private fun moneyTextFieldValue(value: String) = TextFieldValue(value, TextRange(value.length))
```

**Dòng 307:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 308:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
internal fun groupedMoneyCursorPosition(
```

**Dòng 309:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    rawText: String,
```

**Dòng 310:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    selectionEnd: Int,
```

**Dòng 311:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    formattedText: String,
```

**Dòng 312:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
): Int {
```

**Dòng 313:** Biến chỉ đọc.

```kotlin
    val digitsBeforeCaret = rawText.take(selectionEnd.coerceIn(0, rawText.length)).count(Char::isDigit)
```

**Dòng 314:** Điều kiện if.

```kotlin
    if (digitsBeforeCaret == 0) return 0
```

**Dòng 315:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 316:** Biến có thể thay đổi.

```kotlin
    var digitsVisited = 0
```

**Dòng 317:** Phép so sánh/điều kiện.

```kotlin
    formattedText.forEachIndexed { index, character ->
```

**Dòng 318:** Điều kiện if.

```kotlin
        if (character.isDigit()) {
```

**Dòng 319:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            digitsVisited += 1
```

**Dòng 320:** Điều kiện if.

```kotlin
            if (digitsVisited == digitsBeforeCaret) return index + 1
```

**Dòng 321:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 322:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 323:** Kết thúc hàm và trả kết quả.

```kotlin
    return formattedText.length
```

**Dòng 324:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 325:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 326:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
private fun String.groupedMoneyInput(): String {
```

**Dòng 327:** Biến chỉ đọc.

```kotlin
    val digits = filter(Char::isDigit).trimStart('0')
```

**Dòng 328:** Kết thúc hàm và trả kết quả.

```kotlin
    return if (digits.isBlank()) "" else CashAuditCalculator.formatAmount(digits.toLongOrNull() ?: Long.MAX_VALUE)
```

**Dòng 329:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

## `app/src/main/java/com/example/delivery/ui/CustomerComponents.kt`

**Dòng 1:** Khai báo package/namespace.

```kotlin
package com.example.delivery.ui
```

**Dòng 2:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 3:** Import dependency.

```kotlin
import android.Manifest
```

**Dòng 4:** Import dependency.

```kotlin
import android.app.Activity
```

**Dòng 5:** Import dependency.

```kotlin
import android.content.Context
```

**Dòng 6:** Import dependency.

```kotlin
import android.widget.Toast
```

**Dòng 7:** Import dependency.

```kotlin
import android.content.Intent
```

**Dòng 8:** Import dependency.

```kotlin
import android.content.pm.PackageManager
```

**Dòng 9:** Import dependency.

```kotlin
import android.graphics.BitmapFactory
```

**Dòng 10:** Import dependency.

```kotlin
import android.net.Uri
```

**Dòng 11:** Import dependency.

```kotlin
import androidx.activity.compose.BackHandler
```

**Dòng 12:** Import dependency.

```kotlin
import androidx.activity.compose.rememberLauncherForActivityResult
```

**Dòng 13:** Import dependency.

```kotlin
import androidx.activity.result.contract.ActivityResultContracts
```

**Dòng 14:** Import dependency.

```kotlin
import androidx.compose.foundation.Image
```

**Dòng 15:** Import dependency.

```kotlin
import androidx.compose.foundation.background
```

**Dòng 16:** Import dependency.

```kotlin
import androidx.compose.foundation.border
```

**Dòng 17:** Import dependency.

```kotlin
import androidx.compose.foundation.clickable
```

**Dòng 18:** Import dependency.

```kotlin
import androidx.compose.foundation.ExperimentalFoundationApi
```

**Dòng 19:** Import dependency.

```kotlin
import androidx.compose.foundation.interaction.MutableInteractionSource
```

**Dòng 20:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.Arrangement
```

**Dòng 21:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.Box
```

**Dòng 22:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.Column
```

**Dòng 23:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.Row
```

**Dòng 24:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.Spacer
```

**Dòng 25:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.fillMaxSize
```

**Dòng 26:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.fillMaxHeight
```

**Dòng 27:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.fillMaxWidth
```

**Dòng 28:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.height
```

**Dòng 29:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.heightIn
```

**Dòng 30:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.imePadding
```

**Dòng 31:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.navigationBarsPadding
```

**Dòng 32:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.offset
```

**Dòng 33:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.padding
```

**Dòng 34:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.size
```

**Dòng 35:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.width
```

**Dòng 36:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.statusBarsPadding
```

**Dòng 37:** Import dependency.

```kotlin
import androidx.compose.foundation.rememberScrollState
```

**Dòng 38:** Import dependency.

```kotlin
import androidx.compose.foundation.relocation.BringIntoViewRequester
```

**Dòng 39:** Import dependency.

```kotlin
import androidx.compose.foundation.relocation.bringIntoViewRequester
```

**Dòng 40:** Import dependency.

```kotlin
import androidx.compose.foundation.verticalScroll
```

**Dòng 41:** Import dependency.

```kotlin
import androidx.compose.foundation.lazy.LazyColumn
```

**Dòng 42:** Import dependency.

```kotlin
import androidx.compose.foundation.lazy.items
```

**Dòng 43:** Import dependency.

```kotlin
import androidx.compose.foundation.lazy.itemsIndexed
```

**Dòng 44:** Import dependency.

```kotlin
import androidx.compose.foundation.lazy.rememberLazyListState
```

**Dòng 45:** Import dependency.

```kotlin
import androidx.compose.foundation.shape.RoundedCornerShape
```

**Dòng 46:** Import dependency.

```kotlin
import androidx.compose.material.icons.Icons
```

**Dòng 47:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.ArrowUpward
```

**Dòng 48:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.Map
```

**Dòng 49:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.Add
```

**Dòng 50:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.ArrowDropDown
```

**Dòng 51:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.CameraAlt
```

**Dòng 52:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.Close
```

**Dòng 53:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.Delete
```

**Dòng 54:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.Edit
```

**Dòng 55:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.LocationOn
```

**Dòng 56:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.Navigation
```

**Dòng 57:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.Pause
```

**Dòng 58:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.People
```

**Dòng 59:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.Phone
```

**Dòng 60:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.ReceiptLong
```

**Dòng 61:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.Remove
```

**Dòng 62:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.Settings
```

**Dòng 63:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.Sms
```

**Dòng 64:** Import dependency.

```kotlin
import androidx.compose.material3.AlertDialog
```

**Dòng 65:** Import dependency.

```kotlin
import androidx.compose.material3.Button
```

**Dòng 66:** Import dependency.

```kotlin
import androidx.compose.material3.ButtonDefaults
```

**Dòng 67:** Import dependency.

```kotlin
import androidx.compose.material3.Card
```

**Dòng 68:** Import dependency.

```kotlin
import androidx.compose.material3.CardDefaults
```

**Dòng 69:** Import dependency.

```kotlin
import androidx.compose.material3.Checkbox
```

**Dòng 70:** Import dependency.

```kotlin
import androidx.compose.material3.DropdownMenu
```

**Dòng 71:** Import dependency.

```kotlin
import androidx.compose.material3.DropdownMenuItem
```

**Dòng 72:** Import dependency.

```kotlin
import androidx.compose.material3.Icon
```

**Dòng 73:** Import dependency.

```kotlin
import androidx.compose.material3.IconButton
```

**Dòng 74:** Import dependency.

```kotlin
import androidx.compose.material3.OutlinedButton
```

**Dòng 75:** Import dependency.

```kotlin
import androidx.compose.material3.OutlinedTextField
```

**Dòng 76:** Import dependency.

```kotlin
import androidx.compose.material3.Surface
```

**Dòng 77:** Import dependency.

```kotlin
import androidx.compose.material3.Text
```

**Dòng 78:** Import dependency.

```kotlin
import androidx.compose.runtime.Composable
```

**Dòng 79:** Import dependency.

```kotlin
import androidx.compose.runtime.LaunchedEffect
```

**Dòng 80:** Import dependency.

```kotlin
import androidx.compose.runtime.getValue
```

**Dòng 81:** Import dependency.

```kotlin
import androidx.compose.runtime.mutableStateOf
```

**Dòng 82:** Import dependency.

```kotlin
import androidx.compose.runtime.remember
```

**Dòng 83:** Import dependency.

```kotlin
import androidx.compose.runtime.saveable.rememberSaveable
```

**Dòng 84:** Import dependency.

```kotlin
import androidx.compose.runtime.setValue
```

**Dòng 85:** Import dependency.

```kotlin
import androidx.compose.ui.Alignment
```

**Dòng 86:** Import dependency.

```kotlin
import androidx.compose.ui.Modifier
```

**Dòng 87:** Import dependency.

```kotlin
import androidx.compose.ui.draw.clip
```

**Dòng 88:** Import dependency.

```kotlin
import androidx.compose.ui.draw.alpha
```

**Dòng 89:** Import dependency.

```kotlin
import androidx.compose.ui.focus.onFocusChanged
```

**Dòng 90:** Import dependency.

```kotlin
import androidx.compose.ui.platform.LocalFocusManager
```

**Dòng 91:** Import dependency.

```kotlin
import androidx.compose.foundation.text.KeyboardActions
```

**Dòng 92:** Import dependency.

```kotlin
import androidx.compose.foundation.text.KeyboardOptions
```

**Dòng 93:** Import dependency.

```kotlin
import androidx.compose.ui.text.input.ImeAction
```

**Dòng 94:** Import dependency.

```kotlin
import androidx.compose.ui.graphics.Color
```

**Dòng 95:** Import dependency.

```kotlin
import androidx.compose.ui.graphics.asImageBitmap
```

**Dòng 96:** Import dependency.

```kotlin
import androidx.compose.ui.layout.ContentScale
```

**Dòng 97:** Import dependency.

```kotlin
import androidx.compose.ui.platform.LocalContext
```

**Dòng 98:** Import dependency.

```kotlin
import androidx.compose.ui.text.font.FontWeight
```

**Dòng 99:** Import dependency.

```kotlin
import androidx.compose.ui.unit.dp
```

**Dòng 100:** Import dependency.

```kotlin
import androidx.compose.ui.unit.sp
```

**Dòng 101:** Import dependency.

```kotlin
import androidx.compose.ui.window.Dialog
```

**Dòng 102:** Import dependency.

```kotlin
import androidx.compose.ui.window.DialogProperties
```

**Dòng 103:** Import dependency.

```kotlin
import androidx.core.content.ContextCompat
```

**Dòng 104:** Import dependency.

```kotlin
import com.example.delivery.history.DeliveryPhotoHistory
```

**Dòng 105:** Import dependency.

```kotlin
import com.example.delivery.history.PaymentChannel
```

**Dòng 106:** Import dependency.

```kotlin
import com.example.delivery.history.ProofPhotoType
```

**Dòng 107:** Import dependency.

```kotlin
import com.example.delivery.history.TransferEvidence
```

**Dòng 108:** Import dependency.

```kotlin
import com.example.delivery.orderio.CoordinateUpdateRequest
```

**Dòng 109:** Import dependency.

```kotlin
import com.example.delivery.orderio.CoordinateTextParser
```

**Dòng 110:** Import dependency.

```kotlin
import com.example.delivery.location.RealtimeLocationPolicy
```

**Dòng 111:** Import dependency.

```kotlin
import com.example.delivery.customer.CustomerAddress
```

**Dòng 112:** Import dependency.

```kotlin
import com.example.delivery.customer.CustomerContactMethod
```

**Dòng 113:** Import dependency.

```kotlin
import com.example.delivery.customer.CustomerPhone
```

**Dòng 114:** Import dependency.

```kotlin
import com.example.delivery.customer.CustomerProfile
```

**Dòng 115:** Import dependency.

```kotlin
import com.example.delivery.customer.CustomerProfileStore
```

**Dòng 116:** Import dependency.

```kotlin
import com.example.delivery.customer.matchesSearch
```

**Dòng 117:** Import dependency.

```kotlin
import com.example.delivery.model.DeliveryOrder
```

**Dòng 118:** Import dependency.

```kotlin
import com.example.delivery.model.DeliveryOutcome
```

**Dòng 119:** Import dependency.

```kotlin
import com.example.delivery.model.DeliveryStatus
```

**Dòng 120:** Import dependency.

```kotlin
import com.example.delivery.model.hasStoredCoordinates
```

**Dòng 121:** Import dependency.

```kotlin
import com.example.delivery.model.canReceiveRouteSequence
```

**Dòng 122:** Import dependency.

```kotlin
import com.example.delivery.model.dispatchDisplayOrder
```

**Dòng 123:** Import dependency.

```kotlin
import com.example.delivery.model.formatVnd
```

**Dòng 124:** Import dependency.

```kotlin
import com.example.delivery.model.isMapVisible
```

**Dòng 125:** Import dependency.

```kotlin
import com.example.delivery.model.isPickupAtWarehouse
```

**Dòng 126:** Import dependency.

```kotlin
import com.example.delivery.model.isRouteActive
```

**Dòng 127:** Import dependency.

```kotlin
import com.example.delivery.model.statusLabel
```

**Dòng 128:** Import dependency.

```kotlin
import com.example.delivery.model.withStableRouteLabels
```

**Dòng 129:** Import dependency.

```kotlin
import com.example.delivery.model.resequenceDraftLabels
```

**Dòng 130:** Import dependency.

```kotlin
import com.example.delivery.model.sequenceText
```

**Dòng 131:** Import dependency.

```kotlin
import com.example.delivery.model.sequenceSortValue
```

**Dòng 132:** Import dependency.

```kotlin
import com.example.delivery.model.csvStatus
```

**Dòng 133:** Import dependency.

```kotlin
import com.example.delivery.navigation.DeliveryRouteStore
```

**Dòng 134:** Import dependency.

```kotlin
import com.example.delivery.navigation.DeliveryZone
```

**Dòng 135:** Import dependency.

```kotlin
import com.example.delivery.navigation.GeoPoint
```

**Dòng 136:** Import dependency.

```kotlin
import com.example.delivery.navigation.persistedRouteLabels
```

**Dòng 137:** Import dependency.

```kotlin
import com.example.delivery.navigation.preferredRouteOrigin
```

**Dòng 138:** Import dependency.

```kotlin
import com.example.delivery.navigation.routeOrdersFrom
```

**Dòng 139:** Import dependency.

```kotlin
import kotlinx.coroutines.delay
```

**Dòng 140:** Import dependency.

```kotlin
import java.util.Locale
```

**Dòng 141:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 142:** Chú thích, không thực thi.

```kotlin
// UI GROUP: CUSTOMER
```

**Dòng 143:** Chú thích, không thực thi.

```kotlin
// Chứa riêng UI danh sách, chi tiết và chỉnh sửa khách hàng.
```

**Dòng 144:** Đánh dấu hàm UI Compose.

```kotlin
@Composable
```

**Dòng 145:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
internal fun CustomerList(
```

**Dòng 146:** Phép so sánh/điều kiện.

```kotlin
    profiles: List<CustomerProfile>,
```

**Dòng 147:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    focusPhone: String?,
```

**Dòng 148:** Phép so sánh/điều kiện.

```kotlin
    onSaveCustomer: (CustomerProfile) -> Unit,
```

**Dòng 149:** Phép so sánh/điều kiện.

```kotlin
    onDeleteCustomer: (CustomerProfile) -> Unit,
```

**Dòng 150:** Phép so sánh/điều kiện.

```kotlin
    onGetCustomerCoordinates: () -> Pair<Double, Double>?,
```

**Dòng 151:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
) {
```

**Dòng 152:** Biến có thể thay đổi.

```kotlin
    var searchQuery by rememberSaveable { mutableStateOf("") }
```

**Dòng 153:** Biến có thể thay đổi.

```kotlin
    var editor by remember { mutableStateOf<CustomerProfile?>(null) }
```

**Dòng 154:** Biến có thể thay đổi.

```kotlin
    var deleteConfirmation by remember { mutableStateOf<CustomerProfile?>(null) }
```

**Dòng 155:** Biến có thể thay đổi.

```kotlin
    var detailProfile by remember { mutableStateOf<CustomerProfile?>(null) }
```

**Dòng 156:** Biến chỉ đọc.

```kotlin
    val context = LocalContext.current
```

**Dòng 157:** Biến chỉ đọc.

```kotlin
    val listState = rememberLazyListState()
```

**Dòng 158:** Biến chỉ đọc.

```kotlin
    val filteredProfiles = profiles.filter { it.matchesSearch(searchQuery) }
```

**Dòng 159:** Chạy coroutine theo key.

```kotlin
    LaunchedEffect(focusPhone, profiles) {
```

**Dòng 160:** Điều kiện if.

```kotlin
        if (!focusPhone.isNullOrBlank()) {
```

**Dòng 161:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            searchQuery = ""
```

**Dòng 162:** Biến chỉ đọc.

```kotlin
            val index = profiles.indexOfFirst { profile -> profile.phones.any { it.number == focusPhone } }
```

**Dòng 163:** Điều kiện if.

```kotlin
            if (index >= 0) listState.scrollToItem(index)
```

**Dòng 164:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 165:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 166:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
    Box(Modifier.fillMaxSize().background(AppBackground)) {
```

**Dòng 167:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        Column(Modifier.fillMaxSize()) {
```

**Dòng 168:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
```

**Dòng 169:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
                Column(Modifier.weight(1f)) {
```

**Dòng 170:** Hiển thị văn bản.

```kotlin
                    Text("KHÁCH HÀNG", color = Color(0xFF12385F), fontWeight = FontWeight.ExtraBold, fontSize = 19.sp)
```

**Dòng 171:** Hiển thị văn bản.

```kotlin
                    Text("${filteredProfiles.size}/${profiles.size} khách trong danh sách", color = Color(0xFF6F7A84), fontSize = 12.sp)
```

**Dòng 172:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                }
```

**Dòng 173:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 174:** Ô nhập liệu.

```kotlin
            OutlinedTextField(
```

**Dòng 175:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                value = searchQuery,
```

**Dòng 176:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                onValueChange = { searchQuery = it },
```

**Dòng 177:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                label = { Text("Tìm tên, SĐT, địa chỉ", fontSize = 12.sp) },
```

**Dòng 178:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                singleLine = true,
```

**Dòng 179:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                trailingIcon = {
```

**Dòng 180:** Điều kiện if.

```kotlin
                    if (searchQuery.isNotBlank()) IconButton(onClick = { searchQuery = "" }) { Icon(Icons.Filled.Close, "Xóa tìm kiếm") }
```

**Dòng 181:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                },
```

**Dòng 182:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 3.dp).heightIn(min = 54.dp),
```

**Dòng 183:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            )
```

**Dòng 184:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            LazyColumn(Modifier.weight(1f), state = listState, verticalArrangement = Arrangement.spacedBy(7.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 8.dp)) {
```

**Dòng 185:** Điều kiện if.

```kotlin
                if (filteredProfiles.isEmpty()) {
```

**Dòng 186:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
                    item { Text("Không tìm thấy khách hàng phù hợp.", color = Color(0xFF68727C), fontSize = 13.sp, modifier = Modifier.fillMaxWidth().padding(top = 24.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center) }
```

**Dòng 187:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                } else {
```

**Dòng 188:** Phép so sánh/điều kiện.

```kotlin
                    itemsIndexed(filteredProfiles, key = { index, profile -> customerListItemKey(profile, index) }) { _, profile ->
```

**Dòng 189:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        CustomerPrimaryNameRow(
```

**Dòng 190:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                            name = profile.displayName,
```

**Dòng 191:** Phép so sánh/điều kiện.

```kotlin
                            highlighted = profile.phones.any { it.number == focusPhone },
```

**Dòng 192:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                            onOpen = { detailProfile = profile },
```

**Dòng 193:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        )
```

**Dòng 194:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    }
```

**Dòng 195:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                }
```

**Dòng 196:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 197:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 198:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        IconButton(onClick = { editor = CustomerProfile.empty() }, modifier = Modifier.align(Alignment.BottomStart).padding(start = 22.dp, bottom = 18.dp).size(62.dp).background(Color(0xFF1E73BE), RoundedCornerShape(50))) {
```

**Dòng 199:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            Icon(Icons.Filled.Add, "Thêm khách hàng", tint = Color.White, modifier = Modifier.size(31.dp))
```

**Dòng 200:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 201:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 202:** Safe-call: chỉ chạy khi khác null.

```kotlin
    detailProfile?.let { profile ->
```

**Dòng 203:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        CustomerDetailDialog(
```

**Dòng 204:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            profile = profile,
```

**Dòng 205:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            onDismiss = { detailProfile = null },
```

**Dòng 206:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            onEdit = { editor = profile },
```

**Dòng 207:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            onDelete = { deleteConfirmation = profile },
```

**Dòng 208:** Phép so sánh/điều kiện.

```kotlin
            onOpenMap = { address -> openCustomerAddressInMap(context, address) },
```

**Dòng 209:** Phép so sánh/điều kiện.

```kotlin
            onNavigate = { address -> navigateToCustomerAddress(context, address) },
```

**Dòng 210:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            onCall = { openCustomerChannel(context, profile, CustomerContactMethod.CALL) },
```

**Dòng 211:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            onOpenZalo = { openCustomerChannel(context, profile, CustomerContactMethod.ZALO) },
```

**Dòng 212:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            onOpenSms = { openCustomerChannel(context, profile, CustomerContactMethod.SMS) },
```

**Dòng 213:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        )
```

**Dòng 214:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 215:** Safe-call: chỉ chạy khi khác null.

```kotlin
    editor?.let { profile -> CustomerEditorDialog(profile, onDismiss = { editor = null }, onSave = { saved -> onSaveCustomer(saved); detailProfile = saved; editor = null }, onGetCustomerCoordinates = onGetCustomerCoordinates) }
```

**Dòng 216:** Safe-call: chỉ chạy khi khác null.

```kotlin
    deleteConfirmation?.let { profile ->
```

**Dòng 217:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        AlertDialog(
```

**Dòng 218:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            onDismissRequest = { deleteConfirmation = null },
```

**Dòng 219:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            title = { Text("Xóa khách hàng?") },
```

**Dòng 220:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            text = { Text("Bạn có chắc chắn muốn xóa hồ sơ ${profile.displayName}? Thông tin khách hàng sẽ không còn xuất hiện trong danh sách.") },
```

**Dòng 221:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            confirmButton = {
```

**Dòng 222:** Nút tương tác; onClick xử lý nhấn.

```kotlin
                Button(onClick = { onDeleteCustomer(profile); detailProfile = null; deleteConfirmation = null }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC23D35))) { Text("Xóa") }
```

**Dòng 223:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            },
```

**Dòng 224:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            dismissButton = { OutlinedButton(onClick = { deleteConfirmation = null }) { Text("Hủy") } },
```

**Dòng 225:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        )
```

**Dòng 226:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 227:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 228:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 229:** Chú thích, không thực thi.

```kotlin
/**
```

**Dòng 230:** Chú thích, không thực thi.

```kotlin
 * Hồ sơ cũ có thể mang id trùng do từng được sinh từ SĐT. Ghép index vào key
```

**Dòng 231:** Chú thích, không thực thi.

```kotlin
 * chỉ để bảo vệ LazyColumn; dữ liệu chính đã được gộp theo SĐT ở model.
```

**Dòng 232:** Chú thích, không thực thi.

```kotlin
 */
```

**Dòng 233:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
internal fun customerListItemKey(profile: CustomerProfile, index: Int): String = "customer|${profile.id}|$index"
```

**Dòng 234:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 235:** Đánh dấu hàm UI Compose.

```kotlin
@Composable
```

**Dòng 236:** Phép so sánh/điều kiện.

```kotlin
private fun CustomerPrimaryNameRow(name: String, highlighted: Boolean, onOpen: () -> Unit) {
```

**Dòng 237:** Container ngang.

```kotlin
    Row(
```

**Dòng 238:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        modifier = Modifier
```

**Dòng 239:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            .fillMaxWidth()
```

**Dòng 240:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            .background(if (highlighted) Color(0xFFFBEDE3) else AppSurface, RoundedCornerShape(14.dp))
```

**Dòng 241:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            .border(1.dp, if (highlighted) Color(0xFFE5B37A) else Color(0xFFE0E6EA), RoundedCornerShape(14.dp))
```

**Dòng 242:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            .clickable(onClick = onOpen)
```

**Dòng 243:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            .padding(horizontal = 14.dp, vertical = 15.dp),
```

**Dòng 244:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        verticalAlignment = Alignment.CenterVertically,
```

**Dòng 245:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    ) {
```

**Dòng 246:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        Icon(Icons.Filled.People, null, tint = Color(0xFF12385F), modifier = Modifier.size(24.dp))
```

**Dòng 247:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        Text(name, color = Color(0xFF182B3D), fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, modifier = Modifier.weight(1f).padding(start = 10.dp))
```

**Dòng 248:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        Icon(Icons.Filled.Navigation, "Mở chi tiết khách hàng", tint = Color(0xFF698092), modifier = Modifier.size(20.dp))
```

**Dòng 249:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 250:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 251:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 252:** Đánh dấu hàm UI Compose.

```kotlin
@Composable
```

**Dòng 253:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
private fun CustomerDetailDialog(
```

**Dòng 254:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    profile: CustomerProfile,
```

**Dòng 255:** Phép so sánh/điều kiện.

```kotlin
    onDismiss: () -> Unit,
```

**Dòng 256:** Phép so sánh/điều kiện.

```kotlin
    onEdit: () -> Unit,
```

**Dòng 257:** Phép so sánh/điều kiện.

```kotlin
    onDelete: () -> Unit,
```

**Dòng 258:** Phép so sánh/điều kiện.

```kotlin
    onOpenMap: (CustomerAddress) -> Unit,
```

**Dòng 259:** Phép so sánh/điều kiện.

```kotlin
    onNavigate: (CustomerAddress) -> Unit,
```

**Dòng 260:** Phép so sánh/điều kiện.

```kotlin
    onCall: () -> Unit,
```

**Dòng 261:** Phép so sánh/điều kiện.

```kotlin
    onOpenZalo: () -> Unit,
```

**Dòng 262:** Phép so sánh/điều kiện.

```kotlin
    onOpenSms: () -> Unit,
```

**Dòng 263:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
) {
```

**Dòng 264:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
```

**Dòng 265:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        Surface(
```

**Dòng 266:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            modifier = Modifier.fillMaxSize().navigationBarsPadding().padding(6.dp),
```

**Dòng 267:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            shape = RoundedCornerShape(18.dp),
```

**Dòng 268:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            color = AppBackground,
```

**Dòng 269:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        ) {
```

**Dòng 270:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            Column(Modifier.fillMaxSize()) {
```

**Dòng 271:** Container ngang.

```kotlin
                Row(
```

**Dòng 272:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
                    modifier = Modifier.fillMaxWidth().background(AppSurface).padding(horizontal = 10.dp, vertical = 7.dp),
```

**Dòng 273:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    verticalAlignment = Alignment.CenterVertically,
```

**Dòng 274:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                ) {
```

**Dòng 275:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
                    Text("CHI TIẾT KHÁCH HÀNG", color = Color(0xFF12385F), fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, modifier = Modifier.weight(1f))
```

**Dòng 276:** Nút tương tác; onClick xử lý nhấn.

```kotlin
                    IconButton(onClick = onEdit) { Icon(Icons.Filled.Edit, "Sửa khách hàng", tint = Color(0xFF1E73BE)) }
```

**Dòng 277:** Nút tương tác; onClick xử lý nhấn.

```kotlin
                    IconButton(onClick = onDelete) { Icon(Icons.Filled.Delete, "Xóa khách hàng", tint = Color(0xFFC23D35)) }
```

**Dòng 278:** Nút tương tác; onClick xử lý nhấn.

```kotlin
                    IconButton(onClick = onDismiss) { Icon(Icons.Filled.Close, "Đóng chi tiết", tint = Color(0xFF40515E)) }
```

**Dòng 279:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                }
```

**Dòng 280:** Danh sách lazy.

```kotlin
                LazyColumn(
```

**Dòng 281:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
                    modifier = Modifier.weight(1f),
```

**Dòng 282:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp),
```

**Dòng 283:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                ) {
```

**Dòng 284:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    item {
```

**Dòng 285:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        CustomerHousePhotosAtTop(profile)
```

**Dòng 286:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    }
```

**Dòng 287:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    item {
```

**Dòng 288:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        CustomerProfileBlock(
```

**Dòng 289:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                            profile = profile,
```

**Dòng 290:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                            onOpenMap = onOpenMap,
```

**Dòng 291:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                            onNavigate = onNavigate,
```

**Dòng 292:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                            onCall = onCall,
```

**Dòng 293:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                            onOpenZalo = onOpenZalo,
```

**Dòng 294:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                            onOpenSms = onOpenSms,
```

**Dòng 295:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        )
```

**Dòng 296:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    }
```

**Dòng 297:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                }
```

**Dòng 298:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 299:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 300:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 301:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 302:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 303:** Đánh dấu hàm UI Compose.

```kotlin
@Composable
```

**Dòng 304:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
private fun CustomerProfileBlock(
```

**Dòng 305:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    profile: CustomerProfile,
```

**Dòng 306:** Phép so sánh/điều kiện.

```kotlin
    onOpenMap: (CustomerAddress) -> Unit,
```

**Dòng 307:** Phép so sánh/điều kiện.

```kotlin
    onNavigate: (CustomerAddress) -> Unit,
```

**Dòng 308:** Phép so sánh/điều kiện.

```kotlin
    onCall: () -> Unit,
```

**Dòng 309:** Phép so sánh/điều kiện.

```kotlin
    onOpenZalo: () -> Unit,
```

**Dòng 310:** Phép so sánh/điều kiện.

```kotlin
    onOpenSms: () -> Unit,
```

**Dòng 311:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
) {
```

**Dòng 312:** Biến chỉ đọc.

```kotlin
    val names = profile.names.ifEmpty { listOf(profile.displayName) }.filter(String::isNotBlank)
```

**Dòng 313:** Biến chỉ đọc.

```kotlin
    val phones = profile.phones.filter { it.number.isNotBlank() }
```

**Dòng 314:** Biến chỉ đọc.

```kotlin
    val addresses = profile.addresses.filter { it.address.isNotBlank() }
```

**Dòng 315:** Container dọc.

```kotlin
    Column(
```

**Dòng 316:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        Modifier
```

**Dòng 317:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            .fillMaxWidth()
```

**Dòng 318:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            .background(AppSurface, RoundedCornerShape(20.dp))
```

**Dòng 319:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            .border(1.dp, Color(0xFFE0E6EA), RoundedCornerShape(20.dp))
```

**Dòng 320:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            .padding(12.dp),
```

**Dòng 321:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        verticalArrangement = Arrangement.spacedBy(6.dp),
```

**Dòng 322:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    ) {
```

**Dòng 323:** Phép so sánh/điều kiện.

```kotlin
        names.forEachIndexed { index, name ->
```

**Dòng 324:** Hiển thị văn bản.

```kotlin
            Text(
```

**Dòng 325:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                text = name,
```

**Dòng 326:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                color = Color(0xFF182B3D),
```

**Dòng 327:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                fontWeight = FontWeight.ExtraBold,
```

**Dòng 328:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                fontSize = 15.sp,
```

**Dòng 329:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
                modifier = Modifier.padding(start = 33.dp),
```

**Dòng 330:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            )
```

**Dòng 331:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 332:** Phép so sánh/điều kiện.

```kotlin
        phones.forEachIndexed { index, phone ->
```

**Dòng 333:** Container ngang.

```kotlin
            Row(verticalAlignment = Alignment.CenterVertically) {
```

**Dòng 334:** Điều kiện if.

```kotlin
                if (index == 0) Icon(Icons.Filled.Phone, "Số điện thoại", tint = Color(0xFF12385F), modifier = Modifier.size(24.dp)) else Spacer(Modifier.width(24.dp))
```

**Dòng 335:** Hiển thị văn bản.

```kotlin
                Text(
```

**Dòng 336:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    text = phone.number,
```

**Dòng 337:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    color = Color(0xFF182B3D),
```

**Dòng 338:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    fontWeight = FontWeight.Bold,
```

**Dòng 339:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    fontSize = 14.sp,
```

**Dòng 340:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
                    modifier = Modifier.padding(start = 8.dp),
```

**Dòng 341:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                )
```

**Dòng 342:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 343:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 344:** Phép so sánh/điều kiện.

```kotlin
        addresses.forEachIndexed { index, address ->
```

**Dòng 345:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            CustomerAddressDisplayRow(
```

**Dòng 346:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                address = address,
```

**Dòng 347:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                index = index,
```

**Dòng 348:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                total = addresses.size,
```

**Dòng 349:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                onOpenMap = { onOpenMap(address) },
```

**Dòng 350:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                onNavigate = { onNavigate(address) },
```

**Dòng 351:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            )
```

**Dòng 352:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 353:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        Row(Modifier.fillMaxWidth().padding(top = 2.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
```

**Dòng 354:** Nút tương tác; onClick xử lý nhấn.

```kotlin
            OutlinedButton(
```

**Dòng 355:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                onClick = onCall,
```

**Dòng 356:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
                modifier = Modifier.weight(1f).height(42.dp),
```

**Dòng 357:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                enabled = phones.any { CustomerContactMethod.CALL in it.methods },
```

**Dòng 358:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF12385F)),
```

**Dòng 359:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            ) { Icon(Icons.Filled.Phone, null, modifier = Modifier.size(18.dp)); Text(" Gọi", fontSize = 14.sp, fontWeight = FontWeight.ExtraBold) }
```

**Dòng 360:** Nút tương tác; onClick xử lý nhấn.

```kotlin
            OutlinedButton(
```

**Dòng 361:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                onClick = onOpenZalo,
```

**Dòng 362:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
                modifier = Modifier.weight(1f).height(42.dp),
```

**Dòng 363:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                enabled = phones.any { CustomerContactMethod.ZALO in it.methods },
```

**Dòng 364:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF1474B5)),
```

**Dòng 365:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            ) { Text("Zalo", fontSize = 14.sp, fontWeight = FontWeight.ExtraBold) }
```

**Dòng 366:** Nút tương tác; onClick xử lý nhấn.

```kotlin
            OutlinedButton(
```

**Dòng 367:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                onClick = onOpenSms,
```

**Dòng 368:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
                modifier = Modifier.weight(1f).height(42.dp),
```

**Dòng 369:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                enabled = phones.any { CustomerContactMethod.SMS in it.methods },
```

**Dòng 370:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF12385F)),
```

**Dòng 371:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            ) { Icon(Icons.Filled.Sms, null, modifier = Modifier.size(18.dp)); Text(" SMS", fontSize = 14.sp, fontWeight = FontWeight.ExtraBold) }
```

**Dòng 372:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 373:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 374:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 375:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 376:** Đánh dấu hàm UI Compose.

```kotlin
@Composable
```

**Dòng 377:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
private fun CustomerAddressDisplayRow(
```

**Dòng 378:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    address: CustomerAddress,
```

**Dòng 379:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    index: Int,
```

**Dòng 380:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    total: Int,
```

**Dòng 381:** Phép so sánh/điều kiện.

```kotlin
    onOpenMap: () -> Unit,
```

**Dòng 382:** Phép so sánh/điều kiện.

```kotlin
    onNavigate: () -> Unit,
```

**Dòng 383:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
) {
```

**Dòng 384:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
    Column(Modifier.fillMaxWidth().padding(top = 3.dp)) {
```

**Dòng 385:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
```

**Dòng 386:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            Icon(Icons.Filled.LocationOn, "Địa chỉ", tint = Color(0xFF12385F), modifier = Modifier.size(24.dp))
```

**Dòng 387:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            Column(Modifier.weight(1f).padding(start = 8.dp)) {
```

**Dòng 388:** Hiển thị văn bản.

```kotlin
                Text(
```

**Dòng 389:** Phép so sánh/điều kiện.

```kotlin
                    text = if (total == 1) address.address else "${address.address} (địa chỉ ${index + 1})",
```

**Dòng 390:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    color = Color(0xFF182B3D),
```

**Dòng 391:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    fontWeight = FontWeight.ExtraBold,
```

**Dòng 392:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    fontSize = 14.sp,
```

**Dòng 393:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                )
```

**Dòng 394:** Biến chỉ đọc.

```kotlin
                val coordinate = if (address.latitude != null && address.longitude != null) {
```

**Dòng 395:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    String.format(java.util.Locale.US, "Tọa độ: %.4f, %.4f", address.latitude, address.longitude)
```

**Dòng 396:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                } else {
```

**Dòng 397:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    "Chưa có tọa độ"
```

**Dòng 398:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                }
```

**Dòng 399:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
                Text(coordinate, color = Color(0xFF66737E), fontSize = 10.sp, modifier = Modifier.padding(top = 1.dp))
```

**Dòng 400:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 401:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 402:** Container ngang.

```kotlin
        Row(
```

**Dòng 403:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            Modifier.fillMaxWidth().padding(start = 32.dp, top = 4.dp),
```

**Dòng 404:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            horizontalArrangement = Arrangement.spacedBy(6.dp),
```

**Dòng 405:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        ) {
```

**Dòng 406:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            OutlinedButton(onClick = onOpenMap, enabled = address.latitude != null && address.longitude != null, modifier = Modifier.height(36.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 9.dp)) { Icon(Icons.Filled.LocationOn, "Xem vị trí", modifier = Modifier.size(18.dp)); Text(" Vị trí", fontSize = 11.sp) }
```

**Dòng 407:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            OutlinedButton(onClick = onNavigate, enabled = address.latitude != null && address.longitude != null, modifier = Modifier.height(36.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 9.dp)) { Icon(Icons.Filled.Navigation, "Chỉ đường", modifier = Modifier.size(18.dp)); Text(" Chỉ đường", fontSize = 11.sp) }
```

**Dòng 408:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 409:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 410:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 411:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 412:** Đánh dấu hàm UI Compose.

```kotlin
@Composable
```

**Dòng 413:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
private fun CustomerHousePhotosAtTop(profile: CustomerProfile) {
```

**Dòng 414:** Biến chỉ đọc.

```kotlin
    val photos = profile.addresses.mapNotNull { address -> address.housePhotoPath?.takeIf(String::isNotBlank)?.let { path -> address to path } }
```

**Dòng 415:** Điều kiện if.

```kotlin
    if (photos.isNotEmpty()) {
```

**Dòng 416:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        Column(Modifier.fillMaxWidth().padding(bottom = 10.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
```

**Dòng 417:** Phép so sánh/điều kiện.

```kotlin
            photos.forEachIndexed { index, (address, path) ->
```

**Dòng 418:** Biến chỉ đọc.

```kotlin
                val bitmap = remember(path) { BitmapFactory.decodeFile(path) }
```

**Dòng 419:** Điều kiện if.

```kotlin
                if (bitmap != null) {
```

**Dòng 420:** Điều kiện if.

```kotlin
                    if (photos.size > 1) Text("Ảnh nhà • Địa chỉ ${index + 1}", color = Color(0xFF40515E), fontWeight = FontWeight.Bold, fontSize = 12.sp)
```

**Dòng 421:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    Image(
```

**Dòng 422:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        bitmap = bitmap.asImageBitmap(),
```

**Dòng 423:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        contentDescription = "Ảnh nhà khách ${address.address}",
```

**Dòng 424:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        contentScale = ContentScale.Fit,
```

**Dòng 425:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)),
```

**Dòng 426:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    )
```

**Dòng 427:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                }
```

**Dòng 428:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 429:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 430:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 431:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 432:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 433:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
private fun openCustomerAddressInMap(context: Context, address: CustomerAddress) {
```

**Dòng 434:** Biến chỉ đọc.

```kotlin
    val latitude = address.latitude ?: return
```

**Dòng 435:** Biến chỉ đọc.

```kotlin
    val longitude = address.longitude ?: return
```

**Dòng 436:** Biến chỉ đọc.

```kotlin
    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("geo:$latitude,$longitude?q=$latitude,$longitude(${Uri.encode(address.address)})"))
```

**Dòng 437:** Điều kiện if.

```kotlin
    if (intent.resolveActivity(context.packageManager) != null) context.startActivity(intent)
```

**Dòng 438:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 439:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 440:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
private fun navigateToCustomerAddress(context: Context, address: CustomerAddress) {
```

**Dòng 441:** Biến chỉ đọc.

```kotlin
    val latitude = address.latitude ?: return
```

**Dòng 442:** Biến chỉ đọc.

```kotlin
    val longitude = address.longitude ?: return
```

**Dòng 443:** Biến chỉ đọc.

```kotlin
    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/dir/?api=1&destination=$latitude,$longitude"))
```

**Dòng 444:** Điều kiện if.

```kotlin
    if (intent.resolveActivity(context.packageManager) != null) context.startActivity(intent)
```

**Dòng 445:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 446:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 447:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
private fun openCustomerChannel(context: Context, profile: CustomerProfile, method: CustomerContactMethod) {
```

**Dòng 448:** Biến chỉ đọc.

```kotlin
    val phone = profile.phones.firstOrNull { method in it.methods }?.number
```

**Dòng 449:** Điều kiện if.

```kotlin
    if (phone.isNullOrBlank()) {
```

**Dòng 450:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        Toast.makeText(context, "Số điện thoại không chọn dùng ${method.label}", Toast.LENGTH_SHORT).show()
```

**Dòng 451:** Kết thúc hàm và trả kết quả.

```kotlin
        return
```

**Dòng 452:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 453:** Rẽ nhánh nhiều trường hợp.

```kotlin
    when (method) {
```

**Dòng 454:** Phép so sánh/điều kiện.

```kotlin
        CustomerContactMethod.CALL -> openCustomerCall(context, phone)
```

**Dòng 455:** Phép so sánh/điều kiện.

```kotlin
        CustomerContactMethod.ZALO -> openCustomerZalo(context, phone)
```

**Dòng 456:** Phép so sánh/điều kiện.

```kotlin
        CustomerContactMethod.SMS -> openCustomerSms(context, phone)
```

**Dòng 457:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 458:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 459:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 460:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
private fun openCustomerCall(context: Context, phone: String) {
```

**Dòng 461:** Biến chỉ đọc.

```kotlin
    val cleanPhone = phone.filter(Char::isDigit)
```

**Dòng 462:** Điều kiện if.

```kotlin
    if (cleanPhone.isBlank()) return
```

**Dòng 463:** Biến chỉ đọc.

```kotlin
    val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$cleanPhone"))
```

**Dòng 464:** Điều kiện if.

```kotlin
    if (intent.resolveActivity(context.packageManager) != null) context.startActivity(intent)
```

**Dòng 465:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 466:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 467:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
private fun openCustomerZalo(context: Context, phone: String) {
```

**Dòng 468:** Biến chỉ đọc.

```kotlin
    val cleanPhone = phone.filter(Char::isDigit)
```

**Dòng 469:** Điều kiện if.

```kotlin
    if (cleanPhone.isBlank()) return
```

**Dòng 470:** Biến chỉ đọc.

```kotlin
    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://zalo.me/$cleanPhone"))
```

**Dòng 471:** Điều kiện if.

```kotlin
    if (intent.resolveActivity(context.packageManager) != null) context.startActivity(intent)
```

**Dòng 472:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 473:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 474:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
private fun openCustomerSms(context: Context, phone: String) {
```

**Dòng 475:** Biến chỉ đọc.

```kotlin
    val cleanPhone = phone.filter(Char::isDigit)
```

**Dòng 476:** Điều kiện if.

```kotlin
    if (cleanPhone.isBlank()) return
```

**Dòng 477:** Biến chỉ đọc.

```kotlin
    val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$cleanPhone"))
```

**Dòng 478:** Điều kiện if.

```kotlin
    if (intent.resolveActivity(context.packageManager) != null) context.startActivity(intent)
```

**Dòng 479:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 480:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 481:** Đánh dấu hàm UI Compose.

```kotlin
@Composable
```

**Dòng 482:** Phép so sánh/điều kiện.

```kotlin
private fun CustomerEditorDialog(profile: CustomerProfile, onDismiss: () -> Unit, onSave: (CustomerProfile) -> Unit, onGetCustomerCoordinates: () -> Pair<Double, Double>?) {
```

**Dòng 483:** Biến chỉ đọc.

```kotlin
    val context = LocalContext.current
```

**Dòng 484:** Biến có thể thay đổi.

```kotlin
    var names by remember(profile.id) { mutableStateOf(profile.names.ifEmpty { listOf(profile.name) }.ifEmpty { listOf("") }) }
```

**Dòng 485:** Biến có thể thay đổi.

```kotlin
    var note by remember(profile.id) { mutableStateOf(profile.note) }
```

**Dòng 486:** Biến có thể thay đổi.

```kotlin
    var phones by remember(profile.id) { mutableStateOf(profile.phones.ifEmpty { listOf(CustomerPhone("", isPrimary = true)) }) }
```

**Dòng 487:** Biến có thể thay đổi.

```kotlin
    var addresses by remember(profile.id) { mutableStateOf(profile.addresses.ifEmpty { listOf(CustomerAddress("", isPrimary = true)) }) }
```

**Dòng 488:** Biến có thể thay đổi.

```kotlin
    var gateCaptureTarget by remember(profile.id) { mutableStateOf<Pair<Int, java.io.File>?>(null) }
```

**Dòng 489:** Biến có thể thay đổi.

```kotlin
    var coordinatePickerTarget by remember(profile.id) { mutableStateOf<Int?>(null) }
```

**Dòng 490:** Biến chỉ đọc.

```kotlin
    val gateCamera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { saved ->
```

**Dòng 491:** Biến chỉ đọc.

```kotlin
        val target = gateCaptureTarget ?: return@rememberLauncherForActivityResult
```

**Dòng 492:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        gateCaptureTarget = null
```

**Dòng 493:** Điều kiện if.

```kotlin
        if (!saved) {
```

**Dòng 494:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            target.second.delete()
```

**Dòng 495:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        } else {
```

**Dòng 496:** Biến đổi collection.

```kotlin
            addresses = addresses.mapIndexed { index, value -> if (index == target.first) value.copy(housePhotoPath = target.second.path) else value }
```

**Dòng 497:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 498:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 499:** Biến chỉ đọc.

```kotlin
    val dialogShape = RoundedCornerShape(18.dp)
```

**Dòng 500:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
```

**Dòng 501:** Container xếp/chồng UI.

```kotlin
        Box(
```

**Dòng 502:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            Modifier
```

**Dòng 503:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                .fillMaxSize()
```

**Dòng 504:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                .navigationBarsPadding()
```

**Dòng 505:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                .imePadding()
```

**Dòng 506:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                .padding(start = 6.dp, top = 8.dp, end = 6.dp, bottom = 12.dp),
```

**Dòng 507:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        ) {
```

**Dòng 508:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            Surface(modifier = Modifier.fillMaxSize().clip(dialogShape), shape = dialogShape, color = AppBackground) {
```

**Dòng 509:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
                Column(modifier = Modifier.fillMaxSize()) {
```

**Dòng 510:** Container ngang.

```kotlin
                Row(
```

**Dòng 511:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
                    modifier = Modifier.fillMaxWidth().background(Color(0xFFEAF5F2)).padding(horizontal = 14.dp, vertical = 10.dp),
```

**Dòng 512:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    horizontalArrangement = Arrangement.spacedBy(7.dp),
```

**Dòng 513:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    verticalAlignment = Alignment.CenterVertically,
```

**Dòng 514:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                ) {
```

**Dòng 515:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
                    Text(if (profile.displayName.isBlank()) "THÊM KHÁCH HÀNG" else "SỬA KHÁCH HÀNG", color = Color(0xFF12385F), fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, modifier = Modifier.weight(1f))
```

**Dòng 516:** Nút tương tác; onClick xử lý nhấn.

```kotlin
                    Button(
```

**Dòng 517:** Lấy phần tử đầu hoặc null.

```kotlin
                        onClick = { onSave(profile.copy(name = names.firstOrNull().orEmpty(), names = names, phones = phones, addresses = addresses, note = note).normalized()) },
```

**Dòng 518:** Lấy phần tử đầu hoặc null.

```kotlin
                        enabled = CustomerProfile(id = profile.id, name = names.firstOrNull().orEmpty(), names = names, phones = phones, addresses = addresses, note = note).normalized().isValid(),
```

**Dòng 519:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
                        modifier = Modifier.height(34.dp),
```

**Dòng 520:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E73BE)),
```

**Dòng 521:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    ) { Text("Lưu", fontSize = 11.sp) }
```

**Dòng 522:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.height(34.dp)) { Text("Đóng", fontSize = 11.sp) }
```

**Dòng 523:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                }
```

**Dòng 524:** Container dọc.

```kotlin
                Column(
```

**Dòng 525:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    modifier = Modifier
```

**Dòng 526:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        .weight(1f)
```

**Dòng 527:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        .fillMaxWidth()
```

**Dòng 528:** Giữ giá trị qua recomposition.

```kotlin
                        .verticalScroll(rememberScrollState())
```

**Dòng 529:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        .padding(start = 14.dp, top = 9.dp, end = 14.dp, bottom = 40.dp),
```

**Dòng 530:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    verticalArrangement = Arrangement.spacedBy(6.dp),
```

**Dòng 531:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                ) {
```

**Dòng 532:** Hiển thị văn bản.

```kotlin
                    Text("1. Thông tin cơ bản", fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
```

**Dòng 533:** Phép so sánh/điều kiện.

```kotlin
                    names.forEachIndexed { index, value ->
```

**Dòng 534:** Container ngang.

```kotlin
                        Row(verticalAlignment = Alignment.CenterVertically) {
```

**Dòng 535:** Biến đổi collection.

```kotlin
                            OutlinedTextField(value = value, onValueChange = { updated -> names = names.mapIndexed { i, item -> if (i == index) updated else item } }, label = { Text(if (index == 0) "Tên khách hàng" else "Tên gọi khác", fontSize = 12.sp) }, modifier = Modifier.weight(1f).heightIn(min = 56.dp).keyboardSafeTextField(), singleLine = true)
```

**Dòng 536:** Điều kiện if.

```kotlin
                            if (names.size > 1) IconButton(onClick = { names = names.filterIndexed { i, _ -> i != index } }, modifier = Modifier.padding(start = 6.dp).size(40.dp).background(Color(0xFFFCE8E6), RoundedCornerShape(10.dp))) { Icon(Icons.Filled.Remove, "Xóa tên", tint = Color(0xFFC23D35)) }
```

**Dòng 537:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        }
```

**Dòng 538:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    }
```

**Dòng 539:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
                    Button(onClick = { names = names + "" }, modifier = Modifier.fillMaxWidth().height(40.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0E7490))) { Icon(Icons.Filled.Add, null, modifier = Modifier.size(17.dp)); Text(" Thêm tên khách hàng", fontSize = 12.sp) }
```

**Dòng 540:** Phép so sánh/điều kiện.

```kotlin
                    phones.forEachIndexed { index, phone ->
```

**Dòng 541:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        PhoneEditorRow(
```

**Dòng 542:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                            phone = phone,
```

**Dòng 543:** Phép so sánh/điều kiện.

```kotlin
                            canDelete = phones.size > 1,
```

**Dòng 544:** Biến đổi collection.

```kotlin
                            onChange = { updated -> phones = phones.mapIndexed { i, value -> if (i == index) updated else value } },
```

**Dòng 545:** Biến đổi collection.

```kotlin
                            onPrimary = { phones = phones.mapIndexed { i, value -> value.copy(isPrimary = i == index) } },
```

**Dòng 546:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                            onDelete = {
```

**Dòng 547:** Biến chỉ đọc.

```kotlin
                                val remaining = phones.filterIndexed { i, _ -> i != index }
```

**Dòng 548:** Biến đổi collection.

```kotlin
                                phones = if (remaining.any { it.isPrimary }) remaining else remaining.mapIndexed { i, value -> value.copy(isPrimary = i == 0) }
```

**Dòng 549:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                            },
```

**Dòng 550:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        )
```

**Dòng 551:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    }
```

**Dòng 552:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
                    Button(onClick = { phones = phones + CustomerPhone("") }, modifier = Modifier.fillMaxWidth().height(40.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E73BE))) { Icon(Icons.Filled.Add, null, modifier = Modifier.size(17.dp)); Text(" Thêm số điện thoại", fontSize = 12.sp) }
```

**Dòng 553:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
                    Text("2. Địa chỉ & Định vị", fontWeight = FontWeight.ExtraBold, fontSize = 13.sp, modifier = Modifier.padding(top = 3.dp))
```

**Dòng 554:** Phép so sánh/điều kiện.

```kotlin
                    addresses.forEachIndexed { index, address ->
```

**Dòng 555:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        AddressEditorBlock(
```

**Dòng 556:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                            address = address,
```

**Dòng 557:** Phép so sánh/điều kiện.

```kotlin
                            canDelete = addresses.size > 1,
```

**Dòng 558:** Biến đổi collection.

```kotlin
                            onChange = { updated -> addresses = addresses.mapIndexed { i, value -> if (i == index) updated else value } },
```

**Dòng 559:** Biến đổi collection.

```kotlin
                            onPrimary = { addresses = addresses.mapIndexed { i, value -> value.copy(isPrimary = i == index) } },
```

**Dòng 560:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                            onDelete = {
```

**Dòng 561:** Biến chỉ đọc.

```kotlin
                                val remaining = addresses.filterIndexed { i, _ -> i != index }
```

**Dòng 562:** Biến đổi collection.

```kotlin
                                addresses = if (remaining.any { it.isPrimary }) remaining else remaining.mapIndexed { i, value -> value.copy(isPrimary = i == 0) }
```

**Dòng 563:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                            },
```

**Dòng 564:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                            onCaptureGate = {
```

**Dòng 565:** Biến chỉ đọc.

```kotlin
                                val file = DeliveryPhotoHistory.createCustomerGateFile(context, profile.id)
```

**Dòng 566:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                                gateCaptureTarget = index to file
```

**Dòng 567:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                                gateCamera.launch(DeliveryPhotoHistory.providerUri(context, file))
```

**Dòng 568:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                            },
```

**Dòng 569:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                            onPickCoordinates = { coordinatePickerTarget = index },
```

**Dòng 570:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        )
```

**Dòng 571:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    }
```

**Dòng 572:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
                    Button(onClick = { addresses = addresses + CustomerAddress("") }, modifier = Modifier.fillMaxWidth().height(40.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF229846))) { Icon(Icons.Filled.Add, null, modifier = Modifier.size(17.dp)); Text(" Thêm địa chỉ mới", fontSize = 12.sp) }
```

**Dòng 573:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
                    Text("3. Thông tin bổ sung", fontWeight = FontWeight.ExtraBold, fontSize = 13.sp, modifier = Modifier.padding(top = 3.dp))
```

**Dòng 574:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
                    OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text("Ghi chú", fontSize = 12.sp) }, modifier = Modifier.fillMaxWidth().heightIn(min = 88.dp).keyboardSafeTextField())
```

**Dòng 575:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
                    Spacer(Modifier.height(180.dp))
```

**Dòng 576:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                }
```

**Dòng 577:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 578:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 579:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 580:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 581:** Safe-call: chỉ chạy khi khác null.

```kotlin
    coordinatePickerTarget?.let { index ->
```

**Dòng 582:** Safe-call: chỉ chạy khi khác null.

```kotlin
        addresses.getOrNull(index)?.let { address ->
```

**Dòng 583:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            CustomerCoordinatePickerDialog(
```

**Dòng 584:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                initialLatitude = address.latitude,
```

**Dòng 585:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                initialLongitude = address.longitude,
```

**Dòng 586:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                onDismiss = { coordinatePickerTarget = null },
```

**Dòng 587:** Phép so sánh/điều kiện.

```kotlin
                onConfirm = { latitude, longitude ->
```

**Dòng 588:** Biến đổi collection.

```kotlin
                    addresses = addresses.mapIndexed { addressIndex, value ->
```

**Dòng 589:** Điều kiện if.

```kotlin
                        if (addressIndex == index) value.copy(latitude = latitude, longitude = longitude) else value
```

**Dòng 590:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    }
```

**Dòng 591:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    coordinatePickerTarget = null
```

**Dòng 592:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                },
```

**Dòng 593:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            )
```

**Dòng 594:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 595:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 596:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 597:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 598:** Đánh dấu hàm UI Compose.

```kotlin
@Composable
```

**Dòng 599:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
@OptIn(ExperimentalFoundationApi::class)
```

**Dòng 600:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
private fun Modifier.keyboardSafeTextField(): Modifier {
```

**Dòng 601:** Biến chỉ đọc.

```kotlin
    val requester = remember { BringIntoViewRequester() }
```

**Dòng 602:** Biến có thể thay đổi.

```kotlin
    var focused by remember { mutableStateOf(false) }
```

**Dòng 603:** Chạy coroutine theo key.

```kotlin
    LaunchedEffect(focused) {
```

**Dòng 604:** Điều kiện if.

```kotlin
        if (focused) {
```

**Dòng 605:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            delay(220)
```

**Dòng 606:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            requester.bringIntoView()
```

**Dòng 607:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            delay(260)
```

**Dòng 608:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            requester.bringIntoView()
```

**Dòng 609:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 610:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 611:** Kết thúc hàm và trả kết quả.

```kotlin
    return bringIntoViewRequester(requester).onFocusChanged { focused = it.isFocused }
```

**Dòng 612:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 613:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 614:** Đánh dấu hàm UI Compose.

```kotlin
@Composable
```

**Dòng 615:** Phép so sánh/điều kiện.

```kotlin
private fun PhoneEditorRow(phone: CustomerPhone, canDelete: Boolean, onChange: (CustomerPhone) -> Unit, onPrimary: () -> Unit, onDelete: () -> Unit) {
```

**Dòng 616:** Biến có thể thay đổi.

```kotlin
    var menuExpanded by remember { mutableStateOf(false) }
```

**Dòng 617:** Container ngang.

```kotlin
    Row(verticalAlignment = Alignment.CenterVertically) {
```

**Dòng 618:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        OutlinedTextField(value = phone.number, onValueChange = { onChange(phone.copy(number = it)) }, label = { Text("Số điện thoại", fontSize = 12.sp) }, modifier = Modifier.weight(1f).heightIn(min = 56.dp).keyboardSafeTextField(), singleLine = true, trailingIcon = {
```

**Dòng 619:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            Box {
```

**Dòng 620:** Nút tương tác; onClick xử lý nhấn.

```kotlin
                IconButton(onClick = { menuExpanded = true }) { Icon(Icons.Filled.ArrowDropDown, "Chọn Gọi, SMS, Zalo") }
```

**Dòng 621:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                DropdownMenu(expanded = menuExpanded, onDismissRequest = { menuExpanded = false }) {
```

**Dòng 622:** Phép so sánh/điều kiện.

```kotlin
                    CustomerContactMethod.entries.forEach { method ->
```

**Dòng 623:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        DropdownMenuItem(text = { Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(checked = method in phone.methods, onCheckedChange = null); Text(method.label) } }, onClick = {
```

**Dòng 624:** Biến chỉ đọc.

```kotlin
                            val methods = if (method in phone.methods) phone.methods - method else phone.methods + method
```

**Dòng 625:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                            onChange(phone.copy(methods = methods.ifEmpty { setOf(CustomerContactMethod.CALL) }))
```

**Dòng 626:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        })
```

**Dòng 627:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    }
```

**Dòng 628:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                }
```

**Dòng 629:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 630:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        })
```

**Dòng 631:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        Checkbox(checked = phone.isPrimary, onCheckedChange = { if (it) onPrimary() })
```

**Dòng 632:** Hiển thị văn bản.

```kotlin
        Text("Chính", fontSize = 10.sp)
```

**Dòng 633:** Điều kiện if.

```kotlin
        if (canDelete) IconButton(onClick = onDelete, modifier = Modifier.padding(start = 4.dp).size(38.dp).background(Color(0xFFFCE8E6), RoundedCornerShape(9.dp))) { Icon(Icons.Filled.Remove, "Xóa số điện thoại", tint = Color(0xFFC23D35)) }
```

**Dòng 634:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 635:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 636:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 637:** Đánh dấu hàm UI Compose.

```kotlin
@Composable
```

**Dòng 638:** Phép so sánh/điều kiện.

```kotlin
private fun AddressEditorBlock(address: CustomerAddress, canDelete: Boolean, onChange: (CustomerAddress) -> Unit, onPrimary: () -> Unit, onDelete: () -> Unit, onCaptureGate: () -> Unit, onPickCoordinates: () -> Unit) {
```

**Dòng 639:** Biến có thể thay đổi.

```kotlin
    var longitudeText by remember { mutableStateOf(address.longitude?.toString().orEmpty()) }
```

**Dòng 640:** Biến có thể thay đổi.

```kotlin
    var latitudeText by remember { mutableStateOf(address.latitude?.toString().orEmpty()) }
```

**Dòng 641:** Biến có thể thay đổi.

```kotlin
    var committedLongitude by remember { mutableStateOf(address.longitude) }
```

**Dòng 642:** Biến có thể thay đổi.

```kotlin
    var committedLatitude by remember { mutableStateOf(address.latitude) }
```

**Dòng 643:** Chạy coroutine theo key.

```kotlin
    LaunchedEffect(address.longitude, address.latitude) {
```

**Dòng 644:** Điều kiện if.

```kotlin
        if (address.longitude != committedLongitude) {
```

**Dòng 645:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            longitudeText = address.longitude?.toString().orEmpty()
```

**Dòng 646:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            committedLongitude = address.longitude
```

**Dòng 647:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 648:** Điều kiện if.

```kotlin
        if (address.latitude != committedLatitude) {
```

**Dòng 649:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            latitudeText = address.latitude?.toString().orEmpty()
```

**Dòng 650:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            committedLatitude = address.latitude
```

**Dòng 651:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 652:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 653:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    fun applyPastedCoordinates(value: String): Boolean {
```

**Dòng 654:** Biến chỉ đọc.

```kotlin
        val coordinates = CoordinateTextParser.parse(value) ?: return false
```

**Dòng 655:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        latitudeText = coordinates.latitude.toString()
```

**Dòng 656:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        longitudeText = coordinates.longitude.toString()
```

**Dòng 657:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        committedLatitude = coordinates.latitude
```

**Dòng 658:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        committedLongitude = coordinates.longitude
```

**Dòng 659:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        onChange(address.copy(latitude = coordinates.latitude, longitude = coordinates.longitude))
```

**Dòng 660:** Kết thúc hàm và trả kết quả.

```kotlin
        return true
```

**Dòng 661:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 662:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
    Column(Modifier.fillMaxWidth().background(Color(0xFFEAF5F2), RoundedCornerShape(10.dp)).padding(7.dp)) {
```

**Dòng 663:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        OutlinedTextField(value = address.address, onValueChange = { onChange(address.copy(address = it)) }, label = { Text("Địa chỉ", fontSize = 12.sp) }, modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp).keyboardSafeTextField(), singleLine = true)
```

**Dòng 664:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
```

**Dòng 665:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            Checkbox(checked = address.isPrimary, onCheckedChange = { if (it) onPrimary() }, modifier = Modifier.size(34.dp))
```

**Dòng 666:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            Text("Địa chỉ chính", fontSize = 10.sp, modifier = Modifier.weight(1f))
```

**Dòng 667:** Điều kiện if.

```kotlin
            if (canDelete) IconButton(onClick = onDelete, modifier = Modifier.size(38.dp).background(Color(0xFFFCE8E6), RoundedCornerShape(9.dp))) { Icon(Icons.Filled.Remove, "Xóa địa chỉ", tint = Color(0xFFC23D35)) }
```

**Dòng 668:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 669:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
```

**Dòng 670:** Ô nhập liệu.

```kotlin
            OutlinedTextField(
```

**Dòng 671:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                value = latitudeText,
```

**Dòng 672:** Phép so sánh/điều kiện.

```kotlin
                onValueChange = { value ->
```

**Dòng 673:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    latitudeText = value
```

**Dòng 674:** Điều kiện if.

```kotlin
                    if (!applyPastedCoordinates(value)) {
```

**Dòng 675:** Biến chỉ đọc.

```kotlin
                        val latitude = value.trim().replace(',', '.').toDoubleOrNull()
```

**Dòng 676:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        committedLatitude = latitude
```

**Dòng 677:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        onChange(address.copy(latitude = latitude))
```

**Dòng 678:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    }
```

**Dòng 679:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                },
```

**Dòng 680:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                label = { Text("Vĩ độ (dán cụm)", fontSize = 11.sp) },
```

**Dòng 681:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                placeholder = { Text("Dán 10.802462, 107.000142", fontSize = 10.sp) },
```

**Dòng 682:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
                modifier = Modifier.weight(1f).heightIn(min = 56.dp).keyboardSafeTextField(),
```

**Dòng 683:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                singleLine = true,
```

**Dòng 684:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            )
```

**Dòng 685:** Ô nhập liệu.

```kotlin
            OutlinedTextField(
```

**Dòng 686:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                value = longitudeText,
```

**Dòng 687:** Phép so sánh/điều kiện.

```kotlin
                onValueChange = { value ->
```

**Dòng 688:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    longitudeText = value
```

**Dòng 689:** Biến chỉ đọc.

```kotlin
                    val longitude = value.trim().replace(',', '.').toDoubleOrNull()
```

**Dòng 690:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    committedLongitude = longitude
```

**Dòng 691:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    onChange(address.copy(longitude = longitude))
```

**Dòng 692:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                },
```

**Dòng 693:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                label = { Text("Kinh độ", fontSize = 11.sp) },
```

**Dòng 694:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
                modifier = Modifier.weight(1f).heightIn(min = 56.dp).keyboardSafeTextField(),
```

**Dòng 695:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                singleLine = true,
```

**Dòng 696:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            )
```

**Dòng 697:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 698:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        Text("Nhập tay từng ô hoặc dán cụm Google Maps theo thứ tự Vĩ độ, Kinh độ vào ô Vĩ độ bên trái.", color = Color(0xFF66737E), fontSize = 9.sp, modifier = Modifier.padding(top = 2.dp))
```

**Dòng 699:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        Row(Modifier.fillMaxWidth().padding(top = 7.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
```

**Dòng 700:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            Button(onClick = onCaptureGate, modifier = Modifier.weight(1f).height(42.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E73BE))) { Icon(Icons.Filled.CameraAlt, "Chụp cổng nhà", modifier = Modifier.size(18.dp)); Text(" Ảnh cổng", fontSize = 11.sp) }
```

**Dòng 701:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            Button(onClick = onPickCoordinates, modifier = Modifier.weight(1f).height(42.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF229846))) { Icon(Icons.Filled.LocationOn, "Chọn tọa độ trên bản đồ", modifier = Modifier.size(18.dp)); Text(" Lấy tọa độ", fontSize = 11.sp) }
```

**Dòng 702:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 703:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 704:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 705:** Dòng trống — phân tách nhóm.

```kotlin

```

## `app/src/main/java/com/example/delivery/ui/CustomerCoordinatePickerDialog.kt`

**Dòng 1:** Khai báo package/namespace.

```kotlin
package com.example.delivery.ui\n\nimport com.example.delivery.map.GoongMapStyleLoader\nimport android.Manifest\nimport android.annotation.SuppressLint\nimport android.content.Context\nimport android.content.pm.PackageManager\nimport android.graphics.Bitmap\nimport android.graphics.Canvas\nimport android.graphics.Paint\nimport android.graphics.Typeface\nimport android.location.Location\nimport android.location.LocationListener\nimport android.location.LocationManager\nimport android.os.Looper\nimport androidx.compose.foundation.background\nimport androidx.compose.foundation.layout.Arrangement\nimport androidx.compose.foundation.layout.Box\nimport androidx.compose.foundation.layout.Column\nimport androidx.compose.foundation.layout.Row\nimport androidx.compose.foundation.layout.Spacer\nimport androidx.compose.foundation.layout.fillMaxSize\nimport androidx.compose.foundation.layout.fillMaxHeight\nimport androidx.compose.foundation.layout.fillMaxWidth\nimport androidx.compose.foundation.layout.height\nimport androidx.compose.foundation.layout.navigationBarsPadding\nimport androidx.compose.foundation.layout.padding\nimport androidx.compose.foundation.layout.width\nimport androidx.compose.foundation.shape.RoundedCornerShape\nimport androidx.compose.material3.Button\nimport androidx.compose.material3.ButtonDefaults\nimport androidx.compose.material3.OutlinedButton\nimport androidx.compose.material3.Surface\nimport androidx.compose.material3.Text\nimport androidx.compose.runtime.Composable\nimport androidx.compose.runtime.DisposableEffect\nimport androidx.compose.runtime.getValue\nimport androidx.compose.runtime.mutableStateOf\nimport androidx.compose.runtime.remember\nimport androidx.compose.runtime.setValue\nimport androidx.compose.ui.Alignment\nimport androidx.compose.ui.Modifier\nimport androidx.compose.ui.graphics.Color\nimport androidx.compose.ui.platform.LocalContext\nimport androidx.compose.ui.text.font.FontWeight\nimport androidx.compose.ui.unit.dp\nimport androidx.compose.ui.unit.sp\nimport androidx.compose.ui.viewinterop.AndroidView\nimport androidx.compose.ui.window.Dialog\nimport androidx.compose.ui.window.DialogProperties\nimport androidx.lifecycle.Lifecycle\nimport androidx.lifecycle.LifecycleEventObserver\nimport androidx.lifecycle.compose.LocalLifecycleOwner\nimport androidx.core.content.ContextCompat\nimport com.example.delivery.BuildConfig\nimport com.example.delivery.location.RealtimeLocationPolicy\nimport org.maplibre.android.MapLibre\nimport org.maplibre.android.annotations.Marker\nimport org.maplibre.android.annotations.MarkerOptions\nimport org.maplibre.android.annotations.IconFactory\nimport org.maplibre.android.camera.CameraPosition\nimport org.maplibre.android.camera.CameraUpdateFactory\nimport org.maplibre.android.geometry.LatLng\nimport org.maplibre.android.maps.MapLibreMap\nimport org.maplibre.android.maps.MapView\nimport org.maplibre.android.maps.Style\nimport java.util.Locale\n\nprivate const val DEFAULT_PICKER_LATITUDE = 10.7769\nprivate const val DEFAULT_PICKER_LONGITUDE = 106.7009\n\ninternal data class CustomerPickerPosition(val latitude: Double, val longitude: Double)\n\ninternal fun initialCustomerPickerPosition(initialLatitude: Double?, initialLongitude: Double?): CustomerPickerPosition {\n    val latitude = initialLatitude.takeValidLatitude()\n    val longitude = initialLongitude.takeValidLongitude()\n    return if (latitude == null || longitude == null) {\n        CustomerPickerPosition(DEFAULT_PICKER_LATITUDE, DEFAULT_PICKER_LONGITUDE)\n    } else {\n        CustomerPickerPosition(latitude, longitude)\n    }\n}\n\ninternal fun shouldInitializeCustomerPinFromGps(initialLatitude: Double?, initialLongitude: Double?): Boolean =\n    initialLatitude.takeValidLatitude() == null || initialLongitude.takeValidLongitude() == null\n\n@Composable\ninternal fun CustomerCoordinatePickerDialog(\n    initialLatitude: Double?,\n    initialLongitude: Double?,\n    onDismiss: () -> Unit,\n    onConfirm: (latitude: Double, longitude: Double) -> Unit,\n    title: String = "CHỌN TỌA ĐỘ TRÊN BẢN ĐỒ",\n    description: String = "Chạm vào bản đồ để di chuyển ghim tới đúng vị trí khách hàng.",\n    confirmLabel: String = "Lấy tọa độ này",\n) {\n    val context = LocalContext.current\n    val initialPosition = remember(initialLatitude, initialLongitude) { initialCustomerPickerPosition(initialLatitude, initialLongitude) }\n    var latitude by remember(initialLatitude, initialLongitude) { mutableStateOf(initialPosition.latitude) }\n    var longitude by remember(initialLatitude, initialLongitude) { mutableStateOf(initialPosition.longitude) }\n    var currentUserPosition by remember { mutableStateOf<CustomerPickerPosition?>(null) }\n    var needsInitialGpsCustomerPin by remember(initialLatitude, initialLongitude) {\n        mutableStateOf(shouldInitializeCustomerPinFromGps(initialLatitude, initialLongitude))\n    }\n    val hasLocationPermission = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||\n        ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED\n    if (hasLocationPermission) {\n        CurrentPickerLocationUpdates { location ->\n            if (location.latitude in -90.0..90.0 && location.longitude in -180.0..180.0) {\n                val gpsPosition = CustomerPickerPosition(location.latitude, location.longitude)\n                currentUserPosition = gpsPosition\n                if (needsInitialGpsCustomerPin) {\n                    latitude = gpsPosition.latitude\n                    longitude = gpsPosition.longitude\n                    needsInitialGpsCustomerPin = false\n                }\n            }\n        }\n    }\n    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {\n        Box(Modifier.fillMaxSize().navigationBarsPadding().padding(horizontal = 10.dp, vertical = 10.dp)) {\n            Surface(\n                modifier = Modifier.align(Alignment.Center).fillMaxWidth().fillMaxHeight(0.88f),\n                shape = RoundedCornerShape(18.dp),\n                color = AppBackground,\n            ) {\n                Column(Modifier.fillMaxSize()) {\n                    Column(Modifier.fillMaxWidth().background(Color(0xFFEAF5F2)).padding(horizontal = 14.dp, vertical = 9.dp)) {\n                    Text(title, color = Color(0xFF12385F), fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)\n                    Text(description, color = Color(0xFF5F6B75), fontSize = 11.sp, modifier = Modifier.padding(top = 3.dp))\n                }\n                Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 8.dp, vertical = 7.dp)) {\n                    CustomerCoordinatePickerMap(\n                        latitude = latitude,\n                        longitude = longitude,\n                        onPointSelected = { selectedLatitude, selectedLongitude ->\n                            latitude = selectedLatitude\n                            longitude = selectedLongitude\n                        },\n                        currentUserPosition = currentUserPosition,\n                        modifier = Modifier.fillMaxSize(),\n                    )\n                }\n                Column(Modifier.fillMaxWidth().background(Color(0xFFF4F7F8)).padding(horizontal = 12.dp, vertical = 9.dp)) {\n                    Text(\n                        text = String.format(Locale.US, "Vĩ độ: %.6f    Kinh độ: %.6f", latitude, longitude),\n                        color = Color(0xFF12385F),\n                        fontSize = 12.sp,\n                        fontWeight = FontWeight.Bold,\n                    )\n                    Text(\n                        text = currentUserPosition?.let { String.format(Locale.US, "GPS hiện tại (xanh): %.6f, %.6f", it.latitude, it.longitude) } ?: "Đang lấy vị trí GPS hiện tại…",\n                        color = Color(0xFF1E73BE),\n                        fontSize = 10.sp,\n                        modifier = Modifier.padding(top = 2.dp),\n                    )\n                    Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.Start) {\n                        OutlinedButton(onClick = onDismiss, modifier = Modifier.height(40.dp)) { Text("Hủy") }\n                        Spacer(Modifier.width(8.dp))\n                        Button(\n                            onClick = { onConfirm(latitude, longitude) },\n                            modifier = Modifier.weight(1f).height(40.dp),\n                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF229846)),\n                        ) { Text(confirmLabel, fontWeight = FontWeight.ExtraBold) }\n                    }\n                }\n            }\n        }\n    }\n}\n}\n\n@Composable\nprivate fun CustomerCoordinatePickerMap(\n    latitude: Double,\n    longitude: Double,\n    onPointSelected: (Double, Double) -> Unit,\n    currentUserPosition: CustomerPickerPosition?,\n    modifier: Modifier,\n) {\n    val context = LocalContext.current\n    val lifecycle = LocalLifecycleOwner.current.lifecycle\n    val mapView = remember(context) { MapLibre.getInstance(context); MapView(context).also { it.onCreate(null) } }\n    var map by remember { mutableStateOf<MapLibreMap?>(null) }\n    var userMarker by remember { mutableStateOf<Marker?>(null) }\n    var customerMarker by remember { mutableStateOf<Marker?>(null) }\n    var hasCenteredOnInitialGps by remember { mutableStateOf(false) }\n    DisposableEffect(mapView, lifecycle) {\n        val observer = LifecycleEventObserver { _, event ->\n            when (event) {\n                Lifecycle.Event.ON_START -> mapView.onStart()\n                Lifecycle.Event.ON_RESUME -> mapView.onResume()\n                Lifecycle.Event.ON_PAUSE -> mapView.onPause()\n                Lifecycle.Event.ON_STOP -> mapView.onStop()\n                else -> Unit\n            }\n        }\n        lifecycle.addObserver(observer)\n        onDispose {\n            lifecycle.removeObserver(observer)\n            mapView.onDestroy()\n        }\n    }\n    AndroidView(\n        modifier = modifier,\n        factory = {\n            mapView.apply {\n                getMapAsync { readyMap ->\n                    configurePickerMap(readyMap, context, latitude, longitude, onPointSelected) { marker ->\n                        map = readyMap\n                        customerMarker = marker\n                    }\n                }\n            }\n        },\n        update = {\n            val readyMap = map ?: return@AndroidView\n            if (readyMap.style == null) return@AndroidView\n            customerMarker?.let { marker ->\n                marker.position = LatLng(latitude, longitude)\n                readyMap.updateMarker(marker)\n            }\n            currentUserPosition?.let { point ->\n                val userPoint = LatLng(point.latitude, point.longitude)\n                val existing = userMarker\n                if (existing == null) {\n                    userMarker = readyMap.addMarker(\n                        MarkerOptions().position(userPoint).title("Vị trí hiện tại (GPS)").icon(pickerMarkerIcon(context, "GPS", 0xFF1E73BE.toInt())),\n                    )\n                } else {\n                    existing.position = userPoint\n                    readyMap.updateMarker(existing)\n                }\n                if (!hasCenteredOnInitialGps) {\n                    readyMap.animateCamera(CameraUpdateFactory.newLatLngZoom(LatLng(latitude, longitude), 15.5))\n                    hasCenteredOnInitialGps = true\n                }\n            }\n        },\n    )\n}\n\nprivate fun configurePickerMap(\n    map: MapLibreMap,\n    context: Context,\n    latitude: Double,\n    longitude: Double,\n    onPointSelected: (Double, Double) -> Unit,\n    onReady: (Marker) -> Unit,\n) {\n    if (map.style != null) return\n    map.setTileCacheEnabled(true)\n    map.setStyle(Style.Builder().fromJson(GoongMapStyleLoader.load(context))) {\n        val initialPoint = LatLng(latitude, longitude)\n        val marker = map.addMarker(MarkerOptions().position(initialPoint).title("Vị trí khách hàng"))\n        map.cameraPosition = CameraPosition.Builder().target(initialPoint).zoom(15.5).build()\n        map.addOnMapClickListener { point ->\n            marker.position = point\n            map.updateMarker(marker)\n            onPointSelected(point.latitude, point.longitude)\n            true\n        }\n        onReady(marker)\n    }\n}\n\nprivate fun pickerMarkerIcon(context: Context, text: String, color: Int): org.maplibre.android.annotations.Icon {\n    val density = context.resources.displayMetrics.density\n    val size = (42 * density).toInt()\n    val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)\n    val canvas = Canvas(bitmap)\n    val paint = Paint(Paint.ANTI_ALIAS_FLAG)\n    paint.color = color\n    canvas.drawCircle(size / 2f, size / 2f, size / 2f - density, paint)\n    paint.color = android.graphics.Color.WHITE\n    paint.textAlign = Paint.Align.CENTER\n    paint.typeface = Typeface.DEFAULT_BOLD\n    paint.textSize = 10 * density\n    canvas.drawText(text, size / 2f, size / 2f - (paint.ascent() + paint.descent()) / 2f, paint)\n    return IconFactory.getInstance(context).fromBitmap(bitmap)\n}\n\n@SuppressLint("MissingPermission")\n@Composable\nprivate fun CurrentPickerLocationUpdates(update: (Location) -> Unit) {\n    val context = LocalContext.current\n    DisposableEffect(context) {\n        val manager = context.getSystemService(LocationManager::class.java)\n        var newestFixTime: Long? = null\n        val listener = object : LocationListener {\n            override fun onLocationChanged(location: Location) {\n                if (RealtimeLocationPolicy.shouldAccept(newestFixTime, location.time)) {\n                    newestFixTime = location.time\n                    update(location)\n                }\n            }\n        }\n        val now = System.currentTimeMillis()\n        listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)\n            .mapNotNull { provider -> runCatching { manager.getLastKnownLocation(provider) }.getOrNull() }\n            .filter { RealtimeLocationPolicy.isFreshLastKnown(it.time, now) }\n            .maxByOrNull { it.time }\n            ?.let(listener::onLocationChanged)\n        listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER).forEach { provider ->\n            runCatching {\n                if (manager.isProviderEnabled(provider)) manager.requestLocationUpdates(provider, 1_500L, 1f, listener, Looper.getMainLooper())\n            }\n        }\n        onDispose { manager.removeUpdates(listener) }\n    }\n}\n\nprivate fun Double?.takeValidLatitude(): Double? = this?.takeIf { it.isFinite() && it in -90.0..90.0 && it != 0.0 }\nprivate fun Double?.takeValidLongitude(): Double? = this?.takeIf { it.isFinite() && it in -180.0..180.0 && it != 0.0 }\n
```

## `app/src/main/java/com/example/delivery/ui/DeliveryCompletionDialog.kt`

**Dòng 1:** Khai báo package/namespace.

```kotlin
package com.example.delivery.ui
```

**Dòng 2:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 3:** Import dependency.

```kotlin
import android.Manifest
```

**Dòng 4:** Import dependency.

```kotlin
import android.app.Activity
```

**Dòng 5:** Import dependency.

```kotlin
import android.content.Context
```

**Dòng 6:** Import dependency.

```kotlin
import android.widget.Toast
```

**Dòng 7:** Import dependency.

```kotlin
import android.content.Intent
```

**Dòng 8:** Import dependency.

```kotlin
import android.content.pm.PackageManager
```

**Dòng 9:** Import dependency.

```kotlin
import android.graphics.BitmapFactory
```

**Dòng 10:** Import dependency.

```kotlin
import android.net.Uri
```

**Dòng 11:** Import dependency.

```kotlin
import androidx.activity.compose.BackHandler
```

**Dòng 12:** Import dependency.

```kotlin
import androidx.activity.compose.rememberLauncherForActivityResult
```

**Dòng 13:** Import dependency.

```kotlin
import androidx.activity.result.contract.ActivityResultContracts
```

**Dòng 14:** Import dependency.

```kotlin
import androidx.compose.foundation.Image
```

**Dòng 15:** Import dependency.

```kotlin
import androidx.compose.foundation.background
```

**Dòng 16:** Import dependency.

```kotlin
import androidx.compose.foundation.border
```

**Dòng 17:** Import dependency.

```kotlin
import androidx.compose.foundation.clickable
```

**Dòng 18:** Import dependency.

```kotlin
import androidx.compose.foundation.ExperimentalFoundationApi
```

**Dòng 19:** Import dependency.

```kotlin
import androidx.compose.foundation.interaction.MutableInteractionSource
```

**Dòng 20:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.Arrangement
```

**Dòng 21:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.Box
```

**Dòng 22:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.Column
```

**Dòng 23:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.Row
```

**Dòng 24:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.Spacer
```

**Dòng 25:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.fillMaxSize
```

**Dòng 26:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.fillMaxHeight
```

**Dòng 27:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.fillMaxWidth
```

**Dòng 28:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.height
```

**Dòng 29:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.heightIn
```

**Dòng 30:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.imePadding
```

**Dòng 31:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.navigationBarsPadding
```

**Dòng 32:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.offset
```

**Dòng 33:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.padding
```

**Dòng 34:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.size
```

**Dòng 35:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.width
```

**Dòng 36:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.statusBarsPadding
```

**Dòng 37:** Import dependency.

```kotlin
import androidx.compose.foundation.rememberScrollState
```

**Dòng 38:** Import dependency.

```kotlin
import androidx.compose.foundation.relocation.BringIntoViewRequester
```

**Dòng 39:** Import dependency.

```kotlin
import androidx.compose.foundation.relocation.bringIntoViewRequester
```

**Dòng 40:** Import dependency.

```kotlin
import androidx.compose.foundation.verticalScroll
```

**Dòng 41:** Import dependency.

```kotlin
import androidx.compose.foundation.lazy.LazyColumn
```

**Dòng 42:** Import dependency.

```kotlin
import androidx.compose.foundation.lazy.items
```

**Dòng 43:** Import dependency.

```kotlin
import androidx.compose.foundation.lazy.itemsIndexed
```

**Dòng 44:** Import dependency.

```kotlin
import androidx.compose.foundation.lazy.rememberLazyListState
```

**Dòng 45:** Import dependency.

```kotlin
import androidx.compose.foundation.shape.RoundedCornerShape
```

**Dòng 46:** Import dependency.

```kotlin
import androidx.compose.material.icons.Icons
```

**Dòng 47:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.ArrowUpward
```

**Dòng 48:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.Map
```

**Dòng 49:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.Add
```

**Dòng 50:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.ArrowDropDown
```

**Dòng 51:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.CameraAlt
```

**Dòng 52:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.Close
```

**Dòng 53:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.Delete
```

**Dòng 54:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.Edit
```

**Dòng 55:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.LocationOn
```

**Dòng 56:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.Navigation
```

**Dòng 57:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.Pause
```

**Dòng 58:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.People
```

**Dòng 59:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.Phone
```

**Dòng 60:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.ReceiptLong
```

**Dòng 61:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.Remove
```

**Dòng 62:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.Settings
```

**Dòng 63:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.Sms
```

**Dòng 64:** Import dependency.

```kotlin
import androidx.compose.material3.AlertDialog
```

**Dòng 65:** Import dependency.

```kotlin
import androidx.compose.material3.Button
```

**Dòng 66:** Import dependency.

```kotlin
import androidx.compose.material3.ButtonDefaults
```

**Dòng 67:** Import dependency.

```kotlin
import androidx.compose.material3.Card
```

**Dòng 68:** Import dependency.

```kotlin
import androidx.compose.material3.CardDefaults
```

**Dòng 69:** Import dependency.

```kotlin
import androidx.compose.material3.Checkbox
```

**Dòng 70:** Import dependency.

```kotlin
import androidx.compose.material3.DropdownMenu
```

**Dòng 71:** Import dependency.

```kotlin
import androidx.compose.material3.DropdownMenuItem
```

**Dòng 72:** Import dependency.

```kotlin
import androidx.compose.material3.Icon
```

**Dòng 73:** Import dependency.

```kotlin
import androidx.compose.material3.IconButton
```

**Dòng 74:** Import dependency.

```kotlin
import androidx.compose.material3.OutlinedButton
```

**Dòng 75:** Import dependency.

```kotlin
import androidx.compose.material3.OutlinedTextField
```

**Dòng 76:** Import dependency.

```kotlin
import androidx.compose.material3.Surface
```

**Dòng 77:** Import dependency.

```kotlin
import androidx.compose.material3.Text
```

**Dòng 78:** Import dependency.

```kotlin
import androidx.compose.runtime.Composable
```

**Dòng 79:** Import dependency.

```kotlin
import androidx.compose.runtime.LaunchedEffect
```

**Dòng 80:** Import dependency.

```kotlin
import androidx.compose.runtime.getValue
```

**Dòng 81:** Import dependency.

```kotlin
import androidx.compose.runtime.mutableStateOf
```

**Dòng 82:** Import dependency.

```kotlin
import androidx.compose.runtime.remember
```

**Dòng 83:** Import dependency.

```kotlin
import androidx.compose.runtime.saveable.rememberSaveable
```

**Dòng 84:** Import dependency.

```kotlin
import androidx.compose.runtime.setValue
```

**Dòng 85:** Import dependency.

```kotlin
import androidx.compose.ui.Alignment
```

**Dòng 86:** Import dependency.

```kotlin
import androidx.compose.ui.Modifier
```

**Dòng 87:** Import dependency.

```kotlin
import androidx.compose.ui.draw.clip
```

**Dòng 88:** Import dependency.

```kotlin
import androidx.compose.ui.draw.alpha
```

**Dòng 89:** Import dependency.

```kotlin
import androidx.compose.ui.focus.onFocusChanged
```

**Dòng 90:** Import dependency.

```kotlin
import androidx.compose.ui.platform.LocalFocusManager
```

**Dòng 91:** Import dependency.

```kotlin
import androidx.compose.foundation.text.KeyboardActions
```

**Dòng 92:** Import dependency.

```kotlin
import androidx.compose.foundation.text.KeyboardOptions
```

**Dòng 93:** Import dependency.

```kotlin
import androidx.compose.ui.text.input.ImeAction
```

**Dòng 94:** Import dependency.

```kotlin
import androidx.compose.ui.graphics.Color
```

**Dòng 95:** Import dependency.

```kotlin
import androidx.compose.ui.graphics.asImageBitmap
```

**Dòng 96:** Import dependency.

```kotlin
import androidx.compose.ui.layout.ContentScale
```

**Dòng 97:** Import dependency.

```kotlin
import androidx.compose.ui.platform.LocalContext
```

**Dòng 98:** Import dependency.

```kotlin
import androidx.compose.ui.text.font.FontWeight
```

**Dòng 99:** Import dependency.

```kotlin
import androidx.compose.ui.unit.dp
```

**Dòng 100:** Import dependency.

```kotlin
import androidx.compose.ui.unit.sp
```

**Dòng 101:** Import dependency.

```kotlin
import androidx.compose.ui.window.Dialog
```

**Dòng 102:** Import dependency.

```kotlin
import androidx.compose.ui.window.DialogProperties
```

**Dòng 103:** Import dependency.

```kotlin
import androidx.core.content.ContextCompat
```

**Dòng 104:** Import dependency.

```kotlin
import com.example.delivery.history.DeliveryPhotoHistory
```

**Dòng 105:** Import dependency.

```kotlin
import com.example.delivery.history.PaymentChannel
```

**Dòng 106:** Import dependency.

```kotlin
import com.example.delivery.history.ProofPhotoType
```

**Dòng 107:** Import dependency.

```kotlin
import com.example.delivery.history.TransferEvidence
```

**Dòng 108:** Import dependency.

```kotlin
import com.example.delivery.orderio.CoordinateUpdateRequest
```

**Dòng 109:** Import dependency.

```kotlin
import com.example.delivery.orderio.CoordinateTextParser
```

**Dòng 110:** Import dependency.

```kotlin
import com.example.delivery.location.RealtimeLocationPolicy
```

**Dòng 111:** Import dependency.

```kotlin
import com.example.delivery.customer.CustomerAddress
```

**Dòng 112:** Import dependency.

```kotlin
import com.example.delivery.customer.CustomerContactMethod
```

**Dòng 113:** Import dependency.

```kotlin
import com.example.delivery.customer.CustomerPhone
```

**Dòng 114:** Import dependency.

```kotlin
import com.example.delivery.customer.CustomerProfile
```

**Dòng 115:** Import dependency.

```kotlin
import com.example.delivery.customer.CustomerProfileStore
```

**Dòng 116:** Import dependency.

```kotlin
import com.example.delivery.customer.matchesSearch
```

**Dòng 117:** Import dependency.

```kotlin
import com.example.delivery.model.DeliveryOrder
```

**Dòng 118:** Import dependency.

```kotlin
import com.example.delivery.model.DeliveryOutcome
```

**Dòng 119:** Import dependency.

```kotlin
import com.example.delivery.model.DeliveryStatus
```

**Dòng 120:** Import dependency.

```kotlin
import com.example.delivery.model.hasStoredCoordinates
```

**Dòng 121:** Import dependency.

```kotlin
import com.example.delivery.model.canReceiveRouteSequence
```

**Dòng 122:** Import dependency.

```kotlin
import com.example.delivery.model.dispatchDisplayOrder
```

**Dòng 123:** Import dependency.

```kotlin
import com.example.delivery.model.formatVnd
```

**Dòng 124:** Import dependency.

```kotlin
import com.example.delivery.model.isMapVisible
```

**Dòng 125:** Import dependency.

```kotlin
import com.example.delivery.model.isPickupAtWarehouse
```

**Dòng 126:** Import dependency.

```kotlin
import com.example.delivery.model.isRouteActive
```

**Dòng 127:** Import dependency.

```kotlin
import com.example.delivery.model.statusLabel
```

**Dòng 128:** Import dependency.

```kotlin
import com.example.delivery.model.withStableRouteLabels
```

**Dòng 129:** Import dependency.

```kotlin
import com.example.delivery.model.resequenceDraftLabels
```

**Dòng 130:** Import dependency.

```kotlin
import com.example.delivery.model.sequenceText
```

**Dòng 131:** Import dependency.

```kotlin
import com.example.delivery.model.sequenceSortValue
```

**Dòng 132:** Import dependency.

```kotlin
import com.example.delivery.model.csvStatus
```

**Dòng 133:** Import dependency.

```kotlin
import com.example.delivery.navigation.DeliveryRouteStore
```

**Dòng 134:** Import dependency.

```kotlin
import com.example.delivery.navigation.DeliveryZone
```

**Dòng 135:** Import dependency.

```kotlin
import com.example.delivery.navigation.GeoPoint
```

**Dòng 136:** Import dependency.

```kotlin
import com.example.delivery.navigation.persistedRouteLabels
```

**Dòng 137:** Import dependency.

```kotlin
import com.example.delivery.navigation.preferredRouteOrigin
```

**Dòng 138:** Import dependency.

```kotlin
import com.example.delivery.navigation.routeOrdersFrom
```

**Dòng 139:** Import dependency.

```kotlin
import kotlinx.coroutines.delay
```

**Dòng 140:** Import dependency.

```kotlin
import java.util.Locale
```

**Dòng 141:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 142:** Chú thích, không thực thi.

```kotlin
// UI GROUP: COMPLETION DIALOG
```

**Dòng 143:** Chú thích, không thực thi.

```kotlin
// Chỉ hiển thị hộp thoại xác nhận; nghiệp vụ nằm ở màn hình cha.
```

**Dòng 144:** Đánh dấu hàm UI Compose.

```kotlin
@Composable
```

**Dòng 145:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
internal fun DeliveryCompletionDialog(
```

**Dòng 146:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    order: DeliveryOrder,
```

**Dòng 147:** Phép so sánh/điều kiện.

```kotlin
    onDismiss: () -> Unit,
```

**Dòng 148:** Phép so sánh/điều kiện.

```kotlin
    onConfirm: () -> Unit,
```

**Dòng 149:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
) {
```

**Dòng 150:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    AlertDialog(
```

**Dòng 151:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        onDismissRequest = onDismiss,
```

**Dòng 152:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        title = { Text("Xác nhận giao thành công") },
```

**Dòng 153:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        text = { Text("Bạn chắc chắn giao thành công đơn hàng ${order.waybill}?", fontSize = 13.sp) },
```

**Dòng 154:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        confirmButton = {
```

**Dòng 155:** Nút tương tác; onClick xử lý nhấn.

```kotlin
            Button(onClick = onConfirm, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF229846))) { Text("Có") }
```

**Dòng 156:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        },
```

**Dòng 157:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        dismissButton = { OutlinedButton(onClick = onDismiss) { Text("Không") } },
```

**Dòng 158:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    )
```

**Dòng 159:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

## `app/src/main/java/com/example/delivery/ui/DeliveryRouteScreen.kt`

**Dòng 1:** Khai báo package/namespace.

```kotlin
package com.example.delivery.ui
```

**Dòng 2:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 3:** Import dependency.

```kotlin
import androidx.compose.foundation.background
```

**Dòng 4:** Import dependency.

```kotlin
import androidx.compose.foundation.clickable
```

**Dòng 5:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.Arrangement
```

**Dòng 6:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.Column
```

**Dòng 7:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.Row
```

**Dòng 8:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.fillMaxSize
```

**Dòng 9:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.fillMaxWidth
```

**Dòng 10:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.padding
```

**Dòng 11:** Import dependency.

```kotlin
import androidx.compose.foundation.lazy.LazyColumn
```

**Dòng 12:** Import dependency.

```kotlin
import androidx.compose.foundation.lazy.itemsIndexed
```

**Dòng 13:** Import dependency.

```kotlin
import androidx.compose.material.icons.Icons
```

**Dòng 14:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.ArrowBack
```

**Dòng 15:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.Delete
```

**Dòng 16:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.Edit
```

**Dòng 17:** Import dependency.

```kotlin
import androidx.compose.material3.AlertDialog
```

**Dòng 18:** Import dependency.

```kotlin
import androidx.compose.material3.Button
```

**Dòng 19:** Import dependency.

```kotlin
import androidx.compose.material3.Icon
```

**Dòng 20:** Import dependency.

```kotlin
import androidx.compose.material3.IconButton
```

**Dòng 21:** Import dependency.

```kotlin
import androidx.compose.material3.OutlinedButton
```

**Dòng 22:** Import dependency.

```kotlin
import androidx.compose.material3.OutlinedTextField
```

**Dòng 23:** Import dependency.

```kotlin
import androidx.compose.material3.Text
```

**Dòng 24:** Import dependency.

```kotlin
import androidx.compose.runtime.Composable
```

**Dòng 25:** Import dependency.

```kotlin
import androidx.compose.runtime.getValue
```

**Dòng 26:** Import dependency.

```kotlin
import androidx.compose.runtime.mutableStateOf
```

**Dòng 27:** Import dependency.

```kotlin
import androidx.compose.runtime.remember
```

**Dòng 28:** Import dependency.

```kotlin
import androidx.compose.runtime.setValue
```

**Dòng 29:** Import dependency.

```kotlin
import androidx.compose.ui.Alignment
```

**Dòng 30:** Import dependency.

```kotlin
import androidx.compose.ui.Modifier
```

**Dòng 31:** Import dependency.

```kotlin
import androidx.compose.ui.graphics.Color
```

**Dòng 32:** Import dependency.

```kotlin
import androidx.compose.ui.text.font.FontWeight
```

**Dòng 33:** Import dependency.

```kotlin
import androidx.compose.ui.unit.dp
```

**Dòng 34:** Import dependency.

```kotlin
import androidx.compose.ui.unit.sp
```

**Dòng 35:** Import dependency.

```kotlin
import com.example.delivery.navigation.DeliveryZone
```

**Dòng 36:** Import dependency.

```kotlin
import com.example.delivery.navigation.GeoPoint
```

**Dòng 37:** Import dependency.

```kotlin
import java.util.UUID
```

**Dòng 38:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 39:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
enum class RouteCreationMode { NEW_ROUTE, UPDATE_ROUTE }
```

**Dòng 40:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 41:** Đánh dấu hàm UI Compose.

```kotlin
@Composable
```

**Dòng 42:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
internal fun DeliveryRouteScreen(
```

**Dòng 43:** Phép so sánh/điều kiện.

```kotlin
    zones: List<DeliveryZone>,
```

**Dòng 44:** Phép so sánh/điều kiện.

```kotlin
    onZonesChanged: (List<DeliveryZone>) -> Unit,
```

**Dòng 45:** Phép so sánh/điều kiện.

```kotlin
    onCreateRoute: (RouteCreationMode) -> Unit,
```

**Dòng 46:** Phép so sánh/điều kiện.

```kotlin
    onDeleteRoute: () -> Unit,
```

**Dòng 47:** Phép so sánh/điều kiện.

```kotlin
    onClose: () -> Unit,
```

**Dòng 48:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
) {
```

**Dòng 49:** Biến có thể thay đổi.

```kotlin
    var editorOpen by remember { mutableStateOf(false) }
```

**Dòng 50:** Biến có thể thay đổi.

```kotlin
    var editingIndex by remember { mutableStateOf<Int?>(null) }
```

**Dòng 51:** Biến có thể thay đổi.

```kotlin
    var confirmAction by remember { mutableStateOf<String?>(null) }
```

**Dòng 52:** Biến có thể thay đổi.

```kotlin
    var createChoiceOpen by remember { mutableStateOf(false) }
```

**Dòng 53:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
    Column(Modifier.fillMaxSize().background(AppBackground)) {
```

**Dòng 54:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        Row(Modifier.fillMaxWidth().padding(start = 12.dp, top = 8.dp, end = 12.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
```

**Dòng 55:** Nút tương tác; onClick xử lý nhấn.

```kotlin
            IconButton(onClick = onClose) { Icon(Icons.Filled.ArrowBack, "Quay lại", tint = Color(0xFF12385F)) }
```

**Dòng 56:** Hiển thị văn bản.

```kotlin
            Text("TUYẾN GIAO HÀNG", color = Color(0xFF12385F), fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
```

**Dòng 57:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 58:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
```

**Dòng 59:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            Button(onClick = { createChoiceOpen = true }, modifier = Modifier.weight(1f)) { Text("Tạo tuyến") }
```

**Dòng 60:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            OutlinedButton(onClick = { confirmAction = "Xóa" }, modifier = Modifier.weight(1f)) { Text("Xóa tuyến") }
```

**Dòng 61:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 62:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        Text("Danh sách Zone (${zones.size}) — chạm tên Zone để đổi ưu tiên bằng nút lên/xuống.", color = Color(0xFF59636D), fontSize = 11.sp, modifier = Modifier.padding(14.dp, 10.dp, 14.dp, 5.dp))
```

**Dòng 63:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        Button(onClick = { editingIndex = null; editorOpen = true }, modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 5.dp)) { Text("Tạo zone") }
```

**Dòng 64:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        LazyColumn(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp)) {
```

**Dòng 65:** Phép so sánh/điều kiện.

```kotlin
            itemsIndexed(zones, key = { _, zone -> zone.id }) { index, zone ->
```

**Dòng 66:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
                Row(Modifier.fillMaxWidth().background(AppSurface, androidx.compose.foundation.shape.RoundedCornerShape(12.dp)).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
```

**Dòng 67:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
                    Column(Modifier.weight(1f).clickable { editingIndex = index; editorOpen = true }) {
```

**Dòng 68:** Hiển thị văn bản.

```kotlin
                        Text("${index + 1}. ${zone.name}", color = Color(0xFF12385F), fontWeight = FontWeight.Bold)
```

**Dòng 69:** Hiển thị văn bản.

```kotlin
                        Text(zone.points.joinToString("  •  ") { "%.5f, %.5f".format(it.latitude, it.longitude) }, color = Color(0xFF59636D), fontSize = 10.sp)
```

**Dòng 70:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    }
```

**Dòng 71:** Nút tương tác; onClick xử lý nhấn.

```kotlin
                    IconButton(enabled = index > 0, onClick = { val copy = zones.toMutableList(); copy[index] = copy[index - 1].also { copy[index - 1] = copy[index] }; onZonesChanged(copy) }) { Text("↑") }
```

**Dòng 72:** Nút tương tác; onClick xử lý nhấn.

```kotlin
                    IconButton(enabled = index < zones.lastIndex, onClick = { val copy = zones.toMutableList(); copy[index] = copy[index + 1].also { copy[index + 1] = copy[index] }; onZonesChanged(copy) }) { Text("↓") }
```

**Dòng 73:** Nút tương tác; onClick xử lý nhấn.

```kotlin
                    IconButton(onClick = { editingIndex = index; editorOpen = true }) { Icon(Icons.Filled.Edit, "Sửa", tint = Color(0xFF1E73BE)) }
```

**Dòng 74:** Lọc collection.

```kotlin
                    IconButton(onClick = { onZonesChanged(zones.filterIndexed { i, _ -> i != index }) }) { Icon(Icons.Filled.Delete, "Xóa", tint = Color(0xFFC23D35)) }
```

**Dòng 75:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                }
```

**Dòng 76:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 77:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 78:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 79:** Điều kiện if.

```kotlin
    if (createChoiceOpen) {
```

**Dòng 80:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        AlertDialog(
```

**Dòng 81:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            onDismissRequest = { createChoiceOpen = false },
```

**Dòng 82:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            title = { Text("Chọn cách tạo tuyến") },
```

**Dòng 83:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            text = { Text("Tuyến mới — ưu tiên cao nhất: đánh STT toàn bộ MVĐ đủ điều kiện.\n\nCập nhật tuyến — ưu tiên thứ hai: đánh lại STT các MVĐ thuộc SĐT mới được nạp tọa độ.") },
```

**Dòng 84:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            confirmButton = {
```

**Dòng 85:** Nút tương tác; onClick xử lý nhấn.

```kotlin
                Button(onClick = { onCreateRoute(RouteCreationMode.NEW_ROUTE); createChoiceOpen = false }) { Text("Tuyến mới") }
```

**Dòng 86:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            },
```

**Dòng 87:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            dismissButton = {
```

**Dòng 88:** Nút tương tác; onClick xử lý nhấn.

```kotlin
                OutlinedButton(onClick = { onCreateRoute(RouteCreationMode.UPDATE_ROUTE); createChoiceOpen = false }) { Text("Cập nhật tuyến") }
```

**Dòng 89:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            },
```

**Dòng 90:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        )
```

**Dòng 91:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 92:** Safe-call: chỉ chạy khi khác null.

```kotlin
    confirmAction?.let { action ->
```

**Dòng 93:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        AlertDialog(onDismissRequest = { confirmAction = null }, title = { Text("Xác nhận") }, text = { Text("Bạn có chắc chắn muốn xóa Tuyến giao không?") }, confirmButton = { Button(onClick = { onDeleteRoute(); confirmAction = null }) { Text("Có") } }, dismissButton = { OutlinedButton(onClick = { confirmAction = null }) { Text("Không") } })
```

**Dòng 94:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 95:** Điều kiện if.

```kotlin
    if (editorOpen) {
```

**Dòng 96:** Safe-call: chỉ chạy khi khác null.

```kotlin
        ZoneEditorDialog(initial = editingIndex?.let { zones[it] }, onDismiss = { editorOpen = false }, onSave = { zone ->
```

**Dòng 97:** Biến chỉ đọc.

```kotlin
            val copy = zones.toMutableList(); val index = editingIndex
```

**Dòng 98:** Điều kiện if.

```kotlin
            if (index == null) copy += zone else copy[index] = zone
```

**Dòng 99:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            onZonesChanged(copy); editorOpen = false
```

**Dòng 100:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        })
```

**Dòng 101:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 102:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 103:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 104:** Đánh dấu hàm UI Compose.

```kotlin
@Composable
```

**Dòng 105:** Phép so sánh/điều kiện.

```kotlin
private fun ZoneEditorDialog(initial: DeliveryZone?, onDismiss: () -> Unit, onSave: (DeliveryZone) -> Unit) {
```

**Dòng 106:** Biến có thể thay đổi.

```kotlin
    var name by remember(initial?.id) { mutableStateOf(initial?.name.orEmpty()) }
```

**Dòng 107:** Biến có thể thay đổi.

```kotlin
    var points by remember(initial?.id) { mutableStateOf(initial?.points ?: emptyList()) }
```

**Dòng 108:** Biến có thể thay đổi.

```kotlin
    var pointPickerOpen by remember { mutableStateOf(false) }
```

**Dòng 109:** Điều kiện if.

```kotlin
    if (pointPickerOpen) {
```

**Dòng 110:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        ZoneMultiVertexPickerDialog(
```

**Dòng 111:** Biến đổi collection.

```kotlin
            initialPoints = points.map { CustomerPickerPosition(it.latitude, it.longitude) },
```

**Dòng 112:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            onDismiss = { pointPickerOpen = false },
```

**Dòng 113:** Phép so sánh/điều kiện.

```kotlin
            onConfirm = { selected ->
```

**Dòng 114:** Biến đổi collection.

```kotlin
                points = selected.map { point -> GeoPoint(point.latitude, point.longitude) }
```

**Dòng 115:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                pointPickerOpen = false
```

**Dòng 116:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            },
```

**Dòng 117:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        )
```

**Dòng 118:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 119:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    AlertDialog(
```

**Dòng 120:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        onDismissRequest = onDismiss,
```

**Dòng 121:** Phép so sánh/điều kiện.

```kotlin
        title = { Text(if (initial == null) "Tạo Zone mới" else "Sửa Zone") },
```

**Dòng 122:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        text = { Column {
```

**Dòng 123:** Ô nhập liệu.

```kotlin
            OutlinedTextField(
```

**Dòng 124:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                value = name,
```

**Dòng 125:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                onValueChange = { name = it },
```

**Dòng 126:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                label = { Text("Tên Zone") },
```

**Dòng 127:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                placeholder = { Text("Ví dụ: Khu trung tâm") },
```

**Dòng 128:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                singleLine = true,
```

**Dòng 129:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            )
```

**Dòng 130:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            Text("Đã chọn ${points.size} đỉnh; cần ít nhất 3 đỉnh để lưu Zone.", color = Color(0xFF59636D), modifier = Modifier.padding(top = 8.dp))
```

**Dòng 131:** Nút tương tác; onClick xử lý nhấn.

```kotlin
            Button(onClick = { pointPickerOpen = true }) { Text(if (points.isEmpty()) "Mở bản đồ chọn đỉnh" else "Sửa các đỉnh trên bản đồ") }
```

**Dòng 132:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            points.forEachIndexed { i, p -> Text("Đỉnh ${i + 1}: %.6f, %.6f".format(p.latitude, p.longitude), modifier = Modifier.padding(vertical = 3.dp), fontSize = 11.sp) }
```

**Dòng 133:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }},
```

**Dòng 134:** Elvis: dùng giá trị dự phòng khi null.

```kotlin
        confirmButton = { Button(enabled = points.size >= 3 && name.isNotBlank(), onClick = { onSave(DeliveryZone(initial?.id ?: UUID.randomUUID().toString(), name.trim(), points)) }) { Text("Xác nhận") } },
```

**Dòng 135:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        dismissButton = { OutlinedButton(onClick = onDismiss) { Text("Hủy") } },
```

**Dòng 136:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    )
```

**Dòng 137:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

## `app/src/main/java/com/example/delivery/ui/DeliveryV2Screen.kt`

**Dòng 1:** Khai báo package/namespace.

```kotlin
package com.example.delivery.ui
```

**Dòng 2:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 3:** Import dependency.

```kotlin
import android.Manifest
```

**Dòng 4:** Import dependency.

```kotlin
import android.app.Activity
```

**Dòng 5:** Import dependency.

```kotlin
import android.content.Context
```

**Dòng 6:** Import dependency.

```kotlin
import android.widget.Toast
```

**Dòng 7:** Import dependency.

```kotlin
import android.content.Intent
```

**Dòng 8:** Import dependency.

```kotlin
import android.content.pm.PackageManager
```

**Dòng 9:** Import dependency.

```kotlin
import android.graphics.BitmapFactory
```

**Dòng 10:** Import dependency.

```kotlin
import android.net.Uri
```

**Dòng 11:** Import dependency.

```kotlin
import androidx.activity.compose.BackHandler
```

**Dòng 12:** Import dependency.

```kotlin
import androidx.activity.compose.rememberLauncherForActivityResult
```

**Dòng 13:** Import dependency.

```kotlin
import androidx.activity.result.contract.ActivityResultContracts
```

**Dòng 14:** Import dependency.

```kotlin
import androidx.compose.foundation.Image
```

**Dòng 15:** Import dependency.

```kotlin
import androidx.compose.foundation.background
```

**Dòng 16:** Import dependency.

```kotlin
import androidx.compose.foundation.border
```

**Dòng 17:** Import dependency.

```kotlin
import androidx.compose.foundation.clickable
```

**Dòng 18:** Import dependency.

```kotlin
import androidx.compose.foundation.ExperimentalFoundationApi
```

**Dòng 19:** Import dependency.

```kotlin
import androidx.compose.foundation.interaction.MutableInteractionSource
```

**Dòng 20:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.Arrangement
```

**Dòng 21:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.Box
```

**Dòng 22:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.Column
```

**Dòng 23:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.Row
```

**Dòng 24:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.Spacer
```

**Dòng 25:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.fillMaxSize
```

**Dòng 26:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.fillMaxHeight
```

**Dòng 27:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.fillMaxWidth
```

**Dòng 28:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.height
```

**Dòng 29:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.heightIn
```

**Dòng 30:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.imePadding
```

**Dòng 31:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.navigationBarsPadding
```

**Dòng 32:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.offset
```

**Dòng 33:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.padding
```

**Dòng 34:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.size
```

**Dòng 35:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.width
```

**Dòng 36:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.statusBarsPadding
```

**Dòng 37:** Import dependency.

```kotlin
import androidx.compose.foundation.rememberScrollState
```

**Dòng 38:** Import dependency.

```kotlin
import androidx.compose.foundation.relocation.BringIntoViewRequester
```

**Dòng 39:** Import dependency.

```kotlin
import androidx.compose.foundation.relocation.bringIntoViewRequester
```

**Dòng 40:** Import dependency.

```kotlin
import androidx.compose.foundation.verticalScroll
```

**Dòng 41:** Import dependency.

```kotlin
import androidx.compose.foundation.lazy.LazyColumn
```

**Dòng 42:** Import dependency.

```kotlin
import androidx.compose.foundation.lazy.items
```

**Dòng 43:** Import dependency.

```kotlin
import androidx.compose.foundation.lazy.itemsIndexed
```

**Dòng 44:** Import dependency.

```kotlin
import androidx.compose.foundation.lazy.rememberLazyListState
```

**Dòng 45:** Import dependency.

```kotlin
import androidx.compose.foundation.shape.RoundedCornerShape
```

**Dòng 46:** Import dependency.

```kotlin
import androidx.compose.material.icons.Icons
```

**Dòng 47:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.ArrowUpward
```

**Dòng 48:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.Map
```

**Dòng 49:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.Add
```

**Dòng 50:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.ArrowDropDown
```

**Dòng 51:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.CameraAlt
```

**Dòng 52:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.Close
```

**Dòng 53:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.Delete
```

**Dòng 54:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.Edit
```

**Dòng 55:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.LocationOn
```

**Dòng 56:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.Navigation
```

**Dòng 57:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.Pause
```

**Dòng 58:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.People
```

**Dòng 59:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.Phone
```

**Dòng 60:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.ReceiptLong
```

**Dòng 61:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.Remove
```

**Dòng 62:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.Settings
```

**Dòng 63:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.Sms
```

**Dòng 64:** Import dependency.

```kotlin
import androidx.compose.material3.AlertDialog
```

**Dòng 65:** Import dependency.

```kotlin
import androidx.compose.material3.Button
```

**Dòng 66:** Import dependency.

```kotlin
import androidx.compose.material3.ButtonDefaults
```

**Dòng 67:** Import dependency.

```kotlin
import androidx.compose.material3.Card
```

**Dòng 68:** Import dependency.

```kotlin
import androidx.compose.material3.CardDefaults
```

**Dòng 69:** Import dependency.

```kotlin
import androidx.compose.material3.Checkbox
```

**Dòng 70:** Import dependency.

```kotlin
import androidx.compose.material3.DropdownMenu
```

**Dòng 71:** Import dependency.

```kotlin
import androidx.compose.material3.DropdownMenuItem
```

**Dòng 72:** Import dependency.

```kotlin
import androidx.compose.material3.Icon
```

**Dòng 73:** Import dependency.

```kotlin
import androidx.compose.material3.IconButton
```

**Dòng 74:** Import dependency.

```kotlin
import androidx.compose.material3.OutlinedButton
```

**Dòng 75:** Import dependency.

```kotlin
import androidx.compose.material3.OutlinedTextField
```

**Dòng 76:** Import dependency.

```kotlin
import androidx.compose.material3.Surface
```

**Dòng 77:** Import dependency.

```kotlin
import androidx.compose.material3.Text
```

**Dòng 78:** Import dependency.

```kotlin
import androidx.compose.runtime.Composable
```

**Dòng 79:** Import dependency.

```kotlin
import androidx.compose.runtime.LaunchedEffect
```

**Dòng 80:** Import dependency.

```kotlin
import androidx.compose.runtime.getValue
```

**Dòng 81:** Import dependency.

```kotlin
import androidx.compose.runtime.mutableStateOf
```

**Dòng 82:** Import dependency.

```kotlin
import androidx.compose.runtime.remember
```

**Dòng 83:** Import dependency.

```kotlin
import androidx.compose.runtime.saveable.rememberSaveable
```

**Dòng 84:** Import dependency.

```kotlin
import androidx.compose.runtime.setValue
```

**Dòng 85:** Import dependency.

```kotlin
import androidx.compose.ui.Alignment
```

**Dòng 86:** Import dependency.

```kotlin
import androidx.compose.ui.Modifier
```

**Dòng 87:** Import dependency.

```kotlin
import androidx.compose.ui.draw.clip
```

**Dòng 88:** Import dependency.

```kotlin
import androidx.compose.ui.draw.alpha
```

**Dòng 89:** Import dependency.

```kotlin
import androidx.compose.ui.focus.onFocusChanged
```

**Dòng 90:** Import dependency.

```kotlin
import androidx.compose.ui.platform.LocalFocusManager
```

**Dòng 91:** Import dependency.

```kotlin
import androidx.compose.foundation.text.KeyboardActions
```

**Dòng 92:** Import dependency.

```kotlin
import androidx.compose.foundation.text.KeyboardOptions
```

**Dòng 93:** Import dependency.

```kotlin
import androidx.compose.ui.text.input.ImeAction
```

**Dòng 94:** Import dependency.

```kotlin
import androidx.compose.ui.graphics.Color
```

**Dòng 95:** Import dependency.

```kotlin
import androidx.compose.ui.graphics.asImageBitmap
```

**Dòng 96:** Import dependency.

```kotlin
import androidx.compose.ui.layout.ContentScale
```

**Dòng 97:** Import dependency.

```kotlin
import androidx.compose.ui.platform.LocalContext
```

**Dòng 98:** Import dependency.

```kotlin
import androidx.compose.ui.text.font.FontWeight
```

**Dòng 99:** Import dependency.

```kotlin
import androidx.compose.ui.unit.dp
```

**Dòng 100:** Import dependency.

```kotlin
import androidx.compose.ui.unit.sp
```

**Dòng 101:** Import dependency.

```kotlin
import androidx.compose.ui.window.Dialog
```

**Dòng 102:** Import dependency.

```kotlin
import androidx.compose.ui.window.DialogProperties
```

**Dòng 103:** Import dependency.

```kotlin
import androidx.core.content.ContextCompat
```

**Dòng 104:** Import dependency.

```kotlin
import com.example.delivery.history.DeliveryPhotoHistory
```

**Dòng 105:** Import dependency.

```kotlin
import com.example.delivery.history.PaymentChannel
```

**Dòng 106:** Import dependency.

```kotlin
import com.example.delivery.history.ProofPhotoType
```

**Dòng 107:** Import dependency.

```kotlin
import com.example.delivery.history.TransferEvidence
```

**Dòng 108:** Import dependency.

```kotlin
import com.example.delivery.orderio.CoordinateUpdateRequest
```

**Dòng 109:** Import dependency.

```kotlin
import com.example.delivery.orderio.CoordinateTextParser
```

**Dòng 110:** Import dependency.

```kotlin
import com.example.delivery.location.RealtimeLocationPolicy
```

**Dòng 111:** Import dependency.

```kotlin
import com.example.delivery.customer.CustomerAddress
```

**Dòng 112:** Import dependency.

```kotlin
import com.example.delivery.customer.CustomerContactMethod
```

**Dòng 113:** Import dependency.

```kotlin
import com.example.delivery.customer.CustomerPhone
```

**Dòng 114:** Import dependency.

```kotlin
import com.example.delivery.customer.CustomerProfile
```

**Dòng 115:** Import dependency.

```kotlin
import com.example.delivery.customer.CustomerProfileStore
```

**Dòng 116:** Import dependency.

```kotlin
import com.example.delivery.customer.matchesSearch
```

**Dòng 117:** Import dependency.

```kotlin
import com.example.delivery.model.DeliveryOrder
```

**Dòng 118:** Import dependency.

```kotlin
import com.example.delivery.model.DeliveryOutcome
```

**Dòng 119:** Import dependency.

```kotlin
import com.example.delivery.model.DeliveryStatus
```

**Dòng 120:** Import dependency.

```kotlin
import com.example.delivery.model.hasStoredCoordinates
```

**Dòng 121:** Import dependency.

```kotlin
import com.example.delivery.model.canReceiveRouteSequence
```

**Dòng 122:** Import dependency.

```kotlin
import com.example.delivery.model.dispatchDisplayOrder
```

**Dòng 123:** Import dependency.

```kotlin
import com.example.delivery.model.formatVnd
```

**Dòng 124:** Import dependency.

```kotlin
import com.example.delivery.model.isMapVisible
```

**Dòng 125:** Import dependency.

```kotlin
import com.example.delivery.model.isPickupAtWarehouse
```

**Dòng 126:** Import dependency.

```kotlin
import com.example.delivery.model.isRouteActive
```

**Dòng 127:** Import dependency.

```kotlin
import com.example.delivery.model.statusLabel
```

**Dòng 128:** Import dependency.

```kotlin
import com.example.delivery.model.withStableRouteLabels
```

**Dòng 129:** Import dependency.

```kotlin
import com.example.delivery.model.resequenceDraftLabels
```

**Dòng 130:** Import dependency.

```kotlin
import com.example.delivery.model.sequenceText
```

**Dòng 131:** Import dependency.

```kotlin
import com.example.delivery.model.sequenceSortValue
```

**Dòng 132:** Import dependency.

```kotlin
import com.example.delivery.model.csvStatus
```

**Dòng 133:** Import dependency.

```kotlin
import com.example.delivery.navigation.DeliveryRouteStore
```

**Dòng 134:** Import dependency.

```kotlin
import com.example.delivery.navigation.DeliveryZone
```

**Dòng 135:** Import dependency.

```kotlin
import com.example.delivery.navigation.GeoPoint
```

**Dòng 136:** Import dependency.

```kotlin
import com.example.delivery.navigation.persistedRouteLabels
```

**Dòng 137:** Import dependency.

```kotlin
import com.example.delivery.navigation.preferredRouteOrigin
```

**Dòng 138:** Import dependency.

```kotlin
import com.example.delivery.navigation.routeOrdersFrom
```

**Dòng 139:** Import dependency.

```kotlin
import kotlinx.coroutines.delay
```

**Dòng 140:** Import dependency.

```kotlin
import java.util.Locale
```

**Dòng 141:** Import dependency.

```kotlin
import com.example.delivery.ui.logic.buildRouteSequence
```

**Dòng 142:** Import dependency.

```kotlin
import com.example.delivery.ui.logic.findRouteOrigin
```

**Dòng 143:** Import dependency.

```kotlin
import com.example.delivery.ui.logic.nextOrderAfterCompletion
```

**Dòng 144:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 145:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
private enum class DeliveryTab { MAP, DETAIL, CUSTOMERS }
```

**Dòng 146:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
data class TransferPhotoState(val billPath: String? = null, val dropOffPath: String? = null)
```

**Dòng 147:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 148:** Đánh dấu hàm UI Compose.

```kotlin
@Composable
```

**Dòng 149:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
fun DeliveryV2Screen(
```

**Dòng 150:** Phép so sánh/điều kiện.

```kotlin
    orders: List<DeliveryOrder>,
```

**Dòng 151:** Phép so sánh/điều kiện.

```kotlin
    transferPhotos: Map<String, TransferPhotoState>,
```

**Dòng 152:** Phép so sánh/điều kiện.

```kotlin
    transferEvidence: List<TransferEvidence>,
```

**Dòng 153:** Phép so sánh/điều kiện.

```kotlin
    customerProfiles: List<CustomerProfile>,
```

**Dòng 154:** Phép so sánh/điều kiện.

```kotlin
    onDirectDelivered: (DeliveryOrder) -> Unit,
```

**Dòng 155:** Phép so sánh/điều kiện.

```kotlin
    onSaveTransfer: (DeliveryOrder, PaymentChannel, String, String?, String?) -> Unit,
```

**Dòng 156:** Phép so sánh/điều kiện.

```kotlin
    onCaptureTransferPhoto: (DeliveryOrder, ProofPhotoType) -> Unit,
```

**Dòng 157:** Phép so sánh/điều kiện.

```kotlin
    onCall: (DeliveryOrder) -> Unit,
```

**Dòng 158:** Phép so sánh/điều kiện.

```kotlin
    onZalo: (DeliveryOrder, String) -> Unit,
```

**Dòng 159:** Phép so sánh/điều kiện.

```kotlin
    onSms: (DeliveryOrder, String) -> Unit,
```

**Dòng 160:** Phép so sánh/điều kiện.

```kotlin
    onConfirmTransferPayment: (String) -> Unit,
```

**Dòng 161:** Phép so sánh/điều kiện.

```kotlin
    transferMessage: (DeliveryOrder) -> String,
```

**Dòng 162:** Phép so sánh/điều kiện.

```kotlin
    onRouteSequenceLocked: (Map<String, String>) -> Unit,
```

**Dòng 163:** Phép so sánh/điều kiện.

```kotlin
    onCreateRoute: (RouteCreationMode) -> Unit,
```

**Dòng 164:** Phép so sánh/điều kiện.

```kotlin
    onDeleteRoute: () -> Unit,
```

**Dòng 165:** Phép so sánh/điều kiện.

```kotlin
    onSaveCustomer: (CustomerProfile) -> Unit,
```

**Dòng 166:** Phép so sánh/điều kiện.

```kotlin
    onDeleteCustomer: (CustomerProfile) -> Unit,
```

**Dòng 167:** Phép so sánh/điều kiện.

```kotlin
    onGetCustomerCoordinates: () -> Pair<Double, Double>?,
```

**Dòng 168:** Phép so sánh/điều kiện.

```kotlin
    onExportBackup: () -> Unit,
```

**Dòng 169:** Phép so sánh/điều kiện.

```kotlin
    onImportBackup: () -> Unit,
```

**Dòng 170:** Phép so sánh/điều kiện.

```kotlin
    onImportOrders: () -> Unit,
```

**Dòng 171:** Phép so sánh/điều kiện.

```kotlin
    onExportOrders: () -> Unit,
```

**Dòng 172:** Phép so sánh/điều kiện.

```kotlin
    onExportStt: () -> Unit,
```

**Dòng 173:** Phép so sánh/điều kiện.

```kotlin
    onImportStt: () -> Unit,
```

**Dòng 174:** Phép so sánh/điều kiện.

```kotlin
    onAddManualOrder: (DeliveryOrder) -> Unit,
```

**Dòng 175:** Phép so sánh/điều kiện.

```kotlin
    onDeleteOrder: (String) -> Unit,
```

**Dòng 176:** Phép so sánh/điều kiện.

```kotlin
    onDeleteAllOrders: () -> Unit,
```

**Dòng 177:** Phép so sánh/điều kiện.

```kotlin
    onUpdateCoordinates: (CoordinateUpdateRequest) -> Unit,
```

**Dòng 178:** Phép so sánh/điều kiện.

```kotlin
    onSyncOrdersFromCustomerCoordinates: () -> Unit,
```

**Dòng 179:** Phép so sánh/điều kiện.

```kotlin
    onOpenVtmanExport: () -> Unit,
```

**Dòng 180:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    backupStatus: String?,
```

**Dòng 181:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
) {
```

**Dòng 182:** Biến có thể thay đổi.

```kotlin
    var tab by rememberSaveable { mutableStateOf(DeliveryTab.MAP) }
```

**Dòng 183:** Biến có thể thay đổi.

```kotlin
    var selectedNavigationOrder by remember { mutableStateOf<DeliveryOrder?>(null) }
```

**Dòng 184:** Biến có thể thay đổi.

```kotlin
    var selectedWaybill by rememberSaveable { mutableStateOf<String?>(null) }
```

**Dòng 185:** Biến có thể thay đổi.

```kotlin
    var detailScrollTopRequest by remember { mutableStateOf(0) }
```

**Dòng 186:** Biến có thể thay đổi.

```kotlin
    var detailSearchQuery by rememberSaveable { mutableStateOf("") }
```

**Dòng 187:** Biến có thể thay đổi.

```kotlin
    var scannerOpen by remember { mutableStateOf(false) }
```

**Dòng 188:** Biến có thể thay đổi.

```kotlin
    var settingsOpen by remember { mutableStateOf(false) }
```

**Dòng 189:** Biến có thể thay đổi.

```kotlin
    var backupOpen by remember { mutableStateOf(false) }
```

**Dòng 190:** Biến có thể thay đổi.

```kotlin
    var cashAuditOpen by remember { mutableStateOf(false) }
```

**Dòng 191:** Biến có thể thay đổi.

```kotlin
    var transferCheckOpen by remember { mutableStateOf(false) }
```

**Dòng 192:** Biến có thể thay đổi.

```kotlin
    var orderManagementOpen by remember { mutableStateOf(false) }
```

**Dòng 193:** Biến có thể thay đổi.

```kotlin
    var coordinateUpdateOpen by remember { mutableStateOf(false) }
```

**Dòng 194:** Biến có thể thay đổi.

```kotlin
    var routeScreenOpen by remember { mutableStateOf(false) }
```

**Dòng 195:** Biến có thể thay đổi.

```kotlin
    var completingOrder by remember { mutableStateOf<DeliveryOrder?>(null) }
```

**Dòng 196:** Biến có thể thay đổi.

```kotlin
    var focusPhone by remember { mutableStateOf<String?>(null) }
```

**Dòng 197:** Biến có thể thay đổi.

```kotlin
    var currentGps by remember { mutableStateOf<GeoPoint?>(null) }
```

**Dòng 198:** Biến có thể thay đổi.

```kotlin
    var currentGpsUpdatedAt by remember { mutableStateOf(0L) }
```

**Dòng 199:** Chú thích, không thực thi.

```kotlin
    // Khởi tạo từ sequence đã được DeliveryOrderStore commit. Vì vậy sau crash,
```

**Dòng 200:** Chú thích, không thực thi.

```kotlin
    // GPS mới về cũng không thể tự đánh lại STT đã xác nhận trước đó.
```

**Dòng 201:** Biến có thể thay đổi.

```kotlin
    var stableRouteSequence by remember { mutableStateOf(orders.persistedRouteLabels()) }
```

**Dòng 202:** Biến có thể thay đổi.

```kotlin
    var previewRouteSequence by remember { mutableStateOf<Map<String, String>?>(null) }
```

**Dòng 203:** Chạy coroutine theo key.

```kotlin
    LaunchedEffect(orders.isEmpty()) {
```

**Dòng 204:** Điều kiện if.

```kotlin
        if (orders.isEmpty()) {
```

**Dòng 205:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            stableRouteSequence = emptyMap()
```

**Dòng 206:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            previewRouteSequence = null
```

**Dòng 207:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 208:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 209:** Biến chỉ đọc.

```kotlin
    val context = LocalContext.current
```

**Dòng 210:** Biến có thể thay đổi.

```kotlin
    var lastBackPressedAt by remember { mutableStateOf(0L) }
```

**Dòng 211:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    BackHandler {
```

**Dòng 212:** Rẽ nhánh nhiều trường hợp.

```kotlin
        when {
```

**Dòng 213:** Phép so sánh/điều kiện.

```kotlin
            scannerOpen -> scannerOpen = false
```

**Dòng 214:** Phép so sánh/điều kiện.

```kotlin
            routeScreenOpen -> { routeScreenOpen = false; settingsOpen = true }
```

**Dòng 215:** Phép so sánh/điều kiện.

```kotlin
            coordinateUpdateOpen -> { coordinateUpdateOpen = false; orderManagementOpen = true }
```

**Dòng 216:** Phép so sánh/điều kiện.

```kotlin
            orderManagementOpen -> { orderManagementOpen = false; settingsOpen = true }
```

**Dòng 217:** Phép so sánh/điều kiện.

```kotlin
            backupOpen -> { backupOpen = false; settingsOpen = true }
```

**Dòng 218:** Phép so sánh/điều kiện.

```kotlin
            cashAuditOpen -> { cashAuditOpen = false; settingsOpen = true }
```

**Dòng 219:** Phép so sánh/điều kiện.

```kotlin
            transferCheckOpen -> { transferCheckOpen = false; settingsOpen = true }
```

**Dòng 220:** Phép so sánh/điều kiện.

```kotlin
            settingsOpen -> settingsOpen = false
```

**Dòng 221:** Nhánh thay thế.

```kotlin
            else -> {
```

**Dòng 222:** Biến chỉ đọc.

```kotlin
                val now = System.currentTimeMillis()
```

**Dòng 223:** Điều kiện if.

```kotlin
                if (now - lastBackPressedAt <= 1_800L) {
```

**Dòng 224:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    (context as? Activity)?.finish()
```

**Dòng 225:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                } else {
```

**Dòng 226:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    lastBackPressedAt = now
```

**Dòng 227:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    Toast.makeText(context, "Nhấn Back lần nữa để thoát ứng dụng", Toast.LENGTH_SHORT).show()
```

**Dòng 228:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                }
```

**Dòng 229:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 230:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 231:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 232:** Biến có thể thay đổi.

```kotlin
    var zones by remember(context) { mutableStateOf(DeliveryRouteStore.loadZones(context)) }
```

**Dòng 233:** Biến chỉ đọc.

```kotlin
    val locationPreferences = remember(context) { context.getSharedPreferences("location_permission", Context.MODE_PRIVATE) }
```

**Dòng 234:** Biến có thể thay đổi.

```kotlin
    var locationGranted by remember(context) {
```

**Dòng 235:** State Compose; thay đổi kích hoạt recomposition nơi state được đọc.

```kotlin
        mutableStateOf(
```

**Dòng 236:** Phép so sánh/điều kiện.

```kotlin
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
```

**Dòng 237:** Phép so sánh/điều kiện.

```kotlin
                ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED,
```

**Dòng 238:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        )
```

**Dòng 239:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 240:** Biến chỉ đọc.

```kotlin
    val locationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { permissions ->
```

**Dòng 241:** Phép so sánh/điều kiện.

```kotlin
        locationGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true || permissions[Manifest.permission.ACCESS_COARSE_LOCATION] == true
```

**Dòng 242:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 243:** Chạy coroutine theo key.

```kotlin
        LaunchedEffect(Unit) {
```

**Dòng 244:** Điều kiện if.

```kotlin
        if (!locationGranted && !locationPreferences.getBoolean("asked_once", false)) {
```

**Dòng 245:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            locationPreferences.edit().putBoolean("asked_once", true).apply()
```

**Dòng 246:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            locationPermission.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
```

**Dòng 247:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 248:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 249:** Chú thích, không thực thi.

```kotlin
    // GROUP: ROUTE CONDITION — UI chỉ gọi helper, không chứa thuật toán tính tuyến dài.
```

**Dòng 250:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    fun confirmRouteChange() {
```

**Dòng 251:** Biến chỉ đọc.

```kotlin
        val origin = findRouteOrigin(orders, currentGps)
```

**Dòng 252:** Điều kiện if.

```kotlin
        if (origin == null) return
```

**Dòng 253:** Biến chỉ đọc.

```kotlin
        val confirmed = buildRouteSequence(orders, origin)
```

**Dòng 254:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        stableRouteSequence = confirmed
```

**Dòng 255:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        onRouteSequenceLocked(confirmed)
```

**Dòng 256:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        selectedNavigationOrder = null
```

**Dòng 257:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        coordinateUpdateOpen = false
```

**Dòng 258:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        orderManagementOpen = false
```

**Dòng 259:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 260:** Điều kiện if.

```kotlin
    if (scannerOpen) {
```

**Dòng 261:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 262:** Phép so sánh/điều kiện.

```kotlin
        BarcodeScannerScreen(onCodeScanned = { code -> detailSearchQuery = code; scannerOpen = false; tab = DeliveryTab.DETAIL }, onDismiss = { scannerOpen = false })
```

**Dòng 263:** Kết thúc hàm và trả kết quả.

```kotlin
        return
```

**Dòng 264:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 265:** Điều kiện if.

```kotlin
    if (settingsOpen) {
```

**Dòng 266:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        SettingsScreen(
```

**Dòng 267:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            evidence = transferEvidence,
```

**Dòng 268:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            onConfirmPayment = onConfirmTransferPayment,
```

**Dòng 269:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            onOpenCashAudit = { settingsOpen = false; cashAuditOpen = true },
```

**Dòng 270:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            onOpenBackup = { settingsOpen = false; backupOpen = true },
```

**Dòng 271:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            onOpenVtmanExport = onOpenVtmanExport,
```

**Dòng 272:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            onOpenTransferCheck = { settingsOpen = false; transferCheckOpen = true },
```

**Dòng 273:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            onOpenOrderManagement = { settingsOpen = false; orderManagementOpen = true },
```

**Dòng 274:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            onOpenAnchorPoint = { settingsOpen = false; routeScreenOpen = true },
```

**Dòng 275:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            onClose = { settingsOpen = false },
```

**Dòng 276:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        )
```

**Dòng 277:** Kết thúc hàm và trả kết quả.

```kotlin
        return
```

**Dòng 278:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 279:** Điều kiện if.

```kotlin
    if (routeScreenOpen) {
```

**Dòng 280:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        DeliveryRouteScreen(
```

**Dòng 281:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            zones = zones,
```

**Dòng 282:** Phép so sánh/điều kiện.

```kotlin
            onZonesChanged = { updated -> zones = updated; DeliveryRouteStore.saveZones(context, updated) },
```

**Dòng 283:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            onCreateRoute = onCreateRoute,
```

**Dòng 284:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            onDeleteRoute = onDeleteRoute,
```

**Dòng 285:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            onClose = { routeScreenOpen = false; settingsOpen = true },
```

**Dòng 286:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        )
```

**Dòng 287:** Kết thúc hàm và trả kết quả.

```kotlin
        return
```

**Dòng 288:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 289:** Điều kiện if.

```kotlin
    if (orderManagementOpen) {
```

**Dòng 290:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        OrderManagementScreen(
```

**Dòng 291:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            status = backupStatus,
```

**Dòng 292:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            onAddManualOrder = onAddManualOrder,
```

**Dòng 293:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            onDeleteOrder = onDeleteOrder,
```

**Dòng 294:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            onDeleteAllOrders = onDeleteAllOrders,
```

**Dòng 295:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            onOpenCoordinateUpdate = { orderManagementOpen = false; coordinateUpdateOpen = true },
```

**Dòng 296:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            onConfirmRouteChange = { confirmRouteChange() },
```

**Dòng 297:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            onClose = { orderManagementOpen = false; settingsOpen = true },
```

**Dòng 298:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        )
```

**Dòng 299:** Kết thúc hàm và trả kết quả.

```kotlin
        return
```

**Dòng 300:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 301:** Điều kiện if.

```kotlin
    if (backupOpen) {
```

**Dòng 302:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        BackupDataScreen(
```

**Dòng 303:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            onExportBackup = onExportBackup,
```

**Dòng 304:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            onImportBackup = onImportBackup,
```

**Dòng 305:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            onImportOrders = onImportOrders,
```

**Dòng 306:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            onExportOrders = onExportOrders,
```

**Dòng 307:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            onExportStt = onExportStt,
```

**Dòng 308:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            onImportStt = onImportStt,
```

**Dòng 309:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            backupStatus = backupStatus,
```

**Dòng 310:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            onClose = { backupOpen = false; settingsOpen = true },
```

**Dòng 311:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        )
```

**Dòng 312:** Kết thúc hàm và trả kết quả.

```kotlin
        return
```

**Dòng 313:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 314:** Điều kiện if.

```kotlin
    if (cashAuditOpen) {
```

**Dòng 315:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        CashAuditScreen(onClose = { cashAuditOpen = false; settingsOpen = true })
```

**Dòng 316:** Kết thúc hàm và trả kết quả.

```kotlin
        return
```

**Dòng 317:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 318:** Điều kiện if.

```kotlin
    if (transferCheckOpen) {
```

**Dòng 319:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        TransferCheckScreen(onClose = { transferCheckOpen = false; settingsOpen = true })
```

**Dòng 320:** Kết thúc hàm và trả kết quả.

```kotlin
        return
```

**Dòng 321:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 322:** Điều kiện if.

```kotlin
    if (coordinateUpdateOpen) {
```

**Dòng 323:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        CoordinateUpdateScreen(
```

**Dòng 324:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            status = backupStatus,
```

**Dòng 325:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            onSave = onUpdateCoordinates,
```

**Dòng 326:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            onConfirmRouteChange = {
```

**Dòng 327:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                onSyncOrdersFromCustomerCoordinates()
```

**Dòng 328:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                confirmRouteChange()
```

**Dòng 329:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            },
```

**Dòng 330:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            onClose = { coordinateUpdateOpen = false; orderManagementOpen = true },
```

**Dòng 331:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        )
```

**Dòng 332:** Kết thúc hàm và trả kết quả.

```kotlin
        return
```

**Dòng 333:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 334:** Chạy coroutine theo key.

```kotlin
    LaunchedEffect(currentGps, orders, stableRouteSequence, zones) {
```

**Dòng 335:** Điều kiện if.

```kotlin
        if (stableRouteSequence.isEmpty()) {
```

**Dòng 336:** Biến chỉ đọc.

```kotlin
            val origin = findRouteOrigin(orders, currentGps)
```

**Dòng 337:** Điều kiện if.

```kotlin
            if (origin != null) {
```

**Dòng 338:** Biến chỉ đọc.

```kotlin
                val initial = buildRouteSequence(orders, origin)
```

**Dòng 339:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                stableRouteSequence = initial
```

**Dòng 340:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                onRouteSequenceLocked(initial)
```

**Dòng 341:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 342:** Biến chỉ đọc.

```kotlin
        val displayOrders = orders.withStableRouteLabels(previewRouteSequence ?: stableRouteSequence)
```

**Dòng 343:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        Column(Modifier.fillMaxSize().background(AppBackground).statusBarsPadding().navigationBarsPadding()) {
```

**Dòng 344:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
```

**Dòng 345:** Nút tương tác; onClick xử lý nhấn.

```kotlin
            IconButton(onClick = { settingsOpen = true }) { Icon(Icons.Filled.Settings, "Cài đặt", tint = Color(0xFF12385F)) }
```

**Dòng 346:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            Text("GIAO HÀNG THEO CÁCH CỦA BẠN", modifier = Modifier.weight(1f), color = Color(0xFFE57B22), fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
```

**Dòng 347:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 348:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        Box(Modifier.weight(1f)) {
```

**Dòng 349:** Chú thích, không thực thi.

```kotlin
            // Giữ bản đồ luôn trong composition. Khi đổi tab chỉ ẩn lớp hiển thị,
```

**Dòng 350:** Chú thích, không thực thi.

```kotlin
            // không tháo MapView nên không gọi onDestroy và không tải lại style/map tiles.
```

**Dòng 351:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            MapDeliveryScreen(
```

**Dòng 352:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                orders = displayOrders,
```

**Dòng 353:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                selectedNavigationOrder = selectedNavigationOrder,
```

**Dòng 354:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                selectedWaybill = selectedWaybill,
```

**Dòng 355:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                onRouteSequencePreview = { previewRouteSequence = it },
```

**Dòng 356:** Phép so sánh/điều kiện.

```kotlin
                onRouteSequenceLocked = { updated -> previewRouteSequence = null; stableRouteSequence = updated; onRouteSequenceLocked(updated) },
```

**Dòng 357:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                onSelectNavigation = { selectedNavigationOrder = it; selectedWaybill = it.waybill },
```

**Dòng 358:** Phép so sánh/điều kiện.

```kotlin
                onSelectOrder = { order -> selectedWaybill = order.waybill; selectedNavigationOrder = order },
```

**Dòng 359:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                onReturnToNearest = { selectedNavigationOrder = null },
```

**Dòng 360:** Phép so sánh/điều kiện.

```kotlin
                onOpenDetail = { order -> selectedWaybill = order.waybill; selectedNavigationOrder = order; detailSearchQuery = order.waybill; tab = DeliveryTab.DETAIL },
```

**Dòng 361:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                locationGranted = locationGranted,
```

**Dòng 362:** Phép so sánh/điều kiện.

```kotlin
                onLocationChanged = { latitude, longitude ->
```

**Dòng 363:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    currentGps = GeoPoint(latitude, longitude)
```

**Dòng 364:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    currentGpsUpdatedAt = System.currentTimeMillis()
```

**Dòng 365:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                },
```

**Dòng 366:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
                modifier = Modifier.fillMaxSize().padding(top = 8.dp).alpha(if (tab == DeliveryTab.MAP) 1f else 0f),
```

**Dòng 367:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            )
```

**Dòng 368:** Điều kiện if.

```kotlin
            if (tab != DeliveryTab.MAP) when (tab) {
```

**Dòng 369:** Phép so sánh/điều kiện.

```kotlin
            DeliveryTab.DETAIL -> OrderDetailScreen(
```

**Dòng 370:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                orders = displayOrders,
```

**Dòng 371:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                searchQuery = detailSearchQuery,
```

**Dòng 372:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                onSearchChange = { detailSearchQuery = it },
```

**Dòng 373:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                selectedWaybill = selectedWaybill,
```

**Dòng 374:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                scrollToTopRequest = detailScrollTopRequest,
```

**Dòng 375:** Phép so sánh/điều kiện.

```kotlin
                onSelectOrder = { order -> selectedWaybill = order.waybill; selectedNavigationOrder = order },
```

**Dòng 376:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                onOpenScanner = { scannerOpen = true },
```

**Dòng 377:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                onDelivered = { completingOrder = it },
```

**Dòng 378:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                onCall = onCall,
```

**Dòng 379:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                onZalo = { onZalo(it, transferMessage(it)) },
```

**Dòng 380:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                onSms = { onSms(it, transferMessage(it)) },
```

**Dòng 381:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                onOpenCustomer = { selectedWaybill = it.waybill; focusPhone = it.phone; tab = DeliveryTab.CUSTOMERS },
```

**Dòng 382:** Phép so sánh/điều kiện.

```kotlin
                onNavigateOrder = { order -> selectedWaybill = order.waybill; selectedNavigationOrder = order; tab = DeliveryTab.MAP },
```

**Dòng 383:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            )
```

**Dòng 384:** Phép so sánh/điều kiện.

```kotlin
            DeliveryTab.CUSTOMERS -> CustomerList(
```

**Dòng 385:** Lọc collection.

```kotlin
                customerProfiles.filterNot { CustomerProfileStore.isDeleted(context, it.id) },
```

**Dòng 386:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                focusPhone,
```

**Dòng 387:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                onSaveCustomer,
```

**Dòng 388:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                onDeleteCustomer,
```

**Dòng 389:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            ) {
```

**Dòng 390:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                currentGps?.takeIf { RealtimeLocationPolicy.isFreshLastKnown(currentGpsUpdatedAt, System.currentTimeMillis()) }
```

**Dòng 391:** Safe-call: chỉ chạy khi khác null.

```kotlin
                    ?.let { gps -> gps.latitude to gps.longitude }
```

**Dòng 392:** Elvis: dùng giá trị dự phòng khi null.

```kotlin
                    ?: onGetCustomerCoordinates()
```

**Dòng 393:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 394:** Phép so sánh/điều kiện.

```kotlin
            DeliveryTab.MAP -> Unit
```

**Dòng 395:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 396:** Điều kiện if.

```kotlin
            if (tab == DeliveryTab.DETAIL) {
```

**Dòng 397:** Nút tương tác; onClick xử lý nhấn.

```kotlin
                IconButton(
```

**Dòng 398:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    onClick = { detailScrollTopRequest += 1 },
```

**Dòng 399:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
                    modifier = Modifier.align(Alignment.BottomStart).padding(start = 22.dp, bottom = 18.dp).size(62.dp).background(Color(0xFF12385F), androidx.compose.foundation.shape.CircleShape),
```

**Dòng 400:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                ) {
```

**Dòng 401:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
                    Icon(Icons.Filled.ArrowUpward, contentDescription = "Về đầu danh sách", tint = Color.White, modifier = Modifier.size(31.dp))
```

**Dòng 402:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                }
```

**Dòng 403:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 404:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 405:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        Box(Modifier.fillMaxWidth()) {
```

**Dòng 406:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            Row(Modifier.fillMaxWidth().background(AppSurface).padding(horizontal = 10.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
```

**Dòng 407:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
                TabButton("Bản đồ", Icons.Filled.Map, tab == DeliveryTab.MAP, Modifier.weight(1f)) { tab = DeliveryTab.MAP }
```

**Dòng 408:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            TabButton("Chi tiết", Icons.Filled.ReceiptLong, tab == DeliveryTab.DETAIL, Modifier.weight(1f)) { tab = DeliveryTab.DETAIL }
```

**Dòng 409:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
                TabButton("Khách hàng", Icons.Filled.People, tab == DeliveryTab.CUSTOMERS, Modifier.weight(1f)) { tab = DeliveryTab.CUSTOMERS }
```

**Dòng 410:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 411:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 412:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 413:** Safe-call: chỉ chạy khi khác null.

```kotlin
    completingOrder?.let { order ->
```

**Dòng 414:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        DeliveryCompletionDialog(
```

**Dòng 415:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            order = order,
```

**Dòng 416:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            onDismiss = { completingOrder = null },
```

**Dòng 417:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            onConfirm = {
```

**Dòng 418:** Biến chỉ đọc.

```kotlin
                val nextOrder = nextOrderAfterCompletion(orders, order)
```

**Dòng 419:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                onDirectDelivered(order)
```

**Dòng 420:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                completingOrder = null
```

**Dòng 421:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                detailSearchQuery = ""
```

**Dòng 422:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                selectedWaybill = nextOrder?.waybill
```

**Dòng 423:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                selectedNavigationOrder = nextOrder
```

**Dòng 424:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            },
```

**Dòng 425:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        )
```

**Dòng 426:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 427:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 428:** Dòng trống — phân tách nhóm.

```kotlin

```

## `app/src/main/java/com/example/delivery/ui/GoonOnlyMapScreen.kt`

**Dòng 1:** Khai báo package/namespace.

```kotlin
package com.example.delivery.ui\n\nimport com.example.delivery.map.GoongMapStyleLoader\nimport android.annotation.SuppressLint\nimport android.content.Context\nimport android.graphics.Bitmap\nimport android.graphics.Canvas\nimport android.graphics.Paint\nimport android.graphics.Typeface\nimport android.location.Location\nimport android.location.LocationListener\nimport android.location.LocationManager\nimport android.os.Looper\nimport androidx.compose.foundation.background\nimport androidx.compose.foundation.layout.Box\nimport androidx.compose.foundation.layout.Column\nimport androidx.compose.foundation.layout.fillMaxSize\nimport androidx.compose.foundation.layout.padding\nimport androidx.compose.foundation.layout.size\nimport androidx.compose.foundation.shape.RoundedCornerShape\nimport androidx.compose.material.icons.Icons\nimport androidx.compose.material.icons.filled.Add\nimport androidx.compose.material.icons.filled.MyLocation\nimport androidx.compose.material.icons.filled.Remove\nimport androidx.compose.material3.Card\nimport androidx.compose.material3.CardDefaults\nimport androidx.compose.material3.Icon\nimport androidx.compose.material3.IconButton\nimport androidx.compose.runtime.Composable\nimport androidx.compose.runtime.DisposableEffect\nimport androidx.compose.runtime.LaunchedEffect\nimport androidx.compose.runtime.getValue\nimport androidx.compose.runtime.mutableStateOf\nimport androidx.compose.runtime.remember\nimport androidx.compose.runtime.saveable.rememberSaveable\nimport androidx.compose.runtime.setValue\nimport androidx.compose.ui.Alignment\nimport androidx.compose.ui.Modifier\nimport androidx.compose.ui.graphics.Color\nimport androidx.compose.ui.graphics.toArgb\nimport androidx.compose.ui.unit.dp\nimport androidx.compose.ui.viewinterop.AndroidView\nimport androidx.lifecycle.Lifecycle\nimport androidx.lifecycle.LifecycleEventObserver\nimport androidx.lifecycle.compose.LocalLifecycleOwner\nimport com.example.delivery.BuildConfig\nimport com.example.delivery.model.DeliveryOrder\nimport com.example.delivery.model.DeliveryOutcome\nimport com.example.delivery.model.DeliveryStatus\nimport com.example.delivery.model.deliveryOutcome\nimport com.example.delivery.model.hasStoredCoordinates\nimport com.example.delivery.model.isMapVisible\nimport com.example.delivery.model.isPickupAtWarehouse\nimport com.example.delivery.model.isRouteActive\nimport com.example.delivery.model.sequenceText\nimport com.example.delivery.model.csvStatus\nimport com.example.delivery.navigation.GeoPoint\nimport com.example.delivery.navigation.GoongDirectionsRepository\nimport com.example.delivery.location.RealtimeLocationPolicy\nimport org.maplibre.android.MapLibre\nimport org.maplibre.android.annotations.IconFactory\nimport org.maplibre.android.annotations.MarkerOptions\nimport org.maplibre.android.annotations.PolylineOptions\nimport org.maplibre.android.camera.CameraPosition\nimport org.maplibre.android.camera.CameraUpdateFactory\nimport org.maplibre.android.geometry.LatLng\nimport org.maplibre.android.maps.MapLibreMap\nimport org.maplibre.android.maps.MapView\nimport org.maplibre.android.maps.Style\n\n@Composable\nfun GoonOnlyMapScreen(\n    orders: List<DeliveryOrder>,\n    selectedNavigationOrder: DeliveryOrder?,\n    locationGranted: Boolean,\n    onLocationChanged: (Double, Double) -> Unit,\n    onSelectOrder: (DeliveryOrder) -> Unit,\n    modifier: Modifier = Modifier,\n) {\n    val context = androidx.compose.ui.platform.LocalContext.current\n    var location by remember(context) { mutableStateOf<Location?>(null) }\n    var route by remember { mutableStateOf<List<GeoPoint>>(emptyList()) }\n    var map by remember { mutableStateOf<MapLibreMap?>(null) }\n    var centerOnFirstFix by rememberSaveable { mutableStateOf(true) }\n    val mapOrders = orders.filter { it.hasStoredCoordinates() && it.csvStatus() != DeliveryStatus.TT505 }\n    val activeOrders = mapOrders.filter { it.isRouteActive() }\n    val target = selectedNavigationOrder?.takeIf { it.hasStoredCoordinates() } ?: activeOrders.minByOrNull { it.sequence }\n    val latitude = location?.latitude ?: 10.7769\n    val longitude = location?.longitude ?: 106.7009\n    val directions = remember { GoongDirectionsRepository() }\n\n    if (locationGranted) LocationUpdates(context, location?.time) { freshLocation ->\n        location = freshLocation\n        onLocationChanged(freshLocation.latitude, freshLocation.longitude)\n    }\n    LaunchedEffect(target?.waybill, latitude, longitude) {\n        if (target == null) {\n            route = emptyList()\n        } else {\n            directions.directions(GeoPoint(latitude, longitude), GeoPoint(target.latitude, target.longitude))\n                .onSuccess { route = it.points }\n                .onFailure { route = emptyList() }\n        }\n    }\n    LaunchedEffect(map, location?.time) {\n        if (centerOnFirstFix) location?.let { fix ->\n            map?.animateCamera(CameraUpdateFactory.newLatLngZoom(LatLng(fix.latitude, fix.longitude), 15.5))\n            centerOnFirstFix = false\n        }\n    }\n    DisposableEffect(map, mapOrders, onSelectOrder) {\n        val readyMap = map ?: return@DisposableEffect onDispose { }\n        val listener = MapLibreMap.OnMarkerClickListener { marker ->\n            val waybill = marker.snippet ?: return@OnMarkerClickListener false\n            val order = mapOrders.firstOrNull { it.waybill == waybill } ?: return@OnMarkerClickListener false\n            onSelectOrder(order)\n            true\n        }\n        readyMap.setOnMarkerClickListener(listener)\n        onDispose { readyMap.setOnMarkerClickListener(null) }\n    }\n    LaunchedEffect(map, route, mapOrders, location?.latitude, location?.longitude, location?.time) {\n        map?.let { readyMap -> renderOverlays(readyMap, context, location, route, mapOrders, target) }\n    }\n    Box(modifier = modifier.background(AppBackground)) {\n        NativeMapView(latitude, longitude, route, mapOrders, onMapReady = { map = it }, modifier = Modifier.fillMaxSize())\n        // Chừa khoảng trống cố định cho bảng danh sách phủ từ đáy lên, để cả ba nút map luôn bấm được.\n        Column(modifier = Modifier.align(Alignment.CenterStart).padding(start = 12.dp, bottom = 160.dp)) {\n            MapButton(Icons.Filled.MyLocation, "Vị trí hiện tại") { map?.animateCamera(CameraUpdateFactory.newLatLngZoom(LatLng(latitude, longitude), 15.5)) }\n            MapButton(Icons.Filled.Add, "Phóng to") { map?.animateCamera(CameraUpdateFactory.zoomIn()) }\n            MapButton(Icons.Filled.Remove, "Thu nhỏ") { map?.animateCamera(CameraUpdateFactory.zoomOut()) }\n        }\n    }\n}\n\n@Composable\nprivate fun MapButton(icon: androidx.compose.ui.graphics.vector.ImageVector, description: String, action: () -> Unit) {\n    Card(shape = RoundedCornerShape(50), colors = CardDefaults.cardColors(containerColor = AppSurface), elevation = CardDefaults.cardElevation(defaultElevation = 0.dp), modifier = Modifier.padding(vertical = 4.dp)) {\n        IconButton(onClick = action, modifier = Modifier.size(48.dp)) { Icon(icon, description, tint = Color(0xFF12385F)) }\n    }\n}\n\n@Composable\nprivate fun NativeMapView(latitude: Double, longitude: Double, route: List<GeoPoint>, orders: List<DeliveryOrder>, onMapReady: (MapLibreMap) -> Unit, modifier: Modifier) {\n    val context = androidx.compose.ui.platform.LocalContext.current\n    val lifecycle = LocalLifecycleOwner.current.lifecycle\n    val mapView = remember(context) { MapLibre.getInstance(context); MapView(context).also { it.onCreate(null) } }\n    DisposableEffect(mapView, lifecycle) {\n        val observer = LifecycleEventObserver { _, event -> when (event) { Lifecycle.Event.ON_START -> mapView.onStart(); Lifecycle.Event.ON_RESUME -> mapView.onResume(); Lifecycle.Event.ON_PAUSE -> mapView.onPause(); Lifecycle.Event.ON_STOP -> mapView.onStop(); else -> Unit } }\n        lifecycle.addObserver(observer)\n        onDispose { lifecycle.removeObserver(observer); mapView.onDestroy() }\n    }\n    AndroidView(modifier = modifier, factory = {\n        mapView.apply {\n            getMapAsync { map ->\n                map.setTileCacheEnabled(true)\n                map.setStyle(Style.Builder().fromJson(GoongMapStyleLoader.load(context))) {\n                    map.cameraPosition = CameraPosition.Builder().target(LatLng(latitude, longitude)).zoom(14.0).build()\n                    onMapReady(map)\n                }\n            }\n        }\n    }, update = { view -> view.getMapAsync { map -> if (map.style != null) onMapReady(map) } })\n}\n\nprivate fun renderOverlays(map: MapLibreMap, context: Context, userLocation: Location?, route: List<GeoPoint>, orders: List<DeliveryOrder>, selectedOrder: DeliveryOrder?) {\n    map.clear()\n    val safeRoute = route.filter { point -> point.latitude.isFinite() && point.longitude.isFinite() && point.latitude in -90.0..90.0 && point.longitude in -180.0..180.0 }\n    if (safeRoute.size > 1) map.addPolyline(PolylineOptions().addAll(safeRoute.map { LatLng(it.latitude, it.longitude) }).color(0xFFFF7043.toInt()).width(6f))\n    orders.filter(DeliveryOrder::hasStoredCoordinates).filter { it.waybill != selectedOrder?.waybill }.forEach { order ->\n        val pickup = order.isPickupAtWarehouse()\n        map.addMarker(\n            MarkerOptions()\n                .position(LatLng(order.latitude, order.longitude))\n                .title(if (pickup) "Tới kho lấy" else "Đơn #${order.sequence}")\n                .snippet(order.waybill)\n                .icon(markerIcon(context, if (pickup) "" else order.sequenceText(), markerColor(order))),\n        )\n    }\n    userLocation?.let { fix ->\n        map.addMarker(MarkerOptions().position(LatLng(fix.latitude, fix.longitude)).title("Vị trí hiện tại").icon(markerIcon(context, "GPS", 0xFF12385F.toInt())))\n    }\n    selectedOrder?.takeIf { it.hasStoredCoordinates() }?.let { order ->\n        map.addMarker(\n            MarkerOptions()\n                .position(LatLng(order.latitude, order.longitude))\n                .title("Đang giao • ${order.waybill}")\n                .snippet(order.waybill)\n                .icon(markerIcon(context, if (order.sequenceText().isNotBlank()) order.sequenceText() else "•", 0xFFE4572E.toInt())),\n        )\n    }\n}\n\nprivate fun markerColor(order: DeliveryOrder): Int = when {\n    order.deliveryOutcome() == DeliveryOutcome.PICKUP_AT_WAREHOUSE -> 0xFF6B47A1.toInt()\n    order.deliveryOutcome() == DeliveryOutcome.TEMPORARY_FAILURE -> 0xFFE17E18.toInt()\n    order.deliveryOutcome() == DeliveryOutcome.TERMINAL_FAILURE -> 0xFFD83A3A.toInt()\n    else -> 0xFF1E73BE.toInt()\n}\n\nprivate fun markerIcon(context: Context, text: String, color: Int): org.maplibre.android.annotations.Icon {\n    val density = context.resources.displayMetrics.density; val size = (44 * density).toInt()\n    val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888); val canvas = Canvas(bitmap); val paint = Paint(Paint.ANTI_ALIAS_FLAG)\n    paint.color = color; canvas.drawCircle(size / 2f, size / 2f, size / 2f - density, paint); paint.color = Color.White.toArgb(); paint.textAlign = Paint.Align.CENTER; paint.typeface = Typeface.DEFAULT_BOLD; paint.textSize = if (text == "GPS") 10 * density else 18 * density\n    canvas.drawText(text, size / 2f, size / 2f - (paint.ascent() + paint.descent()) / 2f, paint)\n    return IconFactory.getInstance(context).fromBitmap(bitmap)\n}\n\n@SuppressLint("MissingPermission")\n@Composable\nprivate fun LocationUpdates(context: Context, currentFixTime: Long?, update: (Location) -> Unit) {\n    DisposableEffect(context) {\n        val manager = context.getSystemService(LocationManager::class.java)\n        var newestFixTime = currentFixTime\n        var acceptedLocation: Location? = null\n        val listener = object : LocationListener {\n            override fun onLocationChanged(location: Location) {\n                val previous = acceptedLocation\n                val accurateEnough = location.accuracy.isFinite() && location.accuracy <= 60f\n                val movedEnough = previous == null || previous.distanceTo(location) >= 5f\n                val materiallyBetter = previous != null && location.accuracy + 8f < previous.accuracy\n                if (accurateEnough && RealtimeLocationPolicy.shouldAccept(newestFixTime, location.time) && (movedEnough || materiallyBetter)) {\n                    newestFixTime = location.time\n                    acceptedLocation = location\n                    update(location)\n                }\n            }\n        }\n        val now = System.currentTimeMillis()\n        listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)\n            .mapNotNull { provider -> runCatching { manager.getLastKnownLocation(provider) }.getOrNull() }\n            .filter { RealtimeLocationPolicy.isFreshLastKnown(it.time, now) && it.accuracy.isFinite() && it.accuracy <= 60f }\n            .minWithOrNull(compareBy<Location> { it.accuracy }.thenByDescending { it.time })\n            ?.let(listener::onLocationChanged)\n        listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER).forEach { provider ->\n            runCatching {\n                if (manager.isProviderEnabled(provider)) {\n                    manager.requestLocationUpdates(provider, 1_500L, 1f, listener, Looper.getMainLooper())\n                }\n            }\n        }\n        onDispose { manager.removeUpdates(listener) }\n    }\n}\n
```

## `app/src/main/java/com/example/delivery/ui/MapDeliveryComponents.kt`

**Dòng 1:** Khai báo package/namespace.

```kotlin
package com.example.delivery.ui
```

**Dòng 2:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 3:** Import dependency.

```kotlin
import android.Manifest
```

**Dòng 4:** Import dependency.

```kotlin
import android.app.Activity
```

**Dòng 5:** Import dependency.

```kotlin
import android.content.Context
```

**Dòng 6:** Import dependency.

```kotlin
import android.widget.Toast
```

**Dòng 7:** Import dependency.

```kotlin
import android.content.Intent
```

**Dòng 8:** Import dependency.

```kotlin
import android.content.pm.PackageManager
```

**Dòng 9:** Import dependency.

```kotlin
import android.graphics.BitmapFactory
```

**Dòng 10:** Import dependency.

```kotlin
import android.net.Uri
```

**Dòng 11:** Import dependency.

```kotlin
import androidx.activity.compose.BackHandler
```

**Dòng 12:** Import dependency.

```kotlin
import androidx.activity.compose.rememberLauncherForActivityResult
```

**Dòng 13:** Import dependency.

```kotlin
import androidx.activity.result.contract.ActivityResultContracts
```

**Dòng 14:** Import dependency.

```kotlin
import androidx.compose.foundation.Image
```

**Dòng 15:** Import dependency.

```kotlin
import androidx.compose.foundation.background
```

**Dòng 16:** Import dependency.

```kotlin
import androidx.compose.foundation.border
```

**Dòng 17:** Import dependency.

```kotlin
import androidx.compose.foundation.clickable
```

**Dòng 18:** Import dependency.

```kotlin
import androidx.compose.foundation.ExperimentalFoundationApi
```

**Dòng 19:** Import dependency.

```kotlin
import androidx.compose.foundation.interaction.MutableInteractionSource
```

**Dòng 20:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.Arrangement
```

**Dòng 21:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.Box
```

**Dòng 22:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.Column
```

**Dòng 23:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.Row
```

**Dòng 24:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.Spacer
```

**Dòng 25:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.fillMaxSize
```

**Dòng 26:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.fillMaxHeight
```

**Dòng 27:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.fillMaxWidth
```

**Dòng 28:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.height
```

**Dòng 29:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.heightIn
```

**Dòng 30:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.imePadding
```

**Dòng 31:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.navigationBarsPadding
```

**Dòng 32:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.offset
```

**Dòng 33:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.padding
```

**Dòng 34:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.size
```

**Dòng 35:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.width
```

**Dòng 36:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.statusBarsPadding
```

**Dòng 37:** Import dependency.

```kotlin
import androidx.compose.foundation.rememberScrollState
```

**Dòng 38:** Import dependency.

```kotlin
import androidx.compose.foundation.relocation.BringIntoViewRequester
```

**Dòng 39:** Import dependency.

```kotlin
import androidx.compose.foundation.relocation.bringIntoViewRequester
```

**Dòng 40:** Import dependency.

```kotlin
import androidx.compose.foundation.verticalScroll
```

**Dòng 41:** Import dependency.

```kotlin
import androidx.compose.foundation.lazy.LazyColumn
```

**Dòng 42:** Import dependency.

```kotlin
import androidx.compose.foundation.lazy.items
```

**Dòng 43:** Import dependency.

```kotlin
import androidx.compose.foundation.lazy.itemsIndexed
```

**Dòng 44:** Import dependency.

```kotlin
import androidx.compose.foundation.lazy.rememberLazyListState
```

**Dòng 45:** Import dependency.

```kotlin
import androidx.compose.foundation.shape.RoundedCornerShape
```

**Dòng 46:** Import dependency.

```kotlin
import androidx.compose.material.icons.Icons
```

**Dòng 47:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.ArrowUpward
```

**Dòng 48:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.Map
```

**Dòng 49:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.Add
```

**Dòng 50:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.ArrowDropDown
```

**Dòng 51:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.CameraAlt
```

**Dòng 52:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.Close
```

**Dòng 53:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.Delete
```

**Dòng 54:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.Edit
```

**Dòng 55:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.LocationOn
```

**Dòng 56:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.Navigation
```

**Dòng 57:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.Pause
```

**Dòng 58:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.People
```

**Dòng 59:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.Phone
```

**Dòng 60:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.ReceiptLong
```

**Dòng 61:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.Remove
```

**Dòng 62:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.Settings
```

**Dòng 63:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.Sms
```

**Dòng 64:** Import dependency.

```kotlin
import androidx.compose.material3.AlertDialog
```

**Dòng 65:** Import dependency.

```kotlin
import androidx.compose.material3.Button
```

**Dòng 66:** Import dependency.

```kotlin
import androidx.compose.material3.ButtonDefaults
```

**Dòng 67:** Import dependency.

```kotlin
import androidx.compose.material3.Card
```

**Dòng 68:** Import dependency.

```kotlin
import androidx.compose.material3.CardDefaults
```

**Dòng 69:** Import dependency.

```kotlin
import androidx.compose.material3.Checkbox
```

**Dòng 70:** Import dependency.

```kotlin
import androidx.compose.material3.DropdownMenu
```

**Dòng 71:** Import dependency.

```kotlin
import androidx.compose.material3.DropdownMenuItem
```

**Dòng 72:** Import dependency.

```kotlin
import androidx.compose.material3.Icon
```

**Dòng 73:** Import dependency.

```kotlin
import androidx.compose.material3.IconButton
```

**Dòng 74:** Import dependency.

```kotlin
import androidx.compose.material3.OutlinedButton
```

**Dòng 75:** Import dependency.

```kotlin
import androidx.compose.material3.OutlinedTextField
```

**Dòng 76:** Import dependency.

```kotlin
import androidx.compose.material3.Surface
```

**Dòng 77:** Import dependency.

```kotlin
import androidx.compose.material3.Text
```

**Dòng 78:** Import dependency.

```kotlin
import androidx.compose.runtime.Composable
```

**Dòng 79:** Import dependency.

```kotlin
import androidx.compose.runtime.LaunchedEffect
```

**Dòng 80:** Import dependency.

```kotlin
import androidx.compose.runtime.getValue
```

**Dòng 81:** Import dependency.

```kotlin
import androidx.compose.runtime.mutableStateOf
```

**Dòng 82:** Import dependency.

```kotlin
import androidx.compose.runtime.remember
```

**Dòng 83:** Import dependency.

```kotlin
import androidx.compose.runtime.saveable.rememberSaveable
```

**Dòng 84:** Import dependency.

```kotlin
import androidx.compose.runtime.setValue
```

**Dòng 85:** Import dependency.

```kotlin
import androidx.compose.ui.Alignment
```

**Dòng 86:** Import dependency.

```kotlin
import androidx.compose.ui.Modifier
```

**Dòng 87:** Import dependency.

```kotlin
import androidx.compose.ui.draw.clip
```

**Dòng 88:** Import dependency.

```kotlin
import androidx.compose.ui.draw.alpha
```

**Dòng 89:** Import dependency.

```kotlin
import androidx.compose.ui.focus.onFocusChanged
```

**Dòng 90:** Import dependency.

```kotlin
import androidx.compose.ui.platform.LocalFocusManager
```

**Dòng 91:** Import dependency.

```kotlin
import androidx.compose.foundation.text.KeyboardActions
```

**Dòng 92:** Import dependency.

```kotlin
import androidx.compose.foundation.text.KeyboardOptions
```

**Dòng 93:** Import dependency.

```kotlin
import androidx.compose.ui.text.input.ImeAction
```

**Dòng 94:** Import dependency.

```kotlin
import androidx.compose.ui.graphics.Color
```

**Dòng 95:** Import dependency.

```kotlin
import androidx.compose.ui.graphics.asImageBitmap
```

**Dòng 96:** Import dependency.

```kotlin
import androidx.compose.ui.layout.ContentScale
```

**Dòng 97:** Import dependency.

```kotlin
import androidx.compose.ui.platform.LocalContext
```

**Dòng 98:** Import dependency.

```kotlin
import androidx.compose.ui.text.font.FontWeight
```

**Dòng 99:** Import dependency.

```kotlin
import androidx.compose.ui.unit.dp
```

**Dòng 100:** Import dependency.

```kotlin
import androidx.compose.ui.unit.sp
```

**Dòng 101:** Import dependency.

```kotlin
import androidx.compose.ui.window.Dialog
```

**Dòng 102:** Import dependency.

```kotlin
import androidx.compose.ui.window.DialogProperties
```

**Dòng 103:** Import dependency.

```kotlin
import androidx.core.content.ContextCompat
```

**Dòng 104:** Import dependency.

```kotlin
import com.example.delivery.history.DeliveryPhotoHistory
```

**Dòng 105:** Import dependency.

```kotlin
import com.example.delivery.history.PaymentChannel
```

**Dòng 106:** Import dependency.

```kotlin
import com.example.delivery.history.ProofPhotoType
```

**Dòng 107:** Import dependency.

```kotlin
import com.example.delivery.history.TransferEvidence
```

**Dòng 108:** Import dependency.

```kotlin
import com.example.delivery.orderio.CoordinateUpdateRequest
```

**Dòng 109:** Import dependency.

```kotlin
import com.example.delivery.orderio.CoordinateTextParser
```

**Dòng 110:** Import dependency.

```kotlin
import com.example.delivery.location.RealtimeLocationPolicy
```

**Dòng 111:** Import dependency.

```kotlin
import com.example.delivery.customer.CustomerAddress
```

**Dòng 112:** Import dependency.

```kotlin
import com.example.delivery.customer.CustomerContactMethod
```

**Dòng 113:** Import dependency.

```kotlin
import com.example.delivery.customer.CustomerPhone
```

**Dòng 114:** Import dependency.

```kotlin
import com.example.delivery.customer.CustomerProfile
```

**Dòng 115:** Import dependency.

```kotlin
import com.example.delivery.customer.CustomerProfileStore
```

**Dòng 116:** Import dependency.

```kotlin
import com.example.delivery.customer.matchesSearch
```

**Dòng 117:** Import dependency.

```kotlin
import com.example.delivery.model.DeliveryOrder
```

**Dòng 118:** Import dependency.

```kotlin
import com.example.delivery.model.DeliveryOutcome
```

**Dòng 119:** Import dependency.

```kotlin
import com.example.delivery.model.DeliveryStatus
```

**Dòng 120:** Import dependency.

```kotlin
import com.example.delivery.model.hasStoredCoordinates
```

**Dòng 121:** Import dependency.

```kotlin
import com.example.delivery.model.canReceiveRouteSequence
```

**Dòng 122:** Import dependency.

```kotlin
import com.example.delivery.model.dispatchDisplayOrder
```

**Dòng 123:** Import dependency.

```kotlin
import com.example.delivery.model.formatVnd
```

**Dòng 124:** Import dependency.

```kotlin
import com.example.delivery.model.isMapVisible
```

**Dòng 125:** Import dependency.

```kotlin
import com.example.delivery.model.isPickupAtWarehouse
```

**Dòng 126:** Import dependency.

```kotlin
import com.example.delivery.model.isRouteActive
```

**Dòng 127:** Import dependency.

```kotlin
import com.example.delivery.model.statusLabel
```

**Dòng 128:** Import dependency.

```kotlin
import com.example.delivery.model.withStableRouteLabels
```

**Dòng 129:** Import dependency.

```kotlin
import com.example.delivery.model.resequenceDraftLabels
```

**Dòng 130:** Import dependency.

```kotlin
import com.example.delivery.model.sequenceText
```

**Dòng 131:** Import dependency.

```kotlin
import com.example.delivery.ui.logic.isValidRouteSequenceText
```

**Dòng 132:** Import dependency.

```kotlin
import com.example.delivery.model.sequenceSortValue
```

**Dòng 133:** Import dependency.

```kotlin
import com.example.delivery.model.csvStatus
```

**Dòng 134:** Import dependency.

```kotlin
import com.example.delivery.navigation.DeliveryRouteStore
```

**Dòng 135:** Import dependency.

```kotlin
import com.example.delivery.navigation.DeliveryZone
```

**Dòng 136:** Import dependency.

```kotlin
import com.example.delivery.navigation.GeoPoint
```

**Dòng 137:** Import dependency.

```kotlin
import com.example.delivery.navigation.persistedRouteLabels
```

**Dòng 138:** Import dependency.

```kotlin
import com.example.delivery.navigation.preferredRouteOrigin
```

**Dòng 139:** Import dependency.

```kotlin
import com.example.delivery.navigation.routeOrdersFrom
```

**Dòng 140:** Import dependency.

```kotlin
import kotlinx.coroutines.delay
```

**Dòng 141:** Import dependency.

```kotlin
import java.util.Locale
```

**Dòng 142:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 143:** Chú thích, không thực thi.

```kotlin
// UI GROUP: MAP
```

**Dòng 144:** Chú thích, không thực thi.

```kotlin
// Chứa riêng UI bản đồ và sheet danh sách đơn.
```

**Dòng 145:** Đánh dấu hàm UI Compose.

```kotlin
@Composable
```

**Dòng 146:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
internal fun MapDeliveryScreen(
```

**Dòng 147:** Phép so sánh/điều kiện.

```kotlin
    orders: List<DeliveryOrder>,
```

**Dòng 148:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    selectedNavigationOrder: DeliveryOrder?,
```

**Dòng 149:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    selectedWaybill: String?,
```

**Dòng 150:** Phép so sánh/điều kiện.

```kotlin
    onRouteSequencePreview: (Map<String, String>?) -> Unit,
```

**Dòng 151:** Phép so sánh/điều kiện.

```kotlin
    onRouteSequenceLocked: (Map<String, String>) -> Unit,
```

**Dòng 152:** Phép so sánh/điều kiện.

```kotlin
    onSelectNavigation: (DeliveryOrder) -> Unit,
```

**Dòng 153:** Phép so sánh/điều kiện.

```kotlin
    onSelectOrder: (DeliveryOrder) -> Unit,
```

**Dòng 154:** Phép so sánh/điều kiện.

```kotlin
    onReturnToNearest: () -> Unit,
```

**Dòng 155:** Phép so sánh/điều kiện.

```kotlin
    onOpenDetail: (DeliveryOrder) -> Unit,
```

**Dòng 156:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    locationGranted: Boolean,
```

**Dòng 157:** Phép so sánh/điều kiện.

```kotlin
    onLocationChanged: (Double, Double) -> Unit,
```

**Dòng 158:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    modifier: Modifier,
```

**Dòng 159:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
) {
```

**Dòng 160:** Biến chỉ đọc.

```kotlin
    val mapOrders = orders.filter(DeliveryOrder::isMapVisible)
```

**Dòng 161:** Biến chỉ đọc.

```kotlin
    val activeOrders = orders.filter { it.isRouteActive() && it.hasStoredCoordinates() }
```

**Dòng 162:** Biến chỉ đọc.

```kotlin
    val target = selectedNavigationOrder?.let { selected -> activeOrders.firstOrNull { it.waybill == selected.waybill } } ?: activeOrders.firstOrNull()
```

**Dòng 163:** Container xếp/chồng UI.

```kotlin
    Box(modifier) {
```

**Dòng 164:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        GoonOnlyMapScreen(
```

**Dòng 165:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            orders = mapOrders,
```

**Dòng 166:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            selectedNavigationOrder = target,
```

**Dòng 167:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            locationGranted = locationGranted,
```

**Dòng 168:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            onLocationChanged = onLocationChanged,
```

**Dòng 169:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            onSelectOrder = onSelectOrder,
```

**Dòng 170:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            modifier = Modifier.fillMaxSize(),
```

**Dòng 171:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        )
```

**Dòng 172:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        MapOrderSheet(
```

**Dòng 173:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            orders = mapOrders,
```

**Dòng 174:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            target = target,
```

**Dòng 175:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            selectedWaybill = selectedWaybill,
```

**Dòng 176:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            onRouteSequencePreview = onRouteSequencePreview,
```

**Dòng 177:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            onRouteSequenceLocked = onRouteSequenceLocked,
```

**Dòng 178:** Phép so sánh/điều kiện.

```kotlin
            manuallySelected = selectedNavigationOrder != null,
```

**Dòng 179:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            onSelectNavigation = onSelectNavigation,
```

**Dòng 180:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            onSelectOrder = onSelectOrder,
```

**Dòng 181:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            onReturnToNearest = onReturnToNearest,
```

**Dòng 182:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            onOpenDetail = onOpenDetail,
```

**Dòng 183:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            modifier = Modifier.fillMaxWidth().fillMaxHeight(0.44f).align(Alignment.BottomCenter),
```

**Dòng 184:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        )
```

**Dòng 185:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 186:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 187:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 188:** Đánh dấu hàm UI Compose.

```kotlin
@Composable
```

**Dòng 189:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
private fun MapOrderSheet(
```

**Dòng 190:** Phép so sánh/điều kiện.

```kotlin
    orders: List<DeliveryOrder>,
```

**Dòng 191:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    target: DeliveryOrder?,
```

**Dòng 192:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    selectedWaybill: String?,
```

**Dòng 193:** Phép so sánh/điều kiện.

```kotlin
    onRouteSequencePreview: (Map<String, String>?) -> Unit,
```

**Dòng 194:** Phép so sánh/điều kiện.

```kotlin
    onRouteSequenceLocked: (Map<String, String>) -> Unit,
```

**Dòng 195:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    manuallySelected: Boolean,
```

**Dòng 196:** Phép so sánh/điều kiện.

```kotlin
    onSelectNavigation: (DeliveryOrder) -> Unit,
```

**Dòng 197:** Phép so sánh/điều kiện.

```kotlin
    onSelectOrder: (DeliveryOrder) -> Unit,
```

**Dòng 198:** Phép so sánh/điều kiện.

```kotlin
    onReturnToNearest: () -> Unit,
```

**Dòng 199:** Phép so sánh/điều kiện.

```kotlin
    onOpenDetail: (DeliveryOrder) -> Unit,
```

**Dòng 200:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    modifier: Modifier,
```

**Dòng 201:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
) {
```

**Dòng 202:** Biến chỉ đọc.

```kotlin
    val listState = rememberLazyListState()
```

**Dòng 203:** Biến chỉ đọc.

```kotlin
    val focusManager = LocalFocusManager.current
```

**Dòng 204:** Biến có thể thay đổi.

```kotlin
    var editingSequence by remember { mutableStateOf(false) }
```

**Dòng 205:** Biến có thể thay đổi.

```kotlin
    var saveSequenceConfirmation by remember { mutableStateOf(false) }
```

**Dòng 206:** Biến có thể thay đổi.

```kotlin
    var sequenceDrafts by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
```

**Dòng 207:** Biến có thể thay đổi.

```kotlin
    var previewSequenceSort by remember { mutableStateOf(false) }
```

**Dòng 208:** Biến chỉ đọc.

```kotlin
    val displayedOrders = if (editingSequence && previewSequenceSort) orders.withStableRouteLabels(sequenceDrafts) else orders
```

**Dòng 209:** Chạy coroutine theo key.

```kotlin
    LaunchedEffect(selectedWaybill, orders) {
```

**Dòng 210:** Biến chỉ đọc.

```kotlin
        val index = selectedOrderIndex(orders, selectedWaybill)
```

**Dòng 211:** Điều kiện if.

```kotlin
        if (index >= 0) listState.animateScrollToItem(index)
```

**Dòng 212:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 213:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    Card(
```

**Dòng 214:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        modifier = modifier.fillMaxWidth(),
```

**Dòng 215:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
```

**Dòng 216:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        colors = CardDefaults.cardColors(containerColor = AppSurface),
```

**Dòng 217:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
```

**Dòng 218:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    ) {
```

**Dòng 219:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        Column(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 12.dp)) {
```

**Dòng 220:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
```

**Dòng 221:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
                Text("${orders.count { it.isRouteActive() }} ĐANG GIAO", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 11.sp, modifier = Modifier.background(Color(0xFFFF7043), RoundedCornerShape(16.dp)).padding(horizontal = 11.dp, vertical = 9.dp).weight(1f))
```

**Dòng 222:** Nút tương tác; onClick xử lý nhấn.

```kotlin
                Button(
```

**Dòng 223:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    onClick = {
```

**Dòng 224:** Điều kiện if.

```kotlin
                        if (editingSequence) saveSequenceConfirmation = true
```

**Dòng 225:** Nhánh thay thế.

```kotlin
                        else {
```

**Dòng 226:** Tạo Map key/value.

```kotlin
                            sequenceDrafts = orders.associate { it.waybill to it.sequenceText() }
```

**Dòng 227:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                            previewSequenceSort = false
```

**Dòng 228:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                            editingSequence = true
```

**Dòng 229:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        }
```

**Dòng 230:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    },
```

**Dòng 231:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E73BE)),
```

**Dòng 232:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
                    modifier = Modifier.height(38.dp),
```

**Dòng 233:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                ) { Text(if (editingSequence) "Lưu" else "Sửa", fontSize = 12.sp) }
```

**Dòng 234:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 235:** Danh sách lazy.

```kotlin
            LazyColumn(
```

**Dòng 236:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                state = listState,
```

**Dòng 237:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
                modifier = Modifier.weight(1f).fillMaxWidth().padding(top = 9.dp),
```

**Dòng 238:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                verticalArrangement = Arrangement.spacedBy(7.dp),
```

**Dòng 239:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            ) {
```

**Dòng 240:** Phép so sánh/điều kiện.

```kotlin
                items(displayedOrders, key = { it.waybill }) { order ->
```

**Dòng 241:** Biến chỉ đọc.

```kotlin
                    val selected = order.waybill == selectedWaybill
```

**Dòng 242:** Biến chỉ đọc.

```kotlin
                    val active = order.waybill == target?.waybill
```

**Dòng 243:** Biến chỉ đọc.

```kotlin
                    val navigable = order.isRouteActive()
```

**Dòng 244:** Container ngang.

```kotlin
                    Row(
```

**Dòng 245:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
                        modifier = Modifier.fillMaxWidth().background(if (selected) Color(0xFFE4F0FB) else if (active) Color(0xFFFBEDE3) else AppSurfaceMuted, RoundedCornerShape(15.dp)).clickable(onClick = { onSelectOrder(order); onOpenDetail(order) }).padding(11.dp),
```

**Dòng 246:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        verticalAlignment = Alignment.CenterVertically,
```

**Dòng 247:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    ) {
```

**Dòng 248:** Điều kiện if.

```kotlin
                        if (editingSequence && order.canReceiveRouteSequence() && order.hasStoredCoordinates()) {
```

**Dòng 249:** Ô nhập liệu.

```kotlin
                            OutlinedTextField(
```

**Dòng 250:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                                value = sequenceDrafts[order.waybill].orEmpty(),
```

**Dòng 251:** Phép so sánh/điều kiện.

```kotlin
                                onValueChange = { value ->
```

**Dòng 252:** Biến chỉ đọc.

```kotlin
                                    val filtered = value.lowercase().filter { it.isDigit() || it == '.' || it == 'n' }
```

**Dòng 253:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                                    sequenceDrafts = sequenceDrafts + (order.waybill to filtered)
```

**Dòng 254:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                                },
```

**Dòng 255:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
                                modifier = Modifier.width(62.dp).onFocusChanged { focus ->
```

**Dòng 256:** Điều kiện if.

```kotlin
                                    if (!focus.isFocused) {
```

**Dòng 257:** Biến chỉ đọc.

```kotlin
                                        val original = orders.associate { it.waybill to it.sequenceText() }
```

**Dòng 258:** Biến chỉ đọc.

```kotlin
                                        val reindexed = orders.resequenceDraftLabels(sequenceDrafts, original)
```

**Dòng 259:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                                        sequenceDrafts = reindexed
```

**Dòng 260:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                                        previewSequenceSort = true
```

**Dòng 261:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                                        onRouteSequencePreview(reindexed)
```

**Dòng 262:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                                    }
```

**Dòng 263:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                                },
```

**Dòng 264:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                                singleLine = true,
```

**Dòng 265:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
```

**Dòng 266:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                                keyboardActions = KeyboardActions(onDone = { focusManager.clearFocus(force = true) }),
```

**Dòng 267:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 12.sp, fontWeight = FontWeight.Bold),
```

**Dòng 268:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                            )
```

**Dòng 269:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        } else if (order.sequenceText().isNotBlank()) {
```

**Dòng 270:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
                            Text(order.sequenceText(), color = Color.White, fontWeight = FontWeight.ExtraBold, modifier = Modifier.background(sequenceColor(order), RoundedCornerShape(50)).padding(horizontal = 12.dp, vertical = 8.dp))
```

**Dòng 271:** Nút tương tác; onClick xử lý nhấn.

```kotlin
                            IconButton(enabled = navigable, onClick = { if (active && manuallySelected) onReturnToNearest() else onSelectNavigation(order) }) {
```

**Dòng 272:** Hiển thị icon.

```kotlin
                                Icon(if (active && manuallySelected) Icons.Filled.Pause else Icons.Filled.Navigation, if (active && manuallySelected) "Tạm dừng" else "Dẫn đường", tint = Color(0xFF12385F))
```

**Dòng 273:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                            }
```

**Dòng 274:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        } else if (order.isPickupAtWarehouse()) {
```

**Dòng 275:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
                            Text("KHO", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 10.sp, modifier = Modifier.background(Color(0xFF6B47A1), RoundedCornerShape(50)).padding(horizontal = 8.dp, vertical = 9.dp))
```

**Dòng 276:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        } else {
```

**Dòng 277:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
                            Spacer(Modifier.width(42.dp))
```

**Dòng 278:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        }
```

**Dòng 279:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
                        Column(Modifier.weight(1f).padding(start = 10.dp)) {
```

**Dòng 280:** Container ngang.

```kotlin
                            Row(verticalAlignment = Alignment.CenterVertically) {
```

**Dòng 281:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
                                Text(order.waybill, color = Color(0xFF12385F), fontWeight = FontWeight.ExtraBold, fontSize = 13.sp, modifier = Modifier.weight(1f))
```

**Dòng 282:** Hiển thị văn bản.

```kotlin
                                Text(order.cod.formatVnd(), color = Color(0xFFFF7043), fontWeight = FontWeight.ExtraBold, fontSize = 12.sp)
```

**Dòng 283:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                            }
```

**Dòng 284:** Hiển thị văn bản.

```kotlin
                            Text("${order.customer} · ${order.statusLabel()}", color = Color(0xFF68727C), fontSize = 11.sp)
```

**Dòng 285:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        }
```

**Dòng 286:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    }
```

**Dòng 287:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                }
```

**Dòng 288:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 289:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 290:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 291:** Điều kiện if.

```kotlin
    if (saveSequenceConfirmation) {
```

**Dòng 292:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        AlertDialog(
```

**Dòng 293:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            onDismissRequest = { saveSequenceConfirmation = false },
```

**Dòng 294:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            title = { Text("Xác nhận lưu STT") },
```

**Dòng 295:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            text = { Text("Bạn có muốn lưu thay đổi không?") },
```

**Dòng 296:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            confirmButton = {
```

**Dòng 297:** Nút tương tác; onClick xử lý nhấn.

```kotlin
                Button(onClick = {
```

**Dòng 298:** Biến chỉ đọc.

```kotlin
                    val original = orders.associate { it.waybill to it.sequenceText() }
```

**Dòng 299:** Biến chỉ đọc.

```kotlin
                    val reindexed = orders.resequenceDraftLabels(sequenceDrafts, original)
```

**Dòng 300:** Biến chỉ đọc.

```kotlin
                    val updated = reindexed.mapNotNull { (waybill, value) ->
```

**Dòng 301:** Biến chỉ đọc.

```kotlin
                        val normalized = value.trim()
```

**Dòng 302:** Biến chỉ đọc.

```kotlin
                        val valid = isValidRouteSequenceText(normalized)
```

**Dòng 303:** Safe-call: chỉ chạy khi khác null.

```kotlin
                        normalized.takeIf { valid }?.let { waybill to it }
```

**Dòng 304:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    }.toMap()
```

**Dòng 305:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    onRouteSequenceLocked(updated)
```

**Dòng 306:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    previewSequenceSort = false
```

**Dòng 307:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    saveSequenceConfirmation = false
```

**Dòng 308:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    editingSequence = false
```

**Dòng 309:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    sequenceDrafts = emptyMap()
```

**Dòng 310:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                }) { Text("Có") }
```

**Dòng 311:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            },
```

**Dòng 312:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            dismissButton = { OutlinedButton(onClick = { onRouteSequencePreview(null); previewSequenceSort = false; saveSequenceConfirmation = false; editingSequence = false; sequenceDrafts = emptyMap() }) { Text("Không") } },
```

**Dòng 313:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        )
```

**Dòng 314:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 315:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 316:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 317:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
private fun sequenceColor(order: DeliveryOrder): Color = when {
```

**Dòng 318:** Phép so sánh/điều kiện.

```kotlin
    order.isPickupAtWarehouse() -> Color(0xFF6B47A1)
```

**Dòng 319:** Nhánh thay thế.

```kotlin
    else -> Color(0xFF1E73BE)
```

**Dòng 320:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 321:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 322:** Đánh dấu hàm UI Compose.

```kotlin
@Composable
```

**Dòng 323:** Phép so sánh/điều kiện.

```kotlin
private fun TabButton(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
```

**Dòng 324:** Biến chỉ đọc.

```kotlin
    val interactionSource = remember { MutableInteractionSource() }
```

**Dòng 325:** Container ngang.

```kotlin
    Row(
```

**Dòng 326:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        modifier = modifier.background(if (selected) Color(0xFF12385F) else Color.Transparent, RoundedCornerShape(10.dp)).clickable(interactionSource = interactionSource, indication = null, onClick = onClick).padding(vertical = 9.dp),
```

**Dòng 327:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        horizontalArrangement = Arrangement.Center,
```

**Dòng 328:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        verticalAlignment = Alignment.CenterVertically,
```

**Dòng 329:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    ) {
```

**Dòng 330:** Hiển thị icon.

```kotlin
        Icon(icon, null, tint = if (selected) Color.White else Color(0xFF12385F))
```

**Dòng 331:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        Spacer(Modifier.width(5.dp)); Text(label, color = if (selected) Color.White else Color(0xFF12385F), fontSize = 11.sp, fontWeight = FontWeight.Bold)
```

**Dòng 332:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 333:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 334:** Dòng trống — phân tách nhóm.

```kotlin

```

## `app/src/main/java/com/example/delivery/ui/OrderDetailScreen.kt`

**Dòng 1:** Khai báo package/namespace.

```kotlin
package com.example.delivery.ui
```

**Dòng 2:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 3:** Import dependency.

```kotlin
import androidx.compose.foundation.background
```

**Dòng 4:** Import dependency.

```kotlin
import androidx.compose.foundation.border
```

**Dòng 5:** Import dependency.

```kotlin
import androidx.compose.foundation.clickable
```

**Dòng 6:** Import dependency.

```kotlin
import androidx.compose.foundation.rememberScrollState
```

**Dòng 7:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.Arrangement
```

**Dòng 8:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.Box
```

**Dòng 9:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.Column
```

**Dòng 10:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.Row
```

**Dòng 11:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.Spacer
```

**Dòng 12:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.fillMaxWidth
```

**Dòng 13:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.height
```

**Dòng 14:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.padding
```

**Dòng 15:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.size
```

**Dòng 16:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.width
```

**Dòng 17:** Import dependency.

```kotlin
import androidx.compose.foundation.verticalScroll
```

**Dòng 18:** Import dependency.

```kotlin
import androidx.compose.foundation.lazy.LazyColumn
```

**Dòng 19:** Import dependency.

```kotlin
import androidx.compose.foundation.lazy.items
```

**Dòng 20:** Import dependency.

```kotlin
import androidx.compose.foundation.lazy.rememberLazyListState
```

**Dòng 21:** Import dependency.

```kotlin
import androidx.compose.foundation.shape.RoundedCornerShape
```

**Dòng 22:** Import dependency.

```kotlin
import androidx.compose.material.icons.Icons
```

**Dòng 23:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.ArrowUpward
```

**Dòng 24:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.Call
```

**Dòng 25:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.CameraAlt
```

**Dòng 26:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.CheckCircle
```

**Dòng 27:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.Close
```

**Dòng 28:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.Message
```

**Dòng 29:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.Person
```

**Dòng 30:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.QrCodeScanner
```

**Dòng 31:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.Search
```

**Dòng 32:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.Sms
```

**Dòng 33:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.Wallet
```

**Dòng 34:** Import dependency.

```kotlin
import androidx.compose.material3.AlertDialog
```

**Dòng 35:** Import dependency.

```kotlin
import androidx.compose.material3.Button
```

**Dòng 36:** Import dependency.

```kotlin
import androidx.compose.material3.Icon
```

**Dòng 37:** Import dependency.

```kotlin
import androidx.compose.material3.IconButton
```

**Dòng 38:** Import dependency.

```kotlin
import androidx.compose.material3.OutlinedTextField
```

**Dòng 39:** Import dependency.

```kotlin
import androidx.compose.material3.Text
```

**Dòng 40:** Import dependency.

```kotlin
import androidx.compose.material3.TextButton
```

**Dòng 41:** Import dependency.

```kotlin
import androidx.compose.runtime.Composable
```

**Dòng 42:** Import dependency.

```kotlin
import androidx.compose.runtime.LaunchedEffect
```

**Dòng 43:** Import dependency.

```kotlin
import androidx.compose.runtime.getValue
```

**Dòng 44:** Import dependency.

```kotlin
import androidx.compose.runtime.mutableStateOf
```

**Dòng 45:** Import dependency.

```kotlin
import androidx.compose.runtime.remember
```

**Dòng 46:** Import dependency.

```kotlin
import androidx.compose.runtime.setValue
```

**Dòng 47:** Import dependency.

```kotlin
import androidx.compose.ui.Alignment
```

**Dòng 48:** Import dependency.

```kotlin
import androidx.compose.ui.Modifier
```

**Dòng 49:** Import dependency.

```kotlin
import androidx.compose.ui.graphics.Color
```

**Dòng 50:** Import dependency.

```kotlin
import androidx.compose.ui.text.font.FontWeight
```

**Dòng 51:** Import dependency.

```kotlin
import androidx.compose.ui.text.style.TextOverflow
```

**Dòng 52:** Import dependency.

```kotlin
import androidx.compose.ui.unit.dp
```

**Dòng 53:** Import dependency.

```kotlin
import androidx.compose.ui.unit.sp
```

**Dòng 54:** Import dependency.

```kotlin
import com.example.delivery.model.DeliveryOrder
```

**Dòng 55:** Import dependency.

```kotlin
import com.example.delivery.model.DeliveryOutcome
```

**Dòng 56:** Import dependency.

```kotlin
import com.example.delivery.model.deliveryOutcome
```

**Dòng 57:** Import dependency.

```kotlin
import com.example.delivery.model.detailStatusLabel
```

**Dòng 58:** Import dependency.

```kotlin
import com.example.delivery.model.dispatchDisplayOrder
```

**Dòng 59:** Import dependency.

```kotlin
import com.example.delivery.model.filterForDetail
```

**Dòng 60:** Import dependency.

```kotlin
import com.example.delivery.model.formatVnd
```

**Dòng 61:** Import dependency.

```kotlin
import com.example.delivery.model.isPickupAtWarehouse
```

**Dòng 62:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 63:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
private val DetailNavy = Color(0xFF12385F)
```

**Dòng 64:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
private val DetailGreen = Color(0xFF229846)
```

**Dòng 65:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
private val DetailRed = Color(0xFFC83B3B)
```

**Dòng 66:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 67:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
private data class ExpandedDetail(val title: String, val value: String)
```

**Dòng 68:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 69:** Phép so sánh/điều kiện.

```kotlin
internal fun selectedOrderIndex(orders: List<DeliveryOrder>, selectedWaybill: String?): Int =
```

**Dòng 70:** Safe-call: chỉ chạy khi khác null.

```kotlin
    selectedWaybill?.let { waybill -> orders.indexOfFirst { it.waybill == waybill } } ?: -1
```

**Dòng 71:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 72:** Đánh dấu hàm UI Compose.

```kotlin
@Composable
```

**Dòng 73:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
fun OrderDetailScreen(
```

**Dòng 74:** Phép so sánh/điều kiện.

```kotlin
    orders: List<DeliveryOrder>,
```

**Dòng 75:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    searchQuery: String,
```

**Dòng 76:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    selectedWaybill: String?,
```

**Dòng 77:** Phép so sánh/điều kiện.

```kotlin
    onSelectOrder: (DeliveryOrder) -> Unit,
```

**Dòng 78:** Phép so sánh/điều kiện.

```kotlin
    onSearchChange: (String) -> Unit,
```

**Dòng 79:** Phép so sánh/điều kiện.

```kotlin
    onOpenScanner: () -> Unit,
```

**Dòng 80:** Phép so sánh/điều kiện.

```kotlin
    onDelivered: (DeliveryOrder) -> Unit,
```

**Dòng 81:** Phép so sánh/điều kiện.

```kotlin
    onCall: (DeliveryOrder) -> Unit,
```

**Dòng 82:** Phép so sánh/điều kiện.

```kotlin
    onZalo: (DeliveryOrder) -> Unit,
```

**Dòng 83:** Phép so sánh/điều kiện.

```kotlin
    onSms: (DeliveryOrder) -> Unit,
```

**Dòng 84:** Phép so sánh/điều kiện.

```kotlin
    onOpenCustomer: (DeliveryOrder) -> Unit,
```

**Dòng 85:** Phép so sánh/điều kiện.

```kotlin
    onNavigateOrder: (DeliveryOrder) -> Unit,
```

**Dòng 86:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    scrollToTopRequest: Int = 0,
```

**Dòng 87:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
) {
```

**Dòng 88:** Biến có thể thay đổi.

```kotlin
    var showDelivered by remember { mutableStateOf(false) }
```

**Dòng 89:** Biến có thể thay đổi.

```kotlin
    var expandedDetail by remember { mutableStateOf<ExpandedDetail?>(null) }
```

**Dòng 90:** Biến chỉ đọc.

```kotlin
    val visible = orders.filterForDetail(searchQuery, showDelivered, false)
```

**Dòng 91:** Biến chỉ đọc.

```kotlin
    val exactOrder = searchQuery.trim().takeIf { it.isNotBlank() }?.let { query ->
```

**Dòng 92:** Lấy phần tử đầu hoặc null.

```kotlin
        orders.firstOrNull { it.waybill.equals(query, ignoreCase = true) }
```

**Dòng 93:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 94:** Biến chỉ đọc.

```kotlin
    val visibleGroups = if (exactOrder != null) {
```

**Dòng 95:** Biến chỉ đọc.

```kotlin
        val groupKey = exactOrder.phone.filter(Char::isDigit).ifBlank { exactOrder.waybill }
```

**Dòng 96:** Lọc collection.

```kotlin
        orders.filter { it.phone.filter(Char::isDigit).ifBlank { it.waybill } == groupKey }
```

**Dòng 97:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            .dispatchDisplayOrder()
```

**Dòng 98:** Phép so sánh/điều kiện.

```kotlin
            .let { group -> listOf(group) }
```

**Dòng 99:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    } else {
```

**Dòng 100:** Lọc collection.

```kotlin
        visible.groupBy { it.phone.filter(Char::isDigit).ifBlank { it.waybill } }.values.toList()
```

**Dòng 101:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 102:** Biến chỉ đọc.

```kotlin
    val displayedOrders = visibleGroups.flatten()
```

**Dòng 103:** Biến chỉ đọc.

```kotlin
    val listState = rememberLazyListState()
```

**Dòng 104:** Chạy coroutine theo key.

```kotlin
    LaunchedEffect(selectedWaybill, searchQuery, showDelivered, orders) {
```

**Dòng 105:** Biến chỉ đọc.

```kotlin
        val index = visibleGroups.indexOfFirst { group: List<DeliveryOrder> -> group.any { order -> order.waybill == selectedWaybill } }
```

**Dòng 106:** Điều kiện if.

```kotlin
        if (index >= 0) listState.animateScrollToItem(index)
```

**Dòng 107:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 108:** Chạy coroutine theo key.

```kotlin
    LaunchedEffect(scrollToTopRequest) {
```

**Dòng 109:** Điều kiện if.

```kotlin
        if (scrollToTopRequest > 0) listState.animateScrollToItem(0)
```

**Dòng 110:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 111:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 112:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
    Column(modifier = Modifier.background(AppBackground)) {
```

**Dòng 113:** Container ngang.

```kotlin
        Row(
```

**Dòng 114:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 7.dp),
```

**Dòng 115:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            verticalAlignment = Alignment.CenterVertically,
```

**Dòng 116:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            horizontalArrangement = Arrangement.spacedBy(7.dp),
```

**Dòng 117:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        ) {
```

**Dòng 118:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            Box(modifier = Modifier.size(46.dp).background(DetailNavy, RoundedCornerShape(12.dp)).clickable(onClick = onOpenScanner), contentAlignment = Alignment.Center) {
```

**Dòng 119:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
                Icon(Icons.Filled.QrCodeScanner, "Quét mã QR", tint = Color.White, modifier = Modifier.size(27.dp))
```

**Dòng 120:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 121:** Ô nhập liệu.

```kotlin
            OutlinedTextField(
```

**Dòng 122:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                value = searchQuery,
```

**Dòng 123:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                onValueChange = onSearchChange,
```

**Dòng 124:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
                modifier = Modifier.weight(1f),
```

**Dòng 125:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                singleLine = true,
```

**Dòng 126:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
                leadingIcon = { Icon(Icons.Filled.Search, null, modifier = Modifier.size(18.dp)) },
```

**Dòng 127:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                trailingIcon = if (searchQuery.isNotBlank()) {
```

**Dòng 128:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
                    { IconButton(onClick = { onSearchChange("") }) { Icon(Icons.Filled.Close, "Xóa tìm kiếm", modifier = Modifier.size(18.dp)) } }
```

**Dòng 129:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                } else null,
```

**Dòng 130:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                placeholder = { Text("Mã đơn, SĐT, khách, tiền", fontSize = 12.sp) },
```

**Dòng 131:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            )
```

**Dòng 132:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 133:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 13.dp, vertical = 3.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
```

**Dòng 134:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            StatusToggle("Đã giao", showDelivered, DetailGreen, Modifier.width(82.dp)) { showDelivered = !showDelivered }
```

**Dòng 135:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 136:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        Text("DANH SÁCH ${displayedOrders.size} ĐƠN", color = Color(0xFF78838F), fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(start = 15.dp, top = 4.dp, bottom = 6.dp))
```

**Dòng 137:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        LazyColumn(state = listState, modifier = Modifier.weight(1f), contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 3.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
```

**Dòng 138:** Phép so sánh/điều kiện.

```kotlin
            items(visibleGroups, key = { group -> group.first().phone + group.first().waybill }) { group ->
```

**Dòng 139:** Điều kiện if.

```kotlin
                if (group.size > 1) GroupedOrderBlock(group, selectedWaybill, onSelectOrder, onDelivered, onCall, onZalo, onSms, onOpenCustomer, onNavigateOrder) else {
```

**Dòng 140:** Biến chỉ đọc.

```kotlin
                    val order = group.first()
```

**Dòng 141:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                CompactOrderCard(
```

**Dòng 142:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    order = order,
```

**Dòng 143:** Phép so sánh/điều kiện.

```kotlin
                    selected = order.waybill == selectedWaybill,
```

**Dòng 144:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    onSelectOrder = { onSelectOrder(order) },
```

**Dòng 145:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    onDelivered = onDelivered,
```

**Dòng 146:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    onCall = onCall,
```

**Dòng 147:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    onZalo = onZalo,
```

**Dòng 148:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    onSms = onSms,
```

**Dòng 149:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    onOpenCustomer = onOpenCustomer,
```

**Dòng 150:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    onNavigateOrder = onNavigateOrder,
```

**Dòng 151:** Phép so sánh/điều kiện.

```kotlin
                    onExpand = { title, value -> expandedDetail = ExpandedDetail(title, value) },
```

**Dòng 152:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    )
```

**Dòng 153:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                }
```

**Dòng 154:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 155:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 156:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 157:** Safe-call: chỉ chạy khi khác null.

```kotlin
    expandedDetail?.let { detail ->
```

**Dòng 158:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        AlertDialog(
```

**Dòng 159:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            onDismissRequest = { expandedDetail = null },
```

**Dòng 160:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            title = { Text(detail.title) },
```

**Dòng 161:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            text = { Text(detail.value) },
```

**Dòng 162:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            confirmButton = {},
```

**Dòng 163:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        )
```

**Dòng 164:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 165:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 166:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 167:** Đánh dấu hàm UI Compose.

```kotlin
@Composable
```

**Dòng 168:** Phép so sánh/điều kiện.

```kotlin
private fun StatusToggle(label: String, selected: Boolean, tint: Color, modifier: Modifier, onClick: () -> Unit) {
```

**Dòng 169:** Hiển thị văn bản.

```kotlin
    Text(label, color = if (selected) Color.White else tint, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = modifier.background(if (selected) tint else tint.copy(alpha = 0.14f), RoundedCornerShape(8.dp)).clickable(onClick = onClick).padding(vertical = 5.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
```

**Dòng 170:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 171:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 172:** Đánh dấu hàm UI Compose.

```kotlin
@Composable
```

**Dòng 173:** Phép so sánh/điều kiện.

```kotlin
fun ManualOrderEntryDialog(onDismiss: () -> Unit, onSave: (DeliveryOrder) -> Unit) {
```

**Dòng 174:** Biến có thể thay đổi.

```kotlin
    var waybill by remember { mutableStateOf("") }
```

**Dòng 175:** Biến có thể thay đổi.

```kotlin
    var customer by remember { mutableStateOf("") }
```

**Dòng 176:** Biến có thể thay đổi.

```kotlin
    var phone by remember { mutableStateOf("") }
```

**Dòng 177:** Biến có thể thay đổi.

```kotlin
    var address by remember { mutableStateOf("") }
```

**Dòng 178:** Biến có thể thay đổi.

```kotlin
    var product by remember { mutableStateOf("") }
```

**Dòng 179:** Biến có thể thay đổi.

```kotlin
    var cod by remember { mutableStateOf("") }
```

**Dòng 180:** Biến có thể thay đổi.

```kotlin
    var service by remember { mutableStateOf("") }
```

**Dòng 181:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    AlertDialog(
```

**Dòng 182:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        onDismissRequest = onDismiss,
```

**Dòng 183:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        title = { Text("THÊM MÃ VẬN ĐƠN") },
```

**Dòng 184:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        text = {
```

**Dòng 185:** Giữ giá trị qua recomposition.

```kotlin
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
```

**Dòng 186:** Ô nhập liệu.

```kotlin
                OutlinedTextField(value = waybill, onValueChange = { waybill = it }, label = { Text("Mã vận đơn *") }, singleLine = true)
```

**Dòng 187:** Ô nhập liệu.

```kotlin
                OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("SĐT khách") }, singleLine = true)
```

**Dòng 188:** Ô nhập liệu.

```kotlin
                OutlinedTextField(value = customer, onValueChange = { customer = it }, label = { Text("Tên khách hàng") }, singleLine = true)
```

**Dòng 189:** Ô nhập liệu.

```kotlin
                OutlinedTextField(value = address, onValueChange = { address = it }, label = { Text("Địa chỉ") })
```

**Dòng 190:** Ô nhập liệu.

```kotlin
                OutlinedTextField(value = product, onValueChange = { product = it }, label = { Text("Hàng hóa") })
```

**Dòng 191:** Lọc collection.

```kotlin
                OutlinedTextField(value = cod, onValueChange = { cod = it.filter { character -> character.isDigit() } }, label = { Text("COD") }, singleLine = true)
```

**Dòng 192:** Ô nhập liệu.

```kotlin
                OutlinedTextField(value = service, onValueChange = { service = it }, label = { Text("Dịch vụ") }, singleLine = true)
```

**Dòng 193:** Hiển thị văn bản.

```kotlin
                Text("Nếu SĐT đã có tọa độ lưu trong Khách hàng, đơn được gán số cuối tuyến. Nếu chưa có, đơn được đưa lên đầu để bổ sung vị trí.", color = Color(0xFF68727C), fontSize = 11.sp)
```

**Dòng 194:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 195:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        },
```

**Dòng 196:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        confirmButton = {
```

**Dòng 197:** Nút tương tác; onClick xử lý nhấn.

```kotlin
            Button(enabled = waybill.isNotBlank(), onClick = {
```

**Dòng 198:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                onSave(
```

**Dòng 199:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    DeliveryOrder(
```

**Dòng 200:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        waybill = waybill,
```

**Dòng 201:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        customer = customer,
```

**Dòng 202:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        phone = phone,
```

**Dòng 203:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        address = address,
```

**Dòng 204:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        product = product,
```

**Dòng 205:** Elvis: dùng giá trị dự phòng khi null.

```kotlin
                        cod = cod.toLongOrNull() ?: 0L,
```

**Dòng 206:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                        service = service,
```

**Dòng 207:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    ),
```

**Dòng 208:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                )
```

**Dòng 209:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }) { Text("Thêm đơn") }
```

**Dòng 210:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        },
```

**Dòng 211:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        dismissButton = { androidx.compose.material3.OutlinedButton(onClick = onDismiss) { Text("Hủy") } },
```

**Dòng 212:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    )
```

**Dòng 213:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 214:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 215:** Đánh dấu hàm UI Compose.

```kotlin
@Composable
```

**Dòng 216:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
private fun GroupedOrderBlock(
```

**Dòng 217:** Phép so sánh/điều kiện.

```kotlin
    group: List<DeliveryOrder>, selectedWaybill: String?, onSelectOrder: (DeliveryOrder) -> Unit,
```

**Dòng 218:** Phép so sánh/điều kiện.

```kotlin
    onDelivered: (DeliveryOrder) -> Unit, onCall: (DeliveryOrder) -> Unit, onZalo: (DeliveryOrder) -> Unit,
```

**Dòng 219:** Phép so sánh/điều kiện.

```kotlin
    onSms: (DeliveryOrder) -> Unit, onOpenCustomer: (DeliveryOrder) -> Unit, onNavigateOrder: (DeliveryOrder) -> Unit,
```

**Dòng 220:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
) {
```

**Dòng 221:** Biến chỉ đọc.

```kotlin
    val first = group.first()
```

**Dòng 222:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
    Column(Modifier.fillMaxWidth().background(Color(0xFFEAF5F2), RoundedCornerShape(12.dp)).padding(6.dp)) {
```

**Dòng 223:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        Text("SĐT ${first.phone} · ${group.size} MVĐ · Tổng COD ${group.sumOf { it.cod }.formatVnd()}", color = DetailNavy, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp, modifier = Modifier.padding(6.dp))
```

**Dòng 224:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
```

**Dòng 225:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            ActionTile("Zalo", Icons.Filled.Message, Color(0xFF086AD8)) { onZalo(first) }
```

**Dòng 226:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            ActionTile("SMS", Icons.Filled.Sms, DetailNavy) { onSms(first) }
```

**Dòng 227:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            ActionTile("Gọi", Icons.Filled.Call, DetailNavy) { onCall(first) }
```

**Dòng 228:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 229:** Phép so sánh/điều kiện.

```kotlin
        group.forEach { order -> CompactOrderCard(order, order.waybill == selectedWaybill, { onSelectOrder(order) }, onDelivered, {}, {}, {}, onOpenCustomer, onNavigateOrder, { _, _ -> }, showUtilities = false) }
```

**Dòng 230:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 231:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 232:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 233:** Đánh dấu hàm UI Compose.

```kotlin
@Composable
```

**Dòng 234:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
private fun CompactOrderCard(
```

**Dòng 235:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    order: DeliveryOrder,
```

**Dòng 236:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    selected: Boolean,
```

**Dòng 237:** Phép so sánh/điều kiện.

```kotlin
    onSelectOrder: () -> Unit,
```

**Dòng 238:** Phép so sánh/điều kiện.

```kotlin
    onDelivered: (DeliveryOrder) -> Unit,
```

**Dòng 239:** Phép so sánh/điều kiện.

```kotlin
    onCall: (DeliveryOrder) -> Unit,
```

**Dòng 240:** Phép so sánh/điều kiện.

```kotlin
    onZalo: (DeliveryOrder) -> Unit,
```

**Dòng 241:** Phép so sánh/điều kiện.

```kotlin
    onSms: (DeliveryOrder) -> Unit,
```

**Dòng 242:** Phép so sánh/điều kiện.

```kotlin
    onOpenCustomer: (DeliveryOrder) -> Unit,
```

**Dòng 243:** Phép so sánh/điều kiện.

```kotlin
    onNavigateOrder: (DeliveryOrder) -> Unit,
```

**Dòng 244:** Phép so sánh/điều kiện.

```kotlin
    onExpand: (String, String) -> Unit,
```

**Dòng 245:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    showUtilities: Boolean = true,
```

**Dòng 246:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
) {
```

**Dòng 247:** Biến chỉ đọc.

```kotlin
    val outcome = order.deliveryOutcome()
```

**Dòng 248:** Biến chỉ đọc.

```kotlin
    val active = outcome == DeliveryOutcome.ACTIVE || outcome == DeliveryOutcome.PICKUP_AT_WAREHOUSE
```

**Dòng 249:** Container dọc.

```kotlin
    Column(
```

**Dòng 250:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        modifier = Modifier
```

**Dòng 251:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            .fillMaxWidth()
```

**Dòng 252:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            .background(orderBlockColor(outcome), RoundedCornerShape(12.dp))
```

**Dòng 253:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            .then(if (selected) Modifier.border(2.dp, DetailNavy, RoundedCornerShape(12.dp)) else Modifier)
```

**Dòng 254:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            .clickable(onClick = onSelectOrder),
```

**Dòng 255:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    ) {
```

**Dòng 256:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 11.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
```

**Dòng 257:** Điều kiện if.

```kotlin
            if (order.sequence > 0) Text(order.sequence.toString(), color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.background(DetailNavy, RoundedCornerShape(8.dp)).clickable(onClick = { onNavigateOrder(order) }).padding(horizontal = 9.dp, vertical = 7.dp)) else Spacer(Modifier.width(39.dp))
```

**Dòng 258:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            Spacer(Modifier.width(8.dp))
```

**Dòng 259:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            Row(modifier = Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
```

**Dòng 260:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
                Text(order.waybill, color = orderWaybillColor(outcome), fontWeight = FontWeight.ExtraBold, fontSize = 17.sp, maxLines = 1, modifier = Modifier.weight(1f, fill = false))
```

**Dòng 261:** Hiển thị văn bản.

```kotlin
                Text(order.detailStatusLabel(), color = orderWaybillColor(outcome), fontWeight = FontWeight.ExtraBold, fontSize = 12.sp, maxLines = 1)
```

**Dòng 262:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 263:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            Spacer(Modifier.width(8.dp))
```

**Dòng 264:** Hiển thị văn bản.

```kotlin
            Text(order.cod.formatVnd(), color = DetailGreen, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
```

**Dòng 265:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 266:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        DividerLine()
```

**Dòng 267:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        DetailRow(Icons.Filled.Person, "${order.customer} · ${order.phone}", onClick = { onOpenCustomer(order) })
```

**Dòng 268:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        DividerLine()
```

**Dòng 269:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        DetailRow(Icons.Filled.Search, order.address, onClick = { onExpand("Địa chỉ", order.address) })
```

**Dòng 270:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        DividerLine()
```

**Dòng 271:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        DetailRow(Icons.Filled.Wallet, order.product, onClick = { onExpand("Hàng hóa", order.product) })
```

**Dòng 272:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        DividerLine()
```

**Dòng 273:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        DetailRow(Icons.Filled.Wallet, order.service)
```

**Dòng 274:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        DividerLine()
```

**Dòng 275:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 5.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
```

**Dòng 276:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            ActionTile("Đã giao", Icons.Filled.CheckCircle, DetailGreen, enabled = active) { onDelivered(order) }
```

**Dòng 277:** Điều kiện if.

```kotlin
            if (!active) ActionTile("Đã xử lý", Icons.Filled.CheckCircle, Color(0xFF8A9299), enabled = false) {}
```

**Dòng 278:** Điều kiện if.

```kotlin
            if (showUtilities) {
```

**Dòng 279:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                ActionTile("Zalo", Icons.Filled.Message, Color(0xFF086AD8)) { onZalo(order) }
```

**Dòng 280:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                ActionTile("SMS", Icons.Filled.Sms, DetailNavy) { onSms(order) }
```

**Dòng 281:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                ActionTile("Gọi", Icons.Filled.Call, DetailNavy) { onCall(order) }
```

**Dòng 282:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            }
```

**Dòng 283:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 284:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 285:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 286:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 287:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
private fun orderBlockColor(outcome: DeliveryOutcome): Color = when (outcome) {
```

**Dòng 288:** Phép so sánh/điều kiện.

```kotlin
    DeliveryOutcome.DELIVERED -> Color(0xFFE8F6EC)
```

**Dòng 289:** Phép so sánh/điều kiện.

```kotlin
    DeliveryOutcome.TEMPORARY_FAILURE -> Color(0xFFFFF0DE)
```

**Dòng 290:** Phép so sánh/điều kiện.

```kotlin
    DeliveryOutcome.TERMINAL_FAILURE -> Color(0xFFFCE8E8)
```

**Dòng 291:** Phép so sánh/điều kiện.

```kotlin
    DeliveryOutcome.PICKUP_AT_WAREHOUSE -> Color(0xFFF2ECFA)
```

**Dòng 292:** Phép so sánh/điều kiện.

```kotlin
    DeliveryOutcome.ACTIVE -> AppSurface
```

**Dòng 293:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 294:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 295:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
private fun orderWaybillColor(outcome: DeliveryOutcome): Color = when (outcome) {
```

**Dòng 296:** Phép so sánh/điều kiện.

```kotlin
    DeliveryOutcome.DELIVERED -> DetailGreen
```

**Dòng 297:** Phép so sánh/điều kiện.

```kotlin
    DeliveryOutcome.TEMPORARY_FAILURE -> Color(0xFFE17E18)
```

**Dòng 298:** Phép so sánh/điều kiện.

```kotlin
    DeliveryOutcome.TERMINAL_FAILURE -> DetailRed
```

**Dòng 299:** Phép so sánh/điều kiện.

```kotlin
    DeliveryOutcome.PICKUP_AT_WAREHOUSE -> Color(0xFF6B47A1)
```

**Dòng 300:** Phép so sánh/điều kiện.

```kotlin
    DeliveryOutcome.ACTIVE -> DetailNavy
```

**Dòng 301:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 302:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 303:** Đánh dấu hàm UI Compose.

```kotlin
@Composable private fun DividerLine() = Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0xFFE7EAEE)))
```

**Dòng 304:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 305:** Đánh dấu hàm UI Compose.

```kotlin
@Composable
```

**Dòng 306:** Phép so sánh/điều kiện.

```kotlin
private fun DetailRow(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String, onClick: (() -> Unit)? = null) {
```

**Dòng 307:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
    Row(modifier = Modifier.fillMaxWidth().then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier).padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
```

**Dòng 308:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        Icon(icon, null, tint = Color(0xFF85909A), modifier = Modifier.size(18.dp))
```

**Dòng 309:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        Spacer(Modifier.width(12.dp))
```

**Dòng 310:** Hiển thị văn bản.

```kotlin
        Text(text, color = Color(0xFF3E454C), fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
```

**Dòng 311:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 312:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 313:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 314:** Đánh dấu hàm UI Compose.

```kotlin
@Composable
```

**Dòng 315:** Phép so sánh/điều kiện.

```kotlin
private fun ActionTile(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, tint: Color, enabled: Boolean = true, onClick: () -> Unit) {
```

**Dòng 316:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
    Column(modifier = Modifier.width(44.dp).then(if (enabled) Modifier.clickable(onClick = onClick) else Modifier).padding(vertical = 2.dp), horizontalAlignment = Alignment.CenterHorizontally) {
```

**Dòng 317:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        Icon(icon, null, tint = if (enabled) tint else Color(0xFFB8BDC2), modifier = Modifier.size(21.dp))
```

**Dòng 318:** Hiển thị văn bản.

```kotlin
        Text(label, color = if (enabled) tint else Color(0xFF8A9299), fontSize = 8.sp, fontWeight = FontWeight.Bold, maxLines = 1)
```

**Dòng 319:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 320:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

## `app/src/main/java/com/example/delivery/ui/SettingsScreen.kt`

**Dòng 1:** Khai báo package/namespace.

```kotlin
package com.example.delivery.ui
```

**Dòng 2:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 3:** Import dependency.

```kotlin
import androidx.compose.foundation.background
```

**Dòng 4:** Import dependency.

```kotlin
import androidx.compose.foundation.clickable
```

**Dòng 5:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.Column
```

**Dòng 6:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.Row
```

**Dòng 7:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.fillMaxSize
```

**Dòng 8:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.fillMaxWidth
```

**Dòng 9:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.padding
```

**Dòng 10:** Import dependency.

```kotlin
import androidx.compose.foundation.layout.statusBarsPadding
```

**Dòng 11:** Import dependency.

```kotlin
import androidx.compose.foundation.shape.RoundedCornerShape
```

**Dòng 12:** Import dependency.

```kotlin
import androidx.compose.material.icons.Icons
```

**Dòng 13:** Import dependency.

```kotlin
import androidx.compose.material.icons.filled.ArrowBack
```

**Dòng 14:** Import dependency.

```kotlin
import androidx.compose.material3.AlertDialog
```

**Dòng 15:** Import dependency.

```kotlin
import androidx.compose.material3.Button
```

**Dòng 16:** Import dependency.

```kotlin
import androidx.compose.material3.ButtonDefaults
```

**Dòng 17:** Import dependency.

```kotlin
import androidx.compose.material3.Icon
```

**Dòng 18:** Import dependency.

```kotlin
import androidx.compose.material3.IconButton
```

**Dòng 19:** Import dependency.

```kotlin
import androidx.compose.material3.OutlinedTextField
```

**Dòng 20:** Import dependency.

```kotlin
import androidx.compose.material3.Text
```

**Dòng 21:** Import dependency.

```kotlin
import androidx.compose.runtime.Composable
```

**Dòng 22:** Import dependency.

```kotlin
import androidx.compose.runtime.getValue
```

**Dòng 23:** Import dependency.

```kotlin
import androidx.compose.runtime.mutableStateOf
```

**Dòng 24:** Import dependency.

```kotlin
import androidx.compose.runtime.remember
```

**Dòng 25:** Import dependency.

```kotlin
import androidx.compose.runtime.setValue
```

**Dòng 26:** Import dependency.

```kotlin
import androidx.compose.ui.Alignment
```

**Dòng 27:** Import dependency.

```kotlin
import androidx.compose.ui.Modifier
```

**Dòng 28:** Import dependency.

```kotlin
import androidx.compose.ui.graphics.Color
```

**Dòng 29:** Import dependency.

```kotlin
import androidx.compose.ui.text.font.FontWeight
```

**Dòng 30:** Import dependency.

```kotlin
import androidx.compose.ui.unit.dp
```

**Dòng 31:** Import dependency.

```kotlin
import androidx.compose.ui.unit.sp
```

**Dòng 32:** Import dependency.

```kotlin
import com.example.delivery.history.TransferEvidence
```

**Dòng 33:** Import dependency.

```kotlin
import com.example.delivery.model.DeliveryOrder
```

**Dòng 34:** Import dependency.

```kotlin
import com.example.delivery.orderio.CoordinateUpdateRequest
```

**Dòng 35:** Import dependency.

```kotlin
import com.example.delivery.orderio.CoordinateTextParser
```

**Dòng 36:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 37:** Đánh dấu hàm UI Compose.

```kotlin
@Composable
```

**Dòng 38:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
fun SettingsScreen(
```

**Dòng 39:** Phép so sánh/điều kiện.

```kotlin
    evidence: List<TransferEvidence>,
```

**Dòng 40:** Phép so sánh/điều kiện.

```kotlin
    onConfirmPayment: (String) -> Unit,
```

**Dòng 41:** Phép so sánh/điều kiện.

```kotlin
    onOpenCashAudit: () -> Unit,
```

**Dòng 42:** Phép so sánh/điều kiện.

```kotlin
    onOpenBackup: () -> Unit,
```

**Dòng 43:** Phép so sánh/điều kiện.

```kotlin
    onOpenVtmanExport: () -> Unit,
```

**Dòng 44:** Phép so sánh/điều kiện.

```kotlin
    onOpenTransferCheck: () -> Unit,
```

**Dòng 45:** Phép so sánh/điều kiện.

```kotlin
    onOpenOrderManagement: () -> Unit,
```

**Dòng 46:** Phép so sánh/điều kiện.

```kotlin
    onOpenAnchorPoint: () -> Unit,
```

**Dòng 47:** Phép so sánh/điều kiện.

```kotlin
    onClose: () -> Unit,
```

**Dòng 48:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
) {
```

**Dòng 49:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
    Column(Modifier.fillMaxSize().background(AppBackground)) {
```

**Dòng 50:** Container ngang.

```kotlin
        Row(
```

**Dòng 51:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            Modifier.fillMaxWidth().statusBarsPadding().padding(start = 12.dp, top = 8.dp, end = 12.dp, bottom = 10.dp),
```

**Dòng 52:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            verticalAlignment = Alignment.CenterVertically,
```

**Dòng 53:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        ) {
```

**Dòng 54:** Nút tương tác; onClick xử lý nhấn.

```kotlin
            IconButton(onClick = onClose) { Icon(Icons.Filled.ArrowBack, "Quay lại", tint = Color(0xFF12385F)) }
```

**Dòng 55:** Hiển thị văn bản.

```kotlin
            Text("CÀI ĐẶT", color = Color(0xFF12385F), fontWeight = FontWeight.ExtraBold)
```

**Dòng 56:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 57:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        SettingsEntry("IMPORT / EXPORT DỮ LIỆU", "Sao lưu khách hàng hoặc quản lý đơn hàng", onOpenBackup)
```

**Dòng 58:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        SettingsEntry("VTMAN EXPORT", "Mở công cụ nạp MVĐ, lấy SĐT và xuất CSV từ VTMan", onOpenVtmanExport)
```

**Dòng 59:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        SettingsEntry("XỬ LÝ ĐƠN", "Thêm đơn hàng, xóa đơn hàng hoặc cập nhật tuyến", onOpenOrderManagement)
```

**Dòng 60:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        SettingsEntry("TUYẾN GIAO HÀNG", "Quản lý tuyến và các vùng giao hàng", onOpenAnchorPoint)
```

**Dòng 61:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        SettingsEntry("BẢNG KÊ TIỀN", "Đếm tiền mặt, nhập Bank, Cước và COD", onOpenCashAudit)
```

**Dòng 62:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        SettingsEntry("CHECK CHUYỂN KHOẢN", null, onOpenTransferCheck)
```

**Dòng 63:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 64:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 65:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 66:** Đánh dấu hàm UI Compose.

```kotlin
@Composable
```

**Dòng 67:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
fun OrderManagementScreen(
```

**Dòng 68:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    status: String?,
```

**Dòng 69:** Phép so sánh/điều kiện.

```kotlin
    onAddManualOrder: (DeliveryOrder) -> Unit,
```

**Dòng 70:** Phép so sánh/điều kiện.

```kotlin
    onDeleteOrder: (String) -> Unit,
```

**Dòng 71:** Phép so sánh/điều kiện.

```kotlin
    onDeleteAllOrders: () -> Unit,
```

**Dòng 72:** Phép so sánh/điều kiện.

```kotlin
    onOpenCoordinateUpdate: () -> Unit,
```

**Dòng 73:** Phép so sánh/điều kiện.

```kotlin
    onConfirmRouteChange: () -> Unit,
```

**Dòng 74:** Phép so sánh/điều kiện.

```kotlin
    onClose: () -> Unit,
```

**Dòng 75:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
) {
```

**Dòng 76:** Biến có thể thay đổi.

```kotlin
    var manualOrderEntry by remember { mutableStateOf(false) }
```

**Dòng 77:** Biến có thể thay đổi.

```kotlin
    var deleteEntryOpen by remember { mutableStateOf(false) }
```

**Dòng 78:** Biến có thể thay đổi.

```kotlin
    var deleteWaybill by remember { mutableStateOf("") }
```

**Dòng 79:** Biến có thể thay đổi.

```kotlin
    var deleteConfirmationOpen by remember { mutableStateOf(false) }
```

**Dòng 80:** Biến có thể thay đổi.

```kotlin
    var deleteAllConfirmationOpen by remember { mutableStateOf(false) }
```

**Dòng 81:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
    Column(Modifier.fillMaxSize().background(AppBackground)) {
```

**Dòng 82:** Container ngang.

```kotlin
        Row(
```

**Dòng 83:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            Modifier.fillMaxWidth().statusBarsPadding().padding(start = 12.dp, top = 8.dp, end = 12.dp, bottom = 10.dp),
```

**Dòng 84:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            verticalAlignment = Alignment.CenterVertically,
```

**Dòng 85:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        ) {
```

**Dòng 86:** Nút tương tác; onClick xử lý nhấn.

```kotlin
            IconButton(onClick = onClose) { Icon(Icons.Filled.ArrowBack, "Quay lại Cài đặt", tint = Color(0xFF12385F)) }
```

**Dòng 87:** Hiển thị văn bản.

```kotlin
            Text("XỬ LÝ ĐƠN", color = Color(0xFF12385F), fontWeight = FontWeight.ExtraBold)
```

**Dòng 88:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 89:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        SettingsEntry("THÊM ĐƠN HÀNG", "Nhập tay mã vận đơn và thông tin người nhận", onClick = { manualOrderEntry = true })
```

**Dòng 90:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        SettingsEntry("XÓA ĐƠN HÀNG", "Chỉ xóa đơn; hồ sơ và lịch sử khách hàng vẫn được giữ lại", onClick = { deleteEntryOpen = !deleteEntryOpen })
```

**Dòng 91:** Điều kiện if.

```kotlin
        if (deleteEntryOpen) {
```

**Dòng 92:** Ô nhập liệu.

```kotlin
            OutlinedTextField(
```

**Dòng 93:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                value = deleteWaybill,
```

**Dòng 94:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                onValueChange = { deleteWaybill = it },
```

**Dòng 95:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                label = { Text("Mã vận đơn cần xóa") },
```

**Dòng 96:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                singleLine = true,
```

**Dòng 97:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 5.dp),
```

**Dòng 98:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            )
```

**Dòng 99:** Nút tương tác; onClick xử lý nhấn.

```kotlin
            Button(
```

**Dòng 100:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                enabled = deleteWaybill.isNotBlank(),
```

**Dòng 101:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                onClick = { deleteConfirmationOpen = true },
```

**Dòng 102:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC23D35)),
```

**Dòng 103:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 5.dp),
```

**Dòng 104:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            ) { Text("Xóa đơn đã nhập") }
```

**Dòng 105:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 106:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        SettingsEntry("XÓA TẤT CẢ ĐƠN HÀNG", "Xóa toàn bộ đơn trong Chi tiết đơn và Bản đồ", onClick = { deleteAllConfirmationOpen = true })
```

**Dòng 107:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        status?.let { Text(it, color = Color(0xFF59636D), fontSize = 11.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) }
```

**Dòng 108:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 109:** Điều kiện if.

```kotlin
    if (manualOrderEntry) {
```

**Dòng 110:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        ManualOrderEntryDialog(
```

**Dòng 111:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            onDismiss = { manualOrderEntry = false },
```

**Dòng 112:** Phép so sánh/điều kiện.

```kotlin
            onSave = { order -> onAddManualOrder(order); manualOrderEntry = false },
```

**Dòng 113:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        )
```

**Dòng 114:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 115:** Điều kiện if.

```kotlin
    if (deleteAllConfirmationOpen) {
```

**Dòng 116:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        AlertDialog(
```

**Dòng 117:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            onDismissRequest = { deleteAllConfirmationOpen = false },
```

**Dòng 118:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            title = { Text("Xóa tất cả đơn hàng?") },
```

**Dòng 119:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            text = { Text("Bạn chắc chắn muốn xoá tất cả các đơn hàng phải không?") },
```

**Dòng 120:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            confirmButton = {
```

**Dòng 121:** Nút tương tác; onClick xử lý nhấn.

```kotlin
                Button(
```

**Dòng 122:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    onClick = { onDeleteAllOrders(); deleteAllConfirmationOpen = false },
```

**Dòng 123:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC23D35)),
```

**Dòng 124:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                ) { Text("Có") }
```

**Dòng 125:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            },
```

**Dòng 126:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            dismissButton = { androidx.compose.material3.OutlinedButton(onClick = { deleteAllConfirmationOpen = false }) { Text("Không") } },
```

**Dòng 127:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        )
```

**Dòng 128:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 129:** Điều kiện if.

```kotlin
    if (deleteConfirmationOpen) {
```

**Dòng 130:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        AlertDialog(
```

**Dòng 131:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            onDismissRequest = { deleteConfirmationOpen = false },
```

**Dòng 132:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            title = { Text("Xóa đơn hàng?") },
```

**Dòng 133:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            text = { Text("Đơn ${deleteWaybill.trim()} sẽ bị xóa khỏi danh sách. Thông tin và lịch sử khách hàng không bị xóa.") },
```

**Dòng 134:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            confirmButton = {
```

**Dòng 135:** Nút tương tác; onClick xử lý nhấn.

```kotlin
                Button(
```

**Dòng 136:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    onClick = { onDeleteOrder(deleteWaybill); deleteWaybill = ""; deleteConfirmationOpen = false; deleteEntryOpen = false },
```

**Dòng 137:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC23D35)),
```

**Dòng 138:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                ) { Text("Xóa đơn") }
```

**Dòng 139:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            },
```

**Dòng 140:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            dismissButton = { androidx.compose.material3.OutlinedButton(onClick = { deleteConfirmationOpen = false }) { Text("Hủy") } },
```

**Dòng 141:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        )
```

**Dòng 142:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 143:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 144:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 145:** Đánh dấu hàm UI Compose.

```kotlin
@Composable
```

**Dòng 146:** Phép so sánh/điều kiện.

```kotlin
private fun SettingsEntry(title: String, subtitle: String?, onClick: () -> Unit) {
```

**Dòng 147:** Container ngang.

```kotlin
    Row(
```

**Dòng 148:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 5.dp).background(AppSurface, RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(horizontal = 13.dp, vertical = 13.dp),
```

**Dòng 149:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        verticalAlignment = Alignment.CenterVertically,
```

**Dòng 150:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    ) {
```

**Dòng 151:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        Column(Modifier.weight(1f)) {
```

**Dòng 152:** Hiển thị văn bản.

```kotlin
            Text(title, color = Color(0xFF12385F), fontWeight = FontWeight.Bold, fontSize = 13.sp)
```

**Dòng 153:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            subtitle?.let { Text(it, color = Color(0xFF59636D), fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp)) }
```

**Dòng 154:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 155:** Hiển thị văn bản.

```kotlin
        Text("›", color = Color(0xFF12385F), fontSize = 25.sp, fontWeight = FontWeight.Bold)
```

**Dòng 156:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 157:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 158:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 159:** Đánh dấu hàm UI Compose.

```kotlin
@Composable
```

**Dòng 160:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
fun CoordinateUpdateScreen(
```

**Dòng 161:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    status: String?,
```

**Dòng 162:** Phép so sánh/điều kiện.

```kotlin
    onSave: (CoordinateUpdateRequest) -> Unit,
```

**Dòng 163:** Phép so sánh/điều kiện.

```kotlin
    onConfirmRouteChange: () -> Unit,
```

**Dòng 164:** Phép so sánh/điều kiện.

```kotlin
    onClose: () -> Unit,
```

**Dòng 165:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
) {
```

**Dòng 166:** Biến có thể thay đổi.

```kotlin
    var reference by remember { mutableStateOf("") }
```

**Dòng 167:** Biến có thể thay đổi.

```kotlin
    var pastedCoordinates by remember { mutableStateOf("") }
```

**Dòng 168:** Biến có thể thay đổi.

```kotlin
    var latitude by remember { mutableStateOf("") }
```

**Dòng 169:** Biến có thể thay đổi.

```kotlin
    var longitude by remember { mutableStateOf("") }
```

**Dòng 170:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
    fun applyPastedCoordinates(value: String): Boolean {
```

**Dòng 171:** Biến chỉ đọc.

```kotlin
        val coordinates = CoordinateTextParser.parse(value) ?: return false
```

**Dòng 172:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        latitude = coordinates.latitude.toString()
```

**Dòng 173:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        longitude = coordinates.longitude.toString()
```

**Dòng 174:** Kết thúc hàm và trả kết quả.

```kotlin
        return true
```

**Dòng 175:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 176:** Biến chỉ đọc.

```kotlin
    val parsedLatitude = latitude.trim().replace(',', '.').toDoubleOrNull()
```

**Dòng 177:** Biến chỉ đọc.

```kotlin
    val parsedLongitude = longitude.trim().replace(',', '.').toDoubleOrNull()
```

**Dòng 178:** Biến chỉ đọc.

```kotlin
    val coordinatesValid = parsedLatitude != null && parsedLongitude != null && parsedLatitude in -90.0..90.0 && parsedLongitude in -180.0..180.0
```

**Dòng 179:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
    Column(Modifier.fillMaxSize().background(AppBackground)) {
```

**Dòng 180:** Container ngang.

```kotlin
        Row(
```

**Dòng 181:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            Modifier.fillMaxWidth().statusBarsPadding().padding(start = 12.dp, top = 8.dp, end = 12.dp, bottom = 10.dp),
```

**Dòng 182:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            verticalAlignment = Alignment.CenterVertically,
```

**Dòng 183:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        ) {
```

**Dòng 184:** Nút tương tác; onClick xử lý nhấn.

```kotlin
            IconButton(onClick = onClose) { Icon(Icons.Filled.ArrowBack, "Quay lại Cài đặt", tint = Color(0xFF12385F)) }
```

**Dòng 185:** Hiển thị văn bản.

```kotlin
            Text("CẬP NHẬT", color = Color(0xFF12385F), fontWeight = FontWeight.ExtraBold)
```

**Dòng 186:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 187:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        Text("Nhập MVĐ hoặc SĐT cùng tọa độ mới; hoặc rà tất cả SĐT đã có tọa độ để đồng bộ và xếp lại tuyến.", color = Color(0xFF59636D), fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
```

**Dòng 188:** Ô nhập liệu.

```kotlin
        OutlinedTextField(
```

**Dòng 189:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            value = reference,
```

**Dòng 190:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            onValueChange = { reference = it },
```

**Dòng 191:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            label = { Text("Mã vận đơn hoặc SĐT") },
```

**Dòng 192:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            singleLine = true,
```

**Dòng 193:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 5.dp),
```

**Dòng 194:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        )
```

**Dòng 195:** Ô nhập liệu.

```kotlin
        OutlinedTextField(
```

**Dòng 196:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            value = pastedCoordinates,
```

**Dòng 197:** Phép so sánh/điều kiện.

```kotlin
            onValueChange = { value ->
```

**Dòng 198:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                pastedCoordinates = value
```

**Dòng 199:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
                applyPastedCoordinates(value)
```

**Dòng 200:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            },
```

**Dòng 201:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            label = { Text("Dán cụm tọa độ") },
```

**Dòng 202:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            placeholder = { Text("10.7769, 106.7009 hoặc 106.7009, 10.7769", fontSize = 11.sp) },
```

**Dòng 203:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            singleLine = true,
```

**Dòng 204:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 5.dp),
```

**Dòng 205:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        )
```

**Dòng 206:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        Text("Có thể dán theo thứ tự vĩ độ, kinh độ hoặc kinh độ, vĩ độ. Hai ô bên dưới vẫn nhập tay được.", color = Color(0xFF59636D), fontSize = 10.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 1.dp))
```

**Dòng 207:** Ô nhập liệu.

```kotlin
        OutlinedTextField(
```

**Dòng 208:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            value = latitude,
```

**Dòng 209:** Phép so sánh/điều kiện.

```kotlin
            onValueChange = { value -> if (!applyPastedCoordinates(value)) latitude = value },
```

**Dòng 210:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            label = { Text("Vĩ độ (Latitude)") },
```

**Dòng 211:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            singleLine = true,
```

**Dòng 212:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 5.dp),
```

**Dòng 213:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        )
```

**Dòng 214:** Ô nhập liệu.

```kotlin
        OutlinedTextField(
```

**Dòng 215:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            value = longitude,
```

**Dòng 216:** Phép so sánh/điều kiện.

```kotlin
            onValueChange = { value -> if (!applyPastedCoordinates(value)) longitude = value },
```

**Dòng 217:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            label = { Text("Kinh độ (Longitude)") },
```

**Dòng 218:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            singleLine = true,
```

**Dòng 219:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 5.dp),
```

**Dòng 220:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        )
```

**Dòng 221:** Nút tương tác; onClick xử lý nhấn.

```kotlin
        Button(
```

**Dòng 222:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            enabled = reference.isNotBlank() && coordinatesValid,
```

**Dòng 223:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            onClick = { onSave(CoordinateUpdateRequest(reference, parsedLatitude!!, parsedLongitude!!)) },
```

**Dòng 224:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
```

**Dòng 225:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        ) { Text("Lưu tọa độ, giữ nguyên STT") }
```

**Dòng 226:** Điều kiện if.

```kotlin
        if (!coordinatesValid && (latitude.isNotBlank() || longitude.isNotBlank())) {
```

**Dòng 227:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            Text("Vĩ độ phải từ -90 đến 90, kinh độ từ -180 đến 180.", color = Color(0xFFC23D35), fontSize = 11.sp, modifier = Modifier.padding(horizontal = 16.dp))
```

**Dòng 228:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 229:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        status?.let { Text(it, color = Color(0xFF59636D), fontSize = 11.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) }
```

**Dòng 230:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 231:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 232:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 233:** Đánh dấu hàm UI Compose.

```kotlin
@Composable
```

**Dòng 234:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
fun BackupDataScreen(
```

**Dòng 235:** Phép so sánh/điều kiện.

```kotlin
    onExportBackup: () -> Unit,
```

**Dòng 236:** Phép so sánh/điều kiện.

```kotlin
    onImportBackup: () -> Unit,
```

**Dòng 237:** Phép so sánh/điều kiện.

```kotlin
    onImportOrders: () -> Unit,
```

**Dòng 238:** Phép so sánh/điều kiện.

```kotlin
    onExportOrders: () -> Unit,
```

**Dòng 239:** Phép so sánh/điều kiện.

```kotlin
    onExportStt: () -> Unit,
```

**Dòng 240:** Phép so sánh/điều kiện.

```kotlin
    onImportStt: () -> Unit,
```

**Dòng 241:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    backupStatus: String?,
```

**Dòng 242:** Phép so sánh/điều kiện.

```kotlin
    onClose: () -> Unit,
```

**Dòng 243:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
) {
```

**Dòng 244:** Biến có thể thay đổi.

```kotlin
    var importConfirmationOpen by remember { mutableStateOf(false) }
```

**Dòng 245:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
    Column(Modifier.fillMaxSize().background(AppBackground)) {
```

**Dòng 246:** Container ngang.

```kotlin
        Row(
```

**Dòng 247:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            Modifier.fillMaxWidth().statusBarsPadding().padding(start = 12.dp, top = 8.dp, end = 12.dp, bottom = 10.dp),
```

**Dòng 248:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            verticalAlignment = Alignment.CenterVertically,
```

**Dòng 249:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        ) {
```

**Dòng 250:** Nút tương tác; onClick xử lý nhấn.

```kotlin
            IconButton(onClick = onClose) { Icon(Icons.Filled.ArrowBack, "Quay lại Cài đặt", tint = Color(0xFF12385F)) }
```

**Dòng 251:** Hiển thị văn bản.

```kotlin
            Text("IMPORT / EXPORT DỮ LIỆU", color = Color(0xFF12385F), fontWeight = FontWeight.ExtraBold)
```

**Dòng 252:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 253:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        Button(onClick = onExportBackup, modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 7.dp)) { Text("Xuất Dữ Liệu Khách Hàng") }
```

**Dòng 254:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        Button(onClick = { importConfirmationOpen = true }, modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 7.dp)) { Text("Nhập Dữ Liệu Khách Hàng") }
```

**Dòng 255:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        Button(onClick = onImportOrders, modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 7.dp)) { Text("Nhập Đơn Hàng") }
```

**Dòng 256:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        Button(onClick = onExportOrders, modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 7.dp)) { Text("Xuất Đơn Hàng") }
```

**Dòng 257:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        Button(onClick = onExportStt, modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 7.dp)) { Text("Lưu STT") }
```

**Dòng 258:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        Button(onClick = onImportStt, modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 7.dp)) { Text("Khôi phục STT") }
```

**Dòng 259:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
        backupStatus?.let { Text(it, modifier = Modifier.padding(horizontal = 16.dp, vertical = 5.dp), color = Color(0xFF59636D), fontSize = 11.sp) }
```

**Dòng 260:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 261:** Điều kiện if.

```kotlin
    if (importConfirmationOpen) {
```

**Dòng 262:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        AlertDialog(
```

**Dòng 263:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            onDismissRequest = { importConfirmationOpen = false },
```

**Dòng 264:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            title = { Text("Nhập dữ liệu khách hàng?") },
```

**Dòng 265:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            text = { Text("Dữ liệu khách hàng và lịch sử hiện có sẽ được thay bằng dữ liệu trong file ZIP.") },
```

**Dòng 266:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            confirmButton = { Button(onClick = { importConfirmationOpen = false; onImportBackup() }) { Text("Chọn ZIP") } },
```

**Dòng 267:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            dismissButton = { Button(onClick = { importConfirmationOpen = false }) { Text("Hủy") } },
```

**Dòng 268:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        )
```

**Dòng 269:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 270:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 271:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 272:** Đánh dấu hàm UI Compose.

```kotlin
@Composable
```

**Dòng 273:** Phép so sánh/điều kiện.

```kotlin
fun TransferCheckScreen(onClose: () -> Unit) {
```

**Dòng 274:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
    Column(Modifier.fillMaxSize().background(AppBackground)) {
```

**Dòng 275:** Container ngang.

```kotlin
        Row(
```

**Dòng 276:** Thiết lập layout/appearance/interaction cho UI.

```kotlin
            Modifier.fillMaxWidth().statusBarsPadding().padding(start = 12.dp, top = 8.dp, end = 12.dp, bottom = 10.dp),
```

**Dòng 277:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
            verticalAlignment = Alignment.CenterVertically,
```

**Dòng 278:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        ) {
```

**Dòng 279:** Nút tương tác; onClick xử lý nhấn.

```kotlin
            IconButton(onClick = onClose) { Icon(Icons.Filled.ArrowBack, "Quay lại Cài đặt", tint = Color(0xFF12385F)) }
```

**Dòng 280:** Hiển thị văn bản.

```kotlin
            Text("CHECK CHUYỂN KHOẢN", color = Color(0xFF12385F), fontWeight = FontWeight.ExtraBold)
```

**Dòng 281:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        }
```

**Dòng 282:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
    }
```

**Dòng 283:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

## `app/src/main/java/com/example/delivery/ui/UiPalette.kt`

**Dòng 1:** Khai báo package/namespace.

```kotlin
package com.example.delivery.ui
```

**Dòng 2:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 3:** Import dependency.

```kotlin
import androidx.compose.ui.graphics.Color
```

**Dòng 4:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 5:** Chú thích, không thực thi.

```kotlin
/** Nền trắng ngà/xám xanh dịu, tránh chói mắt khi dùng liên tục ngoài đường. */
```

**Dòng 6:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
internal val AppBackground = Color(0xFFE7EDF1)
```

**Dòng 7:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
internal val AppSurface = Color(0xFFF0F3F5)
```

**Dòng 8:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
internal val AppSurfaceMuted = Color(0xFFE8EEF2)
```

## `app/src/main/java/com/example/delivery/ui/ZoneMultiVertexPickerDialog.kt`

**Dòng 1:** Khai báo package/namespace.

```kotlin
package com.example.delivery.ui\n\nimport com.example.delivery.map.GoongMapStyleLoader\nimport android.annotation.SuppressLint\nimport android.graphics.Bitmap\nimport android.graphics.Canvas\nimport android.graphics.Paint\nimport android.graphics.Typeface\nimport android.location.Location\nimport android.location.LocationListener\nimport android.location.LocationManager\nimport android.os.Looper\nimport androidx.compose.foundation.background\nimport androidx.compose.foundation.layout.*\nimport androidx.compose.foundation.shape.RoundedCornerShape\nimport androidx.compose.material3.*\nimport androidx.compose.runtime.*\nimport androidx.compose.ui.Modifier\nimport androidx.compose.ui.graphics.Color\nimport androidx.compose.ui.platform.LocalContext\nimport androidx.compose.ui.text.font.FontWeight\nimport androidx.compose.ui.unit.dp\nimport androidx.compose.ui.unit.sp\nimport androidx.compose.ui.viewinterop.AndroidView\nimport androidx.compose.ui.window.Dialog\nimport androidx.compose.ui.window.DialogProperties\nimport androidx.lifecycle.Lifecycle\nimport androidx.lifecycle.LifecycleEventObserver\nimport androidx.lifecycle.compose.LocalLifecycleOwner\nimport org.maplibre.android.MapLibre\nimport org.maplibre.android.annotations.Icon\nimport org.maplibre.android.annotations.IconFactory\nimport org.maplibre.android.annotations.Marker\nimport org.maplibre.android.annotations.MarkerOptions\nimport org.maplibre.android.camera.CameraPosition\nimport org.maplibre.android.geometry.LatLng\nimport org.maplibre.android.maps.MapLibreMap\nimport org.maplibre.android.maps.MapView\nimport org.maplibre.android.maps.Style\nimport java.util.Locale\n\n@Composable\ninternal fun ZoneMultiVertexPickerDialog(initialPoints: List<CustomerPickerPosition>, onDismiss: () -> Unit, onConfirm: (List<CustomerPickerPosition>) -> Unit) {\n    var points by remember(initialPoints) { mutableStateOf(initialPoints) }\n    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {\n        Surface(Modifier.fillMaxSize().padding(10.dp), RoundedCornerShape(18.dp), color = AppBackground) {\n            Column(Modifier.fillMaxSize()) {\n                Column(Modifier.fillMaxWidth().background(Color(0xFFEAF5F2)).padding(14.dp, 10.dp)) {\n                    Text("CHỌN CÁC ĐỈNH CỦA ZONE", color = Color(0xFF12385F), fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)\n                    Text("Chạm bản đồ để thêm đỉnh. Mỗi lần chạm là một điểm; ứng dụng tự hiểu các điểm tạo thành ranh giới Zone.", color = Color(0xFF5F6B75), fontSize = 11.sp)\n                }\n                ZoneVertexMap(points, { points = it }, Modifier.weight(1f).fillMaxWidth().padding(8.dp))\n                Column(Modifier.fillMaxWidth().background(Color(0xFFF4F7F8)).padding(12.dp, 8.dp)) {\n                    Text("ĐÃ CHỌN ${points.size} ĐỈNH", color = Color(0xFF12385F), fontWeight = FontWeight.Bold, fontSize = 12.sp)\n                    if (points.isNotEmpty()) Text(points.mapIndexed { i, p -> "${i + 1}: ${String.format(Locale.US, "%.5f, %.5f", p.latitude, p.longitude)}" }.joinToString("   "), fontSize = 10.sp, maxLines = 2)\n                    Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {\n                        OutlinedButton(onClick = { points = points.dropLast(1) }, enabled = points.isNotEmpty()) { Text("Hoàn tác") }\n                        OutlinedButton(onClick = { points = emptyList() }, enabled = points.isNotEmpty()) { Text("Xóa hết") }\n                        Button(onClick = { onConfirm(points) }, enabled = points.size >= 3, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF229846))) { Text("Lưu đỉnh") }\n                    }\n                    OutlinedButton(onClick = onDismiss, Modifier.fillMaxWidth().padding(top = 3.dp)) { Text("Hủy") }\n                }\n            }\n        }\n    }\n}\n\n@SuppressLint("MissingPermission")\n@Composable\nprivate fun ZoneVertexMap(points: List<CustomerPickerPosition>, onPointsChanged: (List<CustomerPickerPosition>) -> Unit, modifier: Modifier) {\n    val context = LocalContext.current\n    val lifecycle = LocalLifecycleOwner.current.lifecycle\n    val view = remember(context) { MapLibre.getInstance(context); MapView(context).also { it.onCreate(null) } }\n    var map by remember { mutableStateOf<MapLibreMap?>(null) }\n    var markers by remember { mutableStateOf<List<Marker>>(emptyList()) }\n    var userLocation by remember { mutableStateOf<Location?>(null) }\n    var centeredOnUser by remember { mutableStateOf(false) }\n    val latestPoints by rememberUpdatedState(points)\n\n    DisposableEffect(context) {\n        val manager = context.getSystemService(LocationManager::class.java)\n        val listener = object : LocationListener {\n            override fun onLocationChanged(location: Location) {\n                if (location.accuracy.isFinite() && location.accuracy <= 100f) userLocation = location\n            }\n        }\n        listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)\n            .mapNotNull { provider -> runCatching { manager.getLastKnownLocation(provider) }.getOrNull() }\n            .filter { it.accuracy.isFinite() && it.accuracy <= 100f }\n            .minWithOrNull(compareBy<Location> { it.accuracy }.thenByDescending { it.time })\n            ?.let { userLocation = it }\n        listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER).forEach { provider ->\n            runCatching { if (manager.isProviderEnabled(provider)) manager.requestLocationUpdates(provider, 3_000L, 10f, listener, Looper.getMainLooper()) }\n        }\n        onDispose { manager.removeUpdates(listener) }\n    }\n    LaunchedEffect(map, userLocation) {\n        val location = userLocation\n        val ready = map\n        if (!centeredOnUser && ready != null && location != null && points.isEmpty()) {\n            ready.cameraPosition = CameraPosition.Builder().target(LatLng(location.latitude, location.longitude)).zoom(14.5).build()\n            centeredOnUser = true\n        }\n    }\n    DisposableEffect(view, lifecycle) {\n        val observer = LifecycleEventObserver { _, event ->\n            when (event) {\n                Lifecycle.Event.ON_START -> view.onStart()\n                Lifecycle.Event.ON_RESUME -> view.onResume()\n                Lifecycle.Event.ON_PAUSE -> view.onPause()\n                Lifecycle.Event.ON_STOP -> view.onStop()\n                else -> Unit\n            }\n        }\n        lifecycle.addObserver(observer)\n        onDispose { lifecycle.removeObserver(observer); view.onDestroy() }\n    }\n    AndroidView(modifier = modifier, factory = {\n        view.apply {\n            getMapAsync { ready ->\n                map = ready\n                ready.setStyle(Style.Builder().fromJson(GoongMapStyleLoader.load(context))) {\n                    // Chạm bản đồ chỉ thêm đỉnh mới; không chọn hoặc kéo marker cũ.\n                    ready.addOnMapClickListener { point ->\n                        onPointsChanged(latestPoints + CustomerPickerPosition(point.latitude, point.longitude))\n                        true\n                    }\n                }\n            }\n        }\n    }, update = {\n        val ready = map ?: return@AndroidView\n        if (ready.style == null) return@AndroidView\n        while (markers.size > points.size) { markers.lastOrNull()?.let(ready::removeMarker); markers = markers.dropLast(1) }\n        points.forEachIndexed { index, point ->\n            val old = markers.getOrNull(index)\n            if (old == null) {\n                markers = markers + ready.addMarker(MarkerOptions().position(LatLng(point.latitude, point.longitude)).title("Đỉnh ${index + 1}").icon(pin(context, "${index + 1}")))\n            } else {\n                old.position = LatLng(point.latitude, point.longitude)\n                old.setIcon(pin(context, "${index + 1}"))\n                ready.updateMarker(old)\n            }\n        }\n        // Không vẽ polyline; danh sách đỉnh được khép tự động khi kiểm tra ranh giới Zone.\n    })\n}\n\nprivate fun pin(context: android.content.Context, text: String): Icon {\n    val density = context.resources.displayMetrics.density\n    val size = (48 * density).toInt()\n    val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)\n    val canvas = Canvas(bitmap)\n    val paint = Paint(Paint.ANTI_ALIAS_FLAG)\n    paint.color = 0xFF12385F.toInt()\n    canvas.drawCircle(size / 2f, size / 2f, size / 2f - density, paint)\n    paint.color = android.graphics.Color.WHITE\n    paint.textAlign = Paint.Align.CENTER\n    paint.typeface = Typeface.DEFAULT_BOLD\n    paint.textSize = 12 * density\n    canvas.drawText(text, size / 2f, size / 2f - (paint.ascent() + paint.descent()) / 2f, paint)\n    return IconFactory.getInstance(context).fromBitmap(bitmap)\n}\n
```

## `app/src/main/java/com/example/delivery/ui/logic/DeliveryConditions.kt`

**Dòng 1:** Khai báo package/namespace.

```kotlin
package com.example.delivery.ui.logic
```

**Dòng 2:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 3:** Import dependency.

```kotlin
import com.example.delivery.model.DeliveryOrder
```

**Dòng 4:** Import dependency.

```kotlin
import com.example.delivery.model.hasStoredCoordinates
```

**Dòng 5:** Import dependency.

```kotlin
import com.example.delivery.model.isRouteActive
```

**Dòng 6:** Import dependency.

```kotlin
import com.example.delivery.model.sequenceSortValue
```

**Dòng 7:** Import dependency.

```kotlin
import com.example.delivery.model.sequenceText
```

**Dòng 8:** Import dependency.

```kotlin
import com.example.delivery.navigation.GeoPoint
```

**Dòng 9:** Import dependency.

```kotlin
import com.example.delivery.navigation.preferredRouteOrigin
```

**Dòng 10:** Import dependency.

```kotlin
import com.example.delivery.navigation.routeOrdersFrom
```

**Dòng 11:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 12:** Chú thích, không thực thi.

```kotlin
/** GROUP: DELIVERY CONDITIONS / ROUTE LOGIC.
```

**Dòng 13:** Chú thích, không thực thi.

```kotlin
 * Sửa các luật điều kiện/tính tuyến tại đây thay vì nhúng vào UI. */
```

**Dòng 14:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 15:** Phép so sánh/điều kiện.

```kotlin
internal fun findRouteOrigin(orders: List<DeliveryOrder>, currentGps: GeoPoint?): GeoPoint? {
```

**Dòng 16:** Biến chỉ đọc.

```kotlin
    val fallback = orders
```

**Dòng 17:** Lọc collection.

```kotlin
        .filter { it.isRouteActive() && it.hasStoredCoordinates() }
```

**Dòng 18:** Phép so sánh/điều kiện.

```kotlin
        .minByOrNull { if (it.sequence > 0) it.sequence else Int.MAX_VALUE }
```

**Dòng 19:** Safe-call: chỉ chạy khi khác null.

```kotlin
        ?.let { GeoPoint(it.latitude, it.longitude) }
```

**Dòng 20:** Kết thúc hàm và trả kết quả.

```kotlin
    return preferredRouteOrigin(null, currentGps, fallback)
```

**Dòng 21:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 22:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 23:** Phép so sánh/điều kiện.

```kotlin
internal fun buildRouteSequence(orders: List<DeliveryOrder>, origin: GeoPoint): Map<String, String> =
```

**Dòng 24:** Lọc collection.

```kotlin
    routeOrdersFrom(origin, orders.filter(DeliveryOrder::hasStoredCoordinates))
```

**Dòng 25:** Tạo Map key/value.

```kotlin
        .associate { it.waybill to it.sequenceText() }
```

**Dòng 26:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 27:** Phép so sánh/điều kiện.

```kotlin
internal fun nextOrderAfterCompletion(orders: List<DeliveryOrder>, completed: DeliveryOrder): DeliveryOrder? {
```

**Dòng 28:** Biến chỉ đọc.

```kotlin
    val completedSequence = completed.sequenceSortValue()
```

**Dòng 29:** Biến chỉ đọc.

```kotlin
    val candidates = orders
```

**Dòng 30:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        .asSequence()
```

**Dòng 31:** Lọc collection.

```kotlin
        .filter { it.waybill != completed.waybill && it.isRouteActive() }
```

**Dòng 32:** Sắp xếp collection.

```kotlin
        .sortedWith(compareBy<DeliveryOrder> { it.sequenceSortValue() }.thenBy { it.waybill })
```

**Dòng 33:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
        .toList()
```

**Dòng 34:** Kết thúc hàm và trả kết quả.

```kotlin
    return candidates.firstOrNull { it.sequenceSortValue() > completedSequence } ?: candidates.firstOrNull()
```

**Dòng 35:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

**Dòng 36:** Dòng trống — phân tách nhóm.

```kotlin

```

**Dòng 37:** Khai báo hàm; tham số/callback truyền dữ liệu hoặc sự kiện.

```kotlin
internal fun isValidRouteSequenceText(value: String): Boolean {
```

**Dòng 38:** Biến chỉ đọc.

```kotlin
    val normalized = value.trim()
```

**Dòng 39:** Điều kiện if.

```kotlin
    if (normalized.isBlank()) return false
```

**Dòng 40:** Biến chỉ đọc.

```kotlin
    val parts = normalized.split('.', limit = 2)
```

**Dòng 41:** Biến chỉ đọc.

```kotlin
    val baseValid = parts[0].toIntOrNull()?.let { it > 0 } == true
```

**Dòng 42:** Biến chỉ đọc.

```kotlin
    val suffixValid = parts.size == 1 || parts[1].equals("n", true) || parts[1].toIntOrNull()?.let { it > 0 } == true
```

**Dòng 43:** Kết thúc hàm và trả kết quả.

```kotlin
    return baseValid && suffixValid
```

**Dòng 44:** Câu lệnh Kotlin; xem GROUP và hàm chứa để biết vai trò.

```kotlin
}
```

