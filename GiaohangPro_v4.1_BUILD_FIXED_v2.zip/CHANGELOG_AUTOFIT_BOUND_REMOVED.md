# Bản sửa tab bản đồ

Đã loại bỏ cơ chế tự động `fit bounds` trong `GoonOnlyMapScreen.kt`. Tab bản đồ không còn tự động di chuyển/thu phóng camera theo vị trí GPS và đơn hàng đích mỗi khi dữ liệu thay đổi.

Các thao tác thủ công vẫn giữ nguyên: định vị lần đầu theo GPS, nút “Vị trí hiện tại”, phóng to và thu nhỏ.

## Build

- Variant: `release`
- APK: `app-release.apk`
- APK đã được xác minh chữ ký APK Signature Scheme v2.
- Keystore và cấu hình Goong được giữ lại trong gói source theo yêu cầu của chủ sở hữu.

## Bảo mật

Gói này chứa keystore và thông tin cấu hình/key theo yêu cầu. Không chia sẻ công khai; nên lưu trữ ở nơi an toàn.

## Build lại

Mở thư mục source, đặt Android SDK trong `local.properties`, sau đó chạy `./gradlew assembleRelease`.

Lưu ý: `local.properties` trong gói được giữ nguyên từ source đầu vào. Các giá trị Goong có thể nằm trong tài nguyên style hoặc cần bổ sung theo cấu hình dự án.

---

Ngày đóng gói: 2026-09-04

Tệp được sửa: `app/src/main/java/com/example/delivery/ui/GoonOnlyMapScreen.kt`

Đã loại bỏ: import `LatLngBounds` và effect gọi `newLatLngBounds`.

---

**Ghi chú:** Keystore là tài sản nhạy cảm. Hãy đổi/thu hồi key nếu gói bị lộ ngoài phạm vi kiểm soát.
