# GiaohangPro – Fix bảo toàn khách hàng khi nạp MVĐ

## Quy tắc mới

Khi nạp danh sách MVĐ mới, ứng dụng chuẩn hóa SĐT theo khóa `customerPhoneKey()`:

- `0912345678`
- `84912345678`
- `+84912345678`
- `0084912345678`

đều được coi là cùng một khách (`0912345678`).

Nếu khóa SĐT đã tồn tại trong tab Khách hàng:

1. Không tạo `CustomerProfile` mới.
2. Không cập nhật/ghi đè `CustomerProfile` cũ.
3. Không xóa hoặc thay đổi tọa độ đã lưu.
4. Không xóa hoặc thay đổi `housePhotoPath` (hình cổng).
5. Địa chỉ/tọa độ đã lưu có thể được dùng để điền cho `DeliveryOrder` mới, nhưng chỉ là bản sao sang đơn hàng; hồ sơ khách vẫn nguyên vẹn.

## Vị trí sửa chính

### `MainActivity.kt`
Khi nhập MVĐ, `knownCustomers` nay dùng **toàn bộ `customerProfiles` đã lưu**, không dùng danh sách khách suy ra từ các MVĐ hiện tại. Điều này tránh bỏ sót khách đã lưu dữ liệu nhưng chưa xuất hiện trong ca hiện tại.

### `OrderImportCoordinator.kt`
`withCustomerAddress()` chỉ đọc hồ sơ khớp SĐT và copy dữ liệu sang đơn mới. Hàm không gọi `CustomerProfileStore.upsert()` và không sửa hồ sơ.

### `CustomerProfile.kt`
`upsertMissingFromOrders()` chỉ thêm hồ sơ nếu khóa SĐT chưa tồn tại. Hồ sơ trùng SĐT được giữ nguyên.

## Nhận diện app

- Tên hiển thị: **GiaohangPro**
- Application ID: `com.example.giaohangpro`
- Version code: `110`

Application ID mới đảm bảo APK GiaohangPro **không cài đè** ứng dụng cũ có ID `com.example.delivery`.
