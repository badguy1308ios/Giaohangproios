# Giao Hàng v4.1 — bản phân tích và tổ chức code

## Mục tiêu bản này
- Giữ nguyên nghiệp vụ hiện có, chỉ tổ chức phần tích hợp GOONG để dễ kiểm tra.
- Tập trung 2 API GOONG ở khu vực dễ tìm.
- Bổ sung tài liệu giải thích từng dòng cho toàn bộ Kotlin + các file cấu hình chính.
- Lập bản đồ nhóm UI và nhóm điều kiện/validation để debug nhanh.

## Hai API GOONG
1. **Map Tiles/Style:** `https://tiles.goong.io/`
   - Key: `GOONG_MAP_TILES_KEY`
   - Config: `navigation/GoongApiConfig.kt`
   - Loader: `map/GoongMapStyleLoader.kt`
2. **Directions REST:** `https://rsapi.goong.io/Direction`
   - Key: `GOONG_REST_API_KEY`
   - Repository: `navigation/GoongDirectionsRepository.kt`

API key không còn nằm trực tiếp trong `goong_map_style.json`; file style dùng placeholder và được thay lúc chạy.

## Tài liệu
- `CODE_GROUPS.md`: bản đồ UI + điều kiện + luồng 2 API.
- `ANALYSIS_ANNOTATED/`: giải thích từng dòng của từng file Kotlin và cấu hình chính.
- `app/src/main/java/.../navigation/GoongApiConfig.kt`: nơi xem nhanh 2 API.
- `app/src/main/java/.../map/GoongMapStyleLoader.kt`: nơi nạp Map Style và inject key.

## Cấu hình key
Trong `local.properties` cần có:
```properties
GOONG_MAP_TILES_KEY=YOUR_MAP_TILES_KEY
GOONG_REST_API_KEY=YOUR_REST_API_KEY
```
Không commit key thật lên GitHub. Với GitHub Actions nên truyền key từ Secrets/Gradle properties.

## Kiểm tra build
Đã kiểm tra cấu trúc source và các thay đổi liên quan GOONG. Không thể chạy Gradle test hoàn chỉnh trong môi trường đóng gói này vì Gradle Wrapper cần tải Gradle 8.9 từ Internet và môi trường kiểm tra không có DNS/Internet.
