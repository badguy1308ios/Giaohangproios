package com.example.delivery.debug

import android.content.Context

/** Lưu lỗi crash gần nhất để hiển thị một lần khi người dùng mở lại ứng dụng. */
object CrashDiagnostic {
    private const val preferencesName = "delivery_crash_diagnostic"
    private const val crashDetailKey = "last_crash_detail"

    fun record(context: Context, thread: Thread, error: Throwable) {
        runCatching {
            context.getSharedPreferences(preferencesName, Context.MODE_PRIVATE)
                .edit()
                .putString(crashDetailKey, CrashDiagnosticFormatter.format(thread.name, error))
                .commit()
        }
    }

    fun consume(context: Context): String? {
        val preferences = context.getSharedPreferences(preferencesName, Context.MODE_PRIVATE)
        val detail = preferences.getString(crashDetailKey, null) ?: return null
        preferences.edit().remove(crashDetailKey).apply()
        return detail
    }
}

internal object CrashDiagnosticFormatter {
    fun format(threadName: String, error: Throwable): String {
        val type = error.javaClass.simpleName.ifBlank { "không xác định" }
        val message = error.message?.take(240) ?: "không có"
        val trace = error.stackTraceToString().lineSequence().take(8).joinToString("
").take(900)
        return "Bước lỗi: ứng dụng bị dừng đột ngột.
Luồng: $threadName
Loại lỗi: $type
Chi tiết: $message

Dấu vết:
$trace

Chọn Sao chép lỗi và gửi lại nội dung này để kiểm tra tiếp."
    }
}
