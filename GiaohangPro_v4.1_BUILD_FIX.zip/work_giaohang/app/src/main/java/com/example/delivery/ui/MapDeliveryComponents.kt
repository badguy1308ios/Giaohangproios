package com.example.delivery.ui

import android.Manifest
import android.app.Activity
import android.content.Context
import android.widget.Toast
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.relocation.BringIntoViewRequester
import androidx.compose.foundation.relocation.bringIntoViewRequester
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import com.example.delivery.history.DeliveryPhotoHistory
import com.example.delivery.history.PaymentChannel
import com.example.delivery.history.ProofPhotoType
import com.example.delivery.history.TransferEvidence
import com.example.delivery.orderio.CoordinateUpdateRequest
import com.example.delivery.orderio.CoordinateTextParser
import com.example.delivery.location.RealtimeLocationPolicy
import com.example.delivery.customer.CustomerAddress
import com.example.delivery.customer.CustomerContactMethod
import com.example.delivery.customer.CustomerPhone
import com.example.delivery.customer.CustomerProfile
import com.example.delivery.customer.CustomerProfileStore
import com.example.delivery.customer.matchesSearch
import com.example.delivery.model.DeliveryOrder
import com.example.delivery.model.DeliveryOutcome
import com.example.delivery.model.DeliveryStatus
import com.example.delivery.model.hasStoredCoordinates
import com.example.delivery.model.canReceiveRouteSequence
import com.example.delivery.model.dispatchDisplayOrder
import com.example.delivery.model.formatVnd
import com.example.delivery.model.isMapVisible
import com.example.delivery.model.isPickupAtWarehouse
import com.example.delivery.model.isRouteActive
import com.example.delivery.model.statusLabel
import com.example.delivery.model.withStableRouteLabels
import com.example.delivery.model.resequenceDraftLabels
import com.example.delivery.model.sequenceText
import com.example.delivery.ui.logic.isValidRouteSequenceText
import com.example.delivery.model.sequenceSortValue
import com.example.delivery.model.csvStatus
import com.example.delivery.navigation.DeliveryRouteStore
import com.example.delivery.navigation.DeliveryZone
import com.example.delivery.navigation.GeoPoint
import com.example.delivery.navigation.persistedRouteLabels
import com.example.delivery.navigation.preferredRouteOrigin
import com.example.delivery.navigation.routeOrdersFrom
import kotlinx.coroutines.delay
import java.util.Locale

// UI GROUP: MAP
// Chứa riêng UI bản đồ và sheet danh sách đơn.
@Composable
internal fun MapDeliveryScreen(
    orders: List<DeliveryOrder>,
    selectedNavigationOrder: DeliveryOrder?,
    selectedWaybill: String?,
    onRouteSequencePreview: (Map<String, String>?) -> Unit,
    onRouteSequenceLocked: (Map<String, String>) -> Unit,
    onSelectNavigation: (DeliveryOrder) -> Unit,
    onSelectOrder: (DeliveryOrder) -> Unit,
    onReturnToNearest: () -> Unit,
    onOpenDetail: (DeliveryOrder) -> Unit,
    locationGranted: Boolean,
    onLocationChanged: (Double, Double) -> Unit,
    modifier: Modifier,
) {
    val mapOrders = orders.filter(DeliveryOrder::isMapVisible)
    val activeOrders = orders.filter { it.isRouteActive() && it.hasStoredCoordinates() }
    val target = selectedNavigationOrder?.let { selected -> activeOrders.firstOrNull { it.waybill == selected.waybill } } ?: activeOrders.firstOrNull()
    Box(modifier) {
        GoonOnlyMapScreen(
            orders = mapOrders,
            selectedNavigationOrder = target,
            locationGranted = locationGranted,
            onLocationChanged = onLocationChanged,
            onSelectOrder = onSelectOrder,
            modifier = Modifier.fillMaxSize(),
        )
        MapOrderSheet(
            orders = mapOrders,
            target = target,
            selectedWaybill = selectedWaybill,
            onRouteSequencePreview = onRouteSequencePreview,
            onRouteSequenceLocked = onRouteSequenceLocked,
            manuallySelected = selectedNavigationOrder != null,
            onSelectNavigation = onSelectNavigation,
            onSelectOrder = onSelectOrder,
            onReturnToNearest = onReturnToNearest,
            onOpenDetail = onOpenDetail,
            modifier = Modifier.fillMaxWidth().fillMaxHeight(0.44f).align(Alignment.BottomCenter),
        )
    }
}

@Composable
private fun MapOrderSheet(
    orders: List<DeliveryOrder>,
    target: DeliveryOrder?,
    selectedWaybill: String?,
    onRouteSequencePreview: (Map<String, String>?) -> Unit,
    onRouteSequenceLocked: (Map<String, String>) -> Unit,
    manuallySelected: Boolean,
    onSelectNavigation: (DeliveryOrder) -> Unit,
    onSelectOrder: (DeliveryOrder) -> Unit,
    onReturnToNearest: () -> Unit,
    onOpenDetail: (DeliveryOrder) -> Unit,
    modifier: Modifier,
) {
    val listState = rememberLazyListState()
    val focusManager = LocalFocusManager.current
    var editingSequence by remember { mutableStateOf(false) }
    var saveSequenceConfirmation by remember { mutableStateOf(false) }
    var sequenceDrafts by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var previewSequenceSort by remember { mutableStateOf(false) }
    val displayedOrders = if (editingSequence && previewSequenceSort) orders.withStableRouteLabels(sequenceDrafts) else orders
    LaunchedEffect(selectedWaybill, orders) {
        val index = selectedOrderIndex(orders, selectedWaybill)
        if (index >= 0) listState.animateScrollToItem(index)
    }
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
        colors = CardDefaults.cardColors(containerColor = AppSurface),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
    ) {
        Column(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 12.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("${orders.count { it.isRouteActive() }} ĐANG GIAO", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 11.sp, modifier = Modifier.background(Color(0xFFFF7043), RoundedCornerShape(16.dp)).padding(horizontal = 11.dp, vertical = 9.dp).weight(1f))
                Button(
                    onClick = {
                        if (editingSequence) saveSequenceConfirmation = true
                        else {
                            sequenceDrafts = orders.associate { it.waybill to it.sequenceText() }
                            previewSequenceSort = false
                            editingSequence = true
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E73BE)),
                    modifier = Modifier.height(38.dp),
                ) { Text(if (editingSequence) "Lưu" else "Sửa", fontSize = 12.sp) }
            }
            LazyColumn(
                state = listState,
                modifier = Modifier.weight(1f).fillMaxWidth().padding(top = 9.dp),
                verticalArrangement = Arrangement.spacedBy(7.dp),
            ) {
                items(displayedOrders, key = { it.waybill }) { order ->
                    val selected = order.waybill == selectedWaybill
                    val active = order.waybill == target?.waybill
                    val navigable = order.isRouteActive()
                    Row(
                        modifier = Modifier.fillMaxWidth().background(if (selected) Color(0xFFE4F0FB) else if (active) Color(0xFFFBEDE3) else AppSurfaceMuted, RoundedCornerShape(15.dp)).clickable(onClick = { onSelectOrder(order); onOpenDetail(order) }).padding(11.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        if (editingSequence && order.canReceiveRouteSequence() && order.hasStoredCoordinates()) {
                            OutlinedTextField(
                                value = sequenceDrafts[order.waybill].orEmpty(),
                                onValueChange = { value ->
                                    val filtered = value.lowercase().filter { it.isDigit() || it == '.' || it == 'n' }
                                    sequenceDrafts = sequenceDrafts + (order.waybill to filtered)
                                },
                                modifier = Modifier.width(62.dp).onFocusChanged { focus ->
                                    if (!focus.isFocused) {
                                        val original = orders.associate { it.waybill to it.sequenceText() }
                                        val reindexed = orders.resequenceDraftLabels(sequenceDrafts, original)
                                        sequenceDrafts = reindexed
                                        previewSequenceSort = true
                                        onRouteSequencePreview(reindexed)
                                    }
                                },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                                keyboardActions = KeyboardActions(onDone = { focusManager.clearFocus(force = true) }),
                                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 12.sp, fontWeight = FontWeight.Bold),
                            )
                        } else if (order.sequenceText().isNotBlank()) {
                            Text(order.sequenceText(), color = Color.White, fontWeight = FontWeight.ExtraBold, modifier = Modifier.background(sequenceColor(order), RoundedCornerShape(50)).padding(horizontal = 12.dp, vertical = 8.dp))
                            IconButton(enabled = navigable, onClick = { if (active && manuallySelected) onReturnToNearest() else onSelectNavigation(order) }) {
                                Icon(if (active && manuallySelected) Icons.Filled.Pause else Icons.Filled.Navigation, if (active && manuallySelected) "Tạm dừng" else "Dẫn đường", tint = Color(0xFF12385F))
                            }
                        } else if (order.isPickupAtWarehouse()) {
                            Text("KHO", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 10.sp, modifier = Modifier.background(Color(0xFF6B47A1), RoundedCornerShape(50)).padding(horizontal = 8.dp, vertical = 9.dp))
                        } else {
                            Spacer(Modifier.width(42.dp))
                        }
                        Column(Modifier.weight(1f).padding(start = 10.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(order.waybill, color = Color(0xFF12385F), fontWeight = FontWeight.ExtraBold, fontSize = 13.sp, modifier = Modifier.weight(1f))
                                Text(order.cod.formatVnd(), color = Color(0xFFFF7043), fontWeight = FontWeight.ExtraBold, fontSize = 12.sp)
                            }
                            Text("${order.customer} · ${order.statusLabel()}", color = Color(0xFF68727C), fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
    if (saveSequenceConfirmation) {
        AlertDialog(
            onDismissRequest = { saveSequenceConfirmation = false },
            title = { Text("Xác nhận lưu STT") },
            text = { Text("Bạn có muốn lưu thay đổi không?") },
            confirmButton = {
                Button(onClick = {
                    val original = orders.associate { it.waybill to it.sequenceText() }
                    val reindexed = orders.resequenceDraftLabels(sequenceDrafts, original)
                    val updated = reindexed.mapNotNull { (waybill, value) ->
                        val normalized = value.trim()
                        val valid = isValidRouteSequenceText(normalized)
                        normalized.takeIf { valid }?.let { waybill to it }
                    }.toMap()
                    onRouteSequenceLocked(updated)
                    previewSequenceSort = false
                    saveSequenceConfirmation = false
                    editingSequence = false
                    sequenceDrafts = emptyMap()
                }) { Text("Có") }
            },
            dismissButton = { OutlinedButton(onClick = { onRouteSequencePreview(null); previewSequenceSort = false; saveSequenceConfirmation = false; editingSequence = false; sequenceDrafts = emptyMap() }) { Text("Không") } },
        )
    }
}

private fun sequenceColor(order: DeliveryOrder): Color = when {
    order.isPickupAtWarehouse() -> Color(0xFF6B47A1)
    else -> Color(0xFF1E73BE)
}

@Composable
private fun TabButton(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val interactionSource = remember { MutableInteractionSource() }
    Row(
        modifier = modifier.background(if (selected) Color(0xFF12385F) else Color.Transparent, RoundedCornerShape(10.dp)).clickable(interactionSource = interactionSource, indication = null, onClick = onClick).padding(vertical = 9.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, tint = if (selected) Color.White else Color(0xFF12385F))
        Spacer(Modifier.width(5.dp)); Text(label, color = if (selected) Color.White else Color(0xFF12385F), fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

