# Giao Hàng Pro - OpenStreetMap + OSMDroid

Bản source này thay toàn bộ chức năng Goong bằng **OpenStreetMap + OSMDroid**.

## Không cần
- Goong API/SDK
- Google Maps SDK/API
- API Key
- Google Cloud
- Thẻ tín dụng

## Chức năng bản đồ

### 1. Chọn tọa độ khách hàng
Trong Thêm/Sửa khách hàng, bấm nút 📍 cạnh Vĩ độ/Kinh độ:

1. Mở OpenStreetMap trong dialog.
2. Nếu đã có tọa độ, mở đúng vị trí đó.
3. Nếu chưa có, ưu tiên GPS hiện tại.
4. Nếu không có GPS/quyền, dùng vị trí mặc định Đồng Hới.
5. Chạm bản đồ để chọn điểm.
6. Chỉ giữ một marker điểm đang chọn.
7. Bấm **LƯU** để trả Latitude/Longitude về form.
8. Bấm **HỦY** để không thay đổi dữ liệu.
9. Người dùng vẫn phải bấm **LƯU THAY ĐỔI** để lưu khách hàng.

### 2. Tab Bản đồ
- Hiển thị vị trí GPS của tài xế nếu được cấp quyền.
- Hiển thị marker cho mọi đơn có tọa độ hợp lệ.
- Nếu đơn chưa có tọa độ, thử lấy tọa độ từ khách liên quan.
- Tự zoom theo 1 hoặc nhiều đơn.
- Bấm marker để xem mã đơn, khách, địa chỉ, trạng thái và tọa độ.

### 3. Dẫn đường
Bấm **DẪN ĐƯỜNG** sẽ mở Google Maps bên ngoài bằng URI:

`google.navigation:q=LATITUDE,LONGITUDE&mode=l`

Ứng dụng không tự xây route/navigation. Nếu không có Google Maps, app dùng Intent fallback và không crash.

## File đã chỉnh sửa
- `app/src/main/java/com/example/giaohangpro/MainActivity.kt`
- `app/build.gradle.kts`
- `app/src/main/AndroidManifest.xml`
- `local.properties.example`
- `README.md`

## Dependency

```kotlin
implementation("org.osmdroid:osmdroid-android:6.1.20")
```

## Ghi chú
`MainActivity.kt` có chú thích tiếng Việt trực tiếp cho các phần OSMDroid, GPS, marker, chọn tọa độ, lifecycle và Google Maps Intent.

## Cập nhật marker bong bóng đánh số

- Marker đơn hàng trên tab **Bản đồ** được đổi sang dạng **bong bóng có mũi nhọn**, số thứ tự nằm bên trong marker.
- Đơn có tọa độ hợp lệ hiển thị bong bóng màu cam.
- Đơn chưa có tọa độ trong chính đơn hàng và cũng chưa tìm thấy tọa độ của khách hàng liên quan vẫn được đưa lên bản đồ bằng bong bóng màu xám tại vị trí GPS hiện tại của tài xế (hoặc vị trí mặc định khi GPS chưa sẵn sàng).
- Marker chưa có tọa độ được ghi rõ là vị trí tạm và nút **DẪN ĐƯỜNG** bị khóa để tránh dẫn nhầm đến vị trí GPS của tài xế.
- Người dùng cần vào **Khách hàng → Thêm/Sửa → nút 📍** để chọn và lưu tọa độ thủ công. Khi có tọa độ, marker sẽ chuyển sang trạng thái điểm giao thật.

## Cập nhật giao diện tab Bản đồ

Phiên bản này đã tinh chỉnh tab **Bản đồ** theo bố cục ảnh mẫu:

- Bản đồ OpenStreetMap + OSMDroid ở nền phía trên.
- Danh sách đơn hàng dạng **bottom sheet** bo góc lớn ở phía dưới.
- Mỗi dòng hiển thị số thứ tự, nút dẫn đường, mã đơn, tên khách và số tiền.
- Bấm dòng đơn hàng sẽ chọn và focus đúng marker tương ứng trên bản đồ.
- Bấm marker trên bản đồ sẽ đồng bộ trạng thái chọn với danh sách.
- Đơn chưa có tọa độ vẫn được đánh số nhưng nút dẫn đường bị vô hiệu hóa và hiển thị trạng thái chờ bổ sung tọa độ.
- Google Maps vẫn được mở bên ngoài ứng dụng để dẫn đường khi đơn có tọa độ hợp lệ.

Các thay đổi chính nằm trong:

`app/src/main/java/com/example/giaohangpro/MainActivity.kt`
