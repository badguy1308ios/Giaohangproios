package com.example.delivery.orderio

import android.content.Context
import com.example.delivery.model.DeliveryFailureReason
import com.example.delivery.model.DeliveryOrder
import com.example.delivery.model.sequenceText
import com.example.delivery.model.DeliveryStatus
import org.json.JSONArray
import org.json.JSONObject
import org.w3c.dom.Element
import java.io.ByteArrayInputStream
import java.io.InputStream
import java.nio.charset.StandardCharsets
import java.text.Normalizer
import java.util.Locale
import java.util.zip.ZipInputStream
import javax.xml.parsers.DocumentBuilderFactory

private fun String.isValidSequenceLabel(): Boolean {
    val parts = trim().split('.', limit = 2)
    return parts.size == 2 && parts[0].toIntOrNull()?.let { it > 0 } == true &&
        (parts[1].equals("n", true) || parts[1].toIntOrNull()?.let { it > 0 } == true)
}

data class OrderImportResult(
    val orders: List<DeliveryOrder>,
    val skippedRows: Int,
)

/** Đọc danh sách đơn từ CSV, TXT hoặc bảng tính XLSX đầu tiên trong tệp. */
object OrderFileCodec {
    private val headerAliases = mapOf(
        "waybill" to setOf("mavandon", "waybill", "tracking", "madon", "orderid"),
        "customer" to setOf("tenkhachhang", "khachhang", "customer", "nguoinhan", "tennguoinhan"),
        "phone" to setOf("sdt", "sodienthoai", "phone", "mobile", "dienthoai"),
        "address" to setOf("diachi", "address", "diachinguoinhan"),
        "product" to setOf("hanghoa", "sanpham", "product", "noidung", "tenhang", "mathang", "tenhanghoa", "tensanpham", "motahang", "motasanpham", "chitietsanpham", "thongtinhanghoa", "item"),
        "cod" to setOf("cod", "sotien", "tiencod", "amount", "tienthu", "thanhtoan"),
        "service" to setOf("dichvu", "service"),
        "status" to setOf("trangthai", "status"),
        "sequence" to setOf("stt", "sequence", "thutu"),
        "latitude" to setOf("latitude", "lat", "vido"),
        "longitude" to setOf("longitude", "lng", "lon", "kinhdo"),
        "requiresRedelivery" to setOf("giaolai", "requiresredelivery"),
        "wasRedelivered" to setOf("dagiaolai", "wasredelivered"),
        "failureReason" to setOf("lydothatbai", "failurereason", "reason"),
        "failureCount" to setOf("solanthatbai", "failurecount", "attempts"),
        "delivered" to setOf("dagiao", "delivered"),
    )
    private val defaultColumnKeys = listOf("waybill", "customer", "phone", "address", "product", "cod", "service", "status", "sequence", "latitude", "longitude", "requiresRedelivery", "wasRedelivered", "failureReason", "failureCount", "delivered")

    fun import(fileName: String, input: InputStream): OrderImportResult {
        val extension = fileName.substringAfterLast('.', "").lowercase(Locale.ROOT)
        val rows = when (extension) {
            "csv", "txt" -> parseDelimited(input.readBytes().toString(StandardCharsets.UTF_8))
            "xlsx" -> parseXlsx(input)
            else -> error("Chỉ hỗ trợ tệp CSV, XLSX hoặc TXT.")
        }
        return rows.toOrders()
    }

    fun exportCsv(orders: List<DeliveryOrder>): String = buildString {
        append('\uFEFF')
        appendCsvRow(listOf("Mã vận đơn", "Tên khách hàng", "SĐT", "Địa chỉ", "Hàng hóa", "COD", "Dịch vụ", "Trạng thái", "STT", "Vĩ độ", "Kinh độ", "Giao lại", "Đã giao lại", "Lý do thất bại", "Số lần thất bại", "Đã giao"))
        orders.forEach { order ->
            appendCsvRow(
                listOf(
                    order.waybill,
                    order.customer,
                    order.phone,
                    order.address,
                    order.product,
                    order.cod.toString(),
                    order.service,
                    order.status.name,
                    order.sequenceText(),
                    order.latitude.toString(),
                    order.longitude.toString(),
                    order.requiresRedelivery.toString(),
                    order.wasRedelivered.toString(),
                    order.failureReason?.name.orEmpty(),
                    order.failureCount.toString(),
                    order.delivered.toString(),
                ),
            )
        }
    }

    internal fun parseDelimited(rawText: String): List<List<String>> {
        val text = rawText.removePrefix("\uFEFF")
        val firstLine = text.lineSequence().firstOrNull { it.isNotBlank() }.orEmpty()
        val separator = listOf(',', ';', '\t', '|').maxByOrNull { candidate -> firstLine.count { it == candidate } } ?: ','
        val rows = mutableListOf<List<String>>()
        val cells = mutableListOf<String>()
        val value = StringBuilder()
        var quoted = false
        var index = 0
        fun finishRow() {
            cells += value.toString().trim()
            value.clear()
            if (cells.any { it.isNotBlank() }) rows += cells.toList()
            cells.clear()
        }
        while (index < text.length) {
            when (val character = text[index]) {
                '"' -> {
                    if (quoted && index + 1 < text.length && text[index + 1] == '"') {
                        value.append('"')
                        index++
                    } else if (quoted) {
                        quoted = false
                    } else if (value.isEmpty()) {
                        quoted = true
                    } else {
                        value.append(character)
                    }
                }
                separator -> if (quoted) value.append(character) else {
                    cells += value.toString().trim()
                    value.clear()
                }
                '\n' -> if (quoted) value.append(character) else finishRow()
                '\r' -> Unit
                else -> value.append(character)
            }
            index++
        }
        if (value.isNotEmpty() || cells.isNotEmpty()) finishRow()
        return rows
    }

    private fun List<List<String>>.toOrders(): OrderImportResult {
        val usableRows = filter { row -> row.any { it.isNotBlank() } }
        require(usableRows.isNotEmpty()) { "Tệp đơn hàng đang trống." }
        val firstRowKeys = usableRows.first().map(::normalizeHeader)
        val hasHeader = firstRowKeys.any { key -> headerAliases.values.any { key in it } }
        val mapping = if (hasHeader) {
            headerAliases.mapNotNull { (canonical, aliases) ->
                firstRowKeys.indexOfFirst { header ->
                    header in aliases || aliases.any { alias -> alias.length >= 4 && header.contains(alias) }
                }.takeIf { it >= 0 }?.let { canonical to it }
            }.toMap()
        } else defaultColumnKeys.mapIndexed { index, key -> key to index }.toMap()
        val sourceRows = if (hasHeader) usableRows.drop(1) else usableRows
        var skipped = 0
        val parsed = sourceRows.mapNotNull { row ->
            fun value(key: String): String = mapping[key]?.let { row.getOrNull(it).orEmpty().trim() }.orEmpty()
            fun productValue(): String = value("product").ifBlank {
                val productColumn = firstRowKeys.indexOfFirst { header ->
                    header in headerAliases.getValue("product") || header.contains("mathang") || header.contains("hanghoa")
                }
                row.getOrNull(productColumn).orEmpty().trim()
            }
            val waybill = value("waybill")
            if (waybill.isBlank()) {
                skipped++
                null
            } else {
                DeliveryOrder(
                    waybill = waybill,
                    customer = value("customer"),
                    phone = value("phone"),
                    address = value("address"),
                    product = productValue(),
                    cod = value("cod").toMoney(),
                    service = value("service"),
                    status = value("status").toDeliveryStatus(),
                    sequence = value("sequence").substringBefore('.').toIntOrNull() ?: 0,
                    latitude = value("latitude").toCoordinate() ?: 0.0,
                    longitude = value("longitude").toCoordinate() ?: 0.0,
                    requiresRedelivery = value("requiresRedelivery").toBooleanValue(),
                    wasRedelivered = value("wasRedelivered").toBooleanValue(),
                    failureReason = DeliveryFailureReason.entries.firstOrNull { it.name.equals(value("failureReason"), ignoreCase = true) },
                    failureCount = value("failureCount").toIntOrNull()?.coerceAtLeast(0) ?: 0,
                    delivered = value("delivered").toBooleanValue() || value("status").equals("TT515", ignoreCase = true),
                    sequenceLabel = value("sequence").takeIf { it.contains('.') && it.isValidSequenceLabel() },
                )
            }
        }.distinctBy { it.waybill }
        require(parsed.isNotEmpty()) { "Không tìm thấy Mã vận đơn hợp lệ. Hãy dùng cột 'Mã vận đơn' hoặc để mã ở cột đầu tiên." }
        return OrderImportResult(parsed, skipped + (sourceRows.size - parsed.size - skipped).coerceAtLeast(0))
    }

    private fun parseXlsx(input: InputStream): List<List<String>> {
        var sharedStrings = emptyList<String>()
        var sheetBytes: ByteArray? = null
        ZipInputStream(input.buffered()).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                when {
                    entry.name == "xl/sharedStrings.xml" -> sharedStrings = parseSharedStrings(zip.readBytes())
                    entry.name.startsWith("xl/worksheets/") && entry.name.endsWith(".xml") && sheetBytes == null -> sheetBytes = zip.readBytes()
                }
                zip.closeEntry()
            }
        }
        return parseWorksheet(sheetBytes ?: error("Không tìm thấy bảng tính trong tệp XLSX."), sharedStrings)
    }

    private fun parseSharedStrings(bytes: ByteArray): List<String> {
        val items = xmlDocument(bytes).getElementsByTagName("si")
        return List(items.length) { index -> items.item(index).textContent.orEmpty() }
    }

    private fun parseWorksheet(bytes: ByteArray, sharedStrings: List<String>): List<List<String>> {
        val rowNodes = xmlDocument(bytes).getElementsByTagName("row")
        val rows = mutableListOf<List<String>>()
        for (rowIndex in 0 until rowNodes.length) {
            val row = rowNodes.item(rowIndex) as? Element ?: continue
            val rowValues = mutableMapOf<Int, String>()
            val cells = row.getElementsByTagName("c")
            for (cellIndex in 0 until cells.length) {
                val cell = cells.item(cellIndex) as? Element ?: continue
                val column = cell.getAttribute("r").toColumnIndex().takeIf { it >= 0 } ?: rowValues.size
                val raw = cell.textContent.orEmpty()
                val resolved = if (cell.getAttribute("t") == "s") raw.toIntOrNull()?.let { sharedStrings.getOrNull(it) }.orEmpty() else raw
                rowValues[column] = resolved
            }
            if (rowValues.isNotEmpty()) {
                val lastColumn = rowValues.keys.maxOrNull() ?: -1
                rows += List(lastColumn + 1) { column -> rowValues[column].orEmpty() }
            }
        }
        return rows
    }

    private fun xmlDocument(bytes: ByteArray) = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(ByteArrayInputStream(bytes))

    private fun String.toColumnIndex(): Int {
        val letters = takeWhile(Char::isLetter).uppercase(Locale.ROOT)
        if (letters.isBlank()) return -1
        return letters.fold(0) { result, character -> result * 26 + (character - 'A' + 1) } - 1
    }

    private fun String.toMoney(): Long = filter { it.isDigit() || it == '-' }.toLongOrNull() ?: 0L
    private fun String.toCoordinate(): Double? = trim().replace(',', '.').toDoubleOrNull()
    private fun String.toDeliveryStatus(): DeliveryStatus = DeliveryStatus.entries.firstOrNull { it.name.equals(trim(), ignoreCase = true) } ?: DeliveryStatus.TT500
    private fun String.toBooleanValue(): Boolean = trim().lowercase(Locale.ROOT) in setOf("true", "1", "yes", "co", "có")

    private fun normalizeHeader(value: String): String = Normalizer.normalize(value.trim(), Normalizer.Form.NFD)
        .replace("\\p{Mn}+".toRegex(), "")
        .lowercase(Locale.ROOT)
        .replace('đ', 'd')
        .replace("[^a-z0-9]".toRegex(), "")

    private fun StringBuilder.appendCsvRow(values: List<String>) {
        append(values.joinToString(",") { value -> "\"${value.replace("\"", "\"\"")}\"" })
        append("\r\n")
    }
}

/** Lưu danh sách đơn được nhập để vẫn còn sau khi đóng và mở lại ứng dụng. */
object DeliveryOrderStore {
    private const val PREF = "delivery_orders_v1"
    private const val KEY = "items"
    private const val INITIALIZED_KEY = "initialized"

    fun hasBeenInitialized(context: Context): Boolean =
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getBoolean(INITIALIZED_KEY, false)

    fun load(context: Context): List<DeliveryOrder> = runCatching {
        val array = JSONArray(context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, "[]"))
        List(array.length()) { array.getJSONObject(it).toOrder() }
    }.getOrDefault(emptyList())

    fun replace(context: Context, values: List<DeliveryOrder>) {
        val uniqueOrders = values.filter { it.waybill.isNotBlank() }.distinctBy { it.waybill }
        val saved = context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
            .putString(KEY, JSONArray(uniqueOrders.map { it.toJson() }).toString())
            .putBoolean(INITIALIZED_KEY, true)
            .commit()
        check(saved) { "Không thể lưu danh sách đơn hàng." }
    }

    private fun String.isValidSequenceLabel(): Boolean {
        val parts = trim().split('.', limit = 2)
        return parts.size == 2 && parts[0].toIntOrNull()?.let { it > 0 } == true &&
            (parts[1].equals("n", true) || parts[1].toIntOrNull()?.let { it > 0 } == true)
    }

    private fun DeliveryOrder.toJson() = JSONObject()
        .put("waybill", waybill)
        .put("customer", customer)
        .put("phone", phone)
        .put("address", address)
        .put("product", product)
        .put("cod", cod)
        .put("service", service)
        .put("status", status.name)
        .put("sequence", sequence)
        .put("sequenceLabel", sequenceLabel)
        .put("latitude", latitude)
        .put("longitude", longitude)
        .put("requiresRedelivery", requiresRedelivery)
        .put("wasRedelivered", wasRedelivered)
        .put("failureReason", failureReason?.name)
        .put("failureCount", failureCount)
        .put("delivered", delivered)

    private fun JSONObject.toOrder() = DeliveryOrder(
        waybill = getString("waybill"),
        customer = optString("customer"),
        phone = optString("phone"),
        address = optString("address"),
        product = optString("product"),
        cod = optLong("cod"),
        service = optString("service"),
        status = optString("status").toDeliveryStatus(),
        sequence = optString("sequence").substringBefore('.').toIntOrNull() ?: optInt("sequence"),
        latitude = optDouble("latitude", 10.7769),
        longitude = optDouble("longitude", 106.7009),
        requiresRedelivery = optBoolean("requiresRedelivery"),
        wasRedelivered = optBoolean("wasRedelivered"),
        failureReason = DeliveryFailureReason.entries.firstOrNull { it.name.equals(optString("failureReason"), ignoreCase = true) },
        failureCount = optInt("failureCount").coerceAtLeast(0),
        delivered = optBoolean("delivered", optString("status").equals("TT515", ignoreCase = true)),
        sequenceLabel = optString("sequenceLabel").takeIf { it.isValidSequenceLabel() },
    )

    private fun String.toDeliveryStatus(): DeliveryStatus = DeliveryStatus.entries.firstOrNull { it.name.equals(trim(), ignoreCase = true) } ?: DeliveryStatus.TT500
}
