package com.example.delivery.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.delivery.navigation.DeliveryZone
import com.example.delivery.navigation.GeoPoint
import java.util.UUID

enum class RouteCreationMode { NEW_ROUTE, UPDATE_ROUTE }

@Composable
internal fun DeliveryRouteScreen(
    zones: List<DeliveryZone>,
    onZonesChanged: (List<DeliveryZone>) -> Unit,
    onCreateRoute: (RouteCreationMode) -> Unit,
    onDeleteRoute: () -> Unit,
    onClose: () -> Unit,
) {
    var editorOpen by remember { mutableStateOf(false) }
    var editingIndex by remember { mutableStateOf<Int?>(null) }
    var confirmAction by remember { mutableStateOf<String?>(null) }
    var createChoiceOpen by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().background(AppBackground)) {
        Row(Modifier.fillMaxWidth().padding(start = 12.dp, top = 8.dp, end = 12.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose) { Icon(Icons.Filled.ArrowBack, "Quay lại", tint = Color(0xFF12385F)) }
            Text("TUYẾN GIAO HÀNG", color = Color(0xFF12385F), fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { createChoiceOpen = true }, modifier = Modifier.weight(1f)) { Text("Tạo tuyến") }
            OutlinedButton(onClick = { confirmAction = "Xóa" }, modifier = Modifier.weight(1f)) { Text("Xóa tuyến") }
        }
        Text("Danh sách Zone (${zones.size}) — chạm tên Zone để đổi ưu tiên bằng nút lên/xuống.", color = Color(0xFF59636D), fontSize = 11.sp, modifier = Modifier.padding(14.dp, 10.dp, 14.dp, 5.dp))
        Button(onClick = { editingIndex = null; editorOpen = true }, modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 5.dp)) { Text("Tạo zone") }
        LazyColumn(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp)) {
            itemsIndexed(zones, key = { _, zone -> zone.id }) { index, zone ->
                Row(Modifier.fillMaxWidth().background(AppSurface, androidx.compose.foundation.shape.RoundedCornerShape(12.dp)).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f).clickable { editingIndex = index; editorOpen = true }) {
                        Text("${index + 1}. ${zone.name}", color = Color(0xFF12385F), fontWeight = FontWeight.Bold)
                        Text(zone.points.joinToString("  •  ") { "%.5f, %.5f".format(it.latitude, it.longitude) }, color = Color(0xFF59636D), fontSize = 10.sp)
                    }
                    IconButton(enabled = index > 0, onClick = { val copy = zones.toMutableList(); copy[index] = copy[index - 1].also { copy[index - 1] = copy[index] }; onZonesChanged(copy) }) { Text("↑") }
                    IconButton(enabled = index < zones.lastIndex, onClick = { val copy = zones.toMutableList(); copy[index] = copy[index + 1].also { copy[index + 1] = copy[index] }; onZonesChanged(copy) }) { Text("↓") }
                    IconButton(onClick = { editingIndex = index; editorOpen = true }) { Icon(Icons.Filled.Edit, "Sửa", tint = Color(0xFF1E73BE)) }
                    IconButton(onClick = { onZonesChanged(zones.filterIndexed { i, _ -> i != index }) }) { Icon(Icons.Filled.Delete, "Xóa", tint = Color(0xFFC23D35)) }
                }
            }
        }
    }
    if (createChoiceOpen) {
        AlertDialog(
            onDismissRequest = { createChoiceOpen = false },
            title = { Text("Chọn cách tạo tuyến") },
            text = { Text("Tuyến mới — ưu tiên cao nhất: đánh STT toàn bộ MVĐ đủ điều kiện.\n\nCập nhật tuyến — ưu tiên thứ hai: đánh lại STT các MVĐ thuộc SĐT mới được nạp tọa độ.") },
            confirmButton = {
                Button(onClick = { onCreateRoute(RouteCreationMode.NEW_ROUTE); createChoiceOpen = false }) { Text("Tuyến mới") }
            },
            dismissButton = {
                OutlinedButton(onClick = { onCreateRoute(RouteCreationMode.UPDATE_ROUTE); createChoiceOpen = false }) { Text("Cập nhật tuyến") }
            },
        )
    }
    confirmAction?.let { action ->
        AlertDialog(onDismissRequest = { confirmAction = null }, title = { Text("Xác nhận") }, text = { Text("Bạn có chắc chắn muốn xóa Tuyến giao không?") }, confirmButton = { Button(onClick = { onDeleteRoute(); confirmAction = null }) { Text("Có") } }, dismissButton = { OutlinedButton(onClick = { confirmAction = null }) { Text("Không") } })
    }
    if (editorOpen) {
        ZoneEditorDialog(initial = editingIndex?.let { zones[it] }, onDismiss = { editorOpen = false }, onSave = { zone ->
            val copy = zones.toMutableList(); val index = editingIndex
            if (index == null) copy += zone else copy[index] = zone
            onZonesChanged(copy); editorOpen = false
        })
    }
}

@Composable
private fun ZoneEditorDialog(initial: DeliveryZone?, onDismiss: () -> Unit, onSave: (DeliveryZone) -> Unit) {
    var name by remember(initial?.id) { mutableStateOf(initial?.name.orEmpty()) }
    var points by remember(initial?.id) { mutableStateOf(initial?.points ?: emptyList()) }
    var pointPickerOpen by remember { mutableStateOf(false) }
    if (pointPickerOpen) {
        ZoneMultiVertexPickerDialog(
            initialPoints = points.map { CustomerPickerPosition(it.latitude, it.longitude) },
            onDismiss = { pointPickerOpen = false },
            onConfirm = { selected ->
                points = selected.map { point -> GeoPoint(point.latitude, point.longitude) }
                pointPickerOpen = false
            },
        )
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Tạo Zone mới" else "Sửa Zone") },
        text = { Column {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Tên Zone") },
                placeholder = { Text("Ví dụ: Khu trung tâm") },
                singleLine = true,
            )
            Text("Đã chọn ${points.size} đỉnh; cần ít nhất 3 đỉnh để lưu Zone.", color = Color(0xFF59636D), modifier = Modifier.padding(top = 8.dp))
            Button(onClick = { pointPickerOpen = true }) { Text(if (points.isEmpty()) "Mở bản đồ chọn đỉnh" else "Sửa các đỉnh trên bản đồ") }
            points.forEachIndexed { i, p -> Text("Đỉnh ${i + 1}: %.6f, %.6f".format(p.latitude, p.longitude), modifier = Modifier.padding(vertical = 3.dp), fontSize = 11.sp) }
        }},
        confirmButton = { Button(enabled = points.size >= 3 && name.isNotBlank(), onClick = { onSave(DeliveryZone(initial?.id ?: UUID.randomUUID().toString(), name.trim(), points)) }) { Text("Xác nhận") } },
        dismissButton = { OutlinedButton(onClick = onDismiss) { Text("Hủy") } },
    )
}
