package com.example.delivery.orderio

import com.example.delivery.model.DeliveryOrder
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class OrderFileCodecTest {
    @Test
    fun csvImportSupportsVietnameseHeadersAndQuotedAddress() {
        val source = "Mã vận đơn,Tên khách hàng,SĐT,Địa chỉ,Hàng hóa,COD,Dịch vụ,Trạng thái\nTT500001,Nguyễn Văn A,0901000001,\"12 Đường A, Long Thành\",Thùng hàng,125000,GBP,TT506"
        val result = OrderFileCodec.import("orders.csv", ByteArrayInputStream(source.toByteArray()))

        assertEquals(1, result.orders.size)
        assertEquals("TT500001", result.orders.single().waybill)
        assertEquals("12 Đường A, Long Thành", result.orders.single().address)
        assertEquals(125000L, result.orders.single().cod)
        assertEquals("TT506", result.orders.single().status.name)
    }

    @Test
    fun csvImportMapsMatHangColumnIntoOrderProduct() {
        val source = "Mã vận đơn,Tên khách,Mặt hàng,COD\nTT500010,Khách A,Thùng nước 20L,120000"

        val result = OrderFileCodec.import("orders.csv", ByteArrayInputStream(source.toByteArray()))

        assertEquals("Thùng nước 20L", result.orders.single().product)
    }

    @Test
    fun csvFromVtmanMapsQuotedMatHangAfterCustomerAndPhoneColumns() {
        val source = "MÃ VẬN ĐƠN,SỐ ĐIỆN THOẠI,KHÁCH HÀNG,MẶT HÀNG,TRẠNG THÁI,COD,ĐỊA CHỈ,DỊCH VỤ\n\"150480790693\",\"0839339485\",\"Mr. Minh\",\"Áo thun, hàng kiểm\",\"TT500\",\"0đ\",\"D14, Long Thành\",\"COD,PXD\""

        val order = OrderFileCodec.import("vtman-don-hang.csv", ByteArrayInputStream(source.toByteArray())).orders.single()

        assertEquals("Áo thun, hàng kiểm", order.product)
        assertEquals("D14, Long Thành", order.address)
        assertEquals("COD,PXD", order.service)
    }

    @Test
    fun csvFromVtmanMapsUnquotedMatHangFromUserFileShape() {
        val source = "MÃ VẬN ĐƠN,SỐ ĐIỆN THOẠI,KHÁCH HÀNG,MẶT HÀNG,TRẠNG THÁI,COD,ĐỊA CHỈ,DỊCH VỤ\n150480790693,0839339485,Mr. Minh,hs,TT500,0đ,D14 d15 Khu Tái Định Cư, X.Lộc An, H.Long Thành, T.Đồng Nai,"

        val order = OrderFileCodec.import("vtman-don-hang(5).csv", ByteArrayInputStream(source.toByteArray())).orders.single()

        assertEquals("hs", order.product)
        assertEquals("0839339485", order.phone)
    }

    @Test
    fun txtImportUsesDefaultColumnOrderWhenNoHeaderExists() {
        val source = "TT500002;Trần B;0902000002;Địa chỉ B;Sản phẩm B;80000;PTTX;TT500;2;10.7;106.9"
        val result = OrderFileCodec.import("orders.txt", ByteArrayInputStream(source.toByteArray()))

        assertEquals("TT500002", result.orders.single().waybill)
        assertEquals(2, result.orders.single().sequence)
        assertEquals(10.7, result.orders.single().latitude, 0.0001)
    }

    @Test
    fun xlsxImportReadsSharedStringCells() {
        val xlsx = ByteArrayOutputStream().use { output ->
            ZipOutputStream(output).use { zip ->
                zip.putNextEntry(ZipEntry("xl/sharedStrings.xml"))
                zip.write("<sst><si><t>Mã vận đơn</t></si><si><t>Tên khách hàng</t></si><si><t>TT500003</t></si><si><t>Lê C</t></si></sst>".toByteArray())
                zip.closeEntry()
                zip.putNextEntry(ZipEntry("xl/worksheets/sheet1.xml"))
                zip.write("<worksheet><sheetData><row r=\"1\"><c r=\"A1\" t=\"s\"><v>0</v></c><c r=\"B1\" t=\"s\"><v>1</v></c></row><row r=\"2\"><c r=\"A2\" t=\"s\"><v>2</v></c><c r=\"B2\" t=\"s\"><v>3</v></c></row></sheetData></worksheet>".toByteArray())
                zip.closeEntry()
            }
            output.toByteArray()
        }
        val result = OrderFileCodec.import("orders.xlsx", ByteArrayInputStream(xlsx))

        assertEquals(1, result.orders.size)
        assertEquals("TT500003", result.orders.single().waybill)
        assertEquals("Lê C", result.orders.single().customer)
    }

    @Test
    fun csvExportEscapesTextAndIncludesAllOrders() {
        val csv = OrderFileCodec.exportCsv(
            listOf(
                DeliveryOrder("TT500004", "Khách \"D\"", "0904", "Địa chỉ", "Hàng", 500, "GBP"),
            ),
        )

        assertTrue(csv.contains("\"Khách \"\"D\"\"\""))
        assertTrue(csv.contains("Mã vận đơn"))
    }
}
