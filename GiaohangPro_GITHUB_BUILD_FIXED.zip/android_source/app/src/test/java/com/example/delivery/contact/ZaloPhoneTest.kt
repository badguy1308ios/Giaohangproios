package com.example.delivery.contact

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ZaloPhoneTest {
    @Test
    fun `chuan hoa so zalo viet nam co khoang trang sang dau 84`() {
        assertEquals("84933622898", zaloPhoneNumber("093 362 28 98"))
    }

    @Test
    fun `giu nguyen so da co ma quoc gia va tu choi so khong hop le`() {
        assertEquals("84933622898", zaloPhoneNumber("+84 933 622 898"))
        assertNull(zaloPhoneNumber("1234"))
    }

    @Test
    fun `tao so e164 co dau cong de giong danh ba android`() {
        assertEquals("+84933622898", zaloContactPhone("093 362 28 98"))
        assertEquals("+84933622898", zaloContactPhone("+84 933 622 898"))
    }

    @Test
    fun `tu choi so e164 khong hop le`() {
        assertNull(zaloContactPhone("1234"))
    }

}
