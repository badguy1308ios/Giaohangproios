package com.example.delivery.customer

import com.example.delivery.model.DeliveryOrder
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CustomerProfileTest {
    @Test
    fun normalizedKeepsExactlyOnePrimaryPhoneAndAddress() {
        val profile = CustomerProfile(
            name = "Nguyễn Văn A",
            phones = listOf(CustomerPhone("0901"), CustomerPhone("0902")),
            addresses = listOf(CustomerAddress("1 Đường A"), CustomerAddress("2 Đường B")),
        ).normalized()

        assertEquals(1, profile.phones.count { it.isPrimary })
        assertEquals(1, profile.addresses.count { it.isPrimary })
        assertTrue(profile.isValid())
    }

    @Test
    fun contactMethodsCanContainMultipleChoices() {
        val phone = CustomerPhone("0901", methods = setOf(CustomerContactMethod.CALL, CustomerContactMethod.ZALO))
        assertEquals(setOf(CustomerContactMethod.CALL, CustomerContactMethod.ZALO), phone.methods)
    }

    @Test
    fun normalizedPhoneWithoutSelectedMethodsKeepsCallAvailable() {
        val profile = CustomerProfile(
            name = "Khách A",
            phones = listOf(CustomerPhone("0901", methods = emptySet())),
            addresses = listOf(CustomerAddress("Long Thành")),
        ).normalized()

        assertTrue(CustomerContactMethod.CALL in profile.primaryPhone.methods)
    }

    @Test
    fun emptyListsHaveSafePrimaryFallbacks() {
        val profile = CustomerProfile(name = "Khách mới", phones = emptyList(), addresses = emptyList())

        assertEquals("", profile.primaryPhone.number)
        assertEquals("", profile.primaryAddress.address)
    }

    @Test
    fun normalizedNamesKeepUniqueAliasesAndUseFirstNameAsDisplayName() {
        val profile = CustomerProfile(
            name = "Nguyễn An",
            names = listOf("  Nguyễn An  ", "Anh An", "Nguyễn An"),
            phones = listOf(CustomerPhone("0901")),
            addresses = listOf(CustomerAddress("Long Thành")),
        ).normalized()

        assertEquals(listOf("Nguyễn An", "Anh An"), profile.names)
        assertEquals("Nguyễn An", profile.displayName)
    }

    @Test
    fun remainingPhoneBecomesPrimaryAfterPrimaryPhoneIsRemoved() {
        val profile = CustomerProfile(
            name = "Khách",
            phones = listOf(CustomerPhone("0902")),
            addresses = listOf(CustomerAddress("Long Thành")),
        ).normalized()

        assertTrue(profile.primaryPhone.isPrimary)
        assertEquals("0902", profile.primaryPhone.number)
    }

    @Test
    fun normalizedPreservesAllDistinctNamesPhonesAndAddressesForFlexibleCustomerBlocks() {
        val profile = CustomerProfile(
            name = "Nguyễn Văn A",
            names = listOf("Nguyễn Văn A", "Chị A", "Cô A"),
            phones = listOf(CustomerPhone("0901"), CustomerPhone("0902"), CustomerPhone("0903")),
            addresses = listOf(
                CustomerAddress("123 Đường ABC", 10.7769, 106.7009),
                CustomerAddress("456 Đường XYZ", 10.8012, 106.6543),
            ),
        ).normalized()

        assertEquals(listOf("Nguyễn Văn A", "Chị A", "Cô A"), profile.names)
        assertEquals(listOf("0901", "0902", "0903"), profile.phones.map(CustomerPhone::number))
        assertEquals(listOf("123 Đường ABC", "456 Đường XYZ"), profile.addresses.map(CustomerAddress::address))
    }

    @Test
    fun mergeOrdersUsesExistingCustomerForEquivalentPhoneFormats() {
        val saved = CustomerProfile(
            id = "saved-customer",
            name = "Khách đã lưu",
            phones = listOf(CustomerPhone("093 362 28 98", isPrimary = true)),
            addresses = listOf(CustomerAddress("Địa chỉ đã lưu", isPrimary = true)),
        )
        val merged = listOf(saved).mergeOrderCustomers(
            listOf(
                DeliveryOrder("MV01", "Tên từ MVĐ", "+84933622898", "Địa chỉ CSV", "Hàng", 0, "DV"),
                DeliveryOrder("MV02", "Tên từ MVĐ", "0933622898", "Địa chỉ CSV", "Hàng", 0, "DV"),
            ),
        )

        assertEquals(1, merged.size)
        assertEquals("saved-customer", merged.single().id)
        assertEquals("Địa chỉ đã lưu", merged.single().primaryAddress.address)
    }
}
