package com.example.delivery.orderio

import com.example.delivery.customer.CustomerAddress
import com.example.delivery.customer.CustomerPhone
import com.example.delivery.customer.CustomerProfile
import com.example.delivery.model.DeliveryOrder
import com.example.delivery.model.DeliveryStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CustomerCoordinateSyncCoordinatorTest {
    @Test
    fun `ra soat sdt gan toa do khach va danh lai tat ca don dang giao`() {
        val profile = CustomerProfile(
            name = "Khách A",
            phones = listOf(CustomerPhone("0901 000 001", isPrimary = true)),
            addresses = listOf(CustomerAddress("Long Thành", latitude = 10.7769, longitude = 106.7009, isPrimary = true)),
        )
        val manualOrder = DeliveryOrder("TT001", "Khách A", "0901000001", "Chưa có", "Hàng", 1, "DV", sequence = 0, latitude = 0.0, longitude = 0.0)
        val existingRoutedOrder = DeliveryOrder("TT002", "Khách B", "0901000002", "Đã có", "Hàng", 1, "DV", sequence = 8, latitude = 10.78, longitude = 106.71)
        val deliveredOrder = DeliveryOrder("TT003", "Khách A", "0901000001", "Đã có", "Hàng", 1, "DV", status = DeliveryStatus.TT515, sequence = 6)

        val result = CustomerCoordinateSyncCoordinator.sync(listOf(profile), listOf(manualOrder, existingRoutedOrder, deliveredOrder))

        assertEquals(10.7769, result.orders[0].latitude, 0.000001)
        assertEquals(106.7009, result.orders[0].longitude, 0.000001)
        assertEquals(1, result.orders[0].sequence)
        assertEquals(2, result.orders[1].sequence)
        assertEquals(0, result.orders[2].sequence)
        assertEquals(setOf("TT001", "TT003"), result.phoneMatchedWaybills)
        assertTrue("TT001" in result.coordinateUpdatedWaybills)
    }
}
