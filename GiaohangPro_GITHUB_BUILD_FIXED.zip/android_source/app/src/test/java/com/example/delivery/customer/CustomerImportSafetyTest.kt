package com.example.delivery.customer

import com.example.delivery.model.DeliveryOrder
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CustomerImportSafetyTest {
    @Test
    fun phoneFormatsAreSameCustomerKey() {
        assertEquals("0912345678", "+84912345678".customerPhoneKey())
        assertEquals("0912345678", "84912345678".customerPhoneKey())
        assertEquals("0912345678", "0084912345678".customerPhoneKey())
        assertEquals("0912345678", "0912345678".customerPhoneKey())
    }

    @Test
    fun existingCustomerWithSavedDataIsNeverMissing() {
        val saved = CustomerProfile(
            id = "saved-1",
            name = "Khách cũ",
            names = listOf("Khách cũ"),
            phones = listOf(CustomerPhone("+84912345678", isPrimary = true)),
            addresses = listOf(
                CustomerAddress(
                    address = "Địa chỉ đã lưu",
                    latitude = 10.123,
                    longitude = 106.456,
                    isPrimary = true,
                    housePhotoPath = "/data/photo-gate.webp",
                ),
            ),
        ).normalized()
        val imported = DeliveryOrder(
            waybill = "MVĐ-NEW", customer = "Tên từ file", phone = "0912345678",
            address = "Địa chỉ từ file", product = "Hàng", cod = 1000, service = "",
        )

        val missing = listOf(saved).missingProfilesFromOrders(listOf(imported))

        assertTrue(missing.isEmpty())
        assertEquals(10.123, saved.primaryAddress.latitude!!, 0.000001)
        assertEquals(106.456, saved.primaryAddress.longitude!!, 0.000001)
        assertEquals("/data/photo-gate.webp", saved.primaryAddress.housePhotoPath)
    }
}
