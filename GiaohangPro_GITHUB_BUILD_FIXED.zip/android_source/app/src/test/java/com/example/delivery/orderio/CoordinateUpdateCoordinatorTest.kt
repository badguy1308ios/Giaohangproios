package com.example.delivery.orderio

import com.example.delivery.customer.CustomerAddress
import com.example.delivery.customer.CustomerPhone
import com.example.delivery.customer.CustomerProfile
import com.example.delivery.model.DeliveryOrder
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CoordinateUpdateCoordinatorTest {
    @Test
    fun `cap nhat bang ma van don them toa do va dua don chua danh so vao cuoi tuyen`() {
        val order = DeliveryOrder("MV01", "Khach A", "0901000001", "1 Duong A", "Hang", 0, "DV")
        val result = CoordinateUpdateCoordinator.update(
            CoordinateUpdateRequest("MV01", 10.81, 106.91),
            emptyList(),
            listOf(DeliveryOrder("OLD", "B", "2", "A", "", 0, "", sequence = 4), order),
        )
        assertEquals(5, result.orders.single { it.waybill == "MV01" }.sequence)
        assertEquals(10.81, result.orders.single { it.waybill == "MV01" }.latitude, 0.0001)
    }

    @Test
    fun `cap nhat bang sdt sua toa do dia chi chinh cua khach`() {
        val profile = CustomerProfile(
            name = "Khach A",
            names = listOf("Khach A"),
            phones = listOf(CustomerPhone("0901000001", true)),
            addresses = listOf(CustomerAddress("1 Duong A", isPrimary = true)),
        )
        val result = CoordinateUpdateCoordinator.update(
            CoordinateUpdateRequest("0901000001", 10.82, 106.92),
            listOf(profile),
            emptyList(),
        )
        assertTrue(profile.id in result.updatedProfileIds)
        assertEquals(106.92, result.profiles.single().primaryAddress.longitude ?: 0.0, 0.0001)
    }

    @Test
    fun `cap nhat bang sdt xep so thu tu cho moi don chua co tuyen vua co toa do`() {
        val routeOrder = DeliveryOrder("ROUTE-7", "Khach Cu", "0901000000", "A", "Hang", 0, "DV", sequence = 7)
        val manualOne = DeliveryOrder("MANUAL-1", "Khach Moi", "0901000008", "B", "Hang", 0, "DV")
        val manualTwo = DeliveryOrder("MANUAL-2", "Khach Moi", "0901000008", "C", "Hang", 0, "DV")

        val result = CoordinateUpdateCoordinator.update(
            CoordinateUpdateRequest("0901000008", 10.83, 106.93),
            emptyList(),
            listOf(routeOrder, manualOne, manualTwo),
        )

        assertEquals(8, result.orders.single { it.waybill == "MANUAL-1" }.sequence)
        assertEquals(9, result.orders.single { it.waybill == "MANUAL-2" }.sequence)
        assertTrue(result.orders.filter { it.waybill.startsWith("MANUAL") }.all { it.latitude == 10.83 && it.longitude == 106.93 })
    }
}
