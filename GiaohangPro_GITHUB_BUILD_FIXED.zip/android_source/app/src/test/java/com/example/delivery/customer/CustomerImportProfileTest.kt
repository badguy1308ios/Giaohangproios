package com.example.delivery.customer

import com.example.delivery.model.DeliveryOrder
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class CustomerImportProfileTest {
    @Test
    fun `don moi tao ho so theo sdt va giu toa do trong file`() {
        val missing = emptyList<CustomerProfile>().missingProfilesFromOrders(
            listOf(DeliveryOrder("MV01", "Khach Moi", "0901000001", "1 Duong A", "Hang", 0, "DV", latitude = 10.8, longitude = 106.9)),
        )
        assertEquals(1, missing.size)
        assertEquals("Khach Moi", missing.single().displayName)
        assertEquals(10.8, missing.single().primaryAddress.latitude)
    }

    @Test
    fun `don khong co toa do tao khach de bo sung sau`() {
        val missing = emptyList<CustomerProfile>().missingProfilesFromOrders(
            listOf(DeliveryOrder("MV02", "Khach Moi", "0901000002", "2 Duong B", "Hang", 0, "DV", latitude = 0.0, longitude = 0.0)),
        )
        assertNull(missing.single().primaryAddress.latitude)
    }

    @Test
    fun `nhieu mvd cung sdt chi tao mot khach hang`() {
        val missing = emptyList<CustomerProfile>().missingProfilesFromOrders(
            listOf(
                DeliveryOrder("MV03", "Khach Moi", "093 362 28 98", "3 Duong A", "Hang A", 0, "DV"),
                DeliveryOrder("MV04", "Khach Moi", "+84 933 622 898", "4 Duong B", "Hang B", 0, "DV"),
            ),
        )

        assertEquals(1, missing.size)
        assertEquals("0933622898", missing.single().primaryPhone.number.filter(Char::isDigit))
    }

    @Test
    fun `sdt da co trong khach hang thi khong tao ho so moi khi nhap mvd`() {
        val saved = CustomerProfile(
            id = "saved-customer",
            name = "Khach Da Luu",
            phones = listOf(CustomerPhone("0933622898", isPrimary = true)),
            addresses = listOf(CustomerAddress("Dia chi da luu", isPrimary = true)),
        )
        val missing = listOf(saved).missingProfilesFromOrders(
            listOf(DeliveryOrder("MV05", "Ten tu CSV", "+84 933 622 898", "Dia chi tu CSV", "Hang", 0, "DV")),
        )

        assertEquals(emptyList<CustomerProfile>(), missing)
    }
}
