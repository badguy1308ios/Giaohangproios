package com.example.delivery.model

import com.example.delivery.model.DeliveryFailureReason.NO_CONTACT
import com.example.delivery.model.DeliveryFailureReason.PICKUP_AT_WAREHOUSE
import com.example.delivery.model.DeliveryFailureReason.REFUSED
import com.example.delivery.model.detailStatusLabel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import com.example.delivery.navigation.GeoPoint
import com.example.delivery.navigation.distanceMeters
import com.example.delivery.navigation.routeDistanceMeters
import com.example.delivery.navigation.persistedRouteSequence
import com.example.delivery.navigation.preferredRouteOrigin
import com.example.delivery.navigation.routeOrdersFrom
import com.example.delivery.navigation.routeOrdersForDisplay

class DeliveryOrderTest {
    private val active = DeliveryOrder("A001", "An", "0901", "A", "Hàng A", 28000, "GBP", DeliveryStatus.TT500, sequence = 2)
    private val failed = DeliveryOrder("B002", "Bình", "0902", "B", "Hàng B", 65000, "PTTX", DeliveryStatus.TT506, sequence = 0, requiresRedelivery = true)
    private val delivered = DeliveryOrder("C003", "Chi", "0903", "C", "Hàng C", 97000, "GH1P", DeliveryStatus.TT515, sequence = 0)
    private val first = DeliveryOrder("D004", "Dũng", "0904", "D", "Hàng D", 125000, "GBP", DeliveryStatus.TT500, sequence = 1)

    @Test
    fun `csv status codes are shown with the requested detail labels`() {
        assertEquals("TT500", active.detailStatusLabel())
        assertEquals("TT506 · Hẹn lại / Không liên lạc được", active.copy(status = DeliveryStatus.TT506).detailStatusLabel())
        assertEquals("TT507 · Tới kho nhận", active.copy(status = DeliveryStatus.TT507).detailStatusLabel())
        assertEquals("TT508 · Giao lại", active.copy(status = DeliveryStatus.TT508).detailStatusLabel())
        assertEquals("TT505 · Từ chối nhận / Giao thất bại 3 ca", active.copy(status = DeliveryStatus.TT505).detailStatusLabel())
    }

    @Test
    fun `detail list puts numbered route orders before failed and delivered`() {
        val result = listOf(active, failed, delivered, first).filterForDetail("", false, false)
        assertEquals(listOf("D004", "A001", "B002", "C003"), result.map { it.waybill })
    }

    @Test
    fun `search finds order by code phone customer and COD`() {
        val source = listOf(active, failed, delivered)
        assertEquals("A001", source.filterForDetail("a001", false, false).single().waybill)
        assertEquals("B002", source.filterForDetail("0902", false, false).single().waybill)
        assertEquals("C003", source.filterForDetail("chi", false, false).single().waybill)
        assertEquals("C003", source.filterForDetail("97000", false, false).single().waybill)
    }

    @Test
    fun `status filters isolate delivered and transfer-pending failure`() {
        val source = listOf(active, failed, delivered)
        assertEquals(listOf("C003"), source.filterForDetail("", true, false).map { it.waybill })
        assertEquals(listOf("B002"), source.filterForDetail("", false, true).map { it.waybill })
        assertTrue(source.filterForDetail("", true, false).all { it.status == DeliveryStatus.TT515 })
    }

    @Test
    fun `sample data provides twenty unique Long Thanh customers with routable coordinates`() {
        val samples = sampleOrders()
        assertEquals(20, samples.size)
        assertEquals(20, samples.map { it.waybill }.distinct().size)
        assertEquals(20, samples.map { it.phone }.distinct().size)
        assertTrue(samples.all { it.address.contains("Long Thành") && it.latitude != 0.0 && it.longitude != 0.0 && it.sequence > 0 })
    }

    @Test
    fun `saved anchor point wins over GPS and fallback as route origin`() {
        val anchor = GeoPoint(10.7000, 106.6000)
        val gps = GeoPoint(10.8000, 106.9000)
        val fallback = GeoPoint(10.9000, 107.0000)

        assertEquals(anchor, preferredRouteOrigin(anchor, gps, fallback))
        assertEquals(gps, preferredRouteOrigin(null, gps, fallback))
        assertEquals(fallback, preferredRouteOrigin(null, null, fallback))
    }

    @Test
    fun `nearest neighbor route starts at GPS closest order and renumbers stops`() {
        val origin = GeoPoint(10.7800, 106.9500)
        val orders = listOf(
            active.copy(waybill = "far", sequence = 1, latitude = 10.8000, longitude = 106.9800),
            active.copy(waybill = "near", sequence = 2, latitude = 10.7805, longitude = 106.9504),
            active.copy(waybill = "next", sequence = 3, latitude = 10.7820, longitude = 106.9520),
        )
        val route = routeOrdersFrom(origin, orders)
        assertEquals(listOf("near", "next", "far"), route.map { it.waybill })
        assertEquals(listOf(1, 2, 3), route.map { it.sequence })
    }

    @Test
    fun `optimized route keeps neighboring delivery points in consecutive stops`() {
        val origin = GeoPoint(10.7800, 106.9500)
        val orders = listOf(
            active.copy(waybill = "A", sequence = 1, latitude = 10.7810, longitude = 106.9510),
            active.copy(waybill = "B", sequence = 2, latitude = 10.7811, longitude = 106.9511),
            active.copy(waybill = "C", sequence = 3, latitude = 10.7950, longitude = 106.9700),
            active.copy(waybill = "D", sequence = 4, latitude = 10.7952, longitude = 106.9702),
        )

        val route = routeOrdersFrom(origin, orders)
        val sequence = route.associate { it.waybill to it.sequence }

        assertEquals(1, kotlin.math.abs(sequence.getValue("A") - sequence.getValue("B")))
        assertEquals(1, kotlin.math.abs(sequence.getValue("C") - sequence.getValue("D")))
        assertTrue(routeDistanceMeters(origin, route) > 0.0)
    }

    @Test
    fun `persisted route sequence restores only active numbered orders`() {
        val routeOne = active.copy(waybill = "route-one", sequence = 7)
        val routeTwo = active.copy(waybill = "route-two", sequence = 3)
        val deliveredOrder = delivered.copy(waybill = "delivered", sequence = 0)
        val noCoordinates = active.copy(waybill = "pending", sequence = 0, latitude = 0.0, longitude = 0.0)

        assertEquals(
            mapOf("route-two" to 3, "route-one" to 7),
            listOf(deliveredOrder, routeOne, noCoordinates, routeTwo).persistedRouteSequence(),
        )
    }

    @Test
    fun `ba cum diem gan nhau khong bi tach khoi nhau trong STT tuyen`() {
        val origin = GeoPoint(10.7800, 106.9500)
        val orders = listOf(
            active.copy(waybill = "west-1", latitude = 10.7810, longitude = 106.9510),
            active.copy(waybill = "west-2", latitude = 10.7811, longitude = 106.9511),
            active.copy(waybill = "east-1", latitude = 10.8000, longitude = 106.9700),
            active.copy(waybill = "east-2", latitude = 10.8001, longitude = 106.9701),
            active.copy(waybill = "south-1", latitude = 10.7600, longitude = 106.9300),
            active.copy(waybill = "south-2", latitude = 10.7601, longitude = 106.9301),
        )

        val sequence = routeOrdersFrom(origin, orders).associate { it.waybill to it.sequence }

        assertEquals(1, kotlin.math.abs(sequence.getValue("west-1") - sequence.getValue("west-2")))
        assertEquals(1, kotlin.math.abs(sequence.getValue("east-1") - sequence.getValue("east-2")))
        assertEquals(1, kotlin.math.abs(sequence.getValue("south-1") - sequence.getValue("south-2")))
    }

    @Test
    fun `cac mvđ cung sdt dung chung mot stt khi lap tuyen`() {
        val origin = GeoPoint(10.7800, 106.9500)
        val samePhoneA = active.copy(waybill = "same-a", phone = "090 123 4567", latitude = 10.7805, longitude = 106.9504)
        val samePhoneB = active.copy(waybill = "same-b", phone = "0901234567", latitude = 10.7820, longitude = 106.9520)
        val other = active.copy(waybill = "other", phone = "0909999999", latitude = 10.8000, longitude = 106.9800)

        val sequence = routeOrdersFrom(origin, listOf(other, samePhoneB, samePhoneA)).associate { it.waybill to it.sequence }

        assertEquals(sequence.getValue("same-a"), sequence.getValue("same-b"))
        assertTrue(sequence.getValue("other") != sequence.getValue("same-a"))
    }

    @Test
    fun `map and detail share active then failed then delivered order without numbering terminal orders`() {
        val origin = GeoPoint(10.7800, 106.9500)
        val near = first.copy(waybill = "near", latitude = 10.7805, longitude = 106.9504)
        val later = active.copy(waybill = "later", latitude = 10.7900, longitude = 106.9600)
        val shared = routeOrdersForDisplay(origin, listOf(later, delivered, failed, near))

        assertEquals(listOf("near", "later", "B002", "C003"), shared.map { it.waybill })
        assertEquals(listOf(1, 2, 0, 0), shared.map { it.sequence })
        assertEquals(shared.map { it.waybill }, shared.filterForDetail("", false, false).map { it.waybill })
    }

    @Test
    fun `terminal order is cleared while the next route number stays unchanged`() {
        val initial = listOf(
            first.copy(waybill = "one", sequence = 1),
            active.copy(waybill = "two", sequence = 2),
            active.copy(waybill = "three", sequence = 3),
        )
        val fixedNumbers = initial.associate { it.waybill to it.sequence }
        val afterDelivered = initial.map { order ->
            if (order.waybill == "one") order.copy(status = DeliveryStatus.TT515, sequence = 0) else order
        }.withStableRouteSequence(fixedNumbers)
        val afterFailed = initial.map { order ->
            if (order.waybill == "one") order.copy(sequence = 0, requiresRedelivery = true) else order
        }.withStableRouteSequence(fixedNumbers)

        assertEquals(listOf("two", "three", "one"), afterDelivered.map { it.waybill })
        assertEquals(listOf(2, 3, 0), afterDelivered.map { it.sequence })
        assertEquals(listOf("two", "three", "one"), afterFailed.map { it.waybill })
        assertEquals(listOf(2, 3, 0), afterFailed.map { it.sequence })
    }

    @Test
    fun `redelivery receives the next number after the last active route order`() {
        val orders = listOf(
            first.copy(sequence = 4),
            active.copy(sequence = 9),
            failed.copy(sequence = 0),
            delivered.copy(sequence = 0),
        )
        assertEquals(10, orders.nextActiveSequence())
    }

    @Test
    fun `Long Thanh samples are within five kilometers of test center`() {
        val center = GeoPoint(10.7800, 106.9500)
        assertTrue(sampleOrders().all { order -> distanceMeters(center, GeoPoint(order.latitude, order.longitude)) <= 5_000.0 })
    }

    @Test
    fun `dao chieu kinh do vi do duoc khoi phuc truoc khi dua vao ban do`() {
        val reversed = active.copy(latitude = 106.7009, longitude = 10.7769)

        val normalized = reversed.normalizedCoordinates()

        assertEquals(10.7769, normalized.latitude, 0.000001)
        assertEquals(106.7009, normalized.longitude, 0.000001)
        assertTrue(normalized.hasStoredCoordinates())
    }

    @Test
    fun `toa do ngoai pham vi khong the lam marker ban do`() {
        val invalid = active.copy(latitude = 300.0, longitude = 250.0)

        val normalized = invalid.normalizedCoordinates()

        assertEquals(0.0, normalized.latitude, 0.0)
        assertEquals(0.0, normalized.longitude, 0.0)
        assertTrue(!normalized.hasStoredCoordinates())
    }

    @Test
    fun `detail list follows seven priority groups and map keeps only route deliveries`() {
        val noCoordinates = active.copy(waybill = "no-coordinates", sequence = 0, latitude = 0.0, longitude = 0.0)
        val inProgress = active.copy(waybill = "in-progress", sequence = 2)
        val redelivery = active.copy(waybill = "redelivery", sequence = 5, wasRedelivered = true)
        val pickup = active.copy(waybill = "pickup", sequence = 0, failureReason = PICKUP_AT_WAREHOUSE, failureCount = 1)
        val temporary = active.copy(waybill = "temporary", sequence = 0, requiresRedelivery = true, failureReason = NO_CONTACT, failureCount = 1)
        val terminal = active.copy(waybill = "terminal", sequence = 0, failureReason = REFUSED, failureCount = 1)
        val completed = active.copy(waybill = "completed", status = DeliveryStatus.TT515, sequence = 0)

        val displayed = listOf(completed, terminal, temporary, pickup, redelivery, inProgress, noCoordinates).dispatchDisplayOrder()

        assertEquals(listOf("no-coordinates", "in-progress", "redelivery", "pickup", "temporary", "terminal", "completed"), displayed.map { it.waybill })
        assertTrue(inProgress.isMapVisible())
        assertTrue(!pickup.isMapVisible())
        assertTrue(!temporary.isMapVisible())
        assertTrue(!terminal.isMapVisible())
        assertTrue(!completed.isMapVisible())
    }
}
