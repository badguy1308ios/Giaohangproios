package com.example.delivery.ui

import org.junit.Assert.assertEquals
import org.junit.Test

class CashAuditCursorPositionTest {
    @Test
    fun `giu con tro o cuoi khi chu so thu tu chèn dau phay hang nghin`() {
        assertEquals(
            5,
            groupedMoneyCursorPosition(
                rawText = "1000",
                selectionEnd = 4,
                formattedText = "1,000",
            ),
        )
    }

    @Test
    fun `giu con tro o cuoi khi tiep tuc nhap sau dau phay`() {
        assertEquals(
            6,
            groupedMoneyCursorPosition(
                rawText = "1,0000",
                selectionEnd = 6,
                formattedText = "10,000",
            ),
        )
    }

    @Test
    fun `giu dung vi tri con tro khi chen so o giua`() {
        assertEquals(
            2,
            groupedMoneyCursorPosition(
                rawText = "12000",
                selectionEnd = 2,
                formattedText = "12,000",
            ),
        )
    }
}
