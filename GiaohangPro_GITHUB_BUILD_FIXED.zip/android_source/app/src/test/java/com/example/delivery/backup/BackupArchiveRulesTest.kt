package com.example.delivery.backup

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class BackupArchiveRulesTest {
    @Test
    fun `chỉ chấp nhận duong dan ZIP tuong doi an toan`() {
        assertTrue(BackupArchiveRules.isSafeArchivePath("photos/customer_gate/gate_1.webp"))
        assertFalse(BackupArchiveRules.isSafeArchivePath("../private/data.json"))
        assertFalse(BackupArchiveRules.isSafeArchivePath("/absolute/data.json"))
        assertFalse(BackupArchiveRules.isSafeArchivePath("photos//gate.webp"))
    }

    @Test
    fun `anh ZIP duoc phuc hoi dung thu muc noi bo`() {
        assertEquals("customer_gate", BackupArchiveRules.photoFolderForEntry("photos/customer_gate/gate_1.webp"))
        assertEquals("delivery_confirmation", BackupArchiveRules.photoFolderForEntry("photos/bill/bill_1.webp"))
        assertEquals("delivery_confirmation", BackupArchiveRules.photoFolderForEntry("photos/drop_off/drop_1.webp"))
        assertEquals(null, BackupArchiveRules.photoFolderForEntry("customers.json"))
    }
}
