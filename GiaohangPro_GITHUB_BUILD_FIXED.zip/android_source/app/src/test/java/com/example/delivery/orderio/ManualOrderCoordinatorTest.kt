package com.example.delivery.orderio

import com.example.delivery.customer.CustomerAddress
import com.example.delivery.customer.CustomerPhone
import com.example.delivery.customer.CustomerProfile
import com.example.delivery.model.DeliveryOrder
import org.junit.Assert.assertEquals
import org.junit.Test

class ManualOrderCoordinatorTest {
    @Test
    fun `sdt da luu toa do gan so tiep theo va toa do khach`() {
        val profile = CustomerProfile(
            name = "Nguyen Van A",
            names = listOf("Nguyen Van A"),
            phones = listOf(CustomerPhone("0901000001", true)),
            addresses = listOf(CustomerAddress("1 Duong A", 10.8, 106.9, true)),
        )
        val result = ManualOrderCoordinator.place(
            DeliveryOrder("MV01", "", "0901000001", "", "", 0, ""),
            listOf(profile),
            listOf(DeliveryOrder("OLD", "B", "2", "A", "", 0, "", sequence = 5)),
        )
        assertEquals(6, result.sequence)
        assertEquals(10.8, result.latitude, 0.0001)
        assertEquals("Nguyen Van A", result.customer)
    }

    @Test
    fun `sdt chua co toa do khong duoc danh so`() {
        val result = ManualOrderCoordinator.place(
            DeliveryOrder("MV02", "Khach Moi", "0901000002", "2 Duong B", "", 0, ""),
            emptyList(),
            emptyList(),
        )
        assertEquals(0, result.sequence)
        assertEquals(0.0, result.latitude, 0.0001)
    }
}
