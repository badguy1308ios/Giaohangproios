package com.example.delivery.orderio

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class CoordinateTextParserTest {
    @Test
    fun `tach cum vi do roi kinh do`() {
        val result = CoordinateTextParser.parse("10.7769, 106.7009")

        assertEquals(10.7769, result?.latitude ?: 0.0, 0.000001)
        assertEquals(106.7009, result?.longitude ?: 0.0, 0.000001)
    }

    @Test
    fun `dan cum Google Maps vao o vi do ben trai tach dung hai gia tri`() {
        val result = CoordinateTextParser.parse("10.802462,107.000142")

        assertEquals(10.802462, result?.latitude ?: 0.0, 0.000001)
        assertEquals(107.000142, result?.longitude ?: 0.0, 0.000001)
    }

    @Test
    fun `tu nhan biet cum kinh do roi vi do va dau phay thap phan`() {
        val result = CoordinateTextParser.parse("106,7009; 10,7769")

        assertEquals(10.7769, result?.latitude ?: 0.0, 0.000001)
        assertEquals(106.7009, result?.longitude ?: 0.0, 0.000001)
    }

    @Test
    fun `o kinh do giu dung thu tu kinh do roi vi do khi dan cum`() {
        val result = CoordinateTextParser.parseLongitudeThenLatitude("106.7009, 10.7769")

        assertEquals(10.7769, result?.latitude ?: 0.0, 0.000001)
        assertEquals(106.7009, result?.longitude ?: 0.0, 0.000001)
    }

    @Test
    fun `bo qua cum khong du hai toa do`() {
        assertNull(CoordinateTextParser.parse("10.7769"))
    }
}
