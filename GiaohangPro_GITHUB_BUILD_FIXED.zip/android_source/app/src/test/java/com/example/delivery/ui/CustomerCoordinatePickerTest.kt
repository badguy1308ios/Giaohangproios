package com.example.delivery.ui

import com.example.delivery.model.DeliveryOrder
import org.junit.Assert.assertEquals
import org.junit.Test

class CustomerCoordinatePickerTest {
    @Test
    fun `giu toa do hop le cua dia chi dang sua lam diem khoi tao ghim`() {
        assertEquals(
            CustomerPickerPosition(10.8043804, 107.0005469),
            initialCustomerPickerPosition(10.8043804, 107.0005469),
        )
        assertEquals(false, shouldInitializeCustomerPinFromGps(10.8043804, 107.0005469))
    }

    @Test
    fun `thay toa do nam ngoai pham vi bang diem mac dinh an toan`() {
        assertEquals(
            CustomerPickerPosition(10.7769, 106.7009),
            initialCustomerPickerPosition(107.0005469, 10.8043804),
        )
        assertEquals(true, shouldInitializeCustomerPinFromGps(107.0005469, 10.8043804))
    }

    @Test
    fun `chi dung GPS lam ghim khoi tao khi dia chi chua co du toa do`() {
        assertEquals(true, shouldInitializeCustomerPinFromGps(null, null))
        assertEquals(true, shouldInitializeCustomerPinFromGps(10.8043804, null))
    }

    @Test
    fun `tim dung block theo MVĐ sau khi danh sach doi thu tu`() {
        val orders = listOf(
            DeliveryOrder("MVĐ-02", "", "", "", "", 0L, ""),
            DeliveryOrder("MVĐ-01", "", "", "", "", 0L, ""),
        )
        assertEquals(1, selectedOrderIndex(orders, "MVĐ-01"))
        assertEquals(-1, selectedOrderIndex(orders, "MVĐ-khong-ton-tai"))
        assertEquals(-1, selectedOrderIndex(orders, null))
    }
}
