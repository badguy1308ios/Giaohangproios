package com.example.delivery.cash

import org.junit.Assert.assertEquals
import org.junit.Test

class CashAuditCalculatorTest {
    @Test
    fun `tinh tong tien mat tu menh gia`() {
        val counts = mapOf(500_000L to 3, 200_000L to 5, 100_000L to 8, 50_000L to 5)

        assertEquals(3_550_000L, CashAuditCalculator.cashTotal(counts))
        assertEquals("3,550,000", CashAuditCalculator.formatAmount(3_550_000L))
    }

    @Test
    fun `tinh du theo cong thuc tien mat cong bank tru cuoc cong cod`() {
        val result = CashAuditCalculator.calculate(
            counts = mapOf(500_000L to 2),
            cod = 1_500_000L,
            fee = 100_000L,
            bank = 300_000L,
        )

        assertEquals(-300_000L, result.difference)
        assertEquals(CashAuditStatus.DEFICIT, result.status)
    }

    @Test
    fun `tinh du khi tien mat cong bank lon hon cuoc cong cod`() {
        val result = CashAuditCalculator.calculate(
            counts = mapOf(500_000L to 3),
            cod = 1_000_000L,
            fee = 0L,
            bank = 100_000L,
        )

        assertEquals(600_000L, result.difference)
        assertEquals(CashAuditStatus.SURPLUS, result.status)
    }
}
