package com.example.delivery.map

import org.junit.Assert.assertEquals
import org.junit.Test

class MapTileCachePolicyTest {
    @Test
    fun `ambient tile cache uses a bounded 96 megabyte budget`() {
        assertEquals(96L * 1024L * 1024L, MAP_TILE_CACHE_BYTES)
    }
}
