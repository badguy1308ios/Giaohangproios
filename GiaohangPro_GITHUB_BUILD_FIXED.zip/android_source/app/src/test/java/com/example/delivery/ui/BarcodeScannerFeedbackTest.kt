package com.example.delivery.ui

import org.junit.Assert.assertEquals
import org.junit.Test

class BarcodeScannerFeedbackTest {
    @Test
    fun `successful scan feedback stays brief`() {
        assertEquals(45L, QR_SCAN_HAPTIC_MILLIS)
    }
}
