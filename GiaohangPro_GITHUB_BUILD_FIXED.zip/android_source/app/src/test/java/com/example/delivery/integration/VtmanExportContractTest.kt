package com.example.delivery.integration

import org.junit.Assert.assertEquals
import org.junit.Test

class VtmanExportContractTest {
    @Test fun `mo dung package cua cong cu vtman export`() {
        assertEquals("com.vtman.waybillscanner", VtmanExportContract.packageName)
    }

    @Test fun `thong bao ro khi chua cai cong cu`() {
        assertEquals("Chưa cài VTMan Export. Hãy cài công cụ trước rồi mở lại mục này.", VtmanExportContract.unavailableMessage)
    }
}
