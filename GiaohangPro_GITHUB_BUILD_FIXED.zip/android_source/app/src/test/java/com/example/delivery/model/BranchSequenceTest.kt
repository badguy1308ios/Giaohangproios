package com.example.delivery.model

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class BranchSequenceTest {
    private fun order(label: String) = DeliveryOrder(
        waybill = label,
        customer = "Khách",
        phone = label,
        address = "Địa chỉ",
        product = "Hàng",
        cod = 0,
        service = "DV",
        sequence = label.substringBefore('.').toInt(),
        sequenceLabel = label.takeIf { it.contains('.') },
        latitude = 10.7,
        longitude = 106.7,
    )

    @Test
    fun `thu tu stt nguyen truoc nhanh va nhanh mo dung sau cung`() {
        val values = listOf(order("5.n"), order("5.2"), order("6"), order("5.1"), order("5"))
            .sortedBy { it.sequenceSortValue() }
        assertEquals(listOf("5", "5.1", "5.2", "5.n", "6"), values.map { it.sequenceText() })
    }

    @Test
    fun `doi 10 thanh 4 don cu 4 den 9 tu dong don len`() {
        val orders = (1..10).map { order(it.toString()) }
        val drafts = orders.associate { it.waybill to it.sequenceText() }.toMutableMap()
        drafts["10"] = "4"
        val result = orders.resequenceDraftLabels(drafts, orders.associate { it.waybill to it.sequenceText() })
        assertEquals(listOf("1", "2", "3", "5", "6", "7", "8", "9", "10", "4"), orders.map { result[it.waybill] })
    }

    @Test
    fun `stt nhanh khong lam mat thu tu khi khong xung dot`() {
        val orders = listOf(order("1"), order("5.1"), order("5.2"), order("6"))
        val result = orders.resequenceDraftLabels(
            orders.associate { it.waybill to it.sequenceText() },
            orders.associate { it.waybill to it.sequenceText() },
        )
        assertEquals(listOf("1", "5.1", "5.2", "6"), orders.map { result[it.waybill] })
    }

    @Test
    fun `stt nhanh duoc hien thi ben vung`() {
        val branch = order("5.1")
        assertEquals("5.1", branch.sequenceText())
        assertTrue(branch.isRouteActive())
    }
}
