package com.example.delivery.orderio

import com.example.delivery.model.DeliveryFailureReason
import com.example.delivery.model.DeliveryOrder
import com.example.delivery.model.DeliveryStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayInputStream
import java.nio.charset.StandardCharsets

class SttSequenceFileCodecTest {
    @Test
    fun exportAndImportRoundTripOnlyExportsAssignedSequences() {
        val csv = SttSequenceFileCodec.exportCsv(
            listOf(
                DeliveryOrder("A", "", "", "", "", 0, "", sequence = 7),
                DeliveryOrder("B", "", "", "", "", 0, "", sequence = 0),
            ),
        )
        val entries = SttSequenceFileCodec.import(ByteArrayInputStream(csv.toByteArray(StandardCharsets.UTF_8)))
        assertEquals(listOf(SttSequenceEntry("A", 7)), entries)
    }

    @Test
    fun restoreSkipsMissingAndUnsuccessfulOrders() {
        val active = DeliveryOrder("A", "", "", "", "", 0, "", sequence = 0)
        val temporary = DeliveryOrder("B", "", "", "", "", 0, "", status = DeliveryStatus.TT506, failureReason = DeliveryFailureReason.RESCHEDULED)
        val terminal = DeliveryOrder("C", "", "", "", "", 0, "", status = DeliveryStatus.TT505, failureReason = DeliveryFailureReason.REFUSED)
        val warehouse = DeliveryOrder("D", "", "", "", "", 0, "", status = DeliveryStatus.TT507, failureReason = DeliveryFailureReason.PICKUP_AT_WAREHOUSE)
        val result = SttSequenceFileCodec.restore(
            listOf(active, temporary, terminal, warehouse),
            listOf(SttSequenceEntry("A", 9), SttSequenceEntry("B", 8), SttSequenceEntry("C", 7), SttSequenceEntry("D", 6), SttSequenceEntry("MISSING", 5)),
        )
        assertEquals(1, result.restoredCount)
        assertEquals(1, result.skippedMissingCount)
        assertEquals(3, result.skippedStatusCount)
        assertEquals(9, result.orders.first().sequence)
        assertTrue(result.orders.drop(1).all { it.sequence == 0 })
    }
}
