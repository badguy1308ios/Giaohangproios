package com.example.delivery.location

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RealtimeLocationPolicyTest {
    @Test
    fun `chi dung last known moi hon hai phut`() {
        val now = 1_000_000L

        assertTrue(RealtimeLocationPolicy.isFreshLastKnown(now - 120_000L, now))
        assertFalse(RealtimeLocationPolicy.isFreshLastKnown(now - 120_001L, now))
    }

    @Test
    fun `khong ghi de toa do moi bang toa do cu hon`() {
        assertTrue(RealtimeLocationPolicy.shouldAccept(null, 100L))
        assertTrue(RealtimeLocationPolicy.shouldAccept(100L, 100L))
        assertFalse(RealtimeLocationPolicy.shouldAccept(100L, 99L))
    }

    @Test
    fun `chi dung diem GPS moi va co do chinh xac du cho toa do khach hang`() {
        val now = 1_000_000L

        assertTrue(RealtimeLocationPolicy.isUsableForCustomer(now - 5_000L, 18f, now))
        assertFalse(RealtimeLocationPolicy.isUsableForCustomer(now - 5_000L, 76f, now))
        assertFalse(RealtimeLocationPolicy.isUsableForCustomer(now - 120_001L, 18f, now))
    }
}
