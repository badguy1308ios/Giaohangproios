package com.example.delivery.customer

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CustomerSearchTest {
    private val customer = CustomerProfile(
        name = "Nguyễn Văn An",
        names = listOf("Nguyễn Văn An", "Anh An"),
        phones = listOf(CustomerPhone("0901 234 567", isPrimary = true)),
        addresses = listOf(CustomerAddress("Đường Lê Duẩn, Long Thành", isPrimary = true)),
    )

    @Test
    fun `tim thay theo ten khong dau`() {
        assertTrue(customer.matchesSearch("nguyen van an"))
        assertTrue(customer.matchesSearch("anh an"))
    }

    @Test
    fun `tim thay theo so dien thoai va dia chi`() {
        assertTrue(customer.matchesSearch("1234567"))
        assertTrue(customer.matchesSearch("le duan"))
        assertFalse(customer.matchesSearch("khong ton tai"))
    }
}
