package com.example.delivery.orderio

import com.example.delivery.model.DeliveryOrder
import com.example.delivery.model.DeliveryFailureReason
import com.example.delivery.model.DeliveryOutcome
import com.example.delivery.model.DeliveryStatus
import com.example.delivery.model.deliveryOutcome
import com.example.delivery.customer.CustomerAddress
import com.example.delivery.customer.CustomerPhone
import com.example.delivery.customer.CustomerProfile
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class OrderImportCoordinatorTest {
    @Test
    fun `nhap don giu nguyen ban cu va chi them ma van don moi`() {
        val savedOrder = DeliveryOrder("TT001", "Khách cũ", "0901000001", "Địa chỉ cũ", "Hàng cũ", 100_000, "DV", sequence = 4)
        val importedDuplicate = DeliveryOrder(" tt001 ", "Khách bị ghi đè", "0901999999", "Địa chỉ mới", "Hàng mới", 999_000, "DV")
        val importedNew = DeliveryOrder("TT002", "Khách mới", "0901000002", "Địa chỉ mới", "Hàng mới", 200_000, "DV")

        val result = OrderImportCoordinator.appendNew(listOf(savedOrder), listOf(importedDuplicate, importedNew))

        assertEquals(1, result.ignoredDuplicateCount)
        assertEquals(listOf(savedOrder, importedNew), result.orders)
        assertEquals(listOf(importedNew), result.addedOrders)
        assertTrue(result.orders.single { it.waybill == "TT001" }.customer == "Khách cũ")
    }

    @Test
    fun `don moi dung dia chi chinh cua khach khi sdt da ton tai`() {
        val profile = CustomerProfile(
            name = "Khách đã lưu",
            phones = listOf(CustomerPhone("0839 339 485", isPrimary = true)),
            addresses = listOf(CustomerAddress("Địa chỉ khách hàng đã lưu", latitude = 10.7769, longitude = 106.7009, isPrimary = true)),
        )
        val imported = DeliveryOrder("TT100", "Khách CSV", "0839339485", "Địa chỉ CSV", "Áo thun", 0, "COD")

        val result = OrderImportCoordinator.appendNew(emptyList(), listOf(imported), listOf(profile))

        assertEquals("Địa chỉ khách hàng đã lưu", result.addedOrders.single().address)
        assertEquals(10.7769, result.addedOrders.single().latitude, 0.000001)
        assertEquals(106.7009, result.addedOrders.single().longitude, 0.000001)
        assertEquals("Áo thun", result.addedOrders.single().product)
    }

    @Test
    fun `nhap lai mvd cu chi bo sung hang hoa dang trong va khong ghi de thong tin khac`() {
        val savedOrder = DeliveryOrder("150480790693", "Mr. Minh", "0839339485", "Địa chỉ đã lưu", "", 0, "COD", sequence = 7)
        val imported = DeliveryOrder("150480790693", "Tên CSV khác", "0999000000", "Địa chỉ CSV", "hs", 999_000, "DV khác")

        val result = OrderImportCoordinator.appendNew(listOf(savedOrder), listOf(imported))

        assertEquals(1, result.ignoredDuplicateCount)
        assertEquals(1, result.restoredProductCount)
        assertEquals(0, result.addedOrders.size)
        assertEquals("hs", result.orders.single().product)
        assertEquals("Mr. Minh", result.orders.single().customer)
        assertEquals("Địa chỉ đã lưu", result.orders.single().address)
        assertEquals(7, result.orders.single().sequence)
    }

    @Test
    fun `nhap danh sach moi giu don trung kich hoat lai don tam thoi va bo don ngoai file`() {
        val active = DeliveryOrder("TT001", "Khách đang giao", "0901000001", "Địa chỉ cũ", "Hàng cũ", 100_000, "DV", sequence = 4, latitude = 10.7, longitude = 106.7)
        val temporary = DeliveryOrder(
            "TT002", "Khách hẹn", "0901000002", "Địa chỉ hẹn", "Hàng hẹn", 200_000, "DV",
            sequence = 0, latitude = 10.8, longitude = 106.8, requiresRedelivery = true,
            failureReason = DeliveryFailureReason.RESCHEDULED, failureCount = 2,
        )
        val delivered = DeliveryOrder("TT003", "Khách đã giao", "0901000003", "Địa chỉ đã giao", "Hàng", 300_000, "DV", DeliveryStatus.TT515, sequence = 0)
        val absent = DeliveryOrder("TT004", "Khách không có file", "0901000004", "Địa chỉ", "Hàng", 400_000, "DV", sequence = 5)
        val duplicateActive = active.copy(customer = "Tên CSV không được ghi đè", address = "Địa chỉ CSV", cod = 999_000)

        val result = OrderImportCoordinator.replaceWithImportedBatch(
            existingOrders = listOf(active, temporary, delivered, absent),
            importedOrders = listOf(duplicateActive, temporary.copy(customer = "Tên CSV khác"), delivered.copy(customer = "Tên CSV khác")),
        )

        assertEquals(3, result.orders.size)
        assertEquals(3, result.ignoredDuplicateCount)
        assertEquals(1, result.reactivatedCount)
        assertEquals(1, result.removedNotInLatestImportCount)
        assertEquals(active, result.orders.single { it.waybill == "TT001" })
        val reactivated = result.orders.single { it.waybill == "TT002" }
        assertEquals(DeliveryOutcome.ACTIVE, reactivated.deliveryOutcome())
        assertEquals(5, reactivated.sequence)
        assertEquals(2, reactivated.failureCount)
        assertEquals(null, reactivated.failureReason)
        assertEquals(false, reactivated.requiresRedelivery)
        assertEquals(DeliveryOutcome.DELIVERED, result.orders.single { it.waybill == "TT003" }.deliveryOutcome())
        assertTrue(result.orders.none { it.waybill == "TT004" })
    }
}
