package com.example.delivery.cash

import org.junit.Assert.assertEquals
import org.junit.Test

class CashAuditStateTest {
    @Test
    fun `normalize giu day du menh gia va gioi han so luong hop le`() {
        val state = CashAuditState(counts = mapOf(500_000L to 2_000, 200_000L to -3))

        val normalized = state.normalized()

        assertEquals(999, normalized.counts[500_000L])
        assertEquals(0, normalized.counts[200_000L])
        assertEquals(0, normalized.counts[100_000L])
        assertEquals(0, normalized.counts[50_000L])
    }
}
