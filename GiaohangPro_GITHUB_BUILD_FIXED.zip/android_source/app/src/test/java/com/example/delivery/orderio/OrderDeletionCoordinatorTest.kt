package com.example.delivery.orderio

import com.example.delivery.model.DeliveryOrder
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class OrderDeletionCoordinatorTest {
    @Test
    fun `xoa theo ma van don chi loai bo don da chon`() {
        val retained = DeliveryOrder("MV-GIU", "Khach Giữ", "0901000001", "1 Duong A", "Hang", 0, "DV")
        val deleted = DeliveryOrder("MV-XOA", "Khach Xóa", "0901000002", "2 Duong B", "Hang", 0, "DV")

        val result = OrderDeletionCoordinator.delete("mv-xoa", listOf(retained, deleted))

        assertEquals(listOf(retained), result)
        assertTrue(result.none { it.waybill == deleted.waybill })
    }
}
