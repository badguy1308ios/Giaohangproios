package com.example.delivery.debug

import org.junit.Assert.assertTrue
import org.junit.Test

class CrashDiagnosticFormatterTest {
    @Test
    fun formatIncludesStepTypeMessageAndTrace() {
        val report = CrashDiagnosticFormatter.format("Map worker", IllegalStateException("Không tải được bản đồ"))

        assertTrue(report.contains("Bước lỗi: ứng dụng bị dừng đột ngột"))
        assertTrue(report.contains("Luồng: Map worker"))
        assertTrue(report.contains("Loại lỗi: IllegalStateException"))
        assertTrue(report.contains("Không tải được bản đồ"))
        assertTrue(report.contains("Dấu vết:"))
    }
}
