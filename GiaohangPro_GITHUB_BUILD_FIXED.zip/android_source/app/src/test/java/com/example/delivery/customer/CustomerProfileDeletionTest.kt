package com.example.delivery.customer

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CustomerProfileDeletionTest {
    @Test
    fun `xoa dung ho so da chon va giu lai ho so khac`() {
        val customers = listOf(
            CustomerProfile(id = "customer-a", name = "Anh A"),
            CustomerProfile(id = "customer-b", name = "Chị B"),
        )

        val remaining = customers.withoutCustomer("customer-a")

        assertEquals(1, remaining.size)
        assertEquals("customer-b", remaining.single().id)
        assertTrue(customers.withoutCustomer("khong-ton-tai").size == customers.size)
    }
}
