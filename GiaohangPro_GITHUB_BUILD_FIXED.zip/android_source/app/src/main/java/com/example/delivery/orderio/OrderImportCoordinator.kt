package com.example.delivery.orderio

import com.example.delivery.customer.CustomerProfile
import com.example.delivery.customer.customerPhoneKey
import com.example.delivery.model.DeliveryStatus
import com.example.delivery.model.DeliveryOrder
import com.example.delivery.model.isPickupAtWarehouse
import com.example.delivery.model.isTemporaryFailure
import com.example.delivery.model.normalizedCoordinates
import java.util.Locale

data class OrderMergeResult(
    val orders: List<DeliveryOrder>,
    val addedOrders: List<DeliveryOrder>,
    val ignoredDuplicateCount: Int,
    val restoredProductCount: Int = 0,
    val reactivatedCount: Int = 0,
    val removedNotInLatestImportCount: Int = 0,
)


object OrderImportCoordinator {
    
    fun replaceWithImportedBatch(
        existingOrders: List<DeliveryOrder>,
        importedOrders: List<DeliveryOrder>,
        customerProfiles: List<CustomerProfile> = emptyList(),
    ): OrderMergeResult {
        val existingByWaybill = existingOrders.associateBy { it.waybillKey() }
        val accepted = mutableListOf<DeliveryOrder>()
        val added = mutableListOf<DeliveryOrder>()
        val temporaryIndexes = mutableListOf<Int>()
        val importedKeys = mutableSetOf<String>()
        var duplicates = 0
        var restoredProducts = 0

        importedOrders.forEach { imported ->
            val waybillKey = imported.waybillKey()
            if (!importedKeys.add(waybillKey)) return@forEach
            val saved = existingByWaybill[waybillKey]
            if (saved == null) {
                val newOrder = imported.withCustomerAddress(customerProfiles).normalizedCoordinates()
                accepted += newOrder
                added += newOrder
            } else {
                duplicates++
                val preserved = if (saved.product.isBlank() && imported.product.isNotBlank()) {
                    restoredProducts++
                    saved.copy(product = imported.product.trim())
                } else {
                    saved
                }
                accepted += preserved
                if (preserved.isTemporaryFailure() || preserved.isPickupAtWarehouse()) temporaryIndexes += accepted.lastIndex
            }
        }

        temporaryIndexes.forEach { index ->
            val order = accepted[index]
            accepted[index] = order.copy(
                status = DeliveryStatus.TT500,
                sequence = 0,
                sequenceLabel = null,
                requiresRedelivery = false,
                wasRedelivered = false,
                failureReason = null,
            )
        }
        accepted.indices.forEach { index ->
            accepted[index] = accepted[index].copy(sequence = 0, sequenceLabel = null)
        }
        val removed = existingOrders.count { it.waybillKey() !in importedKeys }
        return OrderMergeResult(
            orders = accepted,
            addedOrders = added,
            ignoredDuplicateCount = duplicates,
            restoredProductCount = restoredProducts,
            reactivatedCount = temporaryIndexes.size,
            removedNotInLatestImportCount = removed,
        )
    }

    fun appendNew(
        existingOrders: List<DeliveryOrder>,
        importedOrders: List<DeliveryOrder>,
        customerProfiles: List<CustomerProfile> = emptyList(),
    ): OrderMergeResult {
        val mergedOrders = existingOrders.toMutableList()
        val indexByWaybill = existingOrders.mapIndexed { index, order -> order.waybillKey() to index }.toMap().toMutableMap()
        val added = mutableListOf<DeliveryOrder>()
        var duplicates = 0
        var restoredProducts = 0
        importedOrders.forEach { imported ->
            val waybillKey = imported.waybillKey()
            val existingIndex = indexByWaybill[waybillKey]
            if (existingIndex == null) {
                val accepted = imported.withCustomerAddress(customerProfiles).normalizedCoordinates()
                indexByWaybill[waybillKey] = mergedOrders.size
                mergedOrders += accepted
                added += accepted
            } else {
                duplicates++
                val existing = mergedOrders[existingIndex]
                if (existing.product.isBlank() && imported.product.isNotBlank()) {
                    mergedOrders[existingIndex] = existing.copy(product = imported.product.trim())
                    restoredProducts++
                }
            }
        }
        return OrderMergeResult(mergedOrders, added, duplicates, restoredProducts)
    }

    private fun DeliveryOrder.waybillKey(): String = waybill.trim().lowercase(Locale.ROOT)

    
    private fun DeliveryOrder.withCustomerAddress(profiles: List<CustomerProfile>): DeliveryOrder {
        val targetPhone = phone.customerPhoneKey()
        if (targetPhone.isBlank()) return this

        val matchedProfile = profiles.firstOrNull { profile ->
            profile.phones.any { savedPhone ->
                savedPhone.number.customerPhoneKey() == targetPhone
            }
        } ?: return this

        val savedAddress = matchedProfile.primaryAddress
        if (savedAddress.address.isBlank()) return this

        return copy(
            address = savedAddress.address,
            latitude = savedAddress.latitude ?: latitude,
            longitude = savedAddress.longitude ?: longitude,
        )
    }

}
