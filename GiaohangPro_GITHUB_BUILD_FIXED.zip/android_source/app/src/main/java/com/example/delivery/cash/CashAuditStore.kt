package com.example.delivery.cash

import android.content.Context

data class CashAuditState(
    val counts: Map<Long, Int> = CashAuditCalculator.denominations.associateWith { 0 },
    val bankInput: String = "",
    val feeInput: String = "",
    val codInput: String = "",
) {
    fun normalized(): CashAuditState = copy(
        counts = CashAuditCalculator.denominations.associateWith { denomination ->
            (counts[denomination] ?: 0).coerceIn(0, 999)
        },
    )
}

object CashAuditStore {
    private const val PREFERENCES = "cash_audit_state_v1"
    private const val BANK = "bank"
    private const val FEE = "fee"
    private const val COD = "cod"

    fun load(context: Context): CashAuditState {
        val preferences = context.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE)
        return CashAuditState(
            counts = CashAuditCalculator.denominations.associateWith { denomination ->
                preferences.getInt(countKey(denomination), 0).coerceIn(0, 999)
            },
            bankInput = preferences.getString(BANK, "").orEmpty(),
            feeInput = preferences.getString(FEE, "").orEmpty(),
            codInput = preferences.getString(COD, "").orEmpty(),
        )
    }

    fun save(context: Context, state: CashAuditState) {
        val normalized = state.normalized()
        context.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE).edit().apply {
            normalized.counts.forEach { (denomination, count) -> putInt(countKey(denomination), count) }
            putString(BANK, normalized.bankInput)
            putString(FEE, normalized.feeInput)
            putString(COD, normalized.codInput)
            apply()
        }
    }

    fun reset(context: Context) {
        context.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE).edit().clear().apply()
    }

    private fun countKey(denomination: Long): String = "count_$denomination"
}
