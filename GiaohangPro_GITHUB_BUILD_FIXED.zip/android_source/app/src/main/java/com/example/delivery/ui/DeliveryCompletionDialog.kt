package com.example.delivery.ui

import android.Manifest
import android.app.Activity
import android.content.Context
import android.widget.Toast
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.relocation.BringIntoViewRequester
import androidx.compose.foundation.relocation.bringIntoViewRequester
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import com.example.delivery.history.DeliveryPhotoHistory
import com.example.delivery.history.PaymentChannel
import com.example.delivery.history.ProofPhotoType
import com.example.delivery.history.TransferEvidence
import com.example.delivery.orderio.CoordinateUpdateRequest
import com.example.delivery.orderio.CoordinateTextParser
import com.example.delivery.location.RealtimeLocationPolicy
import com.example.delivery.customer.CustomerAddress
import com.example.delivery.customer.CustomerContactMethod
import com.example.delivery.customer.CustomerPhone
import com.example.delivery.customer.CustomerProfile
import com.example.delivery.customer.CustomerProfileStore
import com.example.delivery.customer.matchesSearch
import com.example.delivery.model.DeliveryOrder
import com.example.delivery.model.DeliveryOutcome
import com.example.delivery.model.DeliveryStatus
import com.example.delivery.model.hasStoredCoordinates
import com.example.delivery.model.canReceiveRouteSequence
import com.example.delivery.model.dispatchDisplayOrder
import com.example.delivery.model.formatVnd
import com.example.delivery.model.isMapVisible
import com.example.delivery.model.isPickupAtWarehouse
import com.example.delivery.model.isRouteActive
import com.example.delivery.model.statusLabel
import com.example.delivery.model.withStableRouteLabels
import com.example.delivery.model.resequenceDraftLabels
import com.example.delivery.model.sequenceText
import com.example.delivery.model.sequenceSortValue
import com.example.delivery.model.csvStatus
import com.example.delivery.navigation.DeliveryRouteStore
import com.example.delivery.navigation.DeliveryZone
import com.example.delivery.navigation.GeoPoint
import com.example.delivery.navigation.persistedRouteLabels
import com.example.delivery.navigation.preferredRouteOrigin
import com.example.delivery.navigation.routeOrdersFrom
import kotlinx.coroutines.delay
import java.util.Locale

@Composable
internal fun DeliveryCompletionDialog(
    order: DeliveryOrder,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Xác nhận giao thành công") },
        text = { Text("Bạn chắc chắn giao thành công đơn hàng ${order.waybill}?", fontSize = 13.sp) },
        confirmButton = {
            Button(onClick = onConfirm, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF229846))) { Text("Có") }
        },
        dismissButton = { OutlinedButton(onClick = onDismiss) { Text("Không") } },
    )
}
