package com.example.delivery.customer

import android.content.Context
import com.example.delivery.model.DeliveryOrder
import com.example.delivery.model.hasStoredCoordinates
import com.example.delivery.model.isMapCoordinatePair
import org.json.JSONArray
import org.json.JSONObject
import java.text.Normalizer
import java.util.Locale
import java.util.UUID

enum class CustomerContactMethod(val label: String) {
    CALL("Gọi"),
    SMS("SMS"),
    ZALO("Zalo"),
}

data class CustomerPhone(
    val number: String,
    val isPrimary: Boolean = false,
    val methods: Set<CustomerContactMethod> = setOf(CustomerContactMethod.CALL, CustomerContactMethod.SMS, CustomerContactMethod.ZALO),
)

data class CustomerAddress(
    val address: String,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val isPrimary: Boolean = false,
    val housePhotoPath: String? = null,
)


fun CustomerAddress.normalizedCoordinates(): CustomerAddress = when {
    latitude == null || longitude == null -> this
    isMapCoordinatePair(latitude, longitude) -> this
    isMapCoordinatePair(longitude, latitude) -> copy(latitude = longitude, longitude = latitude)
    else -> copy(latitude = null, longitude = null)
}

data class CustomerProfile(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "",
    val names: List<String> = emptyList(),
    val phones: List<CustomerPhone> = listOf(CustomerPhone("", isPrimary = true)),
    val addresses: List<CustomerAddress> = listOf(CustomerAddress("", isPrimary = true)),
    val note: String = "",
) {
    val displayName: String get() = names.firstOrNull { it.isNotBlank() } ?: name
    val primaryPhone: CustomerPhone
        get() = phones.firstOrNull { it.isPrimary }
            ?: phones.firstOrNull()
            ?: CustomerPhone(number = "", isPrimary = true)
    val primaryAddress: CustomerAddress
        get() = addresses.firstOrNull { it.isPrimary }
            ?: addresses.firstOrNull()
            ?: CustomerAddress(address = "", isPrimary = true)

    fun normalized(): CustomerProfile {
        val cleanNames = (names + name).map(String::trim).filter(String::isNotBlank).distinct()
        val cleanPhones = phones.map { it.copy(number = it.number.trim()) }.filter { it.number.isNotBlank() }
        val normalizedPhones = cleanPhones.map { phone ->
            phone.copy(methods = phone.methods.ifEmpty {
                if (cleanPhones.size == 1) CustomerContactMethod.entries.toSet()
                else setOf(CustomerContactMethod.CALL)
            })
        }
        val cleanAddresses = addresses.map { it.normalizedCoordinates().copy(address = it.address.trim()) }.filter { it.address.isNotBlank() }
        val primaryPhoneIndex = cleanPhones.indexOfFirst { it.isPrimary }.takeIf { it >= 0 } ?: 0
        val primaryAddressIndex = cleanAddresses.indexOfFirst { it.isPrimary }.takeIf { it >= 0 } ?: 0
        return copy(
            name = cleanNames.firstOrNull().orEmpty(),
            names = cleanNames,
            phones = normalizedPhones.mapIndexed { index, phone -> phone.copy(isPrimary = index == primaryPhoneIndex) },
            addresses = cleanAddresses.mapIndexed { index, address -> address.copy(isPrimary = index == primaryAddressIndex) },
            note = note.trim(),
        )
    }

    fun isValid(): Boolean = (names.any { it.isNotBlank() } || name.isNotBlank()) && phones.any { it.number.isNotBlank() } && addresses.any { it.address.isNotBlank() }

    companion object {
        fun empty() = CustomerProfile()
        fun fromOrder(order: DeliveryOrder) = CustomerProfile(
            id = "order-${order.phone.customerPhoneKey()}",
            name = order.customer,
            names = listOf(order.customer),
            phones = listOf(CustomerPhone(order.phone, isPrimary = true)),
            addresses = listOf(
                CustomerAddress(
                    address = order.address,
                    latitude = order.latitude.takeIf { order.hasStoredCoordinates() },
                    longitude = order.longitude.takeIf { order.hasStoredCoordinates() },
                    isPrimary = true,
                ),
            ),
        )
    }
}


fun List<CustomerProfile>.missingProfilesFromOrders(orders: List<DeliveryOrder>): List<CustomerProfile> {
    val savedPhones = flatMap { profile -> profile.phones.map { it.number.customerPhoneKey() } }.filter(String::isNotBlank).toSet()
    return orders
        .filter { order -> order.phone.customerPhoneKey().isNotBlank() && order.customer.isNotBlank() && order.address.isNotBlank() }
        .distinctBy { it.phone.customerPhoneKey() }
        .filter { order -> order.phone.customerPhoneKey() !in savedPhones }
        .map(CustomerProfile::fromOrder)
        .map(CustomerProfile::normalized)
        .filter(CustomerProfile::isValid)
}


internal fun String.customerPhoneKey(): String {
    val digits = filter(Char::isDigit)
    return when {
        digits.startsWith("0084") && digits.length > 4 -> "0${digits.drop(4)}"
        digits.startsWith("84") && digits.length > 2 -> "0${digits.drop(2)}"
        else -> digits
    }
}

fun List<CustomerProfile>.mergeOrderCustomers(orders: List<DeliveryOrder>): List<CustomerProfile> {
    val savedByPhone = flatMap { profile ->
        profile.phones.mapNotNull { phone -> phone.number.customerPhoneKey().takeIf(String::isNotBlank)?.let { it to profile } }
    }.toMap()
    val orderPhoneKeys = orders.map { it.phone.customerPhoneKey() }.filter(String::isNotBlank).toSet()
    val derived = orders
        .filter { it.phone.customerPhoneKey().isNotBlank() }
        .distinctBy { it.phone.customerPhoneKey() }
        .map { order -> savedByPhone[order.phone.customerPhoneKey()] ?: CustomerProfile.fromOrder(order) }
    val manual = filter { profile -> profile.phones.none { it.number.customerPhoneKey() in orderPhoneKeys } }
    return (derived + manual)
        .distinctBy { profile -> profile.phones.firstOrNull()?.number?.customerPhoneKey().orEmpty().ifBlank { profile.id } }
        .sortedBy { it.displayName.lowercase() }
}

fun List<CustomerProfile>.withoutCustomer(customerId: String): List<CustomerProfile> = filterNot { it.id == customerId }

fun CustomerProfile.matchesSearch(query: String): Boolean {
    val textQuery = query.searchKey()
    if (textQuery.isBlank()) return true
    val digitsQuery = query.filter(Char::isDigit)
    val textMatches = (names + name + addresses.map { it.address }).any { value -> value.searchKey().contains(textQuery) }
    val phoneMatches = phones.any { phone ->
        phone.number.searchKey().contains(textQuery) || (digitsQuery.isNotBlank() && phone.number.filter(Char::isDigit).contains(digitsQuery))
    }
    return textMatches || phoneMatches
}

private fun String.searchKey(): String = Normalizer.normalize(trim(), Normalizer.Form.NFD)
    .replace("\\p{Mn}+".toRegex(), "")
    .lowercase(Locale.ROOT)

object CustomerProfileStore {
    private const val PREF = "customer_profiles_v2"
    private const val KEY = "items"
    private const val DELETED_PREFIX = "deleted_"

    fun load(context: Context): List<CustomerProfile> = runCatching {
        val array = JSONArray(context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, "[]"))
        List(array.length()) { array.getJSONObject(it).toProfile() }
    }.getOrDefault(emptyList())

    fun upsert(context: Context, profile: CustomerProfile): List<CustomerProfile> {
        val normalized = profile.normalized()
        require(normalized.isValid()) { "Hồ sơ khách hàng chưa đủ thông tin" }
        val updated = load(context).filterNot { it.id == normalized.id } + normalized
        return persist(context, updated)
    }

    
    fun upsertMissingFromOrders(context: Context, orders: List<DeliveryOrder>): List<CustomerProfile> {
        val current = load(context)

        val missing = current.missingProfilesFromOrders(orders)

        return if (missing.isEmpty()) current else persist(context, current + missing)
    }

    
    fun replace(context: Context, profiles: List<CustomerProfile>): List<CustomerProfile> = persist(context, profiles)

    private fun persist(context: Context, profiles: List<CustomerProfile>): List<CustomerProfile> {
        val normalized = profiles.map(CustomerProfile::normalized).distinctBy(CustomerProfile::id)
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
            .putString(KEY, JSONArray(normalized.map { it.toJson() }).toString())
            .apply()
        return normalized
    }

    
    fun delete(context: Context, customerId: String): List<CustomerProfile> {
        val updated = load(context).withoutCustomer(customerId)
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
            .putString(KEY, JSONArray(updated.map { it.toJson() }).toString())
            .putBoolean("$DELETED_PREFIX$customerId", true)
            .apply()
        return updated
    }

    fun isDeleted(context: Context, customerId: String): Boolean = context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getBoolean("$DELETED_PREFIX$customerId", false)

    
    fun snapshotJson(context: Context): String = context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"

    fun validateBackupJson(raw: String) {
        val values = JSONArray(raw)
        List(values.length()) { values.getJSONObject(it).toProfile() }.forEach { profile ->
            require(profile.isValid()) { "Một hồ sơ khách hàng trong ZIP chưa đủ thông tin." }
        }
    }

    fun replaceFromBackupJson(context: Context, raw: String) {
        validateBackupJson(raw)
        val preferences = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val editor = preferences.edit().putString(KEY, JSONArray(raw).toString())
        preferences.all.keys.filter { it.startsWith(DELETED_PREFIX) }.forEach(editor::remove)
        check(editor.commit()) {
            "Không thể lưu dữ liệu khách hàng sau khi nhập ZIP."
        }
    }

    private fun CustomerProfile.toJson() = JSONObject()
        .put("id", id)
        .put("name", name)
        .put("names", JSONArray(names))
        .put("note", note)
        .put("phones", JSONArray(phones.map { phone -> JSONObject().put("number", phone.number).put("primary", phone.isPrimary).put("methods", JSONArray(phone.methods.map { it.name })) }))
        .put("addresses", JSONArray(addresses.map { address -> JSONObject().put("address", address.address).put("lat", address.latitude).put("lng", address.longitude).put("primary", address.isPrimary).put("housePhoto", address.housePhotoPath) }))

    private fun JSONObject.toProfile(): CustomerProfile {
        val phoneArray = getJSONArray("phones")
        val addressArray = getJSONArray("addresses")
        return CustomerProfile(
            id = getString("id"),
            name = optString("name"),
            names = optJSONArray("names")?.let { array -> List(array.length()) { array.optString(it) } }.orEmpty(),
            phones = List(phoneArray.length()) { index ->
                val item = phoneArray.getJSONObject(index)
                CustomerPhone(item.getString("number"), item.optBoolean("primary"), item.optJSONArray("methods")?.let { methods -> List(methods.length()) { CustomerContactMethod.valueOf(methods.getString(it)) }.toSet() } ?: setOf(CustomerContactMethod.CALL))
            },
            addresses = List(addressArray.length()) { index ->
                val item = addressArray.getJSONObject(index)
                CustomerAddress(item.getString("address"), item.optDouble("lat").takeIf { !it.isNaN() }, item.optDouble("lng").takeIf { !it.isNaN() }, item.optBoolean("primary"), item.optString("housePhoto").takeIf { it.isNotBlank() && it != "null" })
            },
            note = optString("note"),
        ).normalized()
    }
}
