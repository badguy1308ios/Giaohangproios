package com.example.delivery.navigation

import com.example.delivery.model.DeliveryOrder
import com.example.delivery.model.dispatchDisplayOrder
import com.example.delivery.model.hasStoredCoordinates
import com.example.delivery.model.isRouteActive
import com.example.delivery.model.sequenceText
import com.example.delivery.model.sequenceSortValue
import com.example.delivery.model.phoneGroupKey
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

private const val EARTH_RADIUS_METERS = 6_371_000.0


fun preferredRouteOrigin(anchorPoint: GeoPoint?, currentLocation: GeoPoint?, fallback: GeoPoint?): GeoPoint? =
    anchorPoint ?: currentLocation ?: fallback

fun distanceMeters(from: GeoPoint, to: GeoPoint): Double {
    val deltaLatitude = Math.toRadians(to.latitude - from.latitude)
    val deltaLongitude = Math.toRadians(to.longitude - from.longitude)
    val latitudeOne = Math.toRadians(from.latitude)
    val latitudeTwo = Math.toRadians(to.latitude)
    val haversine = sin(deltaLatitude / 2) * sin(deltaLatitude / 2) +
        cos(latitudeOne) * cos(latitudeTwo) * sin(deltaLongitude / 2) * sin(deltaLongitude / 2)
    return EARTH_RADIUS_METERS * 2 * atan2(sqrt(haversine), sqrt(1 - haversine))
}


fun routeOrdersFrom(origin: GeoPoint, orders: List<DeliveryOrder>): List<DeliveryOrder> = routeOrdersFromZones(origin, orders, emptyList())


fun orderRouteGroupsByZoneAndGeo(groups: Collection<List<DeliveryOrder>>, zones: List<DeliveryZone>): List<List<DeliveryOrder>> {
    if (groups.size <= 1) return groups.toList()
    fun center(group: List<DeliveryOrder>) = GeoPoint(group.map { it.latitude }.average(), group.map { it.longitude }.average())
    fun zoneRank(group: List<DeliveryOrder>): Int = zones.indexOfFirst { zone ->
        group.any { order -> DeliveryRouteStore.contains(zone, order.latitude, order.longitude) }
    }.let { if (it < 0) Int.MAX_VALUE else it }

    val remaining = groups.toMutableList()
    val ordered = mutableListOf<List<DeliveryOrder>>()
    var cursorGroup = remaining.minWithOrNull(compareBy<List<DeliveryOrder>>(
        { group -> center(group).longitude },
        { group -> center(group).latitude },
        { group -> zoneRank(group) },
        { group -> group.minOf { it.waybill } },
    )) ?: return emptyList()
    remaining.remove(cursorGroup)
    ordered += cursorGroup
    var cursor = center(cursorGroup)

    while (remaining.isNotEmpty()) {
        val next = remaining.minWithOrNull(compareBy<List<DeliveryOrder>>(
            { group ->
                val target = center(group)
                val travel = distanceMeters(cursor, target)
                val backward = ((cursor.longitude - target.longitude).coerceAtLeast(0.0)) * 111_000.0
                travel + backward * 2.0
            },
            { group -> zoneRank(group) },
            { group -> center(group).longitude },
            { group -> center(group).latitude },
            { group -> group.minOf { it.waybill } },
        )) ?: break
        ordered += next
        cursor = center(next)
        remaining.remove(next)
    }
    return ordered
}


fun routeOrdersFromZones(origin: GeoPoint, orders: List<DeliveryOrder>, zones: List<DeliveryZone>): List<DeliveryOrder> {
    val candidates = orders.filter { it.isRouteActive() && it.hasStoredCoordinates() }
    val groups = candidates.groupBy { it.phoneGroupKey() }.values
    val orderedGroups = if (zones.isEmpty()) nearestNeighborGroups(origin, groups) else orderRouteGroupsByZoneAndGeo(groups, zones)
    return orderedGroups.flatMapIndexed { index, group ->
        group.sortedWith(compareBy<DeliveryOrder> { it.longitude }.thenBy { it.latitude }.thenBy { it.waybill })
            .map { it.copy(sequence = index + 1) }
    }
}

private fun nearestNeighborGroups(origin: GeoPoint, groups: Collection<List<DeliveryOrder>>): List<List<DeliveryOrder>> {
    val remaining = groups.toMutableList()
    val result = mutableListOf<List<DeliveryOrder>>()
    var cursor = origin
    while (remaining.isNotEmpty()) {
        val next = remaining.minByOrNull { group -> group.minOf { distanceMeters(cursor, GeoPoint(it.latitude, it.longitude)) } } ?: break
        result += next
        cursor = next.minBy { distanceMeters(cursor, GeoPoint(it.latitude, it.longitude)) }.let { GeoPoint(it.latitude, it.longitude) }
        remaining.remove(next)
    }
    return result
}

private fun nearestNeighbor(origin: GeoPoint, orders: List<DeliveryOrder>): List<DeliveryOrder> {
    val remaining = orders.toMutableList()
    val result = mutableListOf<DeliveryOrder>()
    var cursor = origin
    while (remaining.isNotEmpty()) {
        val next = remaining.minByOrNull { distanceMeters(cursor, GeoPoint(it.latitude, it.longitude)) } ?: break
        result += next
        cursor = GeoPoint(next.latitude, next.longitude)
        remaining.remove(next)
    }
    return result
}


private fun optimizeRoute(origin: GeoPoint, initial: List<DeliveryOrder>): List<DeliveryOrder> {
    if (initial.size < 3) return initial
    var route = initial
    var bestDistance = routeDistanceMeters(origin, route)
    var improved = true
    while (improved) {
        improved = false
        var bestCandidate = route
        var bestCandidateDistance = bestDistance

        for (start in 0 until route.lastIndex) {
            for (end in start + 1..route.lastIndex) {
                val candidate = route.toMutableList().apply { subList(start, end + 1).reverse() }
                val candidateDistance = routeDistanceMeters(origin, candidate)
                if (candidateDistance + 0.5 < bestCandidateDistance) {
                    bestCandidate = candidate
                    bestCandidateDistance = candidateDistance
                }
            }
        }

        for (from in route.indices) {
            val without = route.toMutableList().apply { removeAt(from) }
            for (insertion in 0..without.size) {
                val candidate = without.toMutableList().apply { add(insertion, route[from]) }
                val candidateDistance = routeDistanceMeters(origin, candidate)
                if (candidateDistance + 0.5 < bestCandidateDistance) {
                    bestCandidate = candidate
                    bestCandidateDistance = candidateDistance
                }
            }
        }

        if (bestCandidateDistance + 0.5 < bestDistance) {
            route = bestCandidate
            bestDistance = bestCandidateDistance
            improved = true
        }
    }
    return route
}

fun routeDistanceMeters(origin: GeoPoint, route: List<DeliveryOrder>): Double {
    var total = 0.0
    var cursor = origin
    route.forEach { order ->
        val next = GeoPoint(order.latitude, order.longitude)
        total += distanceMeters(cursor, next)
        cursor = next
    }
    return total
}


fun routeOrdersForDisplay(origin: GeoPoint, orders: List<DeliveryOrder>): List<DeliveryOrder> {
    val active = routeOrdersFrom(origin, orders)
    val inactive = orders.filterNot { it.isRouteActive() }.dispatchDisplayOrder()
    return active + inactive
}


fun List<DeliveryOrder>.persistedRouteSequence(): Map<String, Int> =
    filter { it.isRouteActive() && it.hasStoredCoordinates() && it.sequence > 0 && it.sequenceLabel == null }
        .sortedWith(compareBy<DeliveryOrder> { it.sequence }.thenBy { it.waybill })
        .associate { it.waybill to it.sequence }

fun List<DeliveryOrder>.persistedRouteLabels(): Map<String, String> =
    filter { it.isRouteActive() && it.hasStoredCoordinates() }
        .sortedWith(compareBy<DeliveryOrder> { it.sequenceSortValue() }.thenBy { it.waybill })
        .associate { it.waybill to it.sequenceText() }
