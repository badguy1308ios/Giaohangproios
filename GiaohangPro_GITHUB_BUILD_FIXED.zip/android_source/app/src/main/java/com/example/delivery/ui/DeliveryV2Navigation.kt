package com.example.delivery.ui

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import com.example.delivery.history.TransferEvidence
import com.example.delivery.model.DeliveryOrder
import com.example.delivery.navigation.DeliveryRouteStore
import com.example.delivery.navigation.GeoPoint
import com.example.delivery.ui.logic.buildRouteSequence
import com.example.delivery.ui.logic.findRouteOrigin


@Composable
internal fun DeliveryV2Navigation(
    state: DeliveryV2State,
    orders: List<DeliveryOrder>,
    transferEvidence: List<TransferEvidence>,
    backupStatus: String?,
    onConfirmTransferPayment: (String) -> Unit,
    onOpenVtmanExport: () -> Unit,
    onCreateRoute: (RouteCreationMode) -> Unit,
    onDeleteRoute: () -> Unit,
    onAddManualOrder: (DeliveryOrder) -> Unit,
    onDeleteOrder: (String) -> Unit,
    onDeleteAllOrders: () -> Unit,
    onUpdateCoordinates: (com.example.delivery.orderio.CoordinateUpdateRequest) -> Unit,
    onSyncOrdersFromCustomerCoordinates: () -> Unit,
    onExportBackup: () -> Unit,
    onImportBackup: () -> Unit,
    onImportOrders: () -> Unit,
    onExportOrders: () -> Unit,
    onExportStt: () -> Unit,
    onImportStt: () -> Unit,
    onRouteSequenceLocked: (Map<String, String>) -> Unit,
): Boolean {
    val context = LocalContext.current
    LaunchedEffect(context) {
        state.zones = DeliveryRouteStore.loadZones(context)
        state.zonesLoaded = true
    }

    val locationPreferences = androidx.compose.runtime.remember(context) {
        context.getSharedPreferences("location_permission", Context.MODE_PRIVATE)
    }
    val locationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { permissions ->
        state.locationGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            permissions[Manifest.permission.ACCESS_COARSE_LOCATION] == true
    }

    LaunchedEffect(Unit) {
        state.locationGranted = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!state.locationGranted && !locationPreferences.getBoolean("asked_once", false)) {
            locationPreferences.edit().putBoolean("asked_once", true).apply()
            locationPermission.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
        }
    }

    BackHandler {
        when {
            state.scannerOpen -> state.scannerOpen = false
            state.routeScreenOpen -> { state.routeScreenOpen = false; state.settingsOpen = true }
            state.coordinateUpdateOpen -> { state.coordinateUpdateOpen = false; state.orderManagementOpen = true }
            state.orderManagementOpen -> { state.orderManagementOpen = false; state.settingsOpen = true }
            state.backupOpen -> { state.backupOpen = false; state.settingsOpen = true }
            state.cashAuditOpen -> { state.cashAuditOpen = false; state.settingsOpen = true }
            state.transferCheckOpen -> { state.transferCheckOpen = false; state.settingsOpen = true }
            state.settingsOpen -> state.settingsOpen = false
            else -> {
                val now = System.currentTimeMillis()
                if (now - state.lastBackPressedAt <= 1_800L) {
                    (context as? Activity)?.finish()
                } else {
                    state.lastBackPressedAt = now
                    Toast.makeText(context, "Nhấn Back lần nữa để thoát ứng dụng", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    if (state.scannerOpen) {
        BarcodeScannerScreen(onCodeScanned = { code -> state.detailSearchQuery = code; state.scannerOpen = false; state.tab = DeliveryTab.DETAIL }, onDismiss = { state.scannerOpen = false })
        return true
    }
    if (state.settingsOpen) {
        SettingsScreen(
            evidence = transferEvidence,
            onConfirmPayment = onConfirmTransferPayment,
            onOpenCashAudit = { state.settingsOpen = false; state.cashAuditOpen = true },
            onOpenBackup = { state.settingsOpen = false; state.backupOpen = true },
            onOpenVtmanExport = onOpenVtmanExport,
            onOpenTransferCheck = { state.settingsOpen = false; state.transferCheckOpen = true },
            onOpenOrderManagement = { state.settingsOpen = false; state.orderManagementOpen = true },
            onOpenAnchorPoint = { state.settingsOpen = false; state.routeScreenOpen = true },
            onClose = { state.settingsOpen = false },
        )
        return true
    }
    if (state.routeScreenOpen) {
        DeliveryRouteScreen(
            zones = state.zones,
            onZonesChanged = { updated -> state.zones = updated; DeliveryRouteStore.saveZones(context, updated) },
            onCreateRoute = onCreateRoute,
            onDeleteRoute = onDeleteRoute,
            onClose = { state.routeScreenOpen = false; state.settingsOpen = true },
        )
        return true
    }
    if (state.orderManagementOpen) {
        OrderManagementScreen(
            status = backupStatus,
            onAddManualOrder = onAddManualOrder,
            onDeleteOrder = onDeleteOrder,
            onDeleteAllOrders = onDeleteAllOrders,
            onOpenCoordinateUpdate = { state.orderManagementOpen = false; state.coordinateUpdateOpen = true },
            onConfirmRouteChange = {
                val origin = findRouteOrigin(orders, state.currentGps)
                if (origin != null) {
                    val confirmed = buildRouteSequence(orders, origin)
                    state.stableRouteSequence = confirmed
                    onRouteSequenceLocked(confirmed)
                    state.selectedNavigationOrder = null
                    state.coordinateUpdateOpen = false
                    state.orderManagementOpen = false
                }
            },
            onClose = { state.orderManagementOpen = false; state.settingsOpen = true },
        )
        return true
    }
    if (state.backupOpen) {
        BackupDataScreen(onExportBackup, onImportBackup, onImportOrders, onExportOrders, onExportStt, onImportStt, backupStatus) { state.backupOpen = false; state.settingsOpen = true }
        return true
    }
    if (state.cashAuditOpen) {
        CashAuditScreen(onClose = { state.cashAuditOpen = false; state.settingsOpen = true })
        return true
    }
    if (state.transferCheckOpen) {
        TransferCheckScreen(onClose = { state.transferCheckOpen = false; state.settingsOpen = true })
        return true
    }
    if (state.coordinateUpdateOpen) {
        CoordinateUpdateScreen(
            status = backupStatus,
            onSave = onUpdateCoordinates,
            onConfirmRouteChange = {
                onSyncOrdersFromCustomerCoordinates()
                val origin = findRouteOrigin(orders, state.currentGps)
                if (origin != null) {
                    val confirmed = buildRouteSequence(orders, origin)
                    state.stableRouteSequence = confirmed
                    onRouteSequenceLocked(confirmed)
                    state.selectedNavigationOrder = null
                    state.coordinateUpdateOpen = false
                    state.orderManagementOpen = false
                }
            },
            onClose = { state.coordinateUpdateOpen = false; state.orderManagementOpen = true },
        )
        return true
    }
    return false
}
