package com.example.delivery.orderio

import com.example.delivery.model.DeliveryOrder
import com.example.delivery.model.isPickupAtWarehouse
import com.example.delivery.model.isTerminalFailure
import com.example.delivery.model.isTemporaryFailure
import java.io.InputStream
import java.nio.charset.StandardCharsets
import java.text.Normalizer
import java.util.Locale

data class SttSequenceEntry(val waybill: String, val sequence: Int)

data class SttRestoreResult(
    val orders: List<DeliveryOrder>,
    val restoredCount: Int,
    val skippedMissingCount: Int,
    val skippedStatusCount: Int,
)

object SttSequenceFileCodec {
    fun exportCsv(orders: List<DeliveryOrder>): String = buildString {
        append('\uFEFF')
        append("\"Mã vận đơn\",\"STT\"\r\n")
        orders.filter { it.sequence > 0 }.forEach { order ->
            appendCsvRow(order.waybill, order.sequence.toString())
        }
    }

    fun import(input: InputStream): List<SttSequenceEntry> {
        val rows = OrderFileCodec.parseDelimited(input.readBytes().toString(StandardCharsets.UTF_8))
        require(rows.isNotEmpty()) { "Tệp STT đang trống." }
        val first = rows.first().map { value -> value.normalizeHeader() }
        val waybillIndex = first.indexOfFirst { it in setOf("mavandon", "waybill", "tracking", "madon", "orderid") }
        val sequenceIndex = first.indexOfFirst { it in setOf("stt", "sequence", "thutu") }
        val hasHeader = waybillIndex >= 0 || sequenceIndex >= 0
        val wb = if (hasHeader) waybillIndex else 0
        val seq = if (hasHeader) sequenceIndex else 1
        require(wb >= 0 && seq >= 0) { "Tệp STT phải có cột Mã vận đơn và STT." }
        return rows.drop(if (hasHeader) 1 else 0).mapNotNull { row ->
            val waybill = row.getOrNull(wb).orEmpty().trim()
            val sequence = row.getOrNull(seq)?.trim()?.toIntOrNull()
            if (waybill.isBlank() || sequence == null || sequence <= 0) null else SttSequenceEntry(waybill, sequence)
        }.distinctBy { it.waybill.lowercase(Locale.ROOT) }.also {
            require(it.isNotEmpty()) { "Không tìm thấy Mã vận đơn và STT hợp lệ." }
        }
    }

    fun restore(orders: List<DeliveryOrder>, entries: List<SttSequenceEntry>): SttRestoreResult {
        val byWaybill = entries.associateBy { it.waybill.trim().lowercase(Locale.ROOT) }
        var restored = 0
        var missing = 0
        var skipped = 0
        val result = orders.map { order ->
            val entry = byWaybill[order.waybill.trim().lowercase(Locale.ROOT)]
            when {
                entry == null -> order
                order.isTemporaryFailure() || order.isTerminalFailure() || order.isPickupAtWarehouse() -> {
                    skipped++
                    order
                }
                else -> {
                    restored++
                    order.copy(sequence = entry.sequence)
                }
            }
        }
        entries.forEach { entry ->
            if (orders.none { order -> order.waybill.equals(entry.waybill, ignoreCase = true) }) missing++
        }
        return SttRestoreResult(result, restored, missing, skipped)
    }

    private fun String.normalizeHeader(): String = Normalizer.normalize(trim(), Normalizer.Form.NFD)
        .replace("\\p{Mn}+".toRegex(), "")
        .lowercase(Locale.ROOT)
        .replace('đ', 'd')
        .replace("[^a-z0-9]".toRegex(), "")

    private fun StringBuilder.appendCsvRow(waybill: String, sequence: String) {
        append("\"").append(waybill.replace("\"", "\"\""))
            .append("\",\"").append(sequence).append("\"\r\n")
    }
}
