package com.example.delivery.map

import android.content.Context
import com.example.delivery.R
import com.example.delivery.navigation.GoongApiConfig


internal object GoongMapStyleLoader {
    fun load(context: Context): String {
        val key = GoongApiConfig.mapTilesKey
        check(key.isNotBlank()) { "Thiếu GOONG_MAP_TILES_KEY" }

        return context.resources
            .openRawResource(R.raw.goong_map_style)
            .bufferedReader()
            .use { it.readText() }
            .replace("__GOONG_MAP_TILES_KEY__", key)
    }
}
