package com.example.delivery.ui

import android.content.Context
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.relocation.BringIntoViewRequester
import androidx.compose.foundation.relocation.bringIntoViewRequester
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusManager
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.SoftwareKeyboardController
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import com.example.delivery.cash.CashAuditCalculator
import com.example.delivery.cash.CashAuditState
import com.example.delivery.cash.CashAuditStatus
import com.example.delivery.cash.CashAuditStore
import kotlin.math.abs
import kotlinx.coroutines.delay

@Composable
fun CashAuditScreen(onClose: () -> Unit) {
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current
    val keyboardController = LocalSoftwareKeyboardController.current
    val restoredState = remember(context) { CashAuditStore.load(context) }
    var counts by remember(context) { mutableStateOf(restoredState.counts) }
    var bankInput by remember(context) { mutableStateOf(moneyTextFieldValue(restoredState.bankInput)) }
    var feeInput by remember(context) { mutableStateOf(moneyTextFieldValue(restoredState.feeInput)) }
    var codInput by remember(context) { mutableStateOf(moneyTextFieldValue(restoredState.codInput)) }
    fun saveState(
        nextCounts: Map<Long, Int> = counts,
        nextBank: String = bankInput.text,
        nextFee: String = feeInput.text,
        nextCod: String = codInput.text,
    ) {
        CashAuditStore.save(context, CashAuditState(nextCounts, nextBank, nextFee, nextCod))
    }
    val result = CashAuditCalculator.calculate(
        counts = counts,
        bank = CashAuditCalculator.parseAmount(bankInput.text),
        fee = CashAuditCalculator.parseAmount(feeInput.text),
        cod = CashAuditCalculator.parseAmount(codInput.text),
    )
    val resultStyle = when (result.status) {
        CashAuditStatus.SURPLUS -> ResultStyle(Color(0xFFE6F5EA), Color(0xFF167B38), "DƯ")
        CashAuditStatus.DEFICIT -> ResultStyle(Color(0xFFFFE9E7), Color(0xFFC23D35), "THIẾU")
        CashAuditStatus.BALANCED -> ResultStyle(Color(0xFFE8F2FF), Color(0xFF1E73BE), "ĐÃ KHỚP")
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(AppBackground)
            .statusBarsPadding()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 18.dp),
    ) {
        Row(
            Modifier.fillMaxWidth().padding(start = 10.dp, top = 8.dp, end = 14.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onClose) { Icon(Icons.Filled.ArrowBack, "Quay lại Cài đặt", tint = Color(0xFF12385F)) }
            Text("BẢNG KÊ TIỀN", modifier = Modifier.weight(1f), color = Color(0xFF12385F), fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
        }

        Column(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp).background(resultStyle.background, RoundedCornerShape(18.dp)).padding(16.dp),
        ) {
            Text("KẾT QUẢ BẢNG TÍNH", color = resultStyle.foreground, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
            Text(
                text = "${resultStyle.label} ${CashAuditCalculator.formatAmount(abs(result.difference))}đ",
                color = resultStyle.foreground,
                fontSize = 27.sp,
                fontWeight = FontWeight.ExtraBold,
                modifier = Modifier.padding(top = 4.dp),
            )
            Text("(Tiền mặt + Bank) − (Cước + COD)", color = resultStyle.foreground.copy(alpha = 0.78f), fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
        }

        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("ĐẾM TIỀN MẶT", modifier = Modifier.weight(1f), color = Color(0xFFE57B22), fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
            OutlinedButton(onClick = {
                counts = CashAuditCalculator.denominations.associateWith { 0 }
                bankInput = moneyTextFieldValue("")
                feeInput = moneyTextFieldValue("")
                codInput = moneyTextFieldValue("")
                CashAuditStore.reset(context)
                focusManager.clearFocus()
            }, modifier = Modifier.height(36.dp)) { Text("Reset 0", fontSize = 11.sp) }
        }

        Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp).background(AppSurface, RoundedCornerShape(18.dp)).padding(12.dp)) {
            CashAuditCalculator.denominations.forEach { denomination ->
                CashDenominationRow(
                    denomination = denomination,
                    count = counts[denomination] ?: 0,
                    focusManager = focusManager,
                    keyboardController = keyboardController,
                    onCountChange = { count ->
                        val nextCounts = counts + (denomination to count.coerceIn(0, 999))
                        counts = nextCounts
                        saveState(nextCounts = nextCounts)
                    },
                )
            }
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("TỔNG TIỀN MẶT", modifier = Modifier.weight(1f), color = Color(0xFF12385F), fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                Text("${CashAuditCalculator.formatAmount(result.cashTotal)}đ", color = Color(0xFF12385F), fontWeight = FontWeight.ExtraBold, fontSize = 21.sp)
            }
        }

        Text("ĐỐI SOÁT", modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp), color = Color(0xFFE57B22), fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
        Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp).background(AppSurface, RoundedCornerShape(18.dp)).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            MoneyInputRow("Bank", bankInput, { value -> bankInput = value; saveState(nextBank = value.text) }, focusManager, keyboardController)
            MoneyInputRow("Cước", feeInput, { value -> feeInput = value; saveState(nextFee = value.text) }, focusManager, keyboardController)
            MoneyInputRow("COD", codInput, { value -> codInput = value; saveState(nextCod = value.text) }, focusManager, keyboardController)
        }

        Button(
            onClick = onClose,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 16.dp).height(50.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E73BE)),
            shape = RoundedCornerShape(15.dp),
        ) { Text("Đóng bảng kê", fontWeight = FontWeight.ExtraBold) }
    }
}

private data class ResultStyle(val background: Color, val foreground: Color, val label: String)

@Composable
@OptIn(ExperimentalComposeUiApi::class)
private fun CashDenominationRow(
    denomination: Long,
    count: Int,
    focusManager: FocusManager,
    keyboardController: SoftwareKeyboardController?,
    onCountChange: (Int) -> Unit,
) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(7.dp),
    ) {
        Text("${CashAuditCalculator.formatAmount(denomination)}đ", modifier = Modifier.weight(1.38f), color = Color(0xFF12385F), fontWeight = FontWeight.Bold, fontSize = 12.sp)
        IconButton(onClick = { onCountChange((count - 1).coerceAtLeast(0)) }, modifier = Modifier.size(38.dp).background(Color(0xFFF2F6F9), CircleShape)) { Icon(Icons.Filled.Remove, "Giảm số lượng", tint = Color(0xFF1E73BE)) }
        OutlinedTextField(
            value = count.toString(),
            onValueChange = { onCountChange(it.filter(Char::isDigit).toIntOrNull() ?: 0) },
            singleLine = true,
            modifier = Modifier
                .width(58.dp)
                .height(52.dp)
                .focusProperties {
                    next = FocusRequester.Cancel
                    previous = FocusRequester.Cancel
                }
                .onPreviewKeyEvent { event ->
                    if (event.type == KeyEventType.KeyDown && event.key == Key.Enter) {
                        focusManager.clearFocus(force = true)
                        true
                    } else {
                        false
                    }
                },
            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF12385F), textAlign = androidx.compose.ui.text.style.TextAlign.Center),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Done),
            keyboardActions = KeyboardActions(
                onDone = { finishCashAuditInput(focusManager, keyboardController) },
                onNext = { finishCashAuditInput(focusManager, keyboardController) },
            ),
        )
        IconButton(onClick = { onCountChange(count + 1) }, modifier = Modifier.size(38.dp).background(Color(0xFF1E73BE), CircleShape)) { Icon(Icons.Filled.Add, "Tăng số lượng", tint = Color.White) }
        Text("${CashAuditCalculator.formatAmount(denomination * count)}đ", modifier = Modifier.weight(1.23f), color = Color(0xFF12385F), fontWeight = FontWeight.ExtraBold, fontSize = 12.sp, textAlign = androidx.compose.ui.text.style.TextAlign.End)
    }
}

@Composable
@OptIn(ExperimentalFoundationApi::class, ExperimentalComposeUiApi::class)
private fun MoneyInputRow(
    label: String,
    value: TextFieldValue,
    onValueChange: (TextFieldValue) -> Unit,
    focusManager: FocusManager,
    keyboardController: SoftwareKeyboardController?,
) {
    val requester = remember { BringIntoViewRequester() }
    var focused by remember { mutableStateOf(false) }
    LaunchedEffect(focused) {
        if (focused) {
            delay(220)
            requester.bringIntoView()
        }
    }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.width(78.dp), color = Color(0xFF12385F), fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
        OutlinedTextField(
            value = value,
            onValueChange = { incoming ->
                val formatted = incoming.text.groupedMoneyInput()
                onValueChange(
                    TextFieldValue(
                        text = formatted,
                        selection = TextRange(
                            groupedMoneyCursorPosition(
                                rawText = incoming.text,
                                selectionEnd = incoming.selection.end,
                                formattedText = formatted,
                            ),
                        ),
                    ),
                )
            },
            placeholder = { Text("0", fontSize = 13.sp) },
            suffix = { Text("đ", fontSize = 12.sp) },
            singleLine = true,
            modifier = Modifier
                .weight(1f)
                .height(54.dp)
                .bringIntoViewRequester(requester)
                .onFocusChanged { focused = it.isFocused }
                .focusProperties {
                    next = FocusRequester.Cancel
                    previous = FocusRequester.Cancel
                }
                .onPreviewKeyEvent { event ->
                    if (event.type == KeyEventType.KeyDown && event.key == Key.Enter) {
                        focusManager.clearFocus(force = true)
                        true
                    } else {
                        false
                    }
                },
            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF12385F), textAlign = androidx.compose.ui.text.style.TextAlign.End),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Done),
            keyboardActions = KeyboardActions(
                onDone = { finishCashAuditInput(focusManager, keyboardController) },
                onNext = { finishCashAuditInput(focusManager, keyboardController) },
            ),
        )
    }
}

private fun finishCashAuditInput(
    focusManager: FocusManager,
    keyboardController: SoftwareKeyboardController?,
) {
    keyboardController?.hide()
    focusManager.clearFocus(force = true)
}

private fun moneyTextFieldValue(value: String) = TextFieldValue(value, TextRange(value.length))

internal fun groupedMoneyCursorPosition(
    rawText: String,
    selectionEnd: Int,
    formattedText: String,
): Int {
    val digitsBeforeCaret = rawText.take(selectionEnd.coerceIn(0, rawText.length)).count(Char::isDigit)
    if (digitsBeforeCaret == 0) return 0

    var digitsVisited = 0
    formattedText.forEachIndexed { index, character ->
        if (character.isDigit()) {
            digitsVisited += 1
            if (digitsVisited == digitsBeforeCaret) return index + 1
        }
    }
    return formattedText.length
}

private fun String.groupedMoneyInput(): String {
    val digits = filter(Char::isDigit).trimStart('0')
    return if (digits.isBlank()) "" else CashAuditCalculator.formatAmount(digits.toLongOrNull() ?: Long.MAX_VALUE)
}
