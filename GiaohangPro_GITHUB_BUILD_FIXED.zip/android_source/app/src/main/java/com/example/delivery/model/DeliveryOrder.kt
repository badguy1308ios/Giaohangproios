package com.example.delivery.model

import java.text.NumberFormat
import java.util.Locale

enum class DeliveryStatus {
    TT500, TT505, TT506, TT507, TT508, TT515;
    companion object { fun label(status: DeliveryStatus) = status.name }
}

enum class DeliveryOutcome {
    ACTIVE,
    DELIVERED,
    TEMPORARY_FAILURE,
    TERMINAL_FAILURE,
    PICKUP_AT_WAREHOUSE,
}

enum class DeliveryFailureReason(val label: String, val outcome: DeliveryOutcome) {
    NO_CONTACT("Không liên lạc được", DeliveryOutcome.TEMPORARY_FAILURE),
    RESCHEDULED("Hẹn giao lại", DeliveryOutcome.TEMPORARY_FAILURE),
    REFUSED("Từ chối nhận", DeliveryOutcome.TERMINAL_FAILURE),
    THREE_ATTEMPTS("Giao thất bại 3 ca", DeliveryOutcome.TERMINAL_FAILURE),
    PICKUP_AT_WAREHOUSE("Tới kho lấy", DeliveryOutcome.PICKUP_AT_WAREHOUSE),
}

data class DeliveryOrder(
    val waybill: String,
    val customer: String,
    val phone: String,
    val address: String,
    val product: String,
    val cod: Long,
    val service: String,
    val status: DeliveryStatus = DeliveryStatus.TT500,
    val sequence: Int = 0,
    val latitude: Double = 10.7769,
    val longitude: Double = 106.7009,
    val requiresRedelivery: Boolean = false,
    val wasRedelivered: Boolean = false,
    val failureReason: DeliveryFailureReason? = null,
    val failureCount: Int = 0,
    val delivered: Boolean = false,
    
    val sequenceLabel: String? = null,
)

fun Long.formatVnd(): String = NumberFormat.getNumberInstance(Locale("vi", "VN")).format(this) + " đ"


fun DeliveryOrder.csvStatus(): DeliveryStatus = when {
    status == DeliveryStatus.TT515 -> DeliveryStatus.TT500
    status != DeliveryStatus.TT500 -> status
    failureReason?.outcome == DeliveryOutcome.TEMPORARY_FAILURE || requiresRedelivery -> DeliveryStatus.TT506
    failureReason?.outcome == DeliveryOutcome.PICKUP_AT_WAREHOUSE -> DeliveryStatus.TT507
    failureReason?.outcome == DeliveryOutcome.TERMINAL_FAILURE -> DeliveryStatus.TT505
    wasRedelivered -> DeliveryStatus.TT508
    else -> DeliveryStatus.TT500
}


fun DeliveryOrder.deliveryOutcome(): DeliveryOutcome = when {
    delivered || status == DeliveryStatus.TT515 -> DeliveryOutcome.DELIVERED
    else -> when (csvStatus()) {
    DeliveryStatus.TT506 -> DeliveryOutcome.TEMPORARY_FAILURE
    DeliveryStatus.TT507 -> DeliveryOutcome.PICKUP_AT_WAREHOUSE
    DeliveryStatus.TT505 -> DeliveryOutcome.TERMINAL_FAILURE
    else -> DeliveryOutcome.ACTIVE
    }
}
fun DeliveryOrder.statusLabel(): String = when (deliveryOutcome()) {

    DeliveryOutcome.ACTIVE -> if (wasRedelivered) "Đang giao lại" else "Đang giao"
    DeliveryOutcome.DELIVERED -> "Đã giao"
    DeliveryOutcome.TEMPORARY_FAILURE -> "Thất bại tạm thời"
    DeliveryOutcome.TERMINAL_FAILURE -> "Giao thất bại"
    DeliveryOutcome.PICKUP_AT_WAREHOUSE -> "Tới kho lấy"
}


fun DeliveryOrder.canReceiveRouteSequence(): Boolean = !delivered && status != DeliveryStatus.TT515 && csvStatus() != DeliveryStatus.TT505
fun DeliveryOrder.sequenceText(): String = sequenceLabel?.trim()?.takeIf { it.isNotBlank() } ?: sequence.takeIf { it > 0 }?.toString().orEmpty()


fun DeliveryOrder.phoneGroupKey(): String = phone.filter(Char::isDigit).ifBlank { waybill.trim().lowercase(Locale.ROOT) }


fun List<DeliveryOrder>.withSharedPhoneSequence(): List<DeliveryOrder> {
    val canonical = filter { it.sequenceText().isNotBlank() }
        .groupBy { it.phoneGroupKey() }
        .mapValues { (_, group) -> group.minWith(compareBy<DeliveryOrder> { it.sequenceSortValue() }.thenBy { it.waybill }).sequenceText() }
    return map { order -> canonical[order.phoneGroupKey()]?.let(order::withSequenceLabel) ?: order }
}


fun DeliveryOrder.sequenceSortValue(): Long = sequenceText().let { text ->
    if (text.isBlank()) Long.MAX_VALUE
    else {
        val parts = text.split('.', limit = 2)
        val major = parts[0].toIntOrNull() ?: Int.MAX_VALUE
        val minor = parts.getOrNull(1)?.let { if (it.equals("n", true)) 999_999 else it.toIntOrNull() ?: 999_998 } ?: 0
        major.toLong() * 1_000_000L + minor
    }
}

fun DeliveryOrder.isRouteActive(): Boolean = canReceiveRouteSequence() && sequenceText().isNotBlank()
fun DeliveryOrder.isPickupAtWarehouse(): Boolean = deliveryOutcome() == DeliveryOutcome.PICKUP_AT_WAREHOUSE

fun DeliveryOrder.detailStatusLabel(): String = when (csvStatus()) {
    DeliveryStatus.TT500 -> "TT500"
    DeliveryStatus.TT506 -> "TT506 · Hẹn lại / Không liên lạc được"
    DeliveryStatus.TT507 -> "TT507 · Tới kho nhận"
    DeliveryStatus.TT508 -> "TT508 · Giao lại"
    DeliveryStatus.TT505 -> "TT505 · Từ chối nhận / Giao thất bại 3 ca"
    DeliveryStatus.TT515 -> "TT500"
}
fun DeliveryOrder.isMapVisible(): Boolean = hasStoredCoordinates() && isRouteActive()
fun DeliveryOrder.isTemporaryFailure(): Boolean = deliveryOutcome() == DeliveryOutcome.TEMPORARY_FAILURE
fun DeliveryOrder.isTerminalFailure(): Boolean = deliveryOutcome() == DeliveryOutcome.TERMINAL_FAILURE


fun isMapCoordinatePair(latitude: Double, longitude: Double): Boolean =
    latitude.isFinite() && longitude.isFinite() && latitude in -90.0..90.0 && longitude in -180.0..180.0


fun DeliveryOrder.hasStoredCoordinates(): Boolean = isMapCoordinatePair(latitude, longitude) && (latitude != 0.0 || longitude != 0.0)


fun DeliveryOrder.normalizedCoordinates(): DeliveryOrder = when {
    isMapCoordinatePair(latitude, longitude) -> this
    isMapCoordinatePair(longitude, latitude) -> copy(latitude = longitude, longitude = latitude)
    else -> copy(latitude = 0.0, longitude = 0.0)
}

fun List<DeliveryOrder>.nextActiveSequence(): Int = filter { it.isRouteActive() }
    .maxOfOrNull { it.sequence }
    ?.plus(1)
    ?: 1


fun List<DeliveryOrder>.dispatchDisplayOrder(): List<DeliveryOrder> = sortedWith(
    compareBy<DeliveryOrder> {
        when {
            it.deliveryOutcome() == DeliveryOutcome.ACTIVE && !it.hasStoredCoordinates() -> 0
            it.isRouteActive() -> 1
            it.isPickupAtWarehouse() -> 2
            it.isTemporaryFailure() -> 3
            it.isTerminalFailure() -> 4
            it.deliveryOutcome() == DeliveryOutcome.DELIVERED -> 5
            else -> 5
        }
    }.thenBy { it.sequenceSortValue() }.thenBy { it.waybill },
)


fun List<DeliveryOrder>.withStableRouteSequence(sequenceByWaybill: Map<String, Int>): List<DeliveryOrder> =
    map { order ->
        val sequence = sequenceByWaybill[order.waybill]
        if (sequence != null) order.copy(sequence = sequence, sequenceLabel = null) else order
    }.dispatchDisplayOrder()

fun List<DeliveryOrder>.withStableRouteLabels(sequenceByWaybill: Map<String, String>): List<DeliveryOrder> =
    map { order ->
        val label = sequenceByWaybill[order.waybill]
        if (label != null) order.withSequenceLabel(label) else order
    }.dispatchDisplayOrder()


fun List<DeliveryOrder>.resequenceDraftLabels(
    drafts: Map<String, String>,
    original: Map<String, String>,
): Map<String, String> {
    val routable = filter { it.canReceiveRouteSequence() && it.hasStoredCoordinates() }
    val ranked = routable.groupBy { it.phoneGroupKey() }.values.mapIndexed { index, group ->
        val order = group.first()
        val label = group.map { drafts[it.waybill]?.trim().orEmpty().ifBlank { original[it.waybill].orEmpty().ifBlank { it.sequenceText() } } }
            .firstOrNull { it.isNotBlank() } ?: ""
        Triple(group, label, index)
    }.filter { it.second.isNotBlank() && it.second.toSequenceSortValue() != null }
        .sortedWith(compareBy<Triple<List<DeliveryOrder>, String, Int>> { it.second.toSequenceSortValue() }
            .thenBy { if (it.first.any { order -> original[order.waybill] != it.second }) 0 else 1 }
            .thenBy { it.third })

    val result = linkedMapOf<String, String>()
    var previousSort = Long.MIN_VALUE
    var nextMajor = 0
    ranked.forEach { (group, preferred, _) ->
        val preferredSort = preferred.toSequenceSortValue() ?: return@forEach
        val assigned = if (preferredSort > previousSort) {
            preferred
        } else {
            var candidate = maxOf(nextMajor + 1, (previousSort / 1_000_000L).toInt() + 1)
            while (result.values.any { it.toSequenceSortValue() == candidate.toLong() * 1_000_000L }) candidate += 1
            candidate.toString()
        }
        group.forEach { result[it.waybill] = assigned }
        previousSort = assigned.toSequenceSortValue() ?: previousSort
        nextMajor = maxOf(nextMajor, (previousSort / 1_000_000L).toInt())
    }
    return drafts + result
}

private fun String.toSequenceSortValue(): Long? {
    val parts = trim().split('.', limit = 2)
    val major = parts.firstOrNull()?.toIntOrNull() ?: return null
    if (major <= 0) return null
    val minor = parts.getOrNull(1)?.let { if (it.equals("n", true)) 999_999 else it.toIntOrNull() ?: return null } ?: 0
    if (minor <= 0 && parts.size > 1) return null
    return major.toLong() * 1_000_000L + minor
}

fun DeliveryOrder.withSequenceLabel(label: String): DeliveryOrder {
    val normalized = label.trim()
    val major = normalized.substringBefore('.').toIntOrNull() ?: 0
    return copy(sequence = major, sequenceLabel = normalized.takeIf { it.contains('.') })
}

fun List<DeliveryOrder>.filterForDetail(query: String, showDelivered: Boolean, showUnsuccessful: Boolean): List<DeliveryOrder> {
    val normalized = query.trim().lowercase()
    val matched = filter { order ->
        normalized.isBlank() || listOf(order.waybill, order.customer, order.phone, order.cod.toString(), order.cod.formatVnd())
            .any { it.lowercase().contains(normalized) }
    }
    val filtered = when {
        showDelivered -> matched.filter { it.deliveryOutcome() == DeliveryOutcome.DELIVERED }
        showUnsuccessful -> matched.filter { it.isTemporaryFailure() || it.isTerminalFailure() }
        else -> matched
    }
    return filtered.dispatchDisplayOrder()
}

fun sampleOrders() = listOf(
    DeliveryOrder("LT250001", "Nguyễn Minh An", "0900001001", "12 Lê Duẩn, thị trấn Long Thành, Đồng Nai", "Thùng nước giặt 3.5L", 28000, "GBP", DeliveryStatus.TT500, 1, 10.7803, 106.9501),
    DeliveryOrder("LT250002", "Trần Thu Hà", "0900001002", "45 Lê Duẩn, thị trấn Long Thành, Đồng Nai", "Sữa tắm chăm sóc da", 135000, "PTTX", DeliveryStatus.TT506, 2, 10.7821, 106.9518),
    DeliveryOrder("LT250003", "Lê Quốc Bảo", "0900001003", "28 Nguyễn Văn Cừ, thị trấn Long Thành, Đồng Nai", "Phụ kiện điện thoại", 78000, "GH1P", DeliveryStatus.TT507, 3, 10.7758, 106.9529),
    DeliveryOrder("LT250004", "Phạm Ngọc Lan", "0900001004", "67 Nguyễn Văn Cừ, thị trấn Long Thành, Đồng Nai", "Bình giữ nhiệt 1L", 92000, "GBP", DeliveryStatus.TT500, 4, 10.7735, 106.9486),
    DeliveryOrder("LT250005", "Võ Thanh Tâm", "0900001005", "16 Trần Phú, thị trấn Long Thành, Đồng Nai", "Hộp cơm điện", 215000, "PTTX", DeliveryStatus.TT508, 5, 10.7774, 106.9447),
    DeliveryOrder("LT250006", "Đặng Mỹ Duyên", "0900001006", "92 Trần Phú, thị trấn Long Thành, Đồng Nai", "Áo khoác chống nắng", 168000, "GH1P", DeliveryStatus.TT506, 6, 10.7843, 106.9434),
    DeliveryOrder("LT250007", "Bùi Hoàng Nam", "0900001007", "08 Quốc lộ 51, xã An Phước, Long Thành, Đồng Nai", "Dầu nhớt xe máy", 125000, "GBP", DeliveryStatus.TT500, 7, 10.7990, 106.9404),
    DeliveryOrder("LT250008", "Đỗ Thảo Vy", "0900001008", "120 Quốc lộ 51, xã An Phước, Long Thành, Đồng Nai", "Thực phẩm khô", 186000, "PTTX", DeliveryStatus.TT507, 8, 10.8068, 106.9370),
    DeliveryOrder("LT250009", "Hồ Gia Huy", "0900001009", "35 ĐT 769, xã Lộc An, Long Thành, Đồng Nai", "Tai nghe Bluetooth", 359000, "GH1P", DeliveryStatus.TT506, 9, 10.7712, 106.9716),
    DeliveryOrder("LT250010", "Ngô Khánh Linh", "0900001010", "88 ĐT 769, xã Lộc An, Long Thành, Đồng Nai", "Máy xay mini", 245000, "GBP", DeliveryStatus.TT500, 10, 10.7649, 106.9788),
    DeliveryOrder("LT250011", "Dương Quốc Khánh", "0900001011", "14 Đường Cầu Mây, xã Long Đức, Long Thành, Đồng Nai", "Bộ dụng cụ sửa xe", 312000, "PTTX", DeliveryStatus.TT508, 11, 10.7586, 106.9252),
    DeliveryOrder("LT250012", "Lý Bảo Trân", "0900001012", "56 Đường Cầu Mây, xã Long Đức, Long Thành, Đồng Nai", "Chăn hè 1.8m", 275000, "GH1P", DeliveryStatus.TT500, 12, 10.7541, 106.9185),
    DeliveryOrder("LT250013", "Mai Tuấn Kiệt", "0900001013", "21 Đường Hùng Vương, thị trấn Long Thành, Đồng Nai", "Đèn bàn LED", 149000, "GBP", DeliveryStatus.TT506, 13, 10.7897, 106.9549),
    DeliveryOrder("LT250014", "Tạ Hồng Phúc", "0900001014", "73 Đường Hùng Vương, thị trấn Long Thành, Đồng Nai", "Balo laptop", 420000, "PTTX", DeliveryStatus.TT507, 14, 10.7923, 106.9571),
    DeliveryOrder("LT250015", "Cao Thu Trang", "0900001015", "18 Đường Nguyễn Huệ, thị trấn Long Thành, Đồng Nai", "Hộp đựng thực phẩm", 86000, "GH1P", DeliveryStatus.TT500, 15, 10.7865, 106.9460),
    DeliveryOrder("LT250016", "Quách Nhật Minh", "0900001016", "90 Đường Nguyễn Huệ, thị trấn Long Thành, Đồng Nai", "Bàn phím không dây", 535000, "GBP", DeliveryStatus.TT508, 16, 10.7908, 106.9406),
    DeliveryOrder("LT250017", "Châu Kim Ngân", "0900001017", "31 Đường Suối Trầu, xã Suối Trầu, Long Thành, Đồng Nai", "Mỹ phẩm chăm sóc tóc", 198000, "PTTX", DeliveryStatus.TT506, 17, 10.8031, 106.9316),
    DeliveryOrder("LT250018", "Tống Anh Khoa", "0900001018", "76 Đường Suối Trầu, xã Suối Trầu, Long Thành, Đồng Nai", "Máy sấy tóc", 389000, "GH1P", DeliveryStatus.TT500, 18, 10.8097, 106.9364),
    DeliveryOrder("LT250019", "La Mỹ Hạnh", "0900001019", "22 Đường Bàu Cạn, xã Bàu Cạn, Long Thành, Đồng Nai", "Thùng sữa hạt", 264000, "GBP", DeliveryStatus.TT507, 19, 10.7606, 106.9217),
    DeliveryOrder("LT250020", "Triệu Đức Thành", "0900001020", "95 Đường Bàu Cạn, xã Bàu Cạn, Long Thành, Đồng Nai", "Quạt để bàn", 335000, "PTTX", DeliveryStatus.TT508, 20, 10.7554, 106.9248),
)
