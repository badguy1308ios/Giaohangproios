package com.example.delivery.orderio

import com.example.delivery.customer.CustomerProfile
import com.example.delivery.model.DeliveryOrder
import com.example.delivery.model.canReceiveRouteSequence
import com.example.delivery.model.nextActiveSequence

data class CoordinateUpdateRequest(
    val reference: String,
    val latitude: Double,
    val longitude: Double,
)

data class CoordinateUpdateResult(
    val profiles: List<CustomerProfile>,
    val orders: List<DeliveryOrder>,
    val updatedProfileIds: Set<String>,
    val updatedWaybills: Set<String>,
)


object CoordinateUpdateCoordinator {
    fun update(
        request: CoordinateUpdateRequest,
        profiles: List<CustomerProfile>,
        orders: List<DeliveryOrder>,
    ): CoordinateUpdateResult {
        require(request.reference.trim().isNotBlank()) { "Vui lòng nhập SĐT hoặc mã vận đơn." }
        require(request.latitude in -90.0..90.0 && request.longitude in -180.0..180.0) { "Tọa độ không hợp lệ." }
        val reference = request.reference.trim()
        val phoneReference = normalizePhone(reference)
        val matchedOrders = orders.filter { order ->
            order.waybill.equals(reference, ignoreCase = true) ||
                (phoneReference.isNotBlank() && normalizePhone(order.phone) == phoneReference)
        }
        val relevantPhones = (matchedOrders.map { it.phone } + reference.takeIf { phoneReference.isNotBlank() }.orEmpty())
            .map(::normalizePhone)
            .filter(String::isNotBlank)
            .toSet()
        val updatedProfiles = profiles.map { profile ->
            if (profile.phones.any { normalizePhone(it.number) in relevantPhones }) {
                val primaryIndex = profile.addresses.indexOfFirst { it.isPrimary }.takeIf { it >= 0 } ?: 0
                profile.copy(
                    addresses = profile.addresses.mapIndexed { index, address ->
                        if (index == primaryIndex) address.copy(latitude = request.latitude, longitude = request.longitude) else address
                    },
                )
            } else profile
        }
        val updatedProfileIds = profiles.zip(updatedProfiles)
            .filter { (before, after) -> before != after }
            .map { (_, after) -> after.id }
            .toSet()
        val matchedWaybills = matchedOrders.map { it.waybill }.toSet()
        require(matchedWaybills.isNotEmpty() || updatedProfileIds.isNotEmpty()) { "Không tìm thấy khách hàng hoặc mã vận đơn tương ứng." }
        var nextSequence = orders.filter { it.waybill !in matchedWaybills }.nextActiveSequence()
        val updatedOrders = orders.map { order ->
            if (order.waybill !in matchedWaybills) order else order.copy(
                latitude = request.latitude,
                longitude = request.longitude,
                sequence = when {
                    !order.canReceiveRouteSequence() -> 0
                    order.sequence > 0 -> order.sequence
                    else -> nextSequence++
                },
            )
        }
        return CoordinateUpdateResult(updatedProfiles, updatedOrders, updatedProfileIds, matchedWaybills)
    }

    private fun normalizePhone(value: String): String = value.filter(Char::isDigit)
}
