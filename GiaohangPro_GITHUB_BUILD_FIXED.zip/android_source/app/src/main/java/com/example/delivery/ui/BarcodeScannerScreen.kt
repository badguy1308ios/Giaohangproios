package com.example.delivery.ui

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import kotlinx.coroutines.delay
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

internal const val QR_SCAN_HAPTIC_MILLIS = 45L

@Suppress("DEPRECATION")
internal fun triggerQrScanHaptic(context: Context) {
    val vibrator = context.getSystemService(Vibrator::class.java) ?: return
    if (!vibrator.hasVibrator()) return
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        vibrator.vibrate(VibrationEffect.createOneShot(QR_SCAN_HAPTIC_MILLIS, VibrationEffect.DEFAULT_AMPLITUDE))
    } else {
        vibrator.vibrate(QR_SCAN_HAPTIC_MILLIS)
    }
}

@Composable
fun BarcodeScannerScreen(onCodeScanned: (String) -> Unit, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var granted by remember { mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    var torchEnabled by remember { mutableStateOf(false) }
    var boundCamera by remember { mutableStateOf<Camera?>(null) }
    var scannedCode by remember { mutableStateOf<String?>(null) }
    val accepted = remember { AtomicBoolean(false) }
    val executor = remember { Executors.newSingleThreadExecutor() }
    val green = Color(0xFF00E676)

    LaunchedEffect(Unit) { if (!granted) permission.launch(Manifest.permission.CAMERA) }
    LaunchedEffect(scannedCode) {
        val code = scannedCode ?: return@LaunchedEffect
        delay(180)
        onCodeScanned(code)
    }
    DisposableEffect(Unit) { onDispose { executor.shutdown(); boundCamera?.cameraControl?.enableTorch(false) } }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (granted) {
            androidx.compose.ui.viewinterop.AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { viewContext ->
                    PreviewView(viewContext).also { previewView ->
                        val providerFuture = ProcessCameraProvider.getInstance(context)
                        providerFuture.addListener({
                            val provider = providerFuture.get()
                            val preview = Preview.Builder().build().also { it.surfaceProvider = previewView.surfaceProvider }
                            val analysis = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
                            val scanner = BarcodeScanning.getClient(
                                BarcodeScannerOptions.Builder().setBarcodeFormats(
                                    Barcode.FORMAT_QR_CODE,
                                    Barcode.FORMAT_CODE_128,
                                    Barcode.FORMAT_CODE_39,
                                    Barcode.FORMAT_EAN_13,
                                    Barcode.FORMAT_EAN_8,
                                ).build(),
                            )
                            analysis.setAnalyzer(executor) { imageProxy ->
                                val mediaImage = imageProxy.image
                                if (mediaImage == null) {
                                    imageProxy.close()
                                } else {
                                    scanner.process(InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees))
                                        .addOnSuccessListener { values ->
                                            val code = values.firstOrNull { !it.rawValue.isNullOrBlank() }?.rawValue
                                            if (code != null && accepted.compareAndSet(false, true)) {
                                                ContextCompat.getMainExecutor(context).execute {
                                                    triggerQrScanHaptic(context)
                                                    scannedCode = code
                                                }
                                            }
                                        }
                                        .addOnCompleteListener { imageProxy.close() }
                                }
                            }
                            provider.unbindAll()
                            boundCamera = provider.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
                        }, ContextCompat.getMainExecutor(context))
                    }
                },
            )
            ScannerOverlay(green, scannedCode != null)
            IconButton(modifier = Modifier.align(Alignment.TopStart).padding(16.dp), onClick = onDismiss) { Icon(Icons.Filled.Close, "Đóng quét mã", tint = Color.White) }
            IconButton(modifier = Modifier.align(Alignment.TopEnd).padding(16.dp), onClick = { torchEnabled = !torchEnabled; boundCamera?.cameraControl?.enableTorch(torchEnabled) }) { Icon(Icons.Filled.FlashOn, "Đèn flash", tint = if (torchEnabled) green else Color.White) }
            Text("QUÉT MÃ QR", color = Color.White, modifier = Modifier.align(Alignment.TopCenter).padding(top = 22.dp))
            Text(if (scannedCode == null) "Đưa QR hoặc mã vạch vào khung để quét" else "Đã nhận diện mã", color = Color.White, modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 36.dp))
        } else {
            Text("Cần quyền Camera để quét mã", color = Color.White, modifier = Modifier.align(Alignment.Center))
            IconButton(modifier = Modifier.align(Alignment.TopStart).padding(16.dp), onClick = onDismiss) { Icon(Icons.Filled.Close, "Đóng", tint = Color.White) }
        }
    }
}

@Composable
private fun ScannerOverlay(color: Color, isSuccess: Boolean) {
    val transition = rememberInfiniteTransition(label = "scanner")
    val vertical by transition.animateFloat(0f, 1f, infiniteRepeatable(tween(1750, easing = LinearEasing), RepeatMode.Reverse), label = "vertical")
    val accent = if (isSuccess) Color(0xFF69F0AE) else color
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val frameWidth = 296.dp.toPx()
            val frameHeight = 220.dp.toPx()
            val left = (size.width - frameWidth) / 2f
            val top = (size.height - frameHeight) / 2f
            val shade = Color.Black.copy(alpha = 0.46f)
            drawRect(shade, size = Size(size.width, top))
            drawRect(shade, topLeft = Offset(0f, top + frameHeight), size = Size(size.width, size.height - top - frameHeight))
            drawRect(shade, topLeft = Offset(0f, top), size = Size(left, frameHeight))
            drawRect(shade, topLeft = Offset(left + frameWidth, top), size = Size(size.width - left - frameWidth, frameHeight))
        }
        Box(
            Modifier
                .width(296.dp)
                .height(220.dp)
                .border(if (isSuccess) 2.dp else 1.dp, if (isSuccess) accent else Color.White.copy(alpha = 0.92f), RoundedCornerShape(16.dp)),
        ) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(9.dp)
                    .offset(y = (202f * vertical).dp)
                    .background(
                        Brush.horizontalGradient(listOf(Color.Transparent, accent.copy(alpha = 0.2f), accent, accent.copy(alpha = 0.2f), Color.Transparent)),
                        RoundedCornerShape(12.dp),
                    ),
            )
        }
    }
}
