package com.example.delivery.ui

import android.content.Context
import androidx.compose.runtime.Composable
import com.example.delivery.customer.CustomerProfile
import com.example.delivery.customer.CustomerProfileStore
import com.example.delivery.customer.matchesSearch
import com.example.delivery.location.RealtimeLocationPolicy


@Composable
internal fun DeliveryV2Customer(
    state: DeliveryV2State,
    context: Context,
    customerProfiles: List<CustomerProfile>,
    onSaveCustomer: (CustomerProfile) -> Unit,
    onDeleteCustomer: (CustomerProfile) -> Unit,
    onGetCustomerCoordinates: () -> Pair<Double, Double>?,
) {
    CustomerList(
        customerProfiles.filterNot { CustomerProfileStore.isDeleted(context, it.id) },
        state.focusPhone,
        onSaveCustomer,
        onDeleteCustomer,
    ) {
        state.currentGps
            ?.takeIf { RealtimeLocationPolicy.isFreshLastKnown(state.currentGpsUpdatedAt, System.currentTimeMillis()) }
            ?.let { gps -> gps.latitude to gps.longitude }
            ?: onGetCustomerCoordinates()
    }
}
