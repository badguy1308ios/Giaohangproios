package com.example.delivery.navigation

import com.example.delivery.BuildConfig


internal object GoongApiConfig {
    
    val mapTilesKey: String
        get() = BuildConfig.GOONG_MAP_TILES_KEY

    
    val restApiKey: String
        get() = BuildConfig.GOONG_REST_API_KEY

    
    const val directionsEndpoint = "https://rsapi.goong.io/Direction"

    
    const val mapTilesEndpoint = "https://tiles.goong.io/"
}
