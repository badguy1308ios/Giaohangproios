package com.example.delivery.ui

import com.example.delivery.map.GoongMapStyleLoader
import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Looper
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.core.content.ContextCompat
import com.example.delivery.BuildConfig
import com.example.delivery.location.RealtimeLocationPolicy
import org.maplibre.android.MapLibre
import org.maplibre.android.annotations.Marker
import org.maplibre.android.annotations.MarkerOptions
import org.maplibre.android.annotations.IconFactory
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.Style
import java.util.Locale

private const val DEFAULT_PICKER_LATITUDE = 10.7769
private const val DEFAULT_PICKER_LONGITUDE = 106.7009

internal data class CustomerPickerPosition(val latitude: Double, val longitude: Double)

internal fun initialCustomerPickerPosition(initialLatitude: Double?, initialLongitude: Double?): CustomerPickerPosition {
    val latitude = initialLatitude.takeValidLatitude()
    val longitude = initialLongitude.takeValidLongitude()
    return if (latitude == null || longitude == null) {
        CustomerPickerPosition(DEFAULT_PICKER_LATITUDE, DEFAULT_PICKER_LONGITUDE)
    } else {
        CustomerPickerPosition(latitude, longitude)
    }
}

internal fun shouldInitializeCustomerPinFromGps(initialLatitude: Double?, initialLongitude: Double?): Boolean =
    initialLatitude.takeValidLatitude() == null || initialLongitude.takeValidLongitude() == null

@Composable
internal fun CustomerCoordinatePickerDialog(
    initialLatitude: Double?,
    initialLongitude: Double?,
    onDismiss: () -> Unit,
    onConfirm: (latitude: Double, longitude: Double) -> Unit,
    title: String = "CHỌN TỌA ĐỘ TRÊN BẢN ĐỒ",
    description: String = "Chạm vào bản đồ để di chuyển ghim tới đúng vị trí khách hàng.",
    confirmLabel: String = "Lấy tọa độ này",
) {
    val context = LocalContext.current
    val initialPosition = remember(initialLatitude, initialLongitude) { initialCustomerPickerPosition(initialLatitude, initialLongitude) }
    var latitude by remember(initialLatitude, initialLongitude) { mutableStateOf(initialPosition.latitude) }
    var longitude by remember(initialLatitude, initialLongitude) { mutableStateOf(initialPosition.longitude) }
    var currentUserPosition by remember { mutableStateOf<CustomerPickerPosition?>(null) }
    var needsInitialGpsCustomerPin by remember(initialLatitude, initialLongitude) {
        mutableStateOf(shouldInitializeCustomerPinFromGps(initialLatitude, initialLongitude))
    }
    val hasLocationPermission = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
        ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
    if (hasLocationPermission) {
        CurrentPickerLocationUpdates { location ->
            if (location.latitude in -90.0..90.0 && location.longitude in -180.0..180.0) {
                val gpsPosition = CustomerPickerPosition(location.latitude, location.longitude)
                currentUserPosition = gpsPosition
                if (needsInitialGpsCustomerPin) {
                    latitude = gpsPosition.latitude
                    longitude = gpsPosition.longitude
                    needsInitialGpsCustomerPin = false
                }
            }
        }
    }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().navigationBarsPadding().padding(horizontal = 10.dp, vertical = 10.dp)) {
            Surface(
                modifier = Modifier.align(Alignment.Center).fillMaxWidth().fillMaxHeight(0.88f),
                shape = RoundedCornerShape(18.dp),
                color = AppBackground,
            ) {
                Column(Modifier.fillMaxSize()) {
                    Column(Modifier.fillMaxWidth().background(Color(0xFFEAF5F2)).padding(horizontal = 14.dp, vertical = 9.dp)) {
                    Text(title, color = Color(0xFF12385F), fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
                    Text(description, color = Color(0xFF5F6B75), fontSize = 11.sp, modifier = Modifier.padding(top = 3.dp))
                }
                Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 8.dp, vertical = 7.dp)) {
                    CustomerCoordinatePickerMap(
                        latitude = latitude,
                        longitude = longitude,
                        onPointSelected = { selectedLatitude, selectedLongitude ->
                            latitude = selectedLatitude
                            longitude = selectedLongitude
                        },
                        currentUserPosition = currentUserPosition,
                        modifier = Modifier.fillMaxSize(),
                    )
                }
                Column(Modifier.fillMaxWidth().background(Color(0xFFF4F7F8)).padding(horizontal = 12.dp, vertical = 9.dp)) {
                    Text(
                        text = String.format(Locale.US, "Vĩ độ: %.6f    Kinh độ: %.6f", latitude, longitude),
                        color = Color(0xFF12385F),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                    )
                    Text(
                        text = currentUserPosition?.let { String.format(Locale.US, "GPS hiện tại (xanh): %.6f, %.6f", it.latitude, it.longitude) } ?: "Đang lấy vị trí GPS hiện tại…",
                        color = Color(0xFF1E73BE),
                        fontSize = 10.sp,
                        modifier = Modifier.padding(top = 2.dp),
                    )
                    Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.Start) {
                        OutlinedButton(onClick = onDismiss, modifier = Modifier.height(40.dp)) { Text("Hủy") }
                        Spacer(Modifier.width(8.dp))
                        Button(
                            onClick = { onConfirm(latitude, longitude) },
                            modifier = Modifier.weight(1f).height(40.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF229846)),
                        ) { Text(confirmLabel, fontWeight = FontWeight.ExtraBold) }
                    }
                }
            }
        }
    }
}
}

@Composable
private fun CustomerCoordinatePickerMap(
    latitude: Double,
    longitude: Double,
    onPointSelected: (Double, Double) -> Unit,
    currentUserPosition: CustomerPickerPosition?,
    modifier: Modifier,
) {
    val context = LocalContext.current
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    val mapView = remember(context) { MapLibre.getInstance(context); MapView(context).also { it.onCreate(null) } }
    var map by remember { mutableStateOf<MapLibreMap?>(null) }
    var userMarker by remember { mutableStateOf<Marker?>(null) }
    var customerMarker by remember { mutableStateOf<Marker?>(null) }
    var hasCenteredOnInitialGps by remember { mutableStateOf(false) }
    DisposableEffect(mapView, lifecycle) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_START -> mapView.onStart()
                Lifecycle.Event.ON_RESUME -> mapView.onResume()
                Lifecycle.Event.ON_PAUSE -> mapView.onPause()
                Lifecycle.Event.ON_STOP -> mapView.onStop()
                else -> Unit
            }
        }
        lifecycle.addObserver(observer)
        onDispose {
            lifecycle.removeObserver(observer)
            mapView.onDestroy()
        }
    }
    AndroidView(
        modifier = modifier,
        factory = {
            mapView.apply {
                getMapAsync { readyMap ->
                    configurePickerMap(readyMap, context, latitude, longitude, onPointSelected) { marker ->
                        map = readyMap
                        customerMarker = marker
                    }
                }
            }
        },
        update = {
            val readyMap = map ?: return@AndroidView
            if (readyMap.style == null) return@AndroidView
            customerMarker?.let { marker ->
                marker.position = LatLng(latitude, longitude)
                readyMap.updateMarker(marker)
            }
            currentUserPosition?.let { point ->
                val userPoint = LatLng(point.latitude, point.longitude)
                val existing = userMarker
                if (existing == null) {
                    userMarker = readyMap.addMarker(
                        MarkerOptions().position(userPoint).title("Vị trí hiện tại (GPS)").icon(pickerMarkerIcon(context, "GPS", 0xFF1E73BE.toInt())),
                    )
                } else {
                    existing.position = userPoint
                    readyMap.updateMarker(existing)
                }
                if (!hasCenteredOnInitialGps) {
                    readyMap.animateCamera(CameraUpdateFactory.newLatLngZoom(LatLng(latitude, longitude), 15.5))
                    hasCenteredOnInitialGps = true
                }
            }
        },
    )
}

private fun configurePickerMap(
    map: MapLibreMap,
    context: Context,
    latitude: Double,
    longitude: Double,
    onPointSelected: (Double, Double) -> Unit,
    onReady: (Marker) -> Unit,
) {
    if (map.style != null) return
    map.setTileCacheEnabled(true)
    map.setStyle(Style.Builder().fromJson(GoongMapStyleLoader.load(context))) {
        val initialPoint = LatLng(latitude, longitude)
        val marker = map.addMarker(MarkerOptions().position(initialPoint).title("Vị trí khách hàng"))
        map.cameraPosition = CameraPosition.Builder().target(initialPoint).zoom(15.5).build()
        map.addOnMapClickListener { point ->
            marker.position = point
            map.updateMarker(marker)
            onPointSelected(point.latitude, point.longitude)
            true
        }
        onReady(marker)
    }
}

private fun pickerMarkerIcon(context: Context, text: String, color: Int): org.maplibre.android.annotations.Icon {
    val density = context.resources.displayMetrics.density
    val size = (42 * density).toInt()
    val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    paint.color = color
    canvas.drawCircle(size / 2f, size / 2f, size / 2f - density, paint)
    paint.color = android.graphics.Color.WHITE
    paint.textAlign = Paint.Align.CENTER
    paint.typeface = Typeface.DEFAULT_BOLD
    paint.textSize = 10 * density
    canvas.drawText(text, size / 2f, size / 2f - (paint.ascent() + paint.descent()) / 2f, paint)
    return IconFactory.getInstance(context).fromBitmap(bitmap)
}

@SuppressLint("MissingPermission")
@Composable
private fun CurrentPickerLocationUpdates(update: (Location) -> Unit) {
    val context = LocalContext.current
    DisposableEffect(context) {
        val manager = context.getSystemService(LocationManager::class.java)
        var newestFixTime: Long? = null
        val listener = object : LocationListener {
            override fun onLocationChanged(location: Location) {
                if (RealtimeLocationPolicy.shouldAccept(newestFixTime, location.time)) {
                    newestFixTime = location.time
                    update(location)
                }
            }
        }
        val now = System.currentTimeMillis()
        listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)
            .mapNotNull { provider -> runCatching { manager.getLastKnownLocation(provider) }.getOrNull() }
            .filter { RealtimeLocationPolicy.isFreshLastKnown(it.time, now) }
            .maxByOrNull { it.time }
            ?.let(listener::onLocationChanged)
        listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER).forEach { provider ->
            runCatching {
                if (manager.isProviderEnabled(provider)) manager.requestLocationUpdates(provider, 1_500L, 1f, listener, Looper.getMainLooper())
            }
        }
        onDispose { manager.removeUpdates(listener) }
    }
}

private fun Double?.takeValidLatitude(): Double? = this?.takeIf { it.isFinite() && it in -90.0..90.0 && it != 0.0 }
private fun Double?.takeValidLongitude(): Double? = this?.takeIf { it.isFinite() && it in -180.0..180.0 && it != 0.0 }