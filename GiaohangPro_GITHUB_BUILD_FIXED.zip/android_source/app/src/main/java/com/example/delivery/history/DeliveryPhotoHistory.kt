package com.example.delivery.history

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import androidx.core.content.FileProvider
import com.example.delivery.model.DeliveryOrder
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class ProofPhotoType { BILL_CLOSEUP, DROP_OFF_WATERMARK }
enum class PaymentChannel { ZALO, SMS }

data class TransferEvidence(
    val waybill: String,
    val customer: String,
    val phone: String,
    val cod: Long,
    val channel: PaymentChannel,
    val message: String,
    val billPhotoPath: String? = null,
    val dropOffPhotoPath: String? = null,
    val sentConfirmed: Boolean = false,
    val paidConfirmed: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val confirmedAt: Long? = null,
)

object DeliveryPhotoHistory {
    private const val EVIDENCE_PREF = "transfer_evidence_v1"
    private val dateFormat = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US)

    fun createOutputFile(context: Context, waybill: String, type: ProofPhotoType): File {
        val dir = File(context.filesDir, "delivery_confirmation").apply { mkdirs() }
        return File(dir, "${waybill}_${type.name.lowercase()}_${dateFormat.format(Date())}.jpg")
    }

    fun createCustomerGateFile(context: Context, customerId: String): File {
        val dir = File(context.filesDir, "customer_gate").apply { mkdirs() }
        return File(dir, "${customerId}_${dateFormat.format(Date())}.jpg")
    }

    fun providerUri(context: Context, file: File) = FileProvider.getUriForFile(context, "${context.packageName}.deliveryphotos", file)

    fun addDropOffWatermark(file: File, order: DeliveryOrder, latitude: Double?, longitude: Double?): String {
        val original = BitmapFactory.decodeFile(file.path) ?: return file.path
        val bitmap = original.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(bitmap)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val stamp = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("vi", "VN")).format(Date())
        val coordinates = if (latitude != null && longitude != null) String.format(Locale.US, "%.5f, %.5f", latitude, longitude) else "Chưa có GPS"
        paint.color = Color.argb(185, 0, 0, 0)
        canvas.drawRect(0f, (bitmap.height - 106).coerceAtLeast(0).toFloat(), bitmap.width.toFloat(), bitmap.height.toFloat(), paint)
        paint.color = Color.WHITE
        paint.textSize = (bitmap.width / 29f).coerceAtLeast(18f)
        canvas.drawText(order.waybill, 18f, bitmap.height - 70f, paint)
        paint.textSize = (bitmap.width / 36f).coerceAtLeast(15f)
        canvas.drawText("$stamp • $coordinates", 18f, bitmap.height - 32f, paint)
        FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.JPEG, 92, it) }
        original.recycle(); bitmap.recycle()
        return file.path
    }

    fun getEvidence(context: Context): List<TransferEvidence> = readEvidence(context).sortedByDescending { it.createdAt }
    fun upsertEvidence(context: Context, evidence: TransferEvidence) { writeEvidence(context, readEvidence(context).filterNot { it.waybill == evidence.waybill } + evidence) }
    fun confirmPaid(context: Context, waybill: String): TransferEvidence? {
        val current = readEvidence(context).firstOrNull { it.waybill == waybill } ?: return null
        val confirmed = current.copy(paidConfirmed = true, confirmedAt = System.currentTimeMillis())
        upsertEvidence(context, confirmed)
        return confirmed
    }

    fun snapshotEvidenceJson(context: Context): String = context.getSharedPreferences(EVIDENCE_PREF, Context.MODE_PRIVATE).getString("items", "[]") ?: "[]"
    fun validateBackupJson(evidenceRaw: String) {
        val evidence = JSONArray(evidenceRaw)
        List(evidence.length()) { evidence.getJSONObject(it).toEvidence() }
    }

    
    fun clearAll(context: Context) {
        val evidence = readEvidence(context)
        val paths = evidence.flatMap { listOfNotNull(it.billPhotoPath, it.dropOffPhotoPath) }.distinct()
        paths.map(::File).forEach { it.delete() }
        File(context.filesDir, "delivery_confirmation").deleteRecursively()
        check(context.getSharedPreferences(EVIDENCE_PREF, Context.MODE_PRIVATE).edit().clear().commit()) {
            "Không thể xóa bằng chứng giao hàng."
        }
    }

    fun replaceFromBackupJson(context: Context, evidenceRaw: String) {
        validateBackupJson(evidenceRaw)
        val evidenceSaved = context.getSharedPreferences(EVIDENCE_PREF, Context.MODE_PRIVATE).edit().putString("items", JSONArray(evidenceRaw).toString()).commit()
        check(evidenceSaved) { "Không thể lưu bằng chứng chuyển khoản sau khi nhập ZIP." }
    }

    private fun readEvidence(context: Context): List<TransferEvidence> = runCatching {
        val arr = JSONArray(context.getSharedPreferences(EVIDENCE_PREF, Context.MODE_PRIVATE).getString("items", "[]"))
        List(arr.length()) { index -> arr.getJSONObject(index).toEvidence() }
    }.getOrDefault(emptyList())
    private fun writeEvidence(context: Context, values: List<TransferEvidence>) { context.getSharedPreferences(EVIDENCE_PREF, Context.MODE_PRIVATE).edit().putString("items", JSONArray(values.map { it.toJson() }).toString()).apply() }
    private fun TransferEvidence.toJson() = JSONObject().put("waybill", waybill).put("customer", customer).put("phone", phone).put("cod", cod).put("channel", channel.name).put("message", message).put("bill", billPhotoPath).put("drop", dropOffPhotoPath).put("sent", sentConfirmed).put("paid", paidConfirmed).put("created", createdAt).put("confirmed", confirmedAt)
    private fun JSONObject.toEvidence() = TransferEvidence(getString("waybill"), getString("customer"), getString("phone"), getLong("cod"), PaymentChannel.valueOf(getString("channel")), getString("message"), optString("bill").takeIf { it.isNotBlank() && it != "null" }, optString("drop").takeIf { it.isNotBlank() && it != "null" }, optBoolean("sent"), optBoolean("paid"), getLong("created"), optLong("confirmed").takeIf { it > 0 })
}

