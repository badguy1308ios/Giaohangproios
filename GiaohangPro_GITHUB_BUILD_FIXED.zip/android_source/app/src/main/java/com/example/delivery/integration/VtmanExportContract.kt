package com.example.delivery.integration

object VtmanExportContract {
    const val packageName = "com.vtman.waybillscanner"
    const val unavailableMessage = "Chưa cài VTMan Export. Hãy cài công cụ trước rồi mở lại mục này."
}
