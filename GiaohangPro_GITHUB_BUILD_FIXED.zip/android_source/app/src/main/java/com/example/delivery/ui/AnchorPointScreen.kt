package com.example.delivery.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.delivery.navigation.GeoPoint
import java.util.Locale

@Composable
internal fun AnchorPointScreen(
    anchorPoint: GeoPoint?,
    onOpenPicker: () -> Unit,
    onClose: () -> Unit,
) {
    Column(Modifier.fillMaxSize().background(AppBackground)) {
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(start = 12.dp, top = 8.dp, end = 12.dp, bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onClose) { Icon(Icons.Filled.ArrowBack, "Quay lại Cài đặt", tint = Color(0xFF12385F)) }
            Text("ĐIỂM NEO VÀ VÙNG GIAO HÀNG", color = Color(0xFF12385F), fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
        }
        Text(
            "Điểm Neo được lưu cố định và chỉ thay đổi khi bạn đặt lại điểm mới. Khi xác nhận thay đổi tuyến, STT sẽ được xếp từ gần đến xa theo điểm này.",
            color = Color(0xFF59636D),
            fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
        )
        Text(
            anchorPoint?.let { String.format(Locale.US, "Điểm Neo hiện tại: %.6f, %.6f", it.latitude, it.longitude) }
                ?: "Chưa đặt Điểm Neo. Ứng dụng sẽ dùng GPS hoặc điểm dự phòng khi xếp tuyến.",
            color = if (anchorPoint == null) Color(0xFFC23D35) else Color(0xFF1E73BE),
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
        )
        Button(
            onClick = onOpenPicker,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
        ) { Text(if (anchorPoint == null) "Đặt điểm Neo" else "Đặt lại điểm Neo") }
    }
}
