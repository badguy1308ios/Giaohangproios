package com.example.delivery.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material.icons.filled.Wallet
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.delivery.model.DeliveryOrder
import com.example.delivery.model.DeliveryOutcome
import com.example.delivery.model.deliveryOutcome
import com.example.delivery.model.detailStatusLabel
import com.example.delivery.model.dispatchDisplayOrder
import com.example.delivery.model.filterForDetail
import com.example.delivery.model.formatVnd
import com.example.delivery.model.isPickupAtWarehouse

private val DetailNavy = Color(0xFF12385F)
private val DetailGreen = Color(0xFF229846)
private val DetailRed = Color(0xFFC83B3B)

private data class ExpandedDetail(val title: String, val value: String)

internal fun selectedOrderIndex(orders: List<DeliveryOrder>, selectedWaybill: String?): Int =
    selectedWaybill?.let { waybill -> orders.indexOfFirst { it.waybill == waybill } } ?: -1

@Composable
fun OrderDetailScreen(
    orders: List<DeliveryOrder>,
    searchQuery: String,
    selectedWaybill: String?,
    onSelectOrder: (DeliveryOrder) -> Unit,
    onSearchChange: (String) -> Unit,
    onOpenScanner: () -> Unit,
    onDelivered: (DeliveryOrder) -> Unit,
    onCall: (DeliveryOrder) -> Unit,
    onZalo: (DeliveryOrder) -> Unit,
    onSms: (DeliveryOrder) -> Unit,
    onOpenCustomer: (DeliveryOrder) -> Unit,
    onNavigateOrder: (DeliveryOrder) -> Unit,
    scrollToTopRequest: Int = 0,
) {
    var showDelivered by remember { mutableStateOf(false) }
    var expandedDetail by remember { mutableStateOf<ExpandedDetail?>(null) }
    val visible = orders.filterForDetail(searchQuery, showDelivered, false)
    val exactOrder = searchQuery.trim().takeIf { it.isNotBlank() }?.let { query ->
        orders.firstOrNull { it.waybill.equals(query, ignoreCase = true) }
    }
    val visibleGroups = if (exactOrder != null) {
        val groupKey = exactOrder.phone.filter(Char::isDigit).ifBlank { exactOrder.waybill }
        orders.filter { it.phone.filter(Char::isDigit).ifBlank { it.waybill } == groupKey }
            .dispatchDisplayOrder()
            .let { group -> listOf(group) }
    } else {
        visible.groupBy { it.phone.filter(Char::isDigit).ifBlank { it.waybill } }.values.toList()
    }
    val displayedOrders = visibleGroups.flatten()
    val listState = rememberLazyListState()
    LaunchedEffect(selectedWaybill, searchQuery, showDelivered, orders) {
        val index = visibleGroups.indexOfFirst { group: List<DeliveryOrder> -> group.any { order -> order.waybill == selectedWaybill } }
        if (index >= 0) listState.animateScrollToItem(index)
    }
    LaunchedEffect(scrollToTopRequest) {
        if (scrollToTopRequest > 0) listState.animateScrollToItem(0)
    }

    Column(modifier = Modifier.background(AppBackground)) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(7.dp),
        ) {
            Box(modifier = Modifier.size(46.dp).background(DetailNavy, RoundedCornerShape(12.dp)).clickable(onClick = onOpenScanner), contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.QrCodeScanner, "Quét mã QR", tint = Color.White, modifier = Modifier.size(27.dp))
            }
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchChange,
                modifier = Modifier.weight(1f),
                singleLine = true,
                leadingIcon = { Icon(Icons.Filled.Search, null, modifier = Modifier.size(18.dp)) },
                trailingIcon = if (searchQuery.isNotBlank()) {
                    { IconButton(onClick = { onSearchChange("") }) { Icon(Icons.Filled.Close, "Xóa tìm kiếm", modifier = Modifier.size(18.dp)) } }
                } else null,
                placeholder = { Text("Mã đơn, SĐT, khách, tiền", fontSize = 12.sp) },
            )
        }
        Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 13.dp, vertical = 3.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            StatusToggle("Đã giao", showDelivered, DetailGreen, Modifier.width(82.dp)) { showDelivered = !showDelivered }
        }
        Text("DANH SÁCH ${displayedOrders.size} ĐƠN", color = Color(0xFF78838F), fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(start = 15.dp, top = 4.dp, bottom = 6.dp))
        LazyColumn(state = listState, modifier = Modifier.weight(1f), contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 3.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(visibleGroups, key = { group -> group.first().phone + group.first().waybill }) { group ->
                if (group.size > 1) GroupedOrderBlock(group, selectedWaybill, onSelectOrder, onDelivered, onCall, onZalo, onSms, onOpenCustomer, onNavigateOrder) else {
                    val order = group.first()
                CompactOrderCard(
                    order = order,
                    selected = order.waybill == selectedWaybill,
                    onSelectOrder = { onSelectOrder(order) },
                    onDelivered = onDelivered,
                    onCall = onCall,
                    onZalo = onZalo,
                    onSms = onSms,
                    onOpenCustomer = onOpenCustomer,
                    onNavigateOrder = onNavigateOrder,
                    onExpand = { title, value -> expandedDetail = ExpandedDetail(title, value) },
                    )
                }
            }
        }
    }
    expandedDetail?.let { detail ->
        AlertDialog(
            onDismissRequest = { expandedDetail = null },
            title = { Text(detail.title) },
            text = { Text(detail.value) },
            confirmButton = {},
        )
    }
}

@Composable
private fun StatusToggle(label: String, selected: Boolean, tint: Color, modifier: Modifier, onClick: () -> Unit) {
    Text(label, color = if (selected) Color.White else tint, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = modifier.background(if (selected) tint else tint.copy(alpha = 0.14f), RoundedCornerShape(8.dp)).clickable(onClick = onClick).padding(vertical = 5.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
}

@Composable
fun ManualOrderEntryDialog(onDismiss: () -> Unit, onSave: (DeliveryOrder) -> Unit) {
    var waybill by remember { mutableStateOf("") }
    var customer by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var product by remember { mutableStateOf("") }
    var cod by remember { mutableStateOf("") }
    var service by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("THÊM MÃ VẬN ĐƠN") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                OutlinedTextField(value = waybill, onValueChange = { waybill = it }, label = { Text("Mã vận đơn *") }, singleLine = true)
                OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("SĐT khách") }, singleLine = true)
                OutlinedTextField(value = customer, onValueChange = { customer = it }, label = { Text("Tên khách hàng") }, singleLine = true)
                OutlinedTextField(value = address, onValueChange = { address = it }, label = { Text("Địa chỉ") })
                OutlinedTextField(value = product, onValueChange = { product = it }, label = { Text("Hàng hóa") })
                OutlinedTextField(value = cod, onValueChange = { cod = it.filter { character -> character.isDigit() } }, label = { Text("COD") }, singleLine = true)
                OutlinedTextField(value = service, onValueChange = { service = it }, label = { Text("Dịch vụ") }, singleLine = true)
                Text("Nếu SĐT đã có tọa độ lưu trong Khách hàng, đơn được gán số cuối tuyến. Nếu chưa có, đơn được đưa lên đầu để bổ sung vị trí.", color = Color(0xFF68727C), fontSize = 11.sp)
            }
        },
        confirmButton = {
            Button(enabled = waybill.isNotBlank(), onClick = {
                onSave(
                    DeliveryOrder(
                        waybill = waybill,
                        customer = customer,
                        phone = phone,
                        address = address,
                        product = product,
                        cod = cod.toLongOrNull() ?: 0L,
                        service = service,
                    ),
                )
            }) { Text("Thêm đơn") }
        },
        dismissButton = { androidx.compose.material3.OutlinedButton(onClick = onDismiss) { Text("Hủy") } },
    )
}

@Composable
private fun GroupedOrderBlock(
    group: List<DeliveryOrder>, selectedWaybill: String?, onSelectOrder: (DeliveryOrder) -> Unit,
    onDelivered: (DeliveryOrder) -> Unit, onCall: (DeliveryOrder) -> Unit, onZalo: (DeliveryOrder) -> Unit,
    onSms: (DeliveryOrder) -> Unit, onOpenCustomer: (DeliveryOrder) -> Unit, onNavigateOrder: (DeliveryOrder) -> Unit,
) {
    val first = group.first()
    Column(Modifier.fillMaxWidth().background(Color(0xFFEAF5F2), RoundedCornerShape(12.dp)).padding(6.dp)) {
        Text("SĐT ${first.phone} · ${group.size} MVĐ · Tổng COD ${group.sumOf { it.cod }.formatVnd()}", color = DetailNavy, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp, modifier = Modifier.padding(6.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            ActionTile("Zalo", Icons.Filled.Message, Color(0xFF086AD8)) { onZalo(first) }
            ActionTile("SMS", Icons.Filled.Sms, DetailNavy) { onSms(first) }
            ActionTile("Gọi", Icons.Filled.Call, DetailNavy) { onCall(first) }
        }
        group.forEach { order -> CompactOrderCard(order, order.waybill == selectedWaybill, { onSelectOrder(order) }, onDelivered, {}, {}, {}, onOpenCustomer, onNavigateOrder, { _, _ -> }, showUtilities = false) }
    }
}

@Composable
private fun CompactOrderCard(
    order: DeliveryOrder,
    selected: Boolean,
    onSelectOrder: () -> Unit,
    onDelivered: (DeliveryOrder) -> Unit,
    onCall: (DeliveryOrder) -> Unit,
    onZalo: (DeliveryOrder) -> Unit,
    onSms: (DeliveryOrder) -> Unit,
    onOpenCustomer: (DeliveryOrder) -> Unit,
    onNavigateOrder: (DeliveryOrder) -> Unit,
    onExpand: (String, String) -> Unit,
    showUtilities: Boolean = true,
) {
    val outcome = order.deliveryOutcome()
    val active = outcome == DeliveryOutcome.ACTIVE || outcome == DeliveryOutcome.PICKUP_AT_WAREHOUSE
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(orderBlockColor(outcome), RoundedCornerShape(12.dp))
            .then(if (selected) Modifier.border(2.dp, DetailNavy, RoundedCornerShape(12.dp)) else Modifier)
            .clickable(onClick = onSelectOrder),
    ) {
        Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 11.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
            if (order.sequence > 0) Text(order.sequence.toString(), color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.background(DetailNavy, RoundedCornerShape(8.dp)).clickable(onClick = { onNavigateOrder(order) }).padding(horizontal = 9.dp, vertical = 7.dp)) else Spacer(Modifier.width(39.dp))
            Spacer(Modifier.width(8.dp))
            Row(modifier = Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(order.waybill, color = orderWaybillColor(outcome), fontWeight = FontWeight.ExtraBold, fontSize = 17.sp, maxLines = 1, modifier = Modifier.weight(1f, fill = false))
                Text(order.detailStatusLabel(), color = orderWaybillColor(outcome), fontWeight = FontWeight.ExtraBold, fontSize = 12.sp, maxLines = 1)
            }
            Spacer(Modifier.width(8.dp))
            Text(order.cod.formatVnd(), color = DetailGreen, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
        }
        DividerLine()
        DetailRow(Icons.Filled.Person, "${order.customer} · ${order.phone}", onClick = { onOpenCustomer(order) })
        DividerLine()
        DetailRow(Icons.Filled.Search, order.address, onClick = { onExpand("Địa chỉ", order.address) })
        DividerLine()
        DetailRow(Icons.Filled.Wallet, order.product, onClick = { onExpand("Hàng hóa", order.product) })
        DividerLine()
        DetailRow(Icons.Filled.Wallet, order.service)
        DividerLine()
        Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 5.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            ActionTile("Đã giao", Icons.Filled.CheckCircle, DetailGreen, enabled = active) { onDelivered(order) }
            if (!active) ActionTile("Đã xử lý", Icons.Filled.CheckCircle, Color(0xFF8A9299), enabled = false) {}
            if (showUtilities) {
                ActionTile("Zalo", Icons.Filled.Message, Color(0xFF086AD8)) { onZalo(order) }
                ActionTile("SMS", Icons.Filled.Sms, DetailNavy) { onSms(order) }
                ActionTile("Gọi", Icons.Filled.Call, DetailNavy) { onCall(order) }
            }
        }
    }
}

private fun orderBlockColor(outcome: DeliveryOutcome): Color = when (outcome) {
    DeliveryOutcome.DELIVERED -> Color(0xFFE8F6EC)
    DeliveryOutcome.TEMPORARY_FAILURE -> Color(0xFFFFF0DE)
    DeliveryOutcome.TERMINAL_FAILURE -> Color(0xFFFCE8E8)
    DeliveryOutcome.PICKUP_AT_WAREHOUSE -> Color(0xFFF2ECFA)
    DeliveryOutcome.ACTIVE -> AppSurface
}

private fun orderWaybillColor(outcome: DeliveryOutcome): Color = when (outcome) {
    DeliveryOutcome.DELIVERED -> DetailGreen
    DeliveryOutcome.TEMPORARY_FAILURE -> Color(0xFFE17E18)
    DeliveryOutcome.TERMINAL_FAILURE -> DetailRed
    DeliveryOutcome.PICKUP_AT_WAREHOUSE -> Color(0xFF6B47A1)
    DeliveryOutcome.ACTIVE -> DetailNavy
}

@Composable private fun DividerLine() = Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0xFFE7EAEE)))

@Composable
private fun DetailRow(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String, onClick: (() -> Unit)? = null) {
    Row(modifier = Modifier.fillMaxWidth().then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier).padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Color(0xFF85909A), modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(12.dp))
        Text(text, color = Color(0xFF3E454C), fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun ActionTile(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, tint: Color, enabled: Boolean = true, onClick: () -> Unit) {
    Column(modifier = Modifier.width(44.dp).then(if (enabled) Modifier.clickable(onClick = onClick) else Modifier).padding(vertical = 2.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, tint = if (enabled) tint else Color(0xFFB8BDC2), modifier = Modifier.size(21.dp))
        Text(label, color = if (enabled) tint else Color(0xFF8A9299), fontSize = 8.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}
