package com.example.delivery.navigation

import android.net.Uri
import kotlinx.coroutines.delay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

data class GeoPoint(val latitude: Double, val longitude: Double)
data class GoongRoute(val points: List<GeoPoint>)

class GoongDirectionsRepository {
    suspend fun directions(origin: GeoPoint, destination: GeoPoint): Result<GoongRoute> = withContext(Dispatchers.IO) {
        val key = GoongApiConfig.restApiKey
        if (key.isBlank()) return@withContext Result.failure(IllegalStateException("Thiếu GOONG_REST_API_KEY"))
        var lastError: Throwable? = null
        repeat(3) { attempt ->
            try {
                return@withContext Result.success(requestDirections(origin, destination, key))
            } catch (error: Throwable) {
                lastError = error
                if (attempt < 2) delay(450L * (attempt + 1))
            }
        }
        Result.failure(lastError ?: IOException("Goong Directions không trả được tuyến đường"))
    }

    private fun requestDirections(origin: GeoPoint, destination: GeoPoint, key: String): GoongRoute {
        val url = Uri.parse(GoongApiConfig.directionsEndpoint).buildUpon()
            .appendQueryParameter("origin", "${origin.latitude},${origin.longitude}")
            .appendQueryParameter("destination", "${destination.latitude},${destination.longitude}")
            .appendQueryParameter("vehicle", "car")
            .appendQueryParameter("api_key", key)
            .build().toString()
        val connection = URL(url).openConnection() as HttpURLConnection
        connection.connectTimeout = 10_000
        connection.readTimeout = 12_000
        connection.requestMethod = "GET"
        return try {
            if (connection.responseCode !in 200..299) throw IOException("Goong Directions HTTP ${connection.responseCode}")
            val body = connection.inputStream.bufferedReader().use { it.readText() }
            val route = JSONObject(body).optJSONArray("routes")?.optJSONObject(0)
            val encoded = route?.optJSONObject("overview_polyline")?.optString("points") ?: route?.optString("overview_polyline")
            val points = encoded?.takeIf { it.isNotBlank() }?.let(::decodePolyline).orEmpty()
            require(points.size >= 2) { "Goong Directions không có overview_polyline" }
            GoongRoute(points)
        } finally {
            connection.disconnect()
        }
    }

    companion object {
        fun decodePolyline(encoded: String): List<GeoPoint> {
            val points = mutableListOf<GeoPoint>()
            var index = 0
            var latitude = 0
            var longitude = 0
            while (index < encoded.length) {
                fun decodeValue(): Int {
                    var shift = 0
                    var result = 0
                    while (index < encoded.length) {
                        val value = encoded[index++].code - 63
                        result = result or ((value and 0x1f) shl shift)
                        shift += 5
                        if (value < 0x20) break
                    }
                    return if ((result and 1) != 0) (result shr 1).inv() else result shr 1
                }
                latitude += decodeValue()
                longitude += decodeValue()
                points += GeoPoint(latitude / 1e5, longitude / 1e5)
            }
            return points
        }
    }
}
