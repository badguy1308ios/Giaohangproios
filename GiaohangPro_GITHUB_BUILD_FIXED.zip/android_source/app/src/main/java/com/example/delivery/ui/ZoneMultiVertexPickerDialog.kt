package com.example.delivery.ui

import com.example.delivery.map.GoongMapStyleLoader
import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Looper
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import org.maplibre.android.MapLibre
import org.maplibre.android.annotations.Icon
import org.maplibre.android.annotations.IconFactory
import org.maplibre.android.annotations.Marker
import org.maplibre.android.annotations.MarkerOptions
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.Style
import java.util.Locale

@Composable
internal fun ZoneMultiVertexPickerDialog(initialPoints: List<CustomerPickerPosition>, onDismiss: () -> Unit, onConfirm: (List<CustomerPickerPosition>) -> Unit) {
    var points by remember(initialPoints) { mutableStateOf(initialPoints) }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize().padding(10.dp), RoundedCornerShape(18.dp), color = AppBackground) {
            Column(Modifier.fillMaxSize()) {
                Column(Modifier.fillMaxWidth().background(Color(0xFFEAF5F2)).padding(14.dp, 10.dp)) {
                    Text("CHỌN CÁC ĐỈNH CỦA ZONE", color = Color(0xFF12385F), fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
                    Text("Chạm bản đồ để thêm đỉnh. Mỗi lần chạm là một điểm; ứng dụng tự hiểu các điểm tạo thành ranh giới Zone.", color = Color(0xFF5F6B75), fontSize = 11.sp)
                }
                ZoneVertexMap(points, { points = it }, Modifier.weight(1f).fillMaxWidth().padding(8.dp))
                Column(Modifier.fillMaxWidth().background(Color(0xFFF4F7F8)).padding(12.dp, 8.dp)) {
                    Text("ĐÃ CHỌN ${points.size} ĐỈNH", color = Color(0xFF12385F), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    if (points.isNotEmpty()) Text(points.mapIndexed { i, p -> "${i + 1}: ${String.format(Locale.US, "%.5f, %.5f", p.latitude, p.longitude)}" }.joinToString("   "), fontSize = 10.sp, maxLines = 2)
                    Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { points = points.dropLast(1) }, enabled = points.isNotEmpty()) { Text("Hoàn tác") }
                        OutlinedButton(onClick = { points = emptyList() }, enabled = points.isNotEmpty()) { Text("Xóa hết") }
                        Button(onClick = { onConfirm(points) }, enabled = points.size >= 3, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF229846))) { Text("Lưu đỉnh") }
                    }
                    OutlinedButton(onClick = onDismiss, Modifier.fillMaxWidth().padding(top = 3.dp)) { Text("Hủy") }
                }
            }
        }
    }
}

@SuppressLint("MissingPermission")
@Composable
private fun ZoneVertexMap(points: List<CustomerPickerPosition>, onPointsChanged: (List<CustomerPickerPosition>) -> Unit, modifier: Modifier) {
    val context = LocalContext.current
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    val view = remember(context) { MapLibre.getInstance(context); MapView(context).also { it.onCreate(null) } }
    var map by remember { mutableStateOf<MapLibreMap?>(null) }
    var markers by remember { mutableStateOf<List<Marker>>(emptyList()) }
    var userLocation by remember { mutableStateOf<Location?>(null) }
    var centeredOnUser by remember { mutableStateOf(false) }
    val latestPoints by rememberUpdatedState(points)

    DisposableEffect(context) {
        val manager = context.getSystemService(LocationManager::class.java)
        val listener = object : LocationListener {
            override fun onLocationChanged(location: Location) {
                if (location.accuracy.isFinite() && location.accuracy <= 100f) userLocation = location
            }
        }
        listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)
            .mapNotNull { provider -> runCatching { manager.getLastKnownLocation(provider) }.getOrNull() }
            .filter { it.accuracy.isFinite() && it.accuracy <= 100f }
            .minWithOrNull(compareBy<Location> { it.accuracy }.thenByDescending { it.time })
            ?.let { userLocation = it }
        listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER).forEach { provider ->
            runCatching { if (manager.isProviderEnabled(provider)) manager.requestLocationUpdates(provider, 3_000L, 10f, listener, Looper.getMainLooper()) }
        }
        onDispose { manager.removeUpdates(listener) }
    }
    LaunchedEffect(map, userLocation) {
        val location = userLocation
        val ready = map
        if (!centeredOnUser && ready != null && location != null && points.isEmpty()) {
            ready.cameraPosition = CameraPosition.Builder().target(LatLng(location.latitude, location.longitude)).zoom(14.5).build()
            centeredOnUser = true
        }
    }
    DisposableEffect(view, lifecycle) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_START -> view.onStart()
                Lifecycle.Event.ON_RESUME -> view.onResume()
                Lifecycle.Event.ON_PAUSE -> view.onPause()
                Lifecycle.Event.ON_STOP -> view.onStop()
                else -> Unit
            }
        }
        lifecycle.addObserver(observer)
        onDispose { lifecycle.removeObserver(observer); view.onDestroy() }
    }
    AndroidView(modifier = modifier, factory = {
        view.apply {
            getMapAsync { ready ->
                map = ready
                ready.setStyle(Style.Builder().fromJson(GoongMapStyleLoader.load(context))) {
                    ready.addOnMapClickListener { point ->
                        onPointsChanged(latestPoints + CustomerPickerPosition(point.latitude, point.longitude))
                        true
                    }
                }
            }
        }
    }, update = {
        val ready = map ?: return@AndroidView
        if (ready.style == null) return@AndroidView
        while (markers.size > points.size) { markers.lastOrNull()?.let(ready::removeMarker); markers = markers.dropLast(1) }
        points.forEachIndexed { index, point ->
            val old = markers.getOrNull(index)
            if (old == null) {
                markers = markers + ready.addMarker(MarkerOptions().position(LatLng(point.latitude, point.longitude)).title("Đỉnh ${index + 1}").icon(pin(context, "${index + 1}")))
            } else {
                old.position = LatLng(point.latitude, point.longitude)
                old.setIcon(pin(context, "${index + 1}"))
                ready.updateMarker(old)
            }
        }
    })
}

private fun pin(context: android.content.Context, text: String): Icon {
    val density = context.resources.displayMetrics.density
    val size = (48 * density).toInt()
    val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    paint.color = 0xFF12385F.toInt()
    canvas.drawCircle(size / 2f, size / 2f, size / 2f - density, paint)
    paint.color = android.graphics.Color.WHITE
    paint.textAlign = Paint.Align.CENTER
    paint.typeface = Typeface.DEFAULT_BOLD
    paint.textSize = 12 * density
    canvas.drawText(text, size / 2f, size / 2f - (paint.ascent() + paint.descent()) / 2f, paint)
    return IconFactory.getInstance(context).fromBitmap(bitmap)
}
