package com.example.delivery.ui

import com.example.delivery.map.GoongMapStyleLoader
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Looper
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.delivery.BuildConfig
import com.example.delivery.model.DeliveryOrder
import com.example.delivery.model.DeliveryOutcome
import com.example.delivery.model.DeliveryStatus
import com.example.delivery.model.deliveryOutcome
import com.example.delivery.model.hasStoredCoordinates
import com.example.delivery.model.isMapVisible
import com.example.delivery.model.isPickupAtWarehouse
import com.example.delivery.model.isRouteActive
import com.example.delivery.model.sequenceText
import com.example.delivery.model.csvStatus
import com.example.delivery.navigation.GeoPoint
import com.example.delivery.navigation.GoongDirectionsRepository
import com.example.delivery.location.RealtimeLocationPolicy
import org.maplibre.android.MapLibre
import org.maplibre.android.annotations.IconFactory
import org.maplibre.android.annotations.MarkerOptions
import org.maplibre.android.annotations.PolylineOptions
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.Style

@Composable
fun GoonOnlyMapScreen(
    orders: List<DeliveryOrder>,
    selectedNavigationOrder: DeliveryOrder?,
    locationGranted: Boolean,
    onLocationChanged: (Double, Double) -> Unit,
    onSelectOrder: (DeliveryOrder) -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var location by remember(context) { mutableStateOf<Location?>(null) }
    var route by remember { mutableStateOf<List<GeoPoint>>(emptyList()) }
    var map by remember { mutableStateOf<MapLibreMap?>(null) }
    var centerOnFirstFix by rememberSaveable { mutableStateOf(true) }
    val mapOrders = orders.filter { it.hasStoredCoordinates() && it.csvStatus() != DeliveryStatus.TT505 }
    val activeOrders = mapOrders.filter { it.isRouteActive() }
    val target = selectedNavigationOrder?.takeIf { it.hasStoredCoordinates() } ?: activeOrders.minByOrNull { it.sequence }
    val latitude = location?.latitude ?: 10.7769
    val longitude = location?.longitude ?: 106.7009
    val directions = remember { GoongDirectionsRepository() }

    if (locationGranted) LocationUpdates(context, location?.time) { freshLocation ->
        location = freshLocation
        onLocationChanged(freshLocation.latitude, freshLocation.longitude)
    }
    LaunchedEffect(target?.waybill, latitude, longitude) {
        if (target == null) {
            route = emptyList()
        } else {
            directions.directions(GeoPoint(latitude, longitude), GeoPoint(target.latitude, target.longitude))
                .onSuccess { route = it.points }
                .onFailure { route = emptyList() }
        }
    }
    LaunchedEffect(map, location?.time) {
        if (centerOnFirstFix) location?.let { fix ->
            map?.animateCamera(CameraUpdateFactory.newLatLngZoom(LatLng(fix.latitude, fix.longitude), 15.5))
            centerOnFirstFix = false
        }
    }
    DisposableEffect(map, mapOrders, onSelectOrder) {
        val readyMap = map ?: return@DisposableEffect onDispose { }
        val listener = MapLibreMap.OnMarkerClickListener { marker ->
            val waybill = marker.snippet ?: return@OnMarkerClickListener false
            val order = mapOrders.firstOrNull { it.waybill == waybill } ?: return@OnMarkerClickListener false
            onSelectOrder(order)
            true
        }
        readyMap.setOnMarkerClickListener(listener)
        onDispose { readyMap.setOnMarkerClickListener(null) }
    }
    LaunchedEffect(map, route, mapOrders, location?.latitude, location?.longitude, location?.time) {
        map?.let { readyMap -> renderOverlays(readyMap, context, location, route, mapOrders, target) }
    }
    Box(modifier = modifier.background(AppBackground)) {
        NativeMapView(latitude, longitude, route, mapOrders, onMapReady = { map = it }, modifier = Modifier.fillMaxSize())
        Column(modifier = Modifier.align(Alignment.CenterStart).padding(start = 12.dp, bottom = 160.dp)) {
            MapButton(Icons.Filled.MyLocation, "Vị trí hiện tại") { map?.animateCamera(CameraUpdateFactory.newLatLngZoom(LatLng(latitude, longitude), 15.5)) }
            MapButton(Icons.Filled.Add, "Phóng to") { map?.animateCamera(CameraUpdateFactory.zoomIn()) }
            MapButton(Icons.Filled.Remove, "Thu nhỏ") { map?.animateCamera(CameraUpdateFactory.zoomOut()) }
        }
    }
}

@Composable
private fun MapButton(icon: androidx.compose.ui.graphics.vector.ImageVector, description: String, action: () -> Unit) {
    Card(shape = RoundedCornerShape(50), colors = CardDefaults.cardColors(containerColor = AppSurface), elevation = CardDefaults.cardElevation(defaultElevation = 0.dp), modifier = Modifier.padding(vertical = 4.dp)) {
        IconButton(onClick = action, modifier = Modifier.size(48.dp)) { Icon(icon, description, tint = Color(0xFF12385F)) }
    }
}

@Composable
private fun NativeMapView(latitude: Double, longitude: Double, route: List<GeoPoint>, orders: List<DeliveryOrder>, onMapReady: (MapLibreMap) -> Unit, modifier: Modifier) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    val mapView = remember(context) { MapLibre.getInstance(context); MapView(context).also { it.onCreate(null) } }
    DisposableEffect(mapView, lifecycle) {
        val observer = LifecycleEventObserver { _, event -> when (event) { Lifecycle.Event.ON_START -> mapView.onStart(); Lifecycle.Event.ON_RESUME -> mapView.onResume(); Lifecycle.Event.ON_PAUSE -> mapView.onPause(); Lifecycle.Event.ON_STOP -> mapView.onStop(); else -> Unit } }
        lifecycle.addObserver(observer)
        onDispose { lifecycle.removeObserver(observer); mapView.onDestroy() }
    }
    AndroidView(modifier = modifier, factory = {
        mapView.apply {
            getMapAsync { map ->
                map.setTileCacheEnabled(true)
                map.setStyle(Style.Builder().fromJson(GoongMapStyleLoader.load(context))) {
                    map.cameraPosition = CameraPosition.Builder().target(LatLng(latitude, longitude)).zoom(14.0).build()
                    onMapReady(map)
                }
            }
        }
    }, update = { view -> view.getMapAsync { map -> if (map.style != null) onMapReady(map) } })
}

private fun renderOverlays(map: MapLibreMap, context: Context, userLocation: Location?, route: List<GeoPoint>, orders: List<DeliveryOrder>, selectedOrder: DeliveryOrder?) {
    map.clear()
    val safeRoute = route.filter { point -> point.latitude.isFinite() && point.longitude.isFinite() && point.latitude in -90.0..90.0 && point.longitude in -180.0..180.0 }
    if (safeRoute.size > 1) map.addPolyline(PolylineOptions().addAll(safeRoute.map { LatLng(it.latitude, it.longitude) }).color(0xFFFF7043.toInt()).width(6f))
    orders.filter(DeliveryOrder::hasStoredCoordinates).filter { it.waybill != selectedOrder?.waybill }.forEach { order ->
        val pickup = order.isPickupAtWarehouse()
        map.addMarker(
            MarkerOptions()
                .position(LatLng(order.latitude, order.longitude))
                .title(if (pickup) "Tới kho lấy" else "Đơn #${order.sequence}")
                .snippet(order.waybill)
                .icon(markerIcon(context, if (pickup) "" else order.sequenceText(), markerColor(order))),
        )
    }
    userLocation?.let { fix ->
        map.addMarker(MarkerOptions().position(LatLng(fix.latitude, fix.longitude)).title("Vị trí hiện tại").icon(markerIcon(context, "GPS", 0xFF12385F.toInt())))
    }
    selectedOrder?.takeIf { it.hasStoredCoordinates() }?.let { order ->
        map.addMarker(
            MarkerOptions()
                .position(LatLng(order.latitude, order.longitude))
                .title("Đang giao • ${order.waybill}")
                .snippet(order.waybill)
                .icon(markerIcon(context, if (order.sequenceText().isNotBlank()) order.sequenceText() else "•", 0xFFE4572E.toInt())),
        )
    }
}

private fun markerColor(order: DeliveryOrder): Int = when {
    order.deliveryOutcome() == DeliveryOutcome.PICKUP_AT_WAREHOUSE -> 0xFF6B47A1.toInt()
    order.deliveryOutcome() == DeliveryOutcome.TEMPORARY_FAILURE -> 0xFFE17E18.toInt()
    order.deliveryOutcome() == DeliveryOutcome.TERMINAL_FAILURE -> 0xFFD83A3A.toInt()
    else -> 0xFF1E73BE.toInt()
}

private fun markerIcon(context: Context, text: String, color: Int): org.maplibre.android.annotations.Icon {
    val density = context.resources.displayMetrics.density; val size = (44 * density).toInt()
    val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888); val canvas = Canvas(bitmap); val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    paint.color = color; canvas.drawCircle(size / 2f, size / 2f, size / 2f - density, paint); paint.color = Color.White.toArgb(); paint.textAlign = Paint.Align.CENTER; paint.typeface = Typeface.DEFAULT_BOLD; paint.textSize = if (text == "GPS") 10 * density else 18 * density
    canvas.drawText(text, size / 2f, size / 2f - (paint.ascent() + paint.descent()) / 2f, paint)
    return IconFactory.getInstance(context).fromBitmap(bitmap)
}

@SuppressLint("MissingPermission")
@Composable
private fun LocationUpdates(context: Context, currentFixTime: Long?, update: (Location) -> Unit) {
    DisposableEffect(context) {
        val manager = context.getSystemService(LocationManager::class.java)
        var newestFixTime = currentFixTime
        var acceptedLocation: Location? = null
        val listener = object : LocationListener {
            override fun onLocationChanged(location: Location) {
                val previous = acceptedLocation
                val accurateEnough = location.accuracy.isFinite() && location.accuracy <= 60f
                val movedEnough = previous == null || previous.distanceTo(location) >= 5f
                val materiallyBetter = previous != null && location.accuracy + 8f < previous.accuracy
                if (accurateEnough && RealtimeLocationPolicy.shouldAccept(newestFixTime, location.time) && (movedEnough || materiallyBetter)) {
                    newestFixTime = location.time
                    acceptedLocation = location
                    update(location)
                }
            }
        }
        val now = System.currentTimeMillis()
        listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)
            .mapNotNull { provider -> runCatching { manager.getLastKnownLocation(provider) }.getOrNull() }
            .filter { RealtimeLocationPolicy.isFreshLastKnown(it.time, now) && it.accuracy.isFinite() && it.accuracy <= 60f }
            .minWithOrNull(compareBy<Location> { it.accuracy }.thenByDescending { it.time })
            ?.let(listener::onLocationChanged)
        listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER).forEach { provider ->
            runCatching {
                if (manager.isProviderEnabled(provider)) {
                    manager.requestLocationUpdates(provider, 1_500L, 1f, listener, Looper.getMainLooper())
                }
            }
        }
        onDispose { manager.removeUpdates(listener) }
    }
}
