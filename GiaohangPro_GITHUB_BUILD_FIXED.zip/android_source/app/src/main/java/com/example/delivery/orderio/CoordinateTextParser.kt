package com.example.delivery.orderio

data class ParsedCoordinates(val latitude: Double, val longitude: Double)


object CoordinateTextParser {
    private val coordinateNumber = Regex("[-+]?\\d+(?:[.,]\\d+)?")

    fun parse(raw: String): ParsedCoordinates? {
        val values = values(raw)
        if (values.size < 2) return null
        val first = values[0]
        val second = values[1]
        return when {
            first in -90.0..90.0 && second in -180.0..180.0 -> ParsedCoordinates(first, second)
            first in -180.0..180.0 && second in -90.0..90.0 -> ParsedCoordinates(second, first)
            else -> null
        }
    }

    
    fun parseLongitudeThenLatitude(raw: String): ParsedCoordinates? {
        val values = values(raw)
        if (values.size < 2) return null
        val longitude = values[0]
        val latitude = values[1]
        return ParsedCoordinates(latitude, longitude).takeIf {
            it.latitude in -90.0..90.0 && it.longitude in -180.0..180.0
        }
    }

    private fun values(raw: String): List<Double> = coordinateNumber.findAll(raw)
        .mapNotNull { match -> match.value.replace(',', '.').toDoubleOrNull() }
        .take(2)
        .toList()
}
