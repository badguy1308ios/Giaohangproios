package com.example.delivery.map

import android.content.Context
import android.util.Log
import org.maplibre.android.MapLibre
import org.maplibre.android.offline.OfflineManager
import java.util.concurrent.atomic.AtomicBoolean


const val MAP_TILE_CACHE_BYTES = 96L * 1024L * 1024L

private val cacheConfigured = AtomicBoolean(false)

fun configureMapTileCache(context: Context) {
    if (!cacheConfigured.compareAndSet(false, true)) return

    val appContext = context.applicationContext
    MapLibre.getInstance(appContext)
    OfflineManager.getInstance(appContext).setMaximumAmbientCacheSize(
        MAP_TILE_CACHE_BYTES,
        object : OfflineManager.FileSourceCallback {
            override fun onSuccess() = Unit

            override fun onError(error: String) {
                Log.w("MapTileCache", "Không thể cập nhật giới hạn cache tile: $error")
            }
        },
    )
}
