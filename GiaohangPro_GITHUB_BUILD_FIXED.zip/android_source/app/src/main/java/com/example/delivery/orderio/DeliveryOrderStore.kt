package com.example.delivery.orderio

import android.content.Context
import com.example.delivery.model.DeliveryFailureReason
import com.example.delivery.model.DeliveryOrder
import com.example.delivery.model.DeliveryStatus
import org.json.JSONArray
import org.json.JSONObject


object DeliveryOrderStore {
    private const val PREFS = "delivery_order_store"
    private const val ORDERS = "orders_v3"
    private const val INITIALIZED = "initialized"

    fun hasBeenInitialized(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getBoolean(INITIALIZED, false)

    fun load(context: Context): List<DeliveryOrder> = runCatching {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val raw = prefs.getString(ORDERS, "[]") ?: "[]"
        val array = JSONArray(raw)
        buildList(array.length()) {
            for (index in 0 until array.length()) {
                val json = array.optJSONObject(index) ?: continue
                val waybill = json.optString("waybill").trim()
                if (waybill.isBlank()) continue
                add(json.toDeliveryOrder())
            }
        }
    }.getOrDefault(emptyList())

    fun replace(context: Context, orders: List<DeliveryOrder>) {
        val array = JSONArray()
        orders.forEach { array.put(it.toJson()) }
        val saved = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(ORDERS, array.toString())
            .putBoolean(INITIALIZED, true)
            .commit()
        check(saved) { "Unable to persist delivery orders." }
    }

    private fun DeliveryOrder.toJson(): JSONObject = JSONObject().apply {
        put("waybill", waybill)
        put("customer", customer)
        put("phone", phone)
        put("address", address)
        put("product", product)
        put("cod", cod)
        put("service", service)
        put("status", status.name)
        put("sequence", sequence)
        put("latitude", latitude)
        put("longitude", longitude)
        put("requiresRedelivery", requiresRedelivery)
        put("wasRedelivered", wasRedelivered)
        put("failureReason", failureReason?.name ?: JSONObject.NULL)
        put("failureCount", failureCount)
        put("delivered", delivered)
        put("sequenceLabel", sequenceLabel ?: JSONObject.NULL)
    }

    private fun JSONObject.toDeliveryOrder(): DeliveryOrder {
        val status = runCatching {
            DeliveryStatus.valueOf(optString("status", DeliveryStatus.TT500.name))
        }.getOrDefault(DeliveryStatus.TT500)
        val failureReason = optString("failureReason", "")
            .takeIf { it.isNotBlank() && it != JSONObject.NULL.toString() }
            ?.let { value -> runCatching { DeliveryFailureReason.valueOf(value) }.getOrNull() }
        val label = optString("sequenceLabel", "")
            .takeIf { it.isNotBlank() && it != JSONObject.NULL.toString() }

        return DeliveryOrder(
            waybill = optString("waybill"),
            customer = optString("customer"),
            phone = optString("phone"),
            address = optString("address"),
            product = optString("product"),
            cod = optLong("cod", 0L),
            service = optString("service"),
            status = status,
            sequence = optInt("sequence", 0),
            latitude = optDouble("latitude", 0.0),
            longitude = optDouble("longitude", 0.0),
            requiresRedelivery = optBoolean("requiresRedelivery", false),
            wasRedelivered = optBoolean("wasRedelivered", false),
            failureReason = failureReason,
            failureCount = optInt("failureCount", 0).coerceAtLeast(0),
            delivered = optBoolean("delivered", false) || status == DeliveryStatus.TT515,
            sequenceLabel = label,
        )
    }
}
