package com.example.delivery.contact


fun zaloPhoneNumber(rawPhone: String): String? {
    val digits = rawPhone.filter(Char::isDigit)
    val international = when {
        digits.startsWith("0084") -> digits.removePrefix("00")
        digits.startsWith("84") -> digits
        digits.startsWith("0") -> "84${digits.drop(1)}"
        else -> digits
    }
    return international.takeIf { it.startsWith("84") && it.length in 11..12 }
}


fun zaloContactPhone(rawPhone: String): String? = zaloPhoneNumber(rawPhone)?.let { "+$it" }
