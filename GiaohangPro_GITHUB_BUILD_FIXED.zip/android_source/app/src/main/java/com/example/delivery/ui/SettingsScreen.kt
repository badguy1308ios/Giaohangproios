package com.example.delivery.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.delivery.history.TransferEvidence
import com.example.delivery.model.DeliveryOrder
import com.example.delivery.orderio.CoordinateUpdateRequest
import com.example.delivery.orderio.CoordinateTextParser

@Composable
fun SettingsScreen(
    evidence: List<TransferEvidence>,
    onConfirmPayment: (String) -> Unit,
    onOpenCashAudit: () -> Unit,
    onOpenBackup: () -> Unit,
    onOpenVtmanExport: () -> Unit,
    onOpenTransferCheck: () -> Unit,
    onOpenOrderManagement: () -> Unit,
    onOpenAnchorPoint: () -> Unit,
    onClose: () -> Unit,
) {
    Column(Modifier.fillMaxSize().background(AppBackground)) {
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(start = 12.dp, top = 8.dp, end = 12.dp, bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onClose) { Icon(Icons.Filled.ArrowBack, "Quay lại", tint = Color(0xFF12385F)) }
            Text("CÀI ĐẶT", color = Color(0xFF12385F), fontWeight = FontWeight.ExtraBold)
        }
        SettingsEntry("IMPORT / EXPORT DỮ LIỆU", "Sao lưu khách hàng hoặc quản lý đơn hàng", onOpenBackup)
        SettingsEntry("VTMAN EXPORT", "Mở công cụ nạp MVĐ, lấy SĐT và xuất CSV từ VTMan", onOpenVtmanExport)
        SettingsEntry("XỬ LÝ ĐƠN", "Thêm đơn hàng, xóa đơn hàng hoặc cập nhật tuyến", onOpenOrderManagement)
        SettingsEntry("TUYẾN GIAO HÀNG", "Quản lý tuyến và các vùng giao hàng", onOpenAnchorPoint)
        SettingsEntry("BẢNG KÊ TIỀN", "Đếm tiền mặt, nhập Bank, Cước và COD", onOpenCashAudit)
        SettingsEntry("CHECK CHUYỂN KHOẢN", null, onOpenTransferCheck)
    }
}

@Composable
fun OrderManagementScreen(
    status: String?,
    onAddManualOrder: (DeliveryOrder) -> Unit,
    onDeleteOrder: (String) -> Unit,
    onDeleteAllOrders: () -> Unit,
    onOpenCoordinateUpdate: () -> Unit,
    onConfirmRouteChange: () -> Unit,
    onClose: () -> Unit,
) {
    var manualOrderEntry by remember { mutableStateOf(false) }
    var deleteEntryOpen by remember { mutableStateOf(false) }
    var deleteWaybill by remember { mutableStateOf("") }
    var deleteConfirmationOpen by remember { mutableStateOf(false) }
    var deleteAllConfirmationOpen by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().background(AppBackground)) {
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(start = 12.dp, top = 8.dp, end = 12.dp, bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onClose) { Icon(Icons.Filled.ArrowBack, "Quay lại Cài đặt", tint = Color(0xFF12385F)) }
            Text("XỬ LÝ ĐƠN", color = Color(0xFF12385F), fontWeight = FontWeight.ExtraBold)
        }
        SettingsEntry("THÊM ĐƠN HÀNG", "Nhập tay mã vận đơn và thông tin người nhận", onClick = { manualOrderEntry = true })
        SettingsEntry("XÓA ĐƠN HÀNG", "Chỉ xóa đơn; hồ sơ và lịch sử khách hàng vẫn được giữ lại", onClick = { deleteEntryOpen = !deleteEntryOpen })
        if (deleteEntryOpen) {
            OutlinedTextField(
                value = deleteWaybill,
                onValueChange = { deleteWaybill = it },
                label = { Text("Mã vận đơn cần xóa") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 5.dp),
            )
            Button(
                enabled = deleteWaybill.isNotBlank(),
                onClick = { deleteConfirmationOpen = true },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC23D35)),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 5.dp),
            ) { Text("Xóa đơn đã nhập") }
        }
        SettingsEntry("XÓA TẤT CẢ ĐƠN HÀNG", "Xóa toàn bộ đơn trong Chi tiết đơn và Bản đồ", onClick = { deleteAllConfirmationOpen = true })
        status?.let { Text(it, color = Color(0xFF59636D), fontSize = 11.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) }
    }
    if (manualOrderEntry) {
        ManualOrderEntryDialog(
            onDismiss = { manualOrderEntry = false },
            onSave = { order -> onAddManualOrder(order); manualOrderEntry = false },
        )
    }
    if (deleteAllConfirmationOpen) {
        AlertDialog(
            onDismissRequest = { deleteAllConfirmationOpen = false },
            title = { Text("Xóa tất cả đơn hàng?") },
            text = { Text("Bạn chắc chắn muốn xoá tất cả các đơn hàng phải không?") },
            confirmButton = {
                Button(
                    onClick = { onDeleteAllOrders(); deleteAllConfirmationOpen = false },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC23D35)),
                ) { Text("Có") }
            },
            dismissButton = { androidx.compose.material3.OutlinedButton(onClick = { deleteAllConfirmationOpen = false }) { Text("Không") } },
        )
    }
    if (deleteConfirmationOpen) {
        AlertDialog(
            onDismissRequest = { deleteConfirmationOpen = false },
            title = { Text("Xóa đơn hàng?") },
            text = { Text("Đơn ${deleteWaybill.trim()} sẽ bị xóa khỏi danh sách. Thông tin và lịch sử khách hàng không bị xóa.") },
            confirmButton = {
                Button(
                    onClick = { onDeleteOrder(deleteWaybill); deleteWaybill = ""; deleteConfirmationOpen = false; deleteEntryOpen = false },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC23D35)),
                ) { Text("Xóa đơn") }
            },
            dismissButton = { androidx.compose.material3.OutlinedButton(onClick = { deleteConfirmationOpen = false }) { Text("Hủy") } },
        )
    }
}

@Composable
private fun SettingsEntry(title: String, subtitle: String?, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 5.dp).background(AppSurface, RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(horizontal = 13.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color(0xFF12385F), fontWeight = FontWeight.Bold, fontSize = 13.sp)
            subtitle?.let { Text(it, color = Color(0xFF59636D), fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp)) }
        }
        Text("›", color = Color(0xFF12385F), fontSize = 25.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun CoordinateUpdateScreen(
    status: String?,
    onSave: (CoordinateUpdateRequest) -> Unit,
    onConfirmRouteChange: () -> Unit,
    onClose: () -> Unit,
) {
    var reference by remember { mutableStateOf("") }
    var pastedCoordinates by remember { mutableStateOf("") }
    var latitude by remember { mutableStateOf("") }
    var longitude by remember { mutableStateOf("") }
    fun applyPastedCoordinates(value: String): Boolean {
        val coordinates = CoordinateTextParser.parse(value) ?: return false
        latitude = coordinates.latitude.toString()
        longitude = coordinates.longitude.toString()
        return true
    }
    val parsedLatitude = latitude.trim().replace(',', '.').toDoubleOrNull()
    val parsedLongitude = longitude.trim().replace(',', '.').toDoubleOrNull()
    val coordinatesValid = parsedLatitude != null && parsedLongitude != null && parsedLatitude in -90.0..90.0 && parsedLongitude in -180.0..180.0
    Column(Modifier.fillMaxSize().background(AppBackground)) {
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(start = 12.dp, top = 8.dp, end = 12.dp, bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onClose) { Icon(Icons.Filled.ArrowBack, "Quay lại Cài đặt", tint = Color(0xFF12385F)) }
            Text("CẬP NHẬT", color = Color(0xFF12385F), fontWeight = FontWeight.ExtraBold)
        }
        Text("Nhập MVĐ hoặc SĐT cùng tọa độ mới; hoặc rà tất cả SĐT đã có tọa độ để đồng bộ và xếp lại tuyến.", color = Color(0xFF59636D), fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
        OutlinedTextField(
            value = reference,
            onValueChange = { reference = it },
            label = { Text("Mã vận đơn hoặc SĐT") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 5.dp),
        )
        OutlinedTextField(
            value = pastedCoordinates,
            onValueChange = { value ->
                pastedCoordinates = value
                applyPastedCoordinates(value)
            },
            label = { Text("Dán cụm tọa độ") },
            placeholder = { Text("10.7769, 106.7009 hoặc 106.7009, 10.7769", fontSize = 11.sp) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 5.dp),
        )
        Text("Có thể dán theo thứ tự vĩ độ, kinh độ hoặc kinh độ, vĩ độ. Hai ô bên dưới vẫn nhập tay được.", color = Color(0xFF59636D), fontSize = 10.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 1.dp))
        OutlinedTextField(
            value = latitude,
            onValueChange = { value -> if (!applyPastedCoordinates(value)) latitude = value },
            label = { Text("Vĩ độ (Latitude)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 5.dp),
        )
        OutlinedTextField(
            value = longitude,
            onValueChange = { value -> if (!applyPastedCoordinates(value)) longitude = value },
            label = { Text("Kinh độ (Longitude)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 5.dp),
        )
        Button(
            enabled = reference.isNotBlank() && coordinatesValid,
            onClick = { onSave(CoordinateUpdateRequest(reference, parsedLatitude!!, parsedLongitude!!)) },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
        ) { Text("Lưu tọa độ, giữ nguyên STT") }
        if (!coordinatesValid && (latitude.isNotBlank() || longitude.isNotBlank())) {
            Text("Vĩ độ phải từ -90 đến 90, kinh độ từ -180 đến 180.", color = Color(0xFFC23D35), fontSize = 11.sp, modifier = Modifier.padding(horizontal = 16.dp))
        }
        status?.let { Text(it, color = Color(0xFF59636D), fontSize = 11.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) }
    }
}

@Composable
fun BackupDataScreen(
    onExportBackup: () -> Unit,
    onImportBackup: () -> Unit,
    onImportOrders: () -> Unit,
    onExportOrders: () -> Unit,
    onExportStt: () -> Unit,
    onImportStt: () -> Unit,
    backupStatus: String?,
    onClose: () -> Unit,
) {
    var importConfirmationOpen by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().background(AppBackground)) {
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(start = 12.dp, top = 8.dp, end = 12.dp, bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onClose) { Icon(Icons.Filled.ArrowBack, "Quay lại Cài đặt", tint = Color(0xFF12385F)) }
            Text("IMPORT / EXPORT DỮ LIỆU", color = Color(0xFF12385F), fontWeight = FontWeight.ExtraBold)
        }
        Button(onClick = onExportBackup, modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 7.dp)) { Text("Xuất Dữ Liệu Khách Hàng") }
        Button(onClick = { importConfirmationOpen = true }, modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 7.dp)) { Text("Nhập Dữ Liệu Khách Hàng") }
        Button(onClick = onImportOrders, modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 7.dp)) { Text("Nhập Đơn Hàng") }
        Button(onClick = onExportOrders, modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 7.dp)) { Text("Xuất Đơn Hàng") }
        Button(onClick = onExportStt, modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 7.dp)) { Text("Lưu STT") }
        Button(onClick = onImportStt, modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 7.dp)) { Text("Khôi phục STT") }
        backupStatus?.let { Text(it, modifier = Modifier.padding(horizontal = 16.dp, vertical = 5.dp), color = Color(0xFF59636D), fontSize = 11.sp) }
    }
    if (importConfirmationOpen) {
        AlertDialog(
            onDismissRequest = { importConfirmationOpen = false },
            title = { Text("Nhập dữ liệu khách hàng?") },
            text = { Text("Dữ liệu khách hàng và lịch sử hiện có sẽ được thay bằng dữ liệu trong file ZIP.") },
            confirmButton = { Button(onClick = { importConfirmationOpen = false; onImportBackup() }) { Text("Chọn ZIP") } },
            dismissButton = { Button(onClick = { importConfirmationOpen = false }) { Text("Hủy") } },
        )
    }
}

@Composable
fun TransferCheckScreen(onClose: () -> Unit) {
    Column(Modifier.fillMaxSize().background(AppBackground)) {
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(start = 12.dp, top = 8.dp, end = 12.dp, bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onClose) { Icon(Icons.Filled.ArrowBack, "Quay lại Cài đặt", tint = Color(0xFF12385F)) }
            Text("CHECK CHUYỂN KHOẢN", color = Color(0xFF12385F), fontWeight = FontWeight.ExtraBold)
        }
    }
}
