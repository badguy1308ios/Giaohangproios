package com.example.delivery.ui

import androidx.compose.ui.graphics.Color


internal val AppBackground = Color(0xFFE7EDF1)
internal val AppSurface = Color(0xFFF0F3F5)
internal val AppSurfaceMuted = Color(0xFFE8EEF2)
