package com.example.delivery.cash

import java.text.NumberFormat
import java.util.Locale
import kotlin.math.abs

enum class CashAuditStatus { SURPLUS, DEFICIT, BALANCED }

data class CashAuditResult(
    val cashTotal: Long,
    val difference: Long,
    val status: CashAuditStatus,
)

object CashAuditCalculator {
    val denominations = listOf(500_000L, 200_000L, 100_000L, 50_000L)

    fun cashTotal(counts: Map<Long, Int>): Long = denominations.sumOf { denomination ->
        denomination * (counts[denomination] ?: 0).coerceAtLeast(0).toLong()
    }

    
    fun calculate(counts: Map<Long, Int>, cod: Long, fee: Long, bank: Long): CashAuditResult {
        val cash = cashTotal(counts)
        val difference = (cash + bank.coerceAtLeast(0)) - (fee.coerceAtLeast(0) + cod.coerceAtLeast(0))
        val status = when {
            difference > 0 -> CashAuditStatus.SURPLUS
            difference < 0 -> CashAuditStatus.DEFICIT
            else -> CashAuditStatus.BALANCED
        }
        return CashAuditResult(cashTotal = cash, difference = difference, status = status)
    }

    fun parseAmount(raw: String): Long = raw.filter(Char::isDigit).toLongOrNull() ?: 0L

    fun formatAmount(amount: Long): String = NumberFormat.getIntegerInstance(Locale.US).format(abs(amount))
}
