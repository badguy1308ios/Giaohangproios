package com.example.delivery

import android.app.Application
import com.example.delivery.debug.CrashDiagnostic
import com.example.delivery.map.configureMapTileCache

class DeliveryApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        val systemHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            CrashDiagnostic.record(this, thread, error)
            systemHandler?.uncaughtException(thread, error)
        }
        configureMapTileCache(this)
    }
}
