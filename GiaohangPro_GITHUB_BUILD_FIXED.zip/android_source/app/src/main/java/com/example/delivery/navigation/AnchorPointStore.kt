package com.example.delivery.navigation

import android.content.Context


object AnchorPointStore {
    private const val PREFERENCES = "delivery_route_preferences"
    private const val KEY_LATITUDE = "anchor_latitude"
    private const val KEY_LONGITUDE = "anchor_longitude"

    fun load(context: Context): GeoPoint? {
        val preferences = context.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE)
        val latitude = preferences.getString(KEY_LATITUDE, null)?.toDoubleOrNull()
        val longitude = preferences.getString(KEY_LONGITUDE, null)?.toDoubleOrNull()
        return if (latitude.isValidLatitude() && longitude.isValidLongitude()) {
            GeoPoint(latitude!!, longitude!!)
        } else {
            null
        }
    }

    
    fun save(context: Context, point: GeoPoint) {
        require(point.latitude.isValidLatitude()) { "Vĩ độ điểm Neo không hợp lệ." }
        require(point.longitude.isValidLongitude()) { "Kinh độ điểm Neo không hợp lệ." }
        val saved = context.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE).edit()
            .putString(KEY_LATITUDE, point.latitude.toString())
            .putString(KEY_LONGITUDE, point.longitude.toString())
            .commit()
        check(saved) { "Không thể lưu điểm Neo." }
    }

    private fun Double?.isValidLatitude(): Boolean = this != null && isFinite() && this in -90.0..90.0
    private fun Double?.isValidLongitude(): Boolean = this != null && isFinite() && this in -180.0..180.0
}
