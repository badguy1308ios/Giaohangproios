GIAO HANG - GOONG ALPHA: RELEASE KEYSTORE BACKUP

This source package intentionally includes the signing key requested by the owner.
Keep the entire source/ folder private and back it up before changing computers.

Keystore path: signing/giaohang-goong-alpha-release.jks
Alias: giaohang_alpha
Store password: GoongAlpha2026Key
Key password: GoongAlpha2026Key

The release build reads release-signing.properties automatically. Never replace this keystore if future APKs need to update this signing identity.
