# GiaohangPro - GitHub build package

This package is intentionally structured so the Android project is at `android_source/`, matching the path used by the GitHub Actions build log.

The workflow builds `:app:assembleDebug` with Java 17 and uploads the APK as the `GiaohangPro-debug-apk` artifact.

The Android source includes the complete `customer`, `orderio`, `model`, `navigation`, and `ui` packages. The Gradle file does not require a signing keystore for a debug build, and the Compose compiler is configured through the Kotlin Compose plugin rather than an incompatible legacy `composeOptions` version.
